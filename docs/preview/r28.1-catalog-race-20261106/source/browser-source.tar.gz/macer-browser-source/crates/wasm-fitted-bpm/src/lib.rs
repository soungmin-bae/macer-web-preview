mod fere;
use wasm_bindgen::prelude::*;

/// Periodic fitted bond-polarizability response, using the existing frozen
/// RamanDB coefficient bundle. Model arithmetic executes in Rust/WASM.
#[wasm_bindgen]
pub struct FittedBpmSession {
    model: Option<fere::FittedBpmModel>,
}

#[wasm_bindgen]
impl FittedBpmSession {
    #[wasm_bindgen(constructor)]
    pub fn new(bundle_json: &str) -> Result<FittedBpmSession, JsValue> {
        let model = fere::FittedBpmModel::from_bundle_json(bundle_json)
            .map_err(|error| JsValue::from_str(&error))?;
        Ok(Self { model: Some(model) })
    }

    pub fn identity_json(&self) -> Result<String, JsValue> {
        let model = self
            .model
            .as_ref()
            .ok_or_else(|| JsValue::from_str("Fitted BPM session is disposed."))?;
        serde_json::to_string(model.identity())
            .map_err(|error| JsValue::from_str(&error.to_string()))
    }

    pub fn predict_json(&self, request_json: &str) -> Result<String, JsValue> {
        let model = self
            .model
            .as_ref()
            .ok_or_else(|| JsValue::from_str("Fitted BPM session is disposed."))?;
        let request: fere::FittedBpmRequest = serde_json::from_str(request_json)
            .map_err(|error| JsValue::from_str(&format!("Invalid fitted BPM request: {error}")))?;
        let output = model
            .predict(&request)
            .map_err(|error| JsValue::from_str(&error))?;
        serde_json::to_string(&output).map_err(|error| JsValue::from_str(&error.to_string()))
    }

    pub fn dispose(&mut self) {
        self.model = None;
    }
}
