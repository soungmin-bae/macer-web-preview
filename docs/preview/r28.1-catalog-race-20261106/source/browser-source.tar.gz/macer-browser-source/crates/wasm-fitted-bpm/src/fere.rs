//! F64 periodic fitted bond-polarizability response, ported from raman-fere-core.js.
//! Coordinates/radii are Angstrom, masses are amu; activities retain the fitted
//! model's relative units. This is not an absolute experimental cross section.
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::collections::{BTreeMap, BTreeSet};

type V3 = [f64; 3];
type C6 = [f64; 6];
const CM_PER_THZ: f64 = 33.35640951981521;
const MAX_CANDIDATES: u64 = 2_000_000;
const MAX_BONDS: usize = 100_000;

#[derive(Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
struct ElementCorrection {
    atomic_number: u16,
    coefficients: C6,
}
#[derive(Clone, Deserialize)]
struct PairCorrection {
    elements: [String; 2],
    coefficients: C6,
}
#[derive(Clone, Deserialize)]
struct Coefficients {
    global: C6,
    elements: Vec<ElementCorrection>,
    #[serde(default)]
    pairs: Vec<PairCorrection>,
}

#[derive(Clone)]
pub struct FittedBpmModel {
    global: C6,
    elements: BTreeMap<u16, C6>,
    pairs: BTreeMap<String, C6>,
    identity: Value,
    candidate_id: String,
}

#[derive(Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct FittedBpmAtom {
    pub element: String,
    #[serde(alias = "z")]
    pub atomic_number: u16,
    pub mass: f64,
    #[serde(alias = "radius")]
    pub covalent_radius_angstrom: f64,
    pub fractional: V3,
}
#[derive(Clone, Deserialize)]
pub struct FittedBpmGeometry {
    pub lattice: [V3; 3],
    pub atoms: Vec<FittedBpmAtom>,
}
#[derive(Clone, Deserialize)]
pub struct FittedBpmMode {
    #[serde(rename = "frequencyTHz")]
    pub frequency_thz: f64,
    pub eigenvector: Vec<[[f64; 2]; 3]>,
}
#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct FittedBpmRequest {
    pub data: FittedBpmGeometry,
    pub bands: Vec<FittedBpmMode>,
    #[serde(default)]
    pub start_index: usize,
    #[serde(default)]
    pub q: V3,
    #[serde(default)]
    pub directional_nac: bool,
}
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct FittedBpmDiagnostics {
    pub periodic_bond_count: usize,
    pub periodic_image_candidates: u64,
    pub fitted_atomic_numbers: Vec<u16>,
    pub global_only_atomic_numbers: Vec<u16>,
    pub fitted_bond_endpoint_fraction: f64,
    pub fitted_pair_bond_fraction: f64,
    pub matched_pair_labels: Vec<String>,
    pub unmatched_bond_pair_labels: Vec<String>,
    pub bond_stage: &'static str,
}
struct Bond {
    i: usize,
    j: usize,
    shift: V3,
    scale: f64,
    coefficients: C6,
}
struct Prepared {
    atoms: Vec<FittedBpmAtom>,
    positions: Vec<V3>,
    bonds: Vec<Bond>,
    volume: f64,
    diagnostics: FittedBpmDiagnostics,
}

fn finite(v: &V3) -> bool {
    v.iter().all(|x| x.is_finite())
}
fn dot(a: V3, b: V3) -> f64 {
    a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
}
fn cross(a: V3, b: V3) -> V3 {
    [
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    ]
}
fn norm(v: V3) -> f64 {
    v[0].hypot(v[1]).hypot(v[2])
}
fn cartesian(v: V3, cell: &[V3; 3]) -> V3 {
    std::array::from_fn(|k| v[0] * cell[0][k] + v[1] * cell[1][k] + v[2] * cell[2][k])
}
fn pair_key(a: &str, b: &str) -> String {
    if a <= b {
        format!("{a}-{b}")
    } else {
        format!("{b}-{a}")
    }
}
pub fn fitted_bpm_switch(x: f64) -> (f64, f64) {
    if x <= 1.15 {
        return (1., 0.);
    }
    if x >= 1.35 {
        return (0., 0.);
    }
    let t = (x - 1.15) / 0.2;
    (
        1. - 10. * t.powi(3) + 15. * t.powi(4) - 6. * t.powi(5),
        (-30. * t * t + 60. * t.powi(3) - 30. * t.powi(4)) / 0.2,
    )
}
pub fn fitted_bpm_activity(real: &[f64; 9], imag: &[f64; 9]) -> f64 {
    let square = |a: usize| real[a] * real[a] + imag[a] * imag[a];
    let diff = |a: usize, b: usize| (real[a] - real[b]).powi(2) + (imag[a] - imag[b]).powi(2);
    let mr = (real[0] + real[4] + real[8]) / 3.;
    let mi = (imag[0] + imag[4] + imag[8]) / 3.;
    let anisotropy =
        0.5 * (diff(0, 4) + diff(4, 8) + diff(8, 0) + 6. * (square(1) + square(2) + square(5)));
    45. * (mr * mr + mi * mi) + 7. * anisotropy
}

impl FittedBpmModel {
    pub fn from_bundle_json(text: &str) -> Result<Self, String> {
        let bundle: Value =
            serde_json::from_str(text).map_err(|e| format!("Invalid fitted BPM bundle: {e}"))?;
        if bundle["schema"] != "macer-fere-raman-browser-bundle-v1"
            || bundle["qualification"] != "PASS_APPROXIMATE_RAMAN_PREVIEW_V1"
        {
            return Err("Unsupported fitted BPM bundle schema or qualification.".into());
        }
        let model: Coefficients = serde_json::from_value(bundle["candidate"]["model"].clone())
            .map_err(|e| format!("Invalid fitted BPM coefficients: {e}"))?;
        if !model.global.iter().all(|x| x.is_finite()) {
            return Err("Nonfinite fitted BPM global coefficients.".into());
        }
        let mut elements = BTreeMap::new();
        for row in model.elements {
            if row.atomic_number == 0
                || !row.coefficients.iter().all(|x| x.is_finite())
                || elements
                    .insert(row.atomic_number, row.coefficients)
                    .is_some()
            {
                return Err("Invalid or duplicate fitted BPM element correction.".into());
            }
        }
        let mut pairs = BTreeMap::new();
        for row in model.pairs {
            if row.elements.iter().any(|x| x.is_empty())
                || !row.coefficients.iter().all(|x| x.is_finite())
                || pairs
                    .insert(
                        pair_key(&row.elements[0], &row.elements[1]),
                        row.coefficients,
                    )
                    .is_some()
            {
                return Err("Invalid or duplicate fitted BPM pair correction.".into());
            }
        }
        let candidate_id = bundle["candidateId"]
            .as_str()
            .filter(|x| !x.is_empty())
            .ok_or("Missing fitted BPM candidate identity.")?
            .to_string();
        let identity = json!({"id":"fere","label":"Fitted BPM · RamanDB","kernel":"fere-periodic-bond-analytic-rust-f64-v1","candidateId":candidate_id,"candidateSHA256":bundle["candidateSHA256"],"qualification":bundle["qualification"],"runtime":"rust-wasm-f64"});
        Ok(Self {
            global: model.global,
            elements,
            pairs,
            identity,
            candidate_id,
        })
    }
    pub fn identity(&self) -> &Value {
        &self.identity
    }
    fn prepare(&self, geometry: &FittedBpmGeometry) -> Result<Prepared, String> {
        let cell = &geometry.lattice;
        if !cell.iter().all(finite) || geometry.atoms.is_empty() {
            return Err("Fitted BPM requires a finite periodic cell and atoms.".into());
        }
        let det = dot(cell[0], cross(cell[1], cell[2]));
        let volume = det.abs();
        if !volume.is_finite() || volume < 1e-10 {
            return Err("Fitted BPM cell is singular.".into());
        }
        for atom in &geometry.atoms {
            if atom.element.is_empty()
                || atom.atomic_number == 0
                || !finite(&atom.fractional)
                || !atom.mass.is_finite()
                || atom.mass <= 0.
                || !atom.covalent_radius_angstrom.is_finite()
                || atom.covalent_radius_angstrom <= 0.
            {
                return Err("Fitted BPM requires finite coordinates, positive masses and covalent radii, and element identities.".into());
            }
        }
        let reciprocal = [
            cross(cell[1], cell[2]),
            cross(cell[2], cell[0]),
            cross(cell[0], cell[1]),
        ]
        .map(|v| v.map(|x| x / det));
        let positions: Vec<V3> = geometry
            .atoms
            .iter()
            .map(|a| cartesian(a.fractional, cell))
            .collect();
        if !positions.iter().all(finite) {
            return Err("Fitted BPM Cartesian positions are nonfinite.".into());
        }
        let mut bonds = Vec::new();
        let mut candidates = 0u64;
        let mut covered = 0usize;
        let mut pair_covered = 0usize;
        let mut encountered = BTreeSet::new();
        for i in 0..geometry.atoms.len() {
            for j in i..geometry.atoms.len() {
                let ai = &geometry.atoms[i];
                let aj = &geometry.atoms[j];
                let scale = ai.covalent_radius_angstrom + aj.covalent_radius_angstrom;
                let df: V3 = std::array::from_fn(|k| aj.fractional[k] - ai.fractional[k]);
                let mut bounds = [(0i64, 0i64); 3];
                let mut count = 1u64;
                for k in 0..3 {
                    let h = 1.35 * scale * norm(reciprocal[k]);
                    let lo = (-df[k] - h - 1e-10).ceil();
                    let hi = (-df[k] + h + 1e-10).floor();
                    if !lo.is_finite() || !hi.is_finite() || lo.abs() > 1e12 || hi.abs() > 1e12 {
                        return Err("Fitted BPM image bounds exceed numerical range.".into());
                    }
                    bounds[k] = (lo as i64, hi as i64);
                    let width = (hi - lo + 1.).max(0.);
                    if width > MAX_CANDIDATES as f64 {
                        return Err("Fitted BPM periodic-image budget exceeded.".into());
                    }
                    count = count
                        .checked_mul(width as u64)
                        .ok_or("Fitted BPM periodic-image count overflow.")?;
                }
                candidates = candidates
                    .checked_add(count)
                    .ok_or("Fitted BPM periodic-image count overflow.")?;
                if candidates > MAX_CANDIDATES {
                    return Err("Fitted BPM periodic-image budget exceeded. No cell or atom reduction was applied.".into());
                }
                for x in bounds[0].0..=bounds[0].1 {
                    for y in bounds[1].0..=bounds[1].1 {
                        for z in bounds[2].0..=bounds[2].1 {
                            if i == j && !(x > 0 || x == 0 && (y > 0 || y == 0 && z > 0)) {
                                continue;
                            }
                            let shift = cartesian([x as f64, y as f64, z as f64], cell);
                            let v: V3 = std::array::from_fn(|k| {
                                positions[j][k] + shift[k] - positions[i][k]
                            });
                            let radius = norm(v);
                            if radius < 1e-8 {
                                return Err("Coincident periodic atoms in fitted BPM input.".into());
                            }
                            if radius / scale >= 1.35 - 1e-12 {
                                continue;
                            }
                            let key = pair_key(&ai.element, &aj.element);
                            let ei = self.elements.get(&ai.atomic_number);
                            let ej = self.elements.get(&aj.atomic_number);
                            let pair = self.pairs.get(&key);
                            let coefficients = std::array::from_fn(|k| {
                                self.global[k]
                                    + 0.5 * (ei.map_or(0., |v| v[k]) + ej.map_or(0., |v| v[k]))
                                    + pair.map_or(0., |v| v[k])
                            });
                            bonds.push(Bond {
                                i,
                                j,
                                shift,
                                scale,
                                coefficients,
                            });
                            covered += usize::from(ei.is_some()) + usize::from(ej.is_some());
                            pair_covered += usize::from(pair.is_some());
                            encountered.insert(key);
                            if bonds.len() > MAX_BONDS {
                                return Err(
                                    "Fitted BPM bond budget exceeded. Structure was not reduced."
                                        .into(),
                                );
                            }
                        }
                    }
                }
            }
        }
        if bonds.is_empty() {
            return Err("No periodic bonds fall inside the fitted BPM cutoff.".into());
        }
        let fitted: BTreeSet<_> = geometry
            .atoms
            .iter()
            .filter(|a| self.elements.contains_key(&a.atomic_number))
            .map(|a| a.atomic_number)
            .collect();
        let global_only: BTreeSet<_> = geometry
            .atoms
            .iter()
            .filter(|a| !self.elements.contains_key(&a.atomic_number))
            .map(|a| a.atomic_number)
            .collect();
        let diagnostics = FittedBpmDiagnostics {
            periodic_bond_count: bonds.len(),
            periodic_image_candidates: candidates,
            fitted_atomic_numbers: fitted.into_iter().collect(),
            global_only_atomic_numbers: global_only.into_iter().collect(),
            fitted_bond_endpoint_fraction: covered as f64 / (2 * bonds.len()) as f64,
            fitted_pair_bond_fraction: pair_covered as f64 / bonds.len() as f64,
            matched_pair_labels: encountered
                .iter()
                .filter(|k| self.pairs.contains_key(*k))
                .cloned()
                .collect(),
            unmatched_bond_pair_labels: encountered
                .iter()
                .filter(|k| !self.pairs.contains_key(*k))
                .cloned()
                .collect(),
            bond_stage: if pair_covered > 0 {
                "global+element+pair-residual"
            } else {
                "global+element"
            },
        };
        Ok(Prepared {
            atoms: geometry.atoms.clone(),
            positions,
            bonds,
            volume,
            diagnostics,
        })
    }
    pub fn predict(&self, request: &FittedBpmRequest) -> Result<Value, String> {
        if !finite(&request.q)
            || request.q.iter().any(|x| x.abs() > 1e-10)
            || request.directional_nac
        {
            return Err("Fitted BPM requires analytic Gamma modes without directional NAC.".into());
        }
        if request.bands.len() != 3 * request.data.atoms.len()
            || request.start_index > request.bands.len()
        {
            return Err("Invalid fitted BPM Gamma mode count or resume index.".into());
        }
        let prepared = self.prepare(&request.data)?;
        let mut modes = Vec::with_capacity(request.bands.len() - request.start_index);
        for (index, band) in request.bands.iter().enumerate().skip(request.start_index) {
            if !band.frequency_thz.is_finite()
                || band.eigenvector.len() != prepared.atoms.len()
                || band
                    .eigenvector
                    .iter()
                    .flatten()
                    .flatten()
                    .any(|x| !x.is_finite())
            {
                return Err("Invalid complete complex Gamma eigenvector.".into());
            }
            let norm2: f64 = band
                .eigenvector
                .iter()
                .flatten()
                .flatten()
                .map(|x| x * x)
                .sum();
            if (norm2 - 1.).abs() > 1e-6 {
                return Err(format!(
                    "Gamma eigenvectors must be normalized; received {norm2}."
                ));
            }
            let real: Vec<V3> = band
                .eigenvector
                .iter()
                .zip(&prepared.atoms)
                .map(|(e, a)| std::array::from_fn(|k| e[k][0] / a.mass.sqrt()))
                .collect();
            let imag: Vec<V3> = band
                .eigenvector
                .iter()
                .zip(&prepared.atoms)
                .map(|(e, a)| std::array::from_fn(|k| e[k][1] / a.mass.sqrt()))
                .collect();
            let tr = prepared.derivative(&real);
            let ti = prepared.derivative(&imag);
            let activity = fitted_bpm_activity(&tr, &ti);
            if tr.iter().chain(ti.iter()).any(|x| !x.is_finite()) || !activity.is_finite() {
                return Err("Fitted BPM produced a nonfinite tensor or activity.".into());
            }
            modes.push(json!({"modeIndex":index,"frequencyTHz":band.frequency_thz,"frequencyCm":band.frequency_thz*CM_PER_THZ,"tensorReal":tr,"tensorImag":ti,"activity":activity,"activityPerVolume":activity/prepared.volume,"status":if band.frequency_thz<0. {"Imaginary"}else if band.frequency_thz<0.1 {"Near zero"}else{"Optical-frequency"},"responseKind":"fere-dft-fitted-bond-polarizability","candidateId":self.candidate_id}));
        }
        Ok(
            json!({"schema":"macer-fitted-bpm-response-v1","model":self.identity,"diagnostics":prepared.diagnostics,"modes":modes}),
        )
    }
}
impl Prepared {
    fn derivative(&self, displacement: &[V3]) -> [f64; 9] {
        let mut out = [0.; 9];
        for b in &self.bonds {
            let v: V3 = std::array::from_fn(|k| {
                self.positions[b.j][k] + b.shift[k] - self.positions[b.i][k]
            });
            let r = norm(v);
            let x = r / b.scale;
            if x >= 1.35 {
                continue;
            }
            let n = v.map(|v| v / r);
            let dv: V3 = std::array::from_fn(|k| displacement[b.j][k] - displacement[b.i][k]);
            let dr = dot(n, dv);
            let dx = dr / b.scale;
            let dn: V3 = std::array::from_fn(|k| (dv[k] - n[k] * dr) / r);
            let (w, dw) = fitted_bpm_switch(x);
            let mut da = 0.;
            let mut db = 0.;
            let mut anisotropic = 0.;
            for p in 0..3 {
                let power = (p + 1) as i32;
                da += b.coefficients[p]
                    * (dw * x.powi(power) + w * power as f64 * x.powi(power - 1))
                    * dx;
                let xp = if p == 0 { 1. } else { x.powi(p as i32) };
                let dxp = if p == 0 {
                    0.
                } else {
                    p as f64 * x.powi(p as i32 - 1)
                };
                db += b.coefficients[3 + p] * (dw * xp + w * dxp) * dx;
                anisotropic += b.coefficients[3 + p] * w * xp;
            }
            for a in 0..3 {
                for c in 0..3 {
                    let identity = if a == c { 1. } else { 0. };
                    let q = n[a] * n[c] - identity / 3.;
                    let dq = dn[a] * n[c] + n[a] * dn[c];
                    out[a * 3 + c] += da * identity + db * q + anisotropic * dq;
                }
            }
        }
        out
    }
}
