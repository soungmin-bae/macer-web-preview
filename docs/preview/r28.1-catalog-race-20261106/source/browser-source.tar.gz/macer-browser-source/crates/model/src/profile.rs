//! Opt-in evaluator profiling. The report is deliberately separate from
//! scientific E/F/stress results and stays inert unless explicitly enabled.

use serde::Serialize;
use std::collections::BTreeMap;
use std::sync::atomic::{AtomicU8, Ordering};
use std::sync::Mutex;

#[cfg(target_arch = "wasm32")]
#[wasm_bindgen::prelude::wasm_bindgen(
    inline_js = "export function monotonic_ms() { return globalThis.performance.now(); }"
)]
extern "C" {
    #[wasm_bindgen::prelude::wasm_bindgen(js_name = monotonic_ms)]
    fn browser_monotonic_ms() -> f64;
}

#[derive(Clone, Debug, Serialize)]
pub struct ProfileReport {
    pub mode: String,
    pub atoms: usize,
    pub edges: usize,
    pub triples: usize,
    pub events: BTreeMap<String, ProfileEvent>,
    pub counters: BTreeMap<String, u64>,
    #[cfg(feature = "heap-profile")]
    pub heap_events: BTreeMap<String, crate::heap_profile::HeapSnapshot>,
}

impl Default for ProfileReport {
    fn default() -> Self {
        Self {
            mode: "off".into(),
            atoms: 0,
            edges: 0,
            triples: 0,
            events: BTreeMap::new(),
            counters: BTreeMap::new(),
            #[cfg(feature = "heap-profile")]
            heap_events: BTreeMap::new(),
        }
    }
}

#[derive(Clone, Debug, Default, Serialize)]
pub struct ProfileEvent {
    pub calls: u64,
    pub total_ms: f64,
}

#[derive(Default)]
pub struct ProfileCollector {
    mode: AtomicU8,
    report: Mutex<ProfileReport>,
}

impl ProfileCollector {
    pub fn set_mode(&self, mode: &str) -> Result<(), String> {
        let level = match mode {
            "off" => 0,
            "summary" => 1,
            "detailed" => 2,
            _ => return Err("profile must be off, summary, or detailed".into()),
        };
        let mut report = self.report.lock().map_err(|e| e.to_string())?;
        *report = ProfileReport {
            mode: mode.to_owned(),
            ..ProfileReport::default()
        };
        self.mode.store(level, Ordering::Relaxed);
        Ok(())
    }

    pub fn level(&self) -> u8 {
        self.mode.load(Ordering::Relaxed)
    }

    pub fn start(&self, minimum_level: u8) -> Option<f64> {
        (self.level() >= minimum_level).then(monotonic_ms)
    }

    pub fn record_since(&self, name: &str, started: Option<f64>) {
        let Some(started) = started else { return };
        self.record_ms(name, monotonic_ms() - started);
        #[cfg(feature = "heap-profile")]
        {
            let memory = crate::heap_profile::snapshot();
            if let Ok(mut report) = self.report.lock() {
                report.heap_events.insert(name.to_owned(), memory);
            }
        }
    }

    pub fn record_ms(&self, name: &str, elapsed_ms: f64) {
        if self.level() == 0 || !elapsed_ms.is_finite() || elapsed_ms < 0.0 {
            return;
        }
        if let Ok(mut report) = self.report.lock() {
            let event = report.events.entry(name.to_owned()).or_default();
            event.calls += 1;
            event.total_ms += elapsed_ms;
        }
    }

    pub fn record_aggregate_ms(&self, name: &str, elapsed_ms: f64, calls: u64) {
        if self.level() == 0 || calls == 0 || !elapsed_ms.is_finite() || elapsed_ms < 0.0 {
            return;
        }
        if let Ok(mut report) = self.report.lock() {
            let event = report.events.entry(name.to_owned()).or_default();
            event.calls += calls;
            event.total_ms += elapsed_ms;
        }
    }

    pub fn set_graph(&self, atoms: usize, edges: usize, triples: usize) {
        if self.level() == 0 {
            return;
        }
        if let Ok(mut report) = self.report.lock() {
            report.atoms = atoms;
            report.edges = edges;
            report.triples = triples;
        }
    }

    pub fn increment(&self, name: &str, value: u64) {
        if self.level() == 0 {
            return;
        }
        if let Ok(mut report) = self.report.lock() {
            *report.counters.entry(name.to_owned()).or_default() += value;
        }
    }

    pub fn snapshot(&self) -> Result<ProfileReport, String> {
        self.report
            .lock()
            .map(|report| report.clone())
            .map_err(|e| e.to_string())
    }
}

#[cfg(not(target_arch = "wasm32"))]
fn monotonic_ms() -> f64 {
    use std::sync::OnceLock;
    use std::time::Instant;
    static ORIGIN: OnceLock<Instant> = OnceLock::new();
    ORIGIN.get_or_init(Instant::now).elapsed().as_secs_f64() * 1000.0
}

#[cfg(target_arch = "wasm32")]
fn monotonic_ms() -> f64 {
    browser_monotonic_ms()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn profiling_is_off_by_default_and_does_not_collect() {
        let profile = ProfileCollector::default();
        assert_eq!(profile.level(), 0);
        assert!(profile.start(1).is_none());
        profile.record_ms("hidden", 10.0);
        profile.increment("hidden", 1);
        let report = profile.snapshot().unwrap();
        assert_eq!(report.mode, "off");
        assert!(report.events.is_empty());
        assert!(report.counters.is_empty());
    }

    #[test]
    fn summary_mode_collects_timing_and_structure_counts() {
        let profile = ProfileCollector::default();
        profile.set_mode("summary").unwrap();
        let started = profile.start(1);
        profile.record_since("evaluation", started);
        profile.set_graph(32, 512, 2048);
        let report = profile.snapshot().unwrap();
        assert_eq!(report.mode, "summary");
        assert_eq!(
            (report.atoms, report.edges, report.triples),
            (32, 512, 2048)
        );
        assert_eq!(report.events["evaluation"].calls, 1);
        assert!(report.events["evaluation"].total_ms.is_finite());
    }

    #[test]
    fn profile_rejects_unknown_mode_without_changing_current_mode() {
        let profile = ProfileCollector::default();
        profile.set_mode("detailed").unwrap();
        assert!(profile.set_mode("verbose").is_err());
        assert_eq!(profile.snapshot().unwrap().mode, "detailed");
    }
}
