//! Opt-in requested-allocation accounting. Does not measure JS/page RSS or
//! allocator usable sizes. A reset starts a traffic epoch without forgetting
//! allocations that are already live. Reset only at a quiet worker boundary.
use serde::Serialize;
use std::alloc::{GlobalAlloc, Layout};
use std::sync::atomic::{AtomicU64, Ordering::Relaxed};

static LIVE: AtomicU64 = AtomicU64::new(0);
static PEAK: AtomicU64 = AtomicU64::new(0);
static EPOCH_LIVE: AtomicU64 = AtomicU64::new(0);
static ALLOCATED: AtomicU64 = AtomicU64::new(0);
static FREED: AtomicU64 = AtomicU64::new(0);
static ALLOC_CALLS: AtomicU64 = AtomicU64::new(0);
static REALLOC_CALLS: AtomicU64 = AtomicU64::new(0);
static FREE_CALLS: AtomicU64 = AtomicU64::new(0);

#[derive(Clone, Debug, Default, Serialize)]
pub struct HeapSnapshot {
    pub live_requested_bytes: u64,
    pub peak_requested_bytes: u64,
    pub epoch_initial_live_bytes: u64,
    pub allocated_bytes: u64,
    pub freed_bytes: u64,
    pub allocation_calls: u64,
    pub reallocation_calls: u64,
    pub deallocation_calls: u64,
}

pub fn snapshot() -> HeapSnapshot {
    HeapSnapshot {
        live_requested_bytes: LIVE.load(Relaxed),
        peak_requested_bytes: PEAK.load(Relaxed),
        epoch_initial_live_bytes: EPOCH_LIVE.load(Relaxed),
        allocated_bytes: ALLOCATED.load(Relaxed),
        freed_bytes: FREED.load(Relaxed),
        allocation_calls: ALLOC_CALLS.load(Relaxed),
        reallocation_calls: REALLOC_CALLS.load(Relaxed),
        deallocation_calls: FREE_CALLS.load(Relaxed),
    }
}

pub fn reset_epoch() {
    let live = LIVE.load(Relaxed);
    EPOCH_LIVE.store(live, Relaxed);
    PEAK.store(live, Relaxed);
    for counter in [
        &ALLOCATED,
        &FREED,
        &ALLOC_CALLS,
        &REALLOC_CALLS,
        &FREE_CALLS,
    ] {
        counter.store(0, Relaxed);
    }
}

fn allocated(bytes: usize) {
    ALLOCATED.fetch_add(bytes as u64, Relaxed);
    let live = LIVE.fetch_add(bytes as u64, Relaxed) + bytes as u64;
    PEAK.fetch_max(live, Relaxed);
}

fn freed(bytes: usize) {
    FREED.fetch_add(bytes as u64, Relaxed);
    LIVE.fetch_sub(bytes as u64, Relaxed);
}

pub struct TrackingAllocator<A>(pub A);

// Accounting uses only atomics, never allocator-backed strings/containers.
// The underlying allocator owns all allocation/alignment/failure semantics.
unsafe impl<A: GlobalAlloc> GlobalAlloc for TrackingAllocator<A> {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let ptr = unsafe { self.0.alloc(layout) };
        if !ptr.is_null() {
            allocated(layout.size());
            ALLOC_CALLS.fetch_add(1, Relaxed);
        }
        ptr
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let ptr = unsafe { self.0.alloc_zeroed(layout) };
        if !ptr.is_null() {
            allocated(layout.size());
            ALLOC_CALLS.fetch_add(1, Relaxed);
        }
        ptr
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        unsafe { self.0.dealloc(ptr, layout) };
        freed(layout.size());
        FREE_CALLS.fetch_add(1, Relaxed);
    }
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        let result = unsafe { self.0.realloc(ptr, layout, new_size) };
        if !result.is_null() {
            // Realloc traffic counts the full requested new/old capacities,
            // not actual copies: the allocator may extend storage in place.
            freed(layout.size());
            allocated(new_size);
            REALLOC_CALLS.fetch_add(1, Relaxed);
        }
        result
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::alloc::System;
    #[test]
    fn reset_keeps_live_bytes_and_realloc_zeroed_free_balance() {
        let allocator = TrackingAllocator(System);
        reset_epoch();
        let initial = snapshot().live_requested_bytes;
        let layout = Layout::from_size_align(64, 16).unwrap();
        unsafe {
            let ptr = allocator.alloc_zeroed(layout);
            assert!(!ptr.is_null());
            assert!(std::slice::from_raw_parts(ptr, 64).iter().all(|x| *x == 0));
            assert_eq!(snapshot().live_requested_bytes, initial + 64);
            reset_epoch();
            assert_eq!(snapshot().epoch_initial_live_bytes, initial + 64);
            let ptr = allocator.realloc(ptr, layout, 128);
            assert!(!ptr.is_null());
            let current = snapshot();
            assert_eq!(current.live_requested_bytes, initial + 128);
            assert_eq!(current.peak_requested_bytes, initial + 128);
            allocator.dealloc(ptr, Layout::from_size_align(128, 16).unwrap());
        }
        let final_state = snapshot();
        assert_eq!(final_state.live_requested_bytes, initial);
        assert_eq!(final_state.allocated_bytes, 128);
        assert_eq!(final_state.freed_bytes, 192);
        assert_eq!(final_state.reallocation_calls, 1);
        assert_eq!(final_state.deallocation_calls, 1);
    }
}
