//! Native MatterSim 1M/5M evaluation on an explicit, ordered graph.
//! Graph construction is deliberately a separate contract: a wrong neighbor order
//! must not be hidden by an otherwise correct neural network evaluation.

use candle_core::{
    CpuStorage, CustomOp1, CustomOp2, CustomOp3, Device, Layout, Result as CandleResult, Shape,
    Storage, Tensor, Var,
};
#[cfg(not(target_arch = "wasm32"))]
use rayon::prelude::*;
use safetensors::SafeTensors;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::{Arc, Mutex};
#[cfg(not(target_arch = "wasm32"))]
use std::time::Instant;

#[cfg(target_arch = "wasm32")]
struct Instant;

#[cfg(target_arch = "wasm32")]
impl Instant {
    fn now() -> Self {
        Self
    }

    fn elapsed(&self) -> std::time::Duration {
        std::time::Duration::ZERO
    }
}

use crate::precision::{decode_precision_variant, PrecisionArtifactManifest};
use crate::{validate_weights_bytes, ModelManifest};
#[path = "profile.rs"]
pub mod profile;
use profile::{ProfileCollector, ProfileReport};
pub mod webgpu_geometry;
use macer_rust_core::types::{
    CalculationProperty, Calculator, CalculatorCapabilities, CalculatorError, CalculatorEvaluation,
    Evaluation, Potential, Structure,
};

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct OrderedGraph {
    pub atomic_numbers: Vec<u32>,
    pub positions_a: Vec<[f32; 3]>,
    pub cell_a: [[f32; 3]; 3],
    pub source: Vec<u32>,
    pub destination: Vec<u32>,
    pub offsets: Vec<[f32; 3]>,
    pub triple_first: Vec<u32>,
    pub triple_second: Vec<u32>,
}

impl OrderedGraph {
    pub fn from_structure(structure: &Structure) -> std::result::Result<Self, String> {
        let mut graph_input = structure.clone();
        if !structure.pbc.iter().any(|&periodic| periodic) {
            // Radius-graph construction uses a nonsingular cell to derive
            // reciprocal coordinates even when every periodic axis is off.
            // This temporary bounding box never creates periodic images.
            let mut extent = [0.0_f64; 3];
            for axis in 0..3 {
                let low = structure
                    .positions_a
                    .iter()
                    .map(|p| p[axis])
                    .fold(f64::INFINITY, f64::min);
                let high = structure
                    .positions_a
                    .iter()
                    .map(|p| p[axis])
                    .fold(f64::NEG_INFINITY, f64::max);
                extent[axis] = (high - low + 12.0).max(12.0);
            }
            graph_input.cell_a = [
                [extent[0], 0.0, 0.0],
                [0.0, extent[1], 0.0],
                [0.0, 0.0, extent[2]],
            ];
        }
        let wrapped = macer_rust_core::neighbors::wrapped_structure(&graph_input)?;
        let mut graph = macer_rust_core::neighbors::radius_graph(&wrapped, 5., 4.)?;
        let mut positions = wrapped.positions_a.clone();
        let mut shift = vec![[0i32; 3]; positions.len()];
        // A tiny negative scaled coordinate can round to one in a linear
        // solve. Preserve pymatgen's edge ordering, then express the output
        // graph in the same cell image as ASE's float32 atom positions.
        if structure.pbc.iter().any(|&periodic| periodic) {
            for (i, original) in structure.positions_a.iter().enumerate() {
                let frac =
                    macer_rust_core::neighbors::scaled_positions(structure.cell_a, *original)?;
                for axis in 0..3 {
                    if structure.pbc[axis] && frac[axis] < 0. && frac[axis] > -1e-12 {
                        shift[i][axis] = 1;
                        for xyz in 0..3 {
                            positions[i][xyz] -= structure.cell_a[axis][xyz];
                        }
                    }
                }
            }
        }
        for (edge, offset) in graph.offsets.iter_mut().enumerate() {
            let from = graph.source[edge] as usize;
            let to = graph.destination[edge] as usize;
            for axis in 0..3 {
                offset[axis] += (shift[to][axis] - shift[from][axis]) as f32;
            }
        }
        Ok(Self {
            atomic_numbers: wrapped.atomic_numbers.iter().map(|&z| z as u32).collect(),
            positions_a: positions.iter().map(|p| p.map(|x| x as f32)).collect(),
            cell_a: graph_input.cell_a.map(|r| r.map(|x| x as f32)),
            source: graph.source,
            destination: graph.destination,
            offsets: graph.offsets,
            triple_first: graph.triple_first,
            triple_second: graph.triple_second,
        })
    }

    pub fn validate(&self) -> std::result::Result<(), String> {
        let atoms = self.atomic_numbers.len();
        let edges = self.source.len();
        if atoms == 0
            || self.positions_a.len() != atoms
            || self.destination.len() != edges
            || self.offsets.len() != edges
            || self.triple_first.len() != self.triple_second.len()
        {
            return Err("invalid graph array lengths".into());
        }
        if self.atomic_numbers.iter().any(|&z| z > 94)
            || self
                .source
                .iter()
                .chain(&self.destination)
                .any(|&i| i as usize >= atoms)
            || self
                .triple_first
                .iter()
                .chain(&self.triple_second)
                .any(|&i| i as usize >= edges)
        {
            return Err("graph index or atomic number out of range".into());
        }
        if self
            .positions_a
            .iter()
            .flatten()
            .chain(self.cell_a.iter().flatten())
            .chain(self.offsets.iter().flatten())
            .any(|x| !x.is_finite())
        {
            return Err("non-finite graph geometry".into());
        }
        Ok(())
    }
}

impl Potential for Evaluator {
    fn evaluate(&mut self, structure: &Structure) -> std::result::Result<Evaluation, String> {
        let profile_start = self.profile.start(1);
        let graph = OrderedGraph::from_structure(structure)?;
        self.profile.set_graph(
            graph.atomic_numbers.len(),
            graph.source.len(),
            graph.triple_first.len(),
        );
        self.profile.record_since("graph_build", profile_start);
        let result = Evaluator::evaluate(self, &graph)?;
        Ok(Evaluation {
            energy_ev: result.energy_ev as f64,
            forces_ev_per_a: result
                .forces_ev_a
                .into_iter()
                .map(|r| r.map(f64::from))
                .collect(),
            stress_ev_per_a3: if structure.pbc.iter().any(|&periodic| periodic) {
                result.stress_ev_a3.map(|r| r.map(f64::from))
            } else {
                [[0.0; 3]; 3]
            },
            energies_ev: None,
            stresses_ev_per_a3: None,
        })
    }
}

impl Calculator for Evaluator {
    fn capabilities(&self) -> CalculatorCapabilities {
        // MatterSim 1M/5M returns energy, forces, and stress. Its evaluator is
        // currently single-structure; batch execution is layered above it.
        CalculatorCapabilities::energy_forces_stress(false)
    }

    fn evaluate_properties(
        &mut self,
        structure: &Structure,
        requested: &[CalculationProperty],
    ) -> Result<CalculatorEvaluation, CalculatorError> {
        if requested.is_empty() {
            return Ok(CalculatorEvaluation::default());
        }
        for property in requested {
            if !self.capabilities().supports(*property) {
                return Err(CalculatorError::UnsupportedCapability(*property));
            }
        }
        let evaluation =
            <Self as Potential>::evaluate(self, structure).map_err(CalculatorError::Evaluation)?;
        let result = CalculatorEvaluation {
            energy_ev: requested
                .contains(&CalculationProperty::Energy)
                .then_some(evaluation.energy_ev),
            forces_ev_per_a: requested
                .contains(&CalculationProperty::Forces)
                .then_some(evaluation.forces_ev_per_a),
            stress_ev_per_a3: requested
                .contains(&CalculationProperty::Stress)
                .then_some(evaluation.stress_ev_per_a3),
        };
        result.validate(structure.atomic_numbers.len(), requested)?;
        Ok(result)
    }
}

#[derive(Clone, Debug, Serialize)]
pub struct ModelEvaluation {
    pub energy_ev: f32,
    pub forces_ev_a: Vec<[f32; 3]>,
    pub stress_ev_a3: [[f32; 3]; 3],
}

#[derive(Clone, Copy)]
enum EnergyReduction {
    Default,
    Pairwise,
    ReferenceScatter,
}

pub struct Evaluator {
    weights: HashMap<String, Tensor>,
    device: Device,
    num_blocks: usize,
    rbf_dn: [f32; 4],
    rbf_en: [f32; 4],
    sbf_factor: f32,
    sbf_coef: Vec<Vec<Vec<f32>>>,
    graph_cache: Mutex<Option<GraphCache>>,
    gradient_trace_nodes: Mutex<Vec<(String, Tensor)>>,
    profile: Arc<ProfileCollector>,
    energy_reduction: EnergyReduction,
}

#[path = "checkpoint.rs"]
mod checkpoint;

struct PyTorchAcos;

/// Balanced FP32 reduction for optimized-v2 total energies. Avoids the O(N)
/// roundoff of scalar accumulation; derivatives remain exactly one per atom.
struct PairwiseEnergySum;
impl CustomOp1 for PairwiseEnergySum {
    fn name(&self) -> &'static str {
        "pairwise-energy-sum-f32-v1"
    }
    fn cpu_fwd(&self, storage: &CpuStorage, layout: &Layout) -> CandleResult<(CpuStorage, Shape)> {
        let CpuStorage::F32(values) = storage else {
            candle_core::bail!("energy sum requires FP32");
        };
        let mut data = (0..layout.shape().elem_count())
            .map(|i| values[layout_offset(layout, i)])
            .collect::<Vec<_>>();
        let mut n = data.len();
        while n > 1 {
            let pairs = n / 2;
            for i in 0..pairs {
                data[i] = data[2 * i] + data[2 * i + 1];
            }
            if n % 2 == 1 {
                data[pairs] = data[n - 1];
            }
            n = pairs + n % 2;
        }
        Ok((
            CpuStorage::F32(vec![data.first().copied().unwrap_or(0.)]),
            Shape::from(()),
        ))
    }
    fn bwd(
        &self,
        input: &Tensor,
        _result: &Tensor,
        gradient: &Tensor,
    ) -> CandleResult<Option<Tensor>> {
        Ok(Some(gradient.broadcast_as(input.shape())?))
    }
}

/// MatterSim1.2's torch-runstats scatter accumulates atomic energies in atom
/// order for a single CPU graph. Keep its FP32 ordering, not Tensor.sum's tree.
struct ReferenceEnergySum;
impl CustomOp1 for ReferenceEnergySum {
    fn name(&self) -> &'static str {
        "reference-scatter-energy-sum-f32-v1"
    }
    fn cpu_fwd(&self, storage: &CpuStorage, layout: &Layout) -> CandleResult<(CpuStorage, Shape)> {
        let CpuStorage::F32(values) = storage else {
            candle_core::bail!("reference energy sum requires FP32");
        };
        let mut sum = 0.0f32;
        for index in 0..layout.shape().elem_count() {
            sum += values[layout_offset(layout, index)];
        }
        Ok((CpuStorage::F32(vec![sum]), Shape::from(())))
    }
    fn bwd(
        &self,
        input: &Tensor,
        _result: &Tensor,
        gradient: &Tensor,
    ) -> CandleResult<Option<Tensor>> {
        Ok(Some(gradient.broadcast_as(input.shape())?))
    }
}

struct PyTorchSigmoid;
struct PyTorchSilu;
#[cfg(feature = "analytic-gated-backward")]
struct PyTorchSiluDerivative;
#[cfg(feature = "analytic-gated-backward")]
impl CustomOp2 for PyTorchSiluDerivative {
    fn name(&self) -> &'static str {
        "pytorch-silu-derivative"
    }

    fn cpu_fwd(
        &self,
        input: &CpuStorage,
        input_layout: &Layout,
        output: &CpuStorage,
        output_layout: &Layout,
    ) -> CandleResult<(CpuStorage, Shape)> {
        let (CpuStorage::F32(input), CpuStorage::F32(output)) = (input, output) else {
            candle_core::bail!("SiLU derivative currently supports f32 CPU tensors only")
        };
        if input_layout.dims() != output_layout.dims() {
            candle_core::bail!("SiLU derivative input/output shape mismatch")
        }
        let count = input_layout.shape().elem_count();
        #[cfg(feature = "fast-gated-derivative-contiguous")]
        if let Some(((input_start, input_end), (output_start, output_end))) = input_layout
            .contiguous_offsets()
            .zip(output_layout.contiguous_offsets())
            .filter(|((is, ie), (os, oe))| ie - is == count && oe - os == count)
        {
            let input = &input[input_start..input_end];
            let output = &output[output_start..output_end];
            let derivative = map_indexed_f32(count, |index| {
                silu_backward_element(input[index], output[index], 1.0)
            });
            return Ok((CpuStorage::F32(derivative), input_layout.shape().clone()));
        }
        let derivative = map_indexed_f32(count, |index| {
            let x = input[layout_offset(input_layout, index)];
            let y = output[layout_offset(output_layout, index)];
            silu_backward_element(x, y, 1.0)
        });
        Ok((CpuStorage::F32(derivative), input_layout.shape().clone()))
    }
}

#[cfg(not(target_arch = "wasm32"))]
const CPU_PARALLEL_THRESHOLD: usize = 4096;

fn map_indexed_f32(count: usize, f: impl Fn(usize) -> f32 + Send + Sync) -> Vec<f32> {
    #[cfg(not(target_arch = "wasm32"))]
    if count >= CPU_PARALLEL_THRESHOLD {
        return (0..count).into_par_iter().map(f).collect();
    }
    (0..count).map(f).collect()
}

fn map_slice_f32(values: &[f32], f: impl Fn(f32) -> f32 + Send + Sync) -> Vec<f32> {
    #[cfg(not(target_arch = "wasm32"))]
    if values.len() >= CPU_PARALLEL_THRESHOLD {
        return values.par_iter().map(|&value| f(value)).collect();
    }
    values.iter().map(|&value| f(value)).collect()
}

fn layout_offset(layout: &Layout, mut linear_index: usize) -> usize {
    let mut offset = layout.start_offset();
    for axis in (0..layout.dims().len()).rev() {
        let dimension = layout.dims()[axis];
        let coordinate = linear_index % dimension;
        linear_index /= dimension;
        offset += coordinate * layout.stride()[axis];
    }
    offset
}

fn map_layout_f32(
    layout: &Layout,
    values: &[f32],
    f: impl Fn(f32) -> f32 + Send + Sync,
) -> Vec<f32> {
    if let Some((start, end)) = layout.contiguous_offsets() {
        return map_slice_f32(&values[start..end], f);
    }
    let dims = layout.dims();
    let strides = layout.stride();
    if dims.len() == 2 && strides[1] == 1 {
        #[cfg(not(target_arch = "wasm32"))]
        {
            let count = layout.shape().elem_count();
            if count >= CPU_PARALLEL_THRESHOLD {
                let mut mapped = vec![0.0; count];
                mapped
                    .par_chunks_mut(dims[1])
                    .enumerate()
                    .for_each(|(row, output)| {
                        let start = layout.start_offset() + row * strides[0];
                        for (target, &value) in
                            output.iter_mut().zip(&values[start..start + dims[1]])
                        {
                            *target = f(value);
                        }
                    });
                return mapped;
            }
        }
        let mut mapped = Vec::with_capacity(layout.shape().elem_count());
        for row in 0..dims[0] {
            let start = layout.start_offset() + row * strides[0];
            mapped.extend(values[start..start + dims[1]].iter().map(|&value| f(value)));
        }
        return mapped;
    }
    map_indexed_f32(layout.shape().elem_count(), |index| {
        f(values[layout_offset(layout, index)])
    })
}

#[inline]
fn silu_backward_element(value: f32, silu: f32, grad: f32) -> f32 {
    // Since silu(x) = x * sigmoid(x), recover sigmoid from the forward
    // result instead of evaluating expf again in every backward element.
    // Handle zero separately to avoid 0/0.
    let sigmoid = if value == 0.0 { 0.5 } else { silu / value };
    grad * (sigmoid * (1.0 - silu) + silu)
}

fn silu_backward_contiguous(input: &[f32], output: &[f32], grad: &[f32]) -> Vec<f32> {
    let mut result = vec![0.0; input.len()];
    #[cfg(not(target_arch = "wasm32"))]
    if input.len() >= CPU_PARALLEL_THRESHOLD {
        const CHUNK: usize = 4096;
        result
            .par_chunks_mut(CHUNK)
            .enumerate()
            .for_each(|(chunk_index, destination)| {
                let start = chunk_index * CHUNK;
                let end = start + destination.len();
                for index in start..end {
                    destination[index - start] =
                        silu_backward_element(input[index], output[index], grad[index]);
                }
            });
        return result;
    }
    for index in 0..input.len() {
        result[index] = silu_backward_element(input[index], output[index], grad[index]);
    }
    result
}

impl CustomOp1 for PyTorchSigmoid {
    fn name(&self) -> &'static str {
        "pytorch-sigmoid"
    }

    fn cpu_fwd(&self, storage: &CpuStorage, layout: &Layout) -> CandleResult<(CpuStorage, Shape)> {
        let CpuStorage::F32(values) = storage else {
            candle_core::bail!("pytorch-sigmoid currently supports f32 CPU tensors only")
        };
        let result = map_layout_f32(layout, values, |value| (1.0 + (-value).exp()).recip());
        Ok((CpuStorage::F32(result), layout.shape().clone()))
    }

    fn bwd(
        &self,
        _arg: &Tensor,
        result: &Tensor,
        grad_result: &Tensor,
    ) -> CandleResult<Option<Tensor>> {
        let (result_storage, result_layout) = result.storage_and_layout();
        let (grad_storage, grad_layout) = grad_result.storage_and_layout();
        let (Storage::Cpu(CpuStorage::F32(output)), Storage::Cpu(CpuStorage::F32(grad))) =
            (&*result_storage, &*grad_storage)
        else {
            // Keep the accelerator implementation in Candle's device kernels.
            let one_minus = result.affine(-1.0, 1.0)?;
            return Ok(Some(grad_result.mul(result)?.mul(&one_minus)?));
        };
        let count = result.shape().elem_count();
        let contiguous = result_layout
            .contiguous_offsets()
            .zip(grad_layout.contiguous_offsets())
            .filter(|((output_start, output_end), (grad_start, grad_end))| {
                output_end - output_start == count && grad_end - grad_start == count
            });
        let gradient = if let Some(((output_start, _), (grad_start, _))) = contiguous {
            map_indexed_f32(count, |index| {
                let value = output[output_start + index];
                grad[grad_start + index] * value * (1.0 - value)
            })
        } else {
            map_indexed_f32(count, |index| {
                let output_offset = layout_offset(&result_layout, index);
                let grad_offset = layout_offset(&grad_layout, index);
                let value = output[output_offset];
                grad[grad_offset] * value * (1.0 - value)
            })
        };
        Ok(Some(Tensor::from_vec(
            gradient,
            result.shape(),
            result.device(),
        )?))
    }
}

impl CustomOp1 for PyTorchSilu {
    fn name(&self) -> &'static str {
        "pytorch-silu-fused"
    }

    fn cpu_fwd(&self, storage: &CpuStorage, layout: &Layout) -> CandleResult<(CpuStorage, Shape)> {
        let CpuStorage::F32(values) = storage else {
            candle_core::bail!("pytorch-silu-fused currently supports f32 CPU tensors only")
        };
        let result = map_layout_f32(layout, values, |value| value / (1.0 + (-value).exp()));
        Ok((CpuStorage::F32(result), layout.shape().clone()))
    }

    fn bwd(
        &self,
        arg: &Tensor,
        result: &Tensor,
        grad_result: &Tensor,
    ) -> CandleResult<Option<Tensor>> {
        // Read the existing CPU buffers through their layouts. Converting the
        // input, output, and upstream gradient to three temporary vectors on
        // every activation backward pass was pure copying overhead.
        let (input_storage, input_layout) = arg.storage_and_layout();
        let (output_storage, output_layout) = result.storage_and_layout();
        let (grad_storage, grad_layout) = grad_result.storage_and_layout();
        let Storage::Cpu(CpuStorage::F32(input)) = &*input_storage else {
            candle_core::bail!(
                "pytorch-silu-fused backward currently supports f32 CPU tensors only"
            )
        };
        let Storage::Cpu(CpuStorage::F32(output)) = &*output_storage else {
            candle_core::bail!(
                "pytorch-silu-fused backward currently supports f32 CPU tensors only"
            )
        };
        let Storage::Cpu(CpuStorage::F32(grad)) = &*grad_storage else {
            candle_core::bail!(
                "pytorch-silu-fused backward currently supports f32 CPU tensors only"
            )
        };
        let element_count = arg.shape().elem_count();
        let contiguous = input_layout
            .contiguous_offsets()
            .zip(output_layout.contiguous_offsets())
            .zip(grad_layout.contiguous_offsets())
            .filter(|((input, output), grad)| {
                input.1 - input.0 == element_count
                    && output.1 - output.0 == element_count
                    && grad.1 - grad.0 == element_count
            });
        let gradient =
            if let Some((((input_start, _), (output_start, _)), (grad_start, _))) = contiguous {
                silu_backward_contiguous(
                    &input[input_start..input_start + element_count],
                    &output[output_start..output_start + element_count],
                    &grad[grad_start..grad_start + element_count],
                )
            } else {
                map_indexed_f32(element_count, |index| {
                    let value = input[layout_offset(input_layout, index)];
                    let silu = output[layout_offset(output_layout, index)];
                    let upstream = grad[layout_offset(grad_layout, index)];
                    silu_backward_element(value, silu, upstream)
                })
            };
        Ok(Some(Tensor::from_vec(gradient, arg.shape(), arg.device())?))
    }
}

impl CustomOp1 for PyTorchAcos {
    fn name(&self) -> &'static str {
        "pytorch-acos"
    }

    fn cpu_fwd(&self, storage: &CpuStorage, layout: &Layout) -> CandleResult<(CpuStorage, Shape)> {
        let CpuStorage::F32(values) = storage else {
            candle_core::bail!("pytorch-acos currently supports f32 CPU tensors only")
        };
        let (start, end) = layout.contiguous_offsets().ok_or_else(|| {
            candle_core::Error::Msg("pytorch-acos requires contiguous input".into())
        })?;
        let result = values[start..end]
            .iter()
            .map(|value| value.acos())
            .collect();
        Ok((CpuStorage::F32(result), layout.shape().clone()))
    }

    #[cfg(feature = "cuda")]
    fn cuda_fwd(
        &self,
        storage: &candle_core::CudaStorage,
        layout: &Layout,
    ) -> CandleResult<(candle_core::CudaStorage, Shape)> {
        use candle_core::cuda::{
            cudarc::driver::{LaunchConfig, PushKernelArg},
            WrapErr,
        };

        let (start, end) = layout.contiguous_offsets().ok_or_else(|| {
            candle_core::Error::Msg("pytorch-acos requires contiguous input".into())
        })?;
        let count = layout.shape().elem_count();
        if end - start != count {
            return Err(candle_core::Error::Msg(
                "pytorch-acos received an invalid contiguous layout".into(),
            ));
        }
        if count > u32::MAX as usize {
            return Err(candle_core::Error::Msg(
                "pytorch-acos input exceeds the CUDA launch limit".into(),
            ));
        }

        let device = &storage.device;
        let input = storage.as_cuda_slice::<f32>()?.slice(start..end);
        let mut output = if count == 0 {
            device.alloc_zeros::<f32>(1)?.slice(0..0)
        } else {
            // SAFETY: every element is written by the kernel before the output
            // storage is returned to Candle.
            unsafe { device.alloc::<f32>(count)? }
        };
        if count > 0 {
            let ptx = cuda_acos_ptx()?;
            let function =
                device.get_or_load_custom_func("macer_acos_f32", "macer_model_acos_v1", ptx)?;
            let count = count as u64;
            let mut launch = device.cuda_stream().launch_builder(&function);
            launch.arg(&input);
            launch.arg(&mut output);
            launch.arg(&count);
            // SAFETY: the kernel reads `count` contiguous f32 inputs and writes
            // exactly `count` f32 outputs on the storage's owning device.
            unsafe {
                launch
                    .launch(LaunchConfig::for_num_elems(count as u32))
                    .w()?;
            }
        }

        Ok((
            candle_core::CudaStorage::wrap_cuda_slice(output, device.clone()),
            layout.shape().clone(),
        ))
    }

    fn bwd(&self, arg: &Tensor, _res: &Tensor, grad_res: &Tensor) -> CandleResult<Option<Tensor>> {
        let denominator = arg.sqr()?.affine(-1., 1.)?.sqrt()?;
        Ok(Some(grad_res.neg()?.div(&denominator)?))
    }
}

#[cfg(feature = "cuda")]
fn cuda_acos_ptx() -> CandleResult<&'static str> {
    static PTX: std::sync::OnceLock<std::result::Result<String, String>> =
        std::sync::OnceLock::new();
    PTX.get_or_init(|| {
        let source = r#"
            #include <math.h>
            extern "C" __global__ void macer_acos_f32(
                const float* input,
                float* output,
                unsigned long long count
            ) {
                const unsigned long long index =
                    (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;
                if (index < count) output[index] = acosf(input[index]);
            }
        "#;
        candle_core::cuda::cudarc::nvrtc::compile_ptx(source)
            .map(|ptx| ptx.to_src())
            .map_err(|error| error.to_string())
    })
    .as_ref()
    .map(String::as_str)
    .map_err(|error| candle_core::Error::Msg(error.clone()))
}

struct PyTorchNorm3;

impl CustomOp1 for PyTorchNorm3 {
    fn name(&self) -> &'static str {
        "pytorch-vector-norm-3"
    }

    fn cpu_fwd(&self, storage: &CpuStorage, layout: &Layout) -> CandleResult<(CpuStorage, Shape)> {
        let CpuStorage::F32(values) = storage else {
            candle_core::bail!("pytorch-vector-norm-3 currently supports f32 CPU tensors only")
        };
        if layout.shape().rank() != 2 || layout.shape().dims()[1] != 3 {
            candle_core::bail!("pytorch-vector-norm-3 expects a [edges, 3] tensor")
        }
        let (start, end) = layout.contiguous_offsets().ok_or_else(|| {
            candle_core::Error::Msg("pytorch-vector-norm-3 requires contiguous input".into())
        })?;
        let rows = (end - start) / 3;
        let vectors = &values[start..end];
        let norm = |row: &[f32]| {
            let sum = row[0].mul_add(row[0], 0.0);
            let sum = row[1].mul_add(row[1], sum);
            let sum = row[2].mul_add(row[2], sum);
            sum.sqrt()
        };
        let norms = map_indexed_f32(rows, |index| norm(&vectors[index * 3..index * 3 + 3]));
        Ok((CpuStorage::F32(norms), Shape::from(rows)))
    }

    fn bwd(
        &self,
        arg: &Tensor,
        result: &Tensor,
        grad_result: &Tensor,
    ) -> CandleResult<Option<Tensor>> {
        let scale = grad_result.div(result)?.unsqueeze(1)?;
        Ok(Some(arg.broadcast_mul(&scale)?))
    }
}

#[derive(Clone)]
struct GraphTensors {
    source: Tensor,
    destination: Tensor,
    first: Tensor,
    second: Tensor,
    second_sources: Tensor,
    offsets: Tensor,
    one_hot: Tensor,
    species: Tensor,
}

struct GraphCache {
    source: Vec<u32>,
    destination: Vec<u32>,
    offsets: Vec<[f32; 3]>,
    first: Vec<u32>,
    second: Vec<u32>,
    species: Vec<u32>,
    tensors: GraphTensors,
}

impl Evaluator {
    fn gradient_trace_selected(name: &str) -> bool {
        let mode = std::env::var("MACER_RUST_TRACE_GRAD").ok();
        mode.as_deref() == Some("all")
            || (mode.as_deref() == Some("geometry")
                && matches!(
                    name,
                    "edge_length"
                        | "edge_length_full"
                        | "length_rbf"
                        | "rbf"
                        | "sbf"
                        | "sbf_r"
                        | "sbf_theta"
                        | "cosine"
                        | "angle_rij"
                        | "angle_rik"
                ))
            || (mode.as_deref() == Some("geometry")
                && (name.ends_with(".cutoff_rij") || name.ends_with(".cutoff_rik")))
            || (mode.as_deref() != Some("geometry")
                && (name.starts_with("graph_conv.2.") || name.starts_with("graph_conv.3.")))
    }

    fn capture_gradient_trace(&self, name: &str, value: &Tensor) -> CandleResult<()> {
        if std::env::var_os("MACER_RUST_TRACE_GRAD").is_some()
            && Self::gradient_trace_selected(name)
        {
            self.gradient_trace_nodes
                .lock()
                .map_err(|e| candle_core::Error::Msg(e.to_string()))?
                .push((name.to_string(), value.clone()));
        }
        Ok(())
    }

    fn trace(&self, name: &str, value: &Tensor) -> CandleResult<()> {
        self.capture_gradient_trace(name, value)?;
        if matches!(name, "cosine_raw" | "edge_vector" | "edge_length")
            && std::env::var_os("MACER_RUST_TRACE_COSINE_RAW").is_some()
        {
            let flat = value.flatten_all()?.to_vec1::<f32>()?;
            eprintln!(
                "TRACERAWJSON {}",
                serde_json::json!({"name":name,"shape":value.dims(),"values":flat})
            );
        }
        if name == "normalizer" && std::env::var_os("MACER_RUST_TRACE_ATOMIC_ENERGY").is_some() {
            let flat = value.flatten_all()?.to_vec1::<f32>()?;
            eprintln!(
                "TRACEATOMICJSON {}",
                serde_json::json!({"shape":value.dims(),"values":flat})
            );
        }
        if std::env::var_os("MACER_RUST_TRACE_FULL").is_some() {
            let flat = value.flatten_all()?.to_vec1::<f32>()?;
            eprintln!(
                "TRACEJSON {}",
                serde_json::json!({"name":name,"shape":value.dims(),"values":flat})
            );
        } else if std::env::var_os("MACER_RUST_TRACE").is_some() {
            let flat = value.flatten_all()?.to_vec1::<f32>()?;
            let first: Vec<f32> = flat.iter().take(5).copied().collect();
            eprintln!(
                "TRACE {name} shape={:?} first={first:?} sum={} max={}",
                value.dims(),
                flat.iter().map(|&x| x as f64).sum::<f64>(),
                flat.iter().copied().fold(f32::NEG_INFINITY, f32::max)
            );
        }
        Ok(())
    }

    fn trace_gated(&self, prefix: &str, stage: &str, value: &Tensor) -> CandleResult<()> {
        let selected = std::env::var("MACER_RUST_TRACE_GATED").ok();
        if selected.as_deref() == Some(prefix) || selected.as_deref() == Some("all") {
            self.trace(&format!("{prefix}.{stage}"), value)?;
        } else {
            self.capture_gradient_trace(&format!("{prefix}.{stage}"), value)?;
        }
        Ok(())
    }
    /// Construct an evaluator from host-provided manifest and weight bytes.
    /// Native and browser adapters own storage/network access; the evaluator
    /// only validates and consumes the supplied package.
    pub fn from_bytes(
        manifest_json: &[u8],
        weights_bytes: &[u8],
        device: Device,
    ) -> std::result::Result<Self, String> {
        let manifest = ModelManifest::from_json_bytes(manifest_json)?;
        Self::from_manifest_and_weights(&manifest, weights_bytes, device)
    }

    /// Construct from a parsed manifest and in-memory weights. The manifest is
    /// revalidated here so callers cannot bypass the model contract.
    pub fn from_manifest_and_weights(
        manifest: &ModelManifest,
        weights_bytes: &[u8],
        device: Device,
    ) -> std::result::Result<Self, String> {
        validate_weights_bytes(manifest, weights_bytes)?;
        let safe = SafeTensors::deserialize(weights_bytes).map_err(|e| e.to_string())?;
        let values = manifest
            .tensors
            .iter()
            .map(|spec| {
                let view = safe.tensor(&spec.name).map_err(|e| e.to_string())?;
                let data = view
                    .data()
                    .chunks_exact(4)
                    .map(|b| f32::from_le_bytes(b.try_into().unwrap()))
                    .collect();
                Ok((spec.name.clone(), data))
            })
            .collect::<std::result::Result<HashMap<_, _>, String>>()?;
        Self::from_float_values(manifest, values, device)
    }

    /// Construct an isolated experimental precision candidate. The artifact
    /// manifest is bound to the canonical MatterSim source hashes; all stored
    /// values are expanded to F32 before the ordinary evaluator is created.
    pub fn from_precision_variant_bytes(
        source_manifest_json: &[u8],
        artifact_manifest_json: &[u8],
        artifact_weights: &[u8],
        device: Device,
    ) -> std::result::Result<Self, String> {
        let source_manifest = ModelManifest::from_json_bytes(source_manifest_json)?;
        let artifact: PrecisionArtifactManifest = serde_json::from_slice(artifact_manifest_json)
            .map_err(|e| format!("precision artifact manifest parse failed: {e}"))?;
        let values = decode_precision_variant(&source_manifest, &artifact, artifact_weights)?;
        Self::from_float_values(&source_manifest, values, device)
    }

    pub fn from_optimized_bundle_bytes(
        source_manifest: &[u8],
        bundle_manifest: &[u8],
        artifact: &[u8],
        policy_role: &str,
        device: Device,
    ) -> std::result::Result<(Self, crate::optimized_bundle::BundleIdentity), String> {
        let mut decoded = crate::optimized_bundle::decode_bundle(
            source_manifest,
            bundle_manifest,
            artifact,
            policy_role,
        )?;
        let mut effective = decoded.source.clone();
        let mut factor_values = Vec::new();
        for factor in &decoded.factors {
            effective.tensors.retain(|x| {
                x.name != format!("{}.weight", factor.module)
                    && x.name != format!("{}.bias", factor.module)
            });
            for (name, shape) in [
                (
                    format!("{}.down.weight", factor.module),
                    vec![factor.rank, factor.inputs],
                ),
                (
                    format!("{}.up.weight", factor.module),
                    vec![factor.outputs, factor.rank],
                ),
            ] {
                let values = decoded
                    .values
                    .remove(&name)
                    .ok_or("missing decoded factor")?;
                factor_values.push((name, values, shape));
            }
            if factor.bias {
                let values = decoded
                    .values
                    .remove(&format!("{}.up.bias", factor.module))
                    .ok_or("missing factor bias")?;
                factor_values.push((
                    format!("{}.bias", factor.module),
                    values,
                    vec![factor.outputs],
                ));
            }
        }
        let mut evaluator = Self::from_float_values(&effective, decoded.values, device.clone())?;
        for (name, values, shape) in factor_values {
            evaluator.weights.insert(
                name,
                Tensor::from_vec(values, shape.as_slice(), &device).map_err(|e| e.to_string())?,
            );
        }
        evaluator.energy_reduction = match decoded.identity.kernel_version.as_str() {
            "dense-f16-fp32-v2" => EnergyReduction::Pairwise,
            "dense-f16-fp32-v3" | "dense-f16-bias-fp32-v1" => EnergyReduction::ReferenceScatter,
            _ => EnergyReduction::Default,
        };
        Ok((evaluator, decoded.identity))
    }

    fn from_float_values(
        manifest: &ModelManifest,
        mut values: HashMap<String, Vec<f32>>,
        device: Device,
    ) -> std::result::Result<Self, String> {
        let coefficients = |name: &str| -> std::result::Result<Vec<f32>, String> {
            values
                .get(name)
                .cloned()
                .ok_or_else(|| format!("missing coefficient tensor: {name}"))
        };
        let rbf_dn: [f32; 4] = coefficients("rbf.dn")?
            .try_into()
            .map_err(|_| "invalid rbf.dn shape")?;
        let rbf_en: [f32; 4] = coefficients("rbf.en")?
            .try_into()
            .map_err(|_| "invalid rbf.en shape")?;
        let sbf_factor = *coefficients("sbf.factor")?
            .first()
            .ok_or("invalid sbf.factor shape")?;
        let sbf_coef = serde_json::from_str(include_str!("sbf_coefficients.json"))
            .map_err(|e| e.to_string())?;
        let mut weights = HashMap::new();
        for spec in &manifest.tensors {
            let data = values
                .remove(&spec.name)
                .ok_or_else(|| format!("missing decoded weight tensor: {}", spec.name))?;
            let (data, shape) = (data, spec.shape.clone());
            let tensor = Tensor::from_vec(data, shape.as_slice(), &device)
                .map_err(|e| format!("{}: {e}", spec.name))?;
            weights.insert(spec.name.clone(), tensor);
        }
        if !values.is_empty() {
            return Err("decoded weights contain unexpected tensors".into());
        }
        Ok(Self {
            weights,
            device,
            num_blocks: manifest.model_args.num_blocks,
            rbf_dn,
            rbf_en,
            sbf_factor,
            sbf_coef,
            graph_cache: Mutex::new(None),
            gradient_trace_nodes: Mutex::new(Vec::new()),
            profile: Arc::new(ProfileCollector::default()),
            energy_reduction: EnergyReduction::Default,
        })
    }

    /// Enables opt-in diagnostic profiling. `off` is the default and does not
    /// collect timers or alter scientific evaluation results.
    pub fn set_profile(&self, mode: &str) -> std::result::Result<(), String> {
        self.profile.set_mode(mode)
    }

    pub fn profile_report(&self) -> std::result::Result<ProfileReport, String> {
        self.profile.snapshot()
    }

    fn w(&self, key: &str) -> &Tensor {
        &self.weights[key]
    }

    fn linear(&self, x: &Tensor, prefix: &str) -> CandleResult<Tensor> {
        if let Some(down) = self.weights.get(&format!("{prefix}.linear.down.weight")) {
            let up = self.w(&format!("{prefix}.linear.up.weight"));
            let value = x.matmul(&down.t()?)?.matmul(&up.t()?)?;
            return if let Some(bias) = self.weights.get(&format!("{prefix}.linear.bias")) {
                value.broadcast_add(bias)
            } else {
                Ok(value)
            };
        }
        let weight = self.w(&format!("{prefix}.linear.weight"));
        #[cfg(all(feature = "diagnostic-wasm-f64-linear", target_arch = "wasm32"))]
        if self.device.is_cpu() && prefix == "graph_conv.0.three_body.atom_mlp" {
            let input_f64 = x.to_dtype(candle_core::DType::F64)?;
            let weight_f64 = weight.to_dtype(candle_core::DType::F64)?;
            let mut output_f64 = input_f64.matmul(&weight_f64.t()?)?;
            if let Some(bias) = self.weights.get(&format!("{prefix}.linear.bias")) {
                output_f64 = output_f64.broadcast_add(&bias.to_dtype(candle_core::DType::F64)?)?;
            }
            return output_f64.to_dtype(candle_core::DType::F32);
        }
        #[cfg(all(feature = "diagnostic-f64-linear", not(target_arch = "wasm32")))]
        if self.device.is_cpu()
            && std::env::var("MACER_RUST_DIAGNOSTIC_F64_LINEAR_PREFIX").as_deref() == Ok(prefix)
        {
            let input_f64 = x.to_dtype(candle_core::DType::F64)?;
            let weight_f64 = weight.to_dtype(candle_core::DType::F64)?;
            let mut output_f64 = input_f64.matmul(&weight_f64.t()?)?;
            if let Some(bias) = self.weights.get(&format!("{prefix}.linear.bias")) {
                output_f64 = output_f64.broadcast_add(&bias.to_dtype(candle_core::DType::F64)?)?;
            }
            eprintln!("DIAGNOSTIC_F64_LINEAR prefix={prefix}");
            return output_f64.to_dtype(candle_core::DType::F32);
        }
        if let Some(bias) = self.weights.get(&format!("{prefix}.linear.bias")) {
            #[cfg(feature = "fused-linear")]
            if self.device.is_cpu() {
                x.frozen_linear(&weight.t()?, bias)
            } else {
                x.matmul(&weight.t()?)?.broadcast_add(bias)
            }
            #[cfg(not(feature = "fused-linear"))]
            x.matmul(&weight.t()?)?.broadcast_add(bias)
        } else {
            x.matmul(&weight.t()?)
        }
    }

    #[cfg(feature = "analytic-gated-backward")]
    fn linear_input_gradient(&self, gradient: &Tensor, prefix: &str) -> CandleResult<Tensor> {
        if let Some(down) = self.weights.get(&format!("{prefix}.linear.down.weight")) {
            gradient
                .matmul(self.w(&format!("{prefix}.linear.up.weight")))?
                .matmul(down)
        } else {
            gradient.matmul(self.w(&format!("{prefix}.linear.weight")))
        }
    }

    fn sigmoid(&self, x: &Tensor) -> CandleResult<Tensor> {
        // Use the same exp-based forward definition as PyTorch. The tanh
        // identity is mathematically equivalent but rounded differently.
        if self.device.is_cpu() {
            x.apply_op1(PyTorchSigmoid)
        } else {
            x.neg()?.exp()?.affine(1., 1.)?.recip()
        }
    }

    fn sum_energy(&self, values: &Tensor) -> CandleResult<Tensor> {
        if self.device.is_cpu() {
            match self.energy_reduction {
                EnergyReduction::Pairwise => values.apply_op1(PairwiseEnergySum),
                EnergyReduction::ReferenceScatter => values.apply_op1(ReferenceEnergySum),
                EnergyReduction::Default => values.sum_all(),
            }
        } else {
            values.sum_all()
        }
    }

    fn swish(&self, x: &Tensor) -> CandleResult<Tensor> {
        if self.device.is_cpu() {
            x.apply_op1(PyTorchSilu)
        } else {
            x.silu()
        }
    }

    fn gated(&self, x: &Tensor, prefix: &str, layers: usize) -> CandleResult<Tensor> {
        if self.device.is_cpu() && x.dim(0)? > checkpoint::GATED_ROWS {
            let evaluator = std::sync::Arc::new(Self {
                weights: self.weights.clone(),
                device: Device::Cpu,
                num_blocks: self.num_blocks,
                rbf_dn: self.rbf_dn,
                rbf_en: self.rbf_en,
                sbf_factor: self.sbf_factor,
                sbf_coef: self.sbf_coef.clone(),
                graph_cache: Mutex::new(None),
                gradient_trace_nodes: Mutex::new(Vec::new()),
                profile: self.profile.clone(),
                energy_reduction: self.energy_reduction,
            });
            self.profile.increment("checkpoint.gated.calls", 1);
            return x.contiguous()?.apply_op1(checkpoint::GatedCheckpoint {
                evaluator,
                prefix: prefix.to_owned(),
                layers,
            });
        }
        self.gated_direct(x, prefix, layers)
    }

    fn gated_edges(
        &self,
        a: &Tensor,
        b: &Tensor,
        c: &Tensor,
        prefix: &str,
        layers: usize,
    ) -> CandleResult<Tensor> {
        if self.device.is_cpu() && a.dim(0)? > checkpoint::GATED_ROWS {
            let evaluator = std::sync::Arc::new(Self {
                weights: self.weights.clone(),
                device: Device::Cpu,
                num_blocks: self.num_blocks,
                rbf_dn: self.rbf_dn,
                rbf_en: self.rbf_en,
                sbf_factor: self.sbf_factor,
                sbf_coef: self.sbf_coef.clone(),
                graph_cache: Mutex::new(None),
                gradient_trace_nodes: Mutex::new(vec![]),
                profile: self.profile.clone(),
                energy_reduction: self.energy_reduction,
            });
            self.profile.increment("checkpoint.concat_gated.calls", 1);
            a.contiguous()?.apply_op3(
                &b.contiguous()?,
                &c.contiguous()?,
                checkpoint::ConcatGated {
                    evaluator,
                    prefix: prefix.to_owned(),
                    layers,
                },
            )
        } else {
            self.gated(&Tensor::cat(&[a, b, c], 1)?, prefix, layers)
        }
    }

    fn gated_direct(&self, x: &Tensor, prefix: &str, layers: usize) -> CandleResult<Tensor> {
        let mut g = x.clone();
        let mut sigma = x.clone();
        for i in 0..layers {
            g = self.linear(&g, &format!("{prefix}.g.{i}"))?;
            sigma = self.linear(&sigma, &format!("{prefix}.sigma.{i}"))?;
            self.trace_gated(prefix, &format!("g.{i}.linear"), &g)?;
            self.trace_gated(prefix, &format!("sigma.{i}.linear"), &sigma)?;
            if i + 1 == layers {
                if prefix != "final" {
                    g = self.swish(&g)?;
                }
                sigma = self.sigmoid(&sigma)?;
            } else {
                g = self.swish(&g)?;
                sigma = self.swish(&sigma)?;
            }
            self.trace_gated(prefix, &format!("g.{i}.activated"), &g)?;
            self.trace_gated(prefix, &format!("sigma.{i}.activated"), &sigma)?;
        }
        let output = g.mul(&sigma)?;
        self.trace_gated(prefix, "output", &output)?;
        Ok(output)
    }

    /// Computes only the input gradient of a frozen-weight gated MLP. The
    /// checkpoint path never trains model weights, so constructing Candle's
    /// full reverse graph for those constants is unnecessary.
    #[cfg(feature = "analytic-gated-backward")]
    fn gated_input_gradient_direct(
        &self,
        x: &Tensor,
        prefix: &str,
        layers: usize,
        output_gradient: &Tensor,
    ) -> CandleResult<Tensor> {
        struct LayerState {
            g_pre: Tensor,
            sigma_pre: Tensor,
            sigma: Tensor,
            g: Tensor,
        }

        let mut g_state = x.clone();
        let mut sigma_state = x.clone();
        let mut saved = Vec::with_capacity(layers);
        for i in 0..layers {
            #[cfg(feature = "detailed-gated-profile")]
            let matmul_start = self.profile.start(2);
            let g_pre = self.linear(&g_state, &format!("{prefix}.g.{i}"))?;
            let sigma_pre = self.linear(&sigma_state, &format!("{prefix}.sigma.{i}"))?;
            #[cfg(feature = "detailed-gated-profile")]
            self.profile.record_since(
                if i == 0 {
                    "gated_gradient.first_forward_linear_pair"
                } else {
                    "gated_gradient.later_forward_linear_pair"
                },
                matmul_start,
            );
            #[cfg(feature = "detailed-gated-profile")]
            let activation_start = self.profile.start(2);
            let g = if i + 1 == layers && prefix == "final" {
                g_pre.clone()
            } else {
                self.swish(&g_pre)?
            };
            let sigma = if i + 1 == layers {
                self.sigmoid(&sigma_pre)?
            } else {
                self.swish(&sigma_pre)?
            };
            #[cfg(feature = "detailed-gated-profile")]
            {
                self.profile
                    .record_since("gated_gradient.forward_activations", activation_start);
                if self.profile.level() >= 2 {
                    for (input, output) in [(&g_state, &g_pre), (&sigma_state, &sigma_pre)] {
                        self.profile.increment(
                            &format!(
                                "gated_gradient.linear_shape.m{}_k{}_n{}",
                                input.dim(0)?,
                                input.dim(1)?,
                                output.dim(1)?
                            ),
                            1,
                        );
                    }
                    self.profile
                        .increment("gated_gradient.forward_rows", x.dim(0)? as u64);
                    self.profile.increment(
                        "gated_gradient.forward_input_elements",
                        (g_state.elem_count() + sigma_state.elem_count()) as u64,
                    );
                    self.profile.increment(
                        "gated_gradient.forward_output_elements",
                        (g.elem_count() + sigma.elem_count()) as u64,
                    );
                }
            }
            g_state = g.clone();
            sigma_state = sigma.clone();
            saved.push(LayerState {
                g_pre,
                sigma_pre,
                sigma,
                g,
            });
        }

        let last = saved
            .last()
            .ok_or_else(|| candle_core::Error::Msg("gated MLP has zero layers".into()))?;
        let mut g_gradient = output_gradient.mul(&last.sigma)?;
        let mut sigma_gradient = output_gradient.mul(&last.g)?;
        for i in (0..layers).rev() {
            let layer = &saved[i];
            #[cfg(feature = "detailed-gated-profile")]
            let activation_start = self.profile.start(2);
            let g_pre_gradient = if i + 1 == layers && prefix == "final" {
                g_gradient.clone()
            } else {
                let silu_derivative = layer
                    .g_pre
                    .apply_op2_no_bwd(&layer.g, &PyTorchSiluDerivative)?;
                g_gradient.mul(&silu_derivative)?
            };
            let sigma_pre_gradient = if i + 1 == layers {
                sigma_gradient.mul(&layer.sigma.mul(&layer.sigma.affine(-1.0, 1.0)?)?)?
            } else {
                let silu_derivative = layer
                    .sigma_pre
                    .apply_op2_no_bwd(&layer.sigma, &PyTorchSiluDerivative)?;
                sigma_gradient.mul(&silu_derivative)?
            };
            #[cfg(feature = "detailed-gated-profile")]
            self.profile
                .record_since("gated_gradient.backward_activations", activation_start);
            #[cfg(feature = "detailed-gated-profile")]
            let gradient_start = self.profile.start(2);
            g_gradient = self.linear_input_gradient(&g_pre_gradient, &format!("{prefix}.g.{i}"))?;
            sigma_gradient =
                self.linear_input_gradient(&sigma_pre_gradient, &format!("{prefix}.sigma.{i}"))?;
            #[cfg(feature = "detailed-gated-profile")]
            self.profile.record_since(
                if i == 0 {
                    "gated_gradient.first_input_gradient_linear_pair"
                } else {
                    "gated_gradient.later_input_gradient_linear_pair"
                },
                gradient_start,
            );
        }
        Ok(g_gradient.add(&sigma_gradient)?)
    }

    fn rbf(&self, lengths: &Tensor) -> CandleResult<Tensor> {
        let x = lengths.unsqueeze(1)?;
        let x1 = x.broadcast_mul(self.w("rbf.n_1_pi_cutoff"))?;
        let x2 = x.broadcast_mul(self.w("rbf.n_2_pi_cutoff"))?;
        let t1 = x1.sin()?.broadcast_div(&x1)?;
        let t2 = x2.sin()?.broadcast_div(&x2)?;
        let fnr = t1.add(&t2)?.broadcast_mul(self.w("rbf.fnr_weights"))?;
        let mut columns = vec![fnr.narrow(1, 0, 1)?];
        let dn = &self.rbf_dn;
        let en = &self.rbf_en;
        for i in 1..4 {
            let next = fnr
                .narrow(1, i, 1)?
                .add(&columns[i - 1].affine((en[i] / dn[i - 1]).sqrt() as f64, 0.)?)?
                .affine(1. / (dn[i] as f64).sqrt(), 0.)?;
            columns.push(next);
        }
        Tensor::cat(&columns, 1)
    }

    fn polynomial(r: &Tensor, cutoff: f64) -> CandleResult<Tensor> {
        let x = r.affine(1. / cutoff, 0.)?;
        let x3 = x.powf(3.)?;
        let x4 = x3.mul(&x)?;
        let x5 = x4.mul(&x)?;
        let a = x5.affine(-6., 1.)?;
        let b = x4.affine(15., 0.)?;
        a.add(&b)?.sub(&x3.affine(10., 0.)?)?.clamp(0., f64::MAX)
    }

    fn scatter_sum(&self, values: &Tensor, indices: &Tensor, count: usize) -> CandleResult<Tensor> {
        let width = values.dim(1)?;
        let zeros = Tensor::zeros((count, width), values.dtype(), &self.device)?;
        zeros.index_add(indices, values, 0)
    }

    fn graph_tensors(&self, graph: &OrderedGraph) -> CandleResult<GraphTensors> {
        let profile_start = self.profile.start(2);
        let mut cache = self
            .graph_cache
            .lock()
            .map_err(|e| candle_core::Error::Msg(e.to_string()))?;
        if let Some(existing) = cache.as_ref() {
            if existing.source == graph.source
                && existing.destination == graph.destination
                && existing.offsets == graph.offsets
                && existing.first == graph.triple_first
                && existing.second == graph.triple_second
                && existing.species == graph.atomic_numbers
            {
                self.profile.increment("graph_tensor_cache.hit", 1);
                self.profile
                    .record_since("graph_tensor_cache", profile_start);
                return Ok(existing.tensors.clone());
            }
        }
        let n = graph.atomic_numbers.len();
        let e = graph.source.len();
        let t = graph.triple_first.len();
        let second_sources: Vec<u32> = graph
            .triple_second
            .iter()
            .map(|&j| graph.source[j as usize])
            .collect();
        let mut one_hot = vec![0f32; n * 95];
        for (i, &z) in graph.atomic_numbers.iter().enumerate() {
            one_hot[i * 95 + z as usize] = 1.;
        }
        let tensors = GraphTensors {
            source: Tensor::from_vec(graph.source.clone(), e, &self.device)?,
            destination: Tensor::from_vec(graph.destination.clone(), e, &self.device)?,
            first: Tensor::from_vec(graph.triple_first.clone(), t, &self.device)?,
            second: Tensor::from_vec(graph.triple_second.clone(), t, &self.device)?,
            second_sources: Tensor::from_vec(second_sources, t, &self.device)?,
            offsets: Tensor::from_vec(
                graph.offsets.iter().flatten().copied().collect(),
                (e, 3),
                &self.device,
            )?,
            one_hot: Tensor::from_vec(one_hot, (n, 95), &self.device)?,
            species: Tensor::from_vec(graph.atomic_numbers.clone(), n, &self.device)?,
        };
        *cache = Some(GraphCache {
            source: graph.source.clone(),
            destination: graph.destination.clone(),
            offsets: graph.offsets.clone(),
            first: graph.triple_first.clone(),
            second: graph.triple_second.clone(),
            species: graph.atomic_numbers.clone(),
            tensors: tensors.clone(),
        });
        self.profile.increment("graph_tensor_cache.miss", 1);
        // Counts the explicit graph input tensors and cached index/one-hot data.
        self.profile.increment(
            "graph_tensor_cache.explicit_bytes",
            (e * (2 * 4 + 3 * 4) + t * (3 * 4) + n * (95 * 4 + 4)) as u64,
        );
        self.profile
            .record_since("graph_tensor_cache", profile_start);
        Ok(tensors)
    }

    fn forward_block(
        &self,
        graph: &OrderedGraph,
        i: usize,
        mut atom: Tensor,
        mut edge: Tensor,
        pos: &Tensor,
        cell: &Tensor,
    ) -> CandleResult<(Tensor, Tensor)> {
        let n = graph.atomic_numbers.len();
        let e = graph.source.len();
        let cached = self.graph_tensors(graph)?;
        let source = &cached.source;
        let dest = &cached.destination;
        let first = &cached.first;
        let second = &cached.second;
        let offsets = &cached.offsets;
        let from = pos.index_select(&source, 0)?;
        let to = pos.index_select(&dest, 0)?;
        let vector = from.sub(&to.add(&offsets.matmul(cell)?)?)?;
        self.trace("edge_vector", &vector)?;
        let length = if self.device.is_cpu() {
            vector.apply_op1(PyTorchNorm3)?
        } else {
            vector.sqr()?.sum(1)?.sqrt()?
        };
        self.trace("edge_length", &length)?;
        self.trace("edge_length_full", &length)?;
        let vij = vector.index_select(&first, 0)?;
        let vik = vector.index_select(&second, 0)?;
        let rij = length.index_select(&first, 0)?;
        let rik = length.index_select(&second, 0)?;
        self.trace("angle_rij", &rij)?;
        self.trace("angle_rik", &rik)?;
        let cosine_raw = vij.mul(&vik)?.sum(1)?.div(&rij.mul(&rik)?)?;
        self.trace("cosine_raw", &cosine_raw)?;
        let cos = cosine_raw.clamp(-1. + 1e-7, 1. - 1e-7)?;
        self.trace("cosine", &cos)?;
        // MatterSim passes `rik.view(-1)` into the SBF module. Keep a distinct
        // identity node so intermediate-gradient diagnostics compare the same
        // subgraph and do not include the separate angle-denominator path.
        let sbf_rik = rik.affine(1., 0.)?;
        let edge_zero = self.rbf(&length)?;
        let prefix = format!("graph_conv.{i}");
        // MatterSim rebuilds both indexed cutoff paths inside each block.
        // Keep the same graph so reverse accumulation follows the same
        // block order instead of sharing one precomputed cutoff tensor.
        let rij_cutoff = length.index_select(&first, 0)?.affine(1., 0.)?;
        let rik_cutoff = length.index_select(&second, 0)?.affine(1., 0.)?;
        self.trace(&format!("{prefix}.cutoff_rij"), &rij_cutoff)?;
        self.trace(&format!("{prefix}.cutoff_rik"), &rik_cutoff)?;
        let cutoff = Self::polynomial(&rij_cutoff, 4.)?
            .mul(&Self::polynomial(&rik_cutoff, 4.)?)?
            .unsqueeze(1)?;
        self.trace(&format!("graph_conv.{i}.atom_input"), &atom)?;
        let atom_gate_logits = self.linear(&atom, &format!("{prefix}.three_body.atom_mlp"))?;
        self.trace(
            &format!("graph_conv.{i}.atom_gate_logits"),
            &atom_gate_logits,
        )?;
        let gate = self.sigmoid(&atom_gate_logits)?;
        let aggregate = if self.device.is_cpu() && graph.triple_first.len() > 4096 {
            let basis = self.sbf(&sbf_rik, &cos)?;
            self.trace("sbf", &basis)?;
            basis.apply_op3(
                &gate,
                &cutoff,
                checkpoint::TripleAggregate {
                    first: graph.triple_first.clone(),
                    second_sources: cached.second_sources.to_vec1::<u32>()?,
                    edges: e,
                    profile: self.profile.clone(),
                },
            )?
        } else {
            let basis = self.sbf(&sbf_rik, &cos)?;
            self.trace("sbf", &basis)?;
            let gate = gate.index_select(&cached.second_sources, 0)?;
            self.scatter_sum(&basis.mul(&gate)?.broadcast_mul(&cutoff)?, first, e)?
        };
        self.trace(&format!("graph_conv.{i}.aggregate"), &aggregate)?;
        edge =
            edge.add(&self.gated(&aggregate, &format!("{prefix}.three_body.edge_gate_mlp"), 1)?)?;
        self.trace(&format!("graph_conv.{i}.after_three_body"), &edge)?;
        // Both edge and atom updates read the same atom state. Sharing
        // these gathers also combines their reverse scatters.
        let atom_from = atom.index_select(&source, 0)?;
        let atom_to = atom.index_select(&dest, 0)?;

        let edge_gate = self.linear(&edge_zero, &format!("{prefix}.edge_layer_edge"))?;
        self.trace(&format!("graph_conv.{i}.edge_gate"), &edge_gate)?;
        let edge_update = self.gated_edges(
            &atom_from,
            &atom_to,
            &edge,
            &format!("{prefix}.gated_mlp_edge"),
            2,
        )?;
        self.trace(&format!("graph_conv.{i}.edge_update"), &edge_update)?;
        let edge_delta = edge_update.mul(&edge_gate)?;
        self.trace(&format!("graph_conv.{i}.edge_delta"), &edge_delta)?;
        edge = edge.add(&edge_delta)?;
        self.trace(&format!("graph_conv.{i}.after_edge_update"), &edge)?;

        let atom_gate =
            self.swish(&self.linear(&edge_zero, &format!("{prefix}.edge_layer_atom"))?)?;
        let messages = self
            .gated_edges(
                &atom_from,
                &atom_to,
                &edge,
                &format!("{prefix}.gated_mlp_atom"),
                2,
            )?
            .mul(&atom_gate)?;
        atom = atom.add(&self.scatter_sum(&messages, source, n)?)?;
        Ok((atom, edge))
    }

    fn forward_checkpointed(
        &self,
        graph: &OrderedGraph,
        pos: &Tensor,
        cell: &Tensor,
    ) -> CandleResult<Tensor> {
        let profile_total = self.profile.start(1);
        let profile_input = self.profile.start(2);
        let n = graph.atomic_numbers.len();
        let e = graph.source.len();
        let cached = self.graph_tensors(graph)?;
        let vector = pos.index_select(&cached.source, 0)?.sub(
            &pos.index_select(&cached.destination, 0)?
                .add(&cached.offsets.matmul(cell)?)?,
        )?;
        let length = vector.apply_op1(PyTorchNorm3)?;
        let atom = self.linear(&cached.one_hot, "atom_embedding.mlp.0")?;
        let edge_zero = self.rbf(&length)?;
        let edge = self.swish(&self.linear(&edge_zero, "edge_encoder.mlp.0")?)?;
        self.profile
            .record_since("checkpointed.input_features", profile_input);
        let width = atom.dim(1)?;
        let mut state = Tensor::cat(&[atom.flatten_all()?, edge.flatten_all()?], 0)?;
        let geometry = Tensor::cat(&[pos, cell], 0)?;
        let evaluator = std::sync::Arc::new(Self {
            weights: self.weights.clone(),
            device: Device::Cpu,
            num_blocks: self.num_blocks,
            rbf_dn: self.rbf_dn,
            rbf_en: self.rbf_en,
            sbf_factor: self.sbf_factor,
            sbf_coef: self.sbf_coef.clone(),
            graph_cache: Mutex::new(None),
            gradient_trace_nodes: Mutex::new(vec![]),
            profile: self.profile.clone(),
            energy_reduction: self.energy_reduction,
        });
        let shared_graph = std::sync::Arc::new(graph.clone());
        for i in 0..self.num_blocks {
            self.profile.increment("checkpoint.block.forward.calls", 1);
            state = state.apply_op2(
                &geometry,
                checkpoint::BlockCheckpoint {
                    evaluator: evaluator.clone(),
                    graph: shared_graph.clone(),
                    block: i,
                    n,
                    e,
                    width,
                },
            )?;
        }
        let atom = state.narrow(0, 0, n * width)?.reshape((n, width))?;
        let energy = self.gated(&atom, "final", 3)?.squeeze(1)?;
        let result = energy
            .mul(
                &self
                    .w("normalizer.scale")
                    .index_select(&cached.species, 0)?,
            )?
            .add(
                &self
                    .w("normalizer.shift")
                    .index_select(&cached.species, 0)?,
            )?;
        let result = self.sum_energy(&result)?;
        self.profile
            .record_since("forward_checkpointed", profile_total);
        Ok(result)
    }

    fn forward(&self, graph: &OrderedGraph, pos: &Tensor, cell: &Tensor) -> CandleResult<Tensor> {
        #[cfg(not(feature = "uncheckpointed-blocks"))]
        if self.device.is_cpu() && graph.atomic_numbers.len() > 256 {
            return self.forward_checkpointed(graph, pos, cell);
        }
        let forward_start = Instant::now();
        let n = graph.atomic_numbers.len();
        let e = graph.source.len();
        let cached = self.graph_tensors(graph)?;
        let source = &cached.source;
        let dest = &cached.destination;
        let first = &cached.first;
        let second = &cached.second;
        let offsets = &cached.offsets;
        let from = pos.index_select(&source, 0)?;
        let to = pos.index_select(&dest, 0)?;
        let vector = from.sub(&to.add(&offsets.matmul(cell)?)?)?;
        self.trace("edge_vector", &vector)?;
        let length = if self.device.is_cpu() {
            vector.apply_op1(PyTorchNorm3)?
        } else {
            vector.sqr()?.sum(1)?.sqrt()?
        };
        self.trace("edge_length", &length)?;
        self.trace("edge_length_full", &length)?;
        let vij = vector.index_select(&first, 0)?;
        let vik = vector.index_select(&second, 0)?;
        let rij = length.index_select(&first, 0)?;
        let rik = length.index_select(&second, 0)?;
        self.trace("angle_rij", &rij)?;
        self.trace("angle_rik", &rik)?;
        let cosine_raw = vij.mul(&vik)?.sum(1)?.div(&rij.mul(&rik)?)?;
        self.trace("cosine_raw", &cosine_raw)?;
        let cos = cosine_raw.clamp(-1. + 1e-7, 1. - 1e-7)?;
        self.trace("cosine", &cos)?;
        // MatterSim passes `rik.view(-1)` into the SBF module. Keep a distinct
        // identity node so intermediate-gradient diagnostics compare the same
        // subgraph and do not include the separate angle-denominator path.
        let sbf_rik = rik.affine(1., 0.)?;
        let basis = self.sbf(&sbf_rik, &cos)?;
        self.trace("sbf", &basis)?;
        let mut atom = self.linear(&cached.one_hot, "atom_embedding.mlp.0")?;
        self.trace("atom_embedding", &atom)?;
        let length_rbf = length.affine(1., 0.)?;
        self.trace("length_rbf", &length_rbf)?;
        let edge_zero = self.rbf(&length_rbf)?;
        self.trace("rbf", &edge_zero)?;
        let mut edge = self.swish(&self.linear(&edge_zero, "edge_encoder.mlp.0")?)?;
        if std::env::var_os("MACER_RUST_TIMING").is_some() {
            eprintln!(
                "TIMING featurize {:.6}",
                forward_start.elapsed().as_secs_f64()
            );
        }
        self.trace("edge_encoder", &edge)?;
        for i in 0..self.num_blocks {
            let block_start = Instant::now();
            let prefix = format!("graph_conv.{i}");
            // MatterSim rebuilds both indexed cutoff paths inside each block.
            // Keep the same graph so reverse accumulation follows the same
            // block order instead of sharing one precomputed cutoff tensor.
            let rij_cutoff = length.index_select(&first, 0)?.affine(1., 0.)?;
            let rik_cutoff = length.index_select(&second, 0)?.affine(1., 0.)?;
            self.trace(&format!("{prefix}.cutoff_rij"), &rij_cutoff)?;
            self.trace(&format!("{prefix}.cutoff_rik"), &rik_cutoff)?;
            let cutoff = Self::polynomial(&rij_cutoff, 4.)?
                .mul(&Self::polynomial(&rik_cutoff, 4.)?)?
                .unsqueeze(1)?;
            self.trace(&format!("graph_conv.{i}.atom_input"), &atom)?;
            let atom_gate_logits = self.linear(&atom, &format!("{prefix}.three_body.atom_mlp"))?;
            self.trace(
                &format!("graph_conv.{i}.atom_gate_logits"),
                &atom_gate_logits,
            )?;
            let gate = self.sigmoid(&atom_gate_logits)?;
            let aggregate = if self.device.is_cpu() && graph.triple_first.len() > 4096 {
                basis.apply_op3(
                    &gate,
                    &cutoff,
                    checkpoint::TripleAggregate {
                        first: graph.triple_first.clone(),
                        second_sources: cached.second_sources.to_vec1::<u32>()?,
                        edges: e,
                        profile: self.profile.clone(),
                    },
                )?
            } else {
                let gate = gate.index_select(&cached.second_sources, 0)?;
                self.scatter_sum(&basis.mul(&gate)?.broadcast_mul(&cutoff)?, first, e)?
            };
            self.trace(&format!("graph_conv.{i}.aggregate"), &aggregate)?;
            edge = edge.add(&self.gated(
                &aggregate,
                &format!("{prefix}.three_body.edge_gate_mlp"),
                1,
            )?)?;
            self.trace(&format!("graph_conv.{i}.after_three_body"), &edge)?;
            // Both edge and atom updates read the same atom state. Sharing
            // these gathers also combines their reverse scatters.
            let atom_from = atom.index_select(&source, 0)?;
            let atom_to = atom.index_select(&dest, 0)?;

            let edge_gate = self.linear(&edge_zero, &format!("{prefix}.edge_layer_edge"))?;
            self.trace(&format!("graph_conv.{i}.edge_gate"), &edge_gate)?;
            let edge_update = self.gated_edges(
                &atom_from,
                &atom_to,
                &edge,
                &format!("{prefix}.gated_mlp_edge"),
                2,
            )?;
            self.trace(&format!("graph_conv.{i}.edge_update"), &edge_update)?;
            let edge_delta = edge_update.mul(&edge_gate)?;
            self.trace(&format!("graph_conv.{i}.edge_delta"), &edge_delta)?;
            edge = edge.add(&edge_delta)?;
            self.trace(&format!("graph_conv.{i}.after_edge_update"), &edge)?;

            let atom_gate =
                self.swish(&self.linear(&edge_zero, &format!("{prefix}.edge_layer_atom"))?)?;
            let messages = self
                .gated_edges(
                    &atom_from,
                    &atom_to,
                    &edge,
                    &format!("{prefix}.gated_mlp_atom"),
                    2,
                )?
                .mul(&atom_gate)?;
            atom = atom.add(&self.scatter_sum(&messages, source, n)?)?;
            if std::env::var_os("MACER_RUST_TIMING").is_some() {
                eprintln!(
                    "TIMING block.{i} {:.6}",
                    block_start.elapsed().as_secs_f64()
                );
            }
            self.trace(&format!("graph_conv.{i}.atom"), &atom)?;
            self.trace(&format!("graph_conv.{i}.edge"), &edge)?;
        }
        let atomic_energy = self.gated(&atom, "final", 3)?.squeeze(1)?;
        self.trace("final", &atomic_energy)?;
        let scale = self
            .w("normalizer.scale")
            .index_select(&cached.species, 0)?;
        let shift = self
            .w("normalizer.shift")
            .index_select(&cached.species, 0)?;
        let normalized = atomic_energy.mul(&scale)?.add(&shift)?;
        self.trace("normalizer", &normalized)?;
        self.sum_energy(&normalized)
    }

    pub fn evaluate(&self, graph: &OrderedGraph) -> std::result::Result<ModelEvaluation, String> {
        let profile_total = self.profile.start(1);
        graph.validate()?;
        let trace_gradients = std::env::var_os("MACER_RUST_TRACE_GRAD").is_some();
        if trace_gradients {
            self.gradient_trace_nodes
                .lock()
                .map_err(|e| e.to_string())?
                .clear();
        }
        let start = Instant::now();
        let n = graph.atomic_numbers.len();
        let positions = Var::from_vec(
            graph.positions_a.iter().flatten().copied().collect(),
            (n, 3),
            &self.device,
        )
        .map_err(|e| e.to_string())?;
        let strain =
            Var::zeros((3, 3), candle_core::DType::F32, &self.device).map_err(|e| e.to_string())?;
        let identity =
            Tensor::eye(3, candle_core::DType::F32, &self.device).map_err(|e| e.to_string())?;
        let deformation = identity.add(&strain).map_err(|e| e.to_string())?;
        let pos = positions.matmul(&deformation).map_err(|e| e.to_string())?;
        let cell0 = Tensor::from_vec(
            graph.cell_a.iter().flatten().copied().collect(),
            (3, 3),
            &self.device,
        )
        .map_err(|e| e.to_string())?;
        let cell = cell0.matmul(&deformation).map_err(|e| e.to_string())?;
        let profile_forward = self.profile.start(1);
        let energy = self
            .forward(graph, &pos, &cell)
            .map_err(|e| e.to_string())?;
        self.profile.record_since("model_forward", profile_forward);
        if std::env::var_os("MACER_RUST_TIMING").is_some() {
            eprintln!("TIMING forward {:.6}", start.elapsed().as_secs_f64());
        }
        let value = energy.to_scalar::<f32>().map_err(|e| e.to_string())?;
        let backward_start = Instant::now();
        let profile_backward = self.profile.start(1);
        let detailed_backward = self.profile.level() >= 2;
        candle_core::backprop::enable_backward_profile(detailed_backward);
        #[cfg(feature = "consuming-checkpoint-backward")]
        let backward_result = if trace_gradients {
            // Diagnostic clients may retain intermediate graph nodes.
            energy.backward()
        } else {
            let seed = energy
                .ones_like()
                .and_then(|seed| seed.contiguous())
                .map_err(|e| e.to_string())?;
            energy.backward_consuming_with_gradient(&seed)
        };
        #[cfg(not(feature = "consuming-checkpoint-backward"))]
        let backward_result = energy.backward();
        let backward_op_timings = candle_core::backprop::take_backward_profile();
        candle_core::backprop::enable_backward_profile(false);
        let gradients = backward_result.map_err(|e| e.to_string())?;
        self.profile
            .record_since("model_backward", profile_backward);
        for (name, elapsed_ms, calls) in backward_op_timings {
            self.profile
                .record_aggregate_ms(&format!("backward_op.{name}"), elapsed_ms, calls);
        }
        if trace_gradients {
            let nodes = std::mem::take(
                &mut *self
                    .gradient_trace_nodes
                    .lock()
                    .map_err(|e| e.to_string())?,
            );
            for (name, tensor) in nodes {
                let Some(gradient) = gradients.get(&tensor) else {
                    eprintln!(
                        "TRACEGRADJSON {}",
                        serde_json::json!({"name":name,"missing":true})
                    );
                    continue;
                };
                let values = gradient
                    .flatten_all()
                    .map_err(|e| e.to_string())?
                    .to_vec1::<f32>()
                    .map_err(|e| e.to_string())?;
                eprintln!(
                    "TRACEGRADJSON {}",
                    serde_json::json!({"name":name,"shape":gradient.dims(),"values":values})
                );
            }
        }
        if std::env::var_os("MACER_RUST_TIMING").is_some() {
            eprintln!(
                "TIMING backward {:.6}",
                backward_start.elapsed().as_secs_f64()
            );
        }
        // A structure with no neighbors has an energy that is independent of
        // positions and strain. Autodiff omits those zero gradients entirely;
        // interpret the omitted derivatives as zero force and stress.
        let force = if let Some(gradient) = gradients.get(&positions) {
            gradient.to_vec2::<f32>().map_err(|e| e.to_string())?
        } else {
            vec![vec![0.; 3]; n]
        };
        let strain_grad = if let Some(gradient) = gradients.get(&strain) {
            gradient.to_vec2::<f32>().map_err(|e| e.to_string())?
        } else {
            vec![vec![0.; 3]; 3]
        };
        let a = graph.cell_a;
        let volume = a[0][0] * (a[1][1] * a[2][2] - a[1][2] * a[2][1])
            - a[0][1] * (a[1][0] * a[2][2] - a[1][2] * a[2][0])
            + a[0][2] * (a[1][0] * a[2][1] - a[1][1] * a[2][0]);
        if volume.abs() < 1e-12 {
            return Err("cell volume is zero".into());
        }
        let result = ModelEvaluation {
            energy_ev: value,
            forces_ev_a: force.iter().map(|r| [-r[0], -r[1], -r[2]]).collect(),
            stress_ev_a3: std::array::from_fn(|i| {
                std::array::from_fn(|j| strain_grad[i][j] / volume)
            }),
        };
        self.profile.record_since("evaluation_total", profile_total);
        Ok(result)
    }

    fn sbf(&self, length: &Tensor, cosine: &Tensor) -> CandleResult<Tensor> {
        if self.device.is_cpu() && length.elem_count() > 4096 {
            let evaluator = std::sync::Arc::new(Self {
                weights: self.weights.clone(),
                device: Device::Cpu,
                num_blocks: self.num_blocks,
                rbf_dn: self.rbf_dn,
                rbf_en: self.rbf_en,
                sbf_factor: self.sbf_factor,
                sbf_coef: self.sbf_coef.clone(),
                graph_cache: Mutex::new(None),
                gradient_trace_nodes: Mutex::new(Vec::new()),
                profile: self.profile.clone(),
                energy_reduction: self.energy_reduction,
            });
            self.profile.increment("checkpoint.sbf.calls", 1);
            return length.contiguous()?.apply_op2(
                &cosine.contiguous()?,
                checkpoint::BasisCheckpoint { evaluator },
            );
        }
        self.sbf_direct(length, cosine)
    }

    fn sbf_direct(&self, length: &Tensor, cosine: &Tensor) -> CandleResult<Tensor> {
        #[cfg(feature = "fused-sbf-forward")]
        if self.device.is_cpu() {
            let evaluator = std::sync::Arc::new(Self {
                weights: self.weights.clone(),
                device: Device::Cpu,
                num_blocks: self.num_blocks,
                rbf_dn: self.rbf_dn,
                rbf_en: self.rbf_en,
                sbf_factor: self.sbf_factor,
                sbf_coef: self.sbf_coef.clone(),
                graph_cache: Mutex::new(None),
                gradient_trace_nodes: Mutex::new(Vec::new()),
                profile: self.profile.clone(),
                energy_reduction: self.energy_reduction,
            });
            return length
                .contiguous()?
                .apply_op2(&cosine.contiguous()?, FusedSbfForward { evaluator });
        }
        self.sbf_direct_reference(length, cosine)
    }

    fn sbf_direct_reference(&self, length: &Tensor, cosine: &Tensor) -> CandleResult<Tensor> {
        // MatterSim's fixed spherical Bessel coefficients. The JSON is generated
        // from SphericalBasisLayer(4, 4, 5).coef in the reference installation.
        let coef = &self.sbf_coef;
        let r = length.affine(0.2, 0.)?;
        let r2 = r.sqr()?;
        let r3 = r2.mul(&r)?;
        let r4 = r3.mul(&r)?;
        // MatterSim explicitly computes acos(cosine), then applies cos again
        // inside its spherical-harmonic basis. Keep that float32 derivative
        // path instead of simplifying cos(acos(x)) to x: near +/-1 the
        // cancellation changes force gradients measurably.
        self.trace("sbf_r", length)?;
        let theta = cosine.apply_op1(PyTorchAcos)?;
        self.trace("sbf_theta", &theta)?;
        let harmonic_cosine = theta.cos()?;
        let c2 = harmonic_cosine.sqr()?;
        let harmonic = [
            harmonic_cosine.affine(0., 0.5 * (1. / std::f64::consts::PI).sqrt())?,
            harmonic_cosine.affine((3. / (4. * std::f64::consts::PI)).sqrt(), 0.)?,
            c2.affine(3., -1.)?
                .affine((5. / (16. * std::f64::consts::PI)).sqrt(), 0.)?,
            harmonic_cosine
                .mul(&c2.affine(5., -3.)?)?
                .affine((7. / (16. * std::f64::consts::PI)).sqrt(), 0.)?,
        ];
        let factor = self.sbf_factor as f64;
        let mut columns = Vec::with_capacity(16);
        for l in 0..4 {
            for j in 0..4 {
                let p = |k: usize| coef[l][k][j] as f64;
                let radial = match l {
                    0 => r.affine(p(0), 0.)?.sin()?.div(&r)?,
                    1 => {
                        let a = r.affine(p(0), 0.)?.mul(&r.affine(p(1), 0.)?.cos()?)?;
                        let b = r.affine(p(3), 0.)?.sin()?.affine(p(2), 0.)?;
                        a.add(&b)?.div(&r2)?
                    }
                    2 => {
                        let a = r2.affine(p(0), 0.)?.mul(&r.affine(p(1), 0.)?.sin()?)?;
                        let b = r.affine(p(2), 0.)?.mul(&r.affine(p(3), 0.)?.cos()?)?;
                        let c = r.affine(p(5), 0.)?.sin()?.affine(p(4), 0.)?;
                        a.sub(&b)?.add(&c)?.div(&r3)?
                    }
                    _ => {
                        let a = r3.affine(p(0), 0.)?.mul(&r.affine(p(1), 0.)?.cos()?)?;
                        let b = r2.affine(p(2), 0.)?.mul(&r.affine(p(3), 0.)?.sin()?)?;
                        let c = r.affine(p(4), 0.)?.mul(&r.affine(p(5), 0.)?.cos()?)?;
                        let d = r.affine(p(7), 0.)?.sin()?.affine(p(6), 0.)?;
                        a.sub(&b)?.sub(&c)?.add(&d)?.div(&r4)?
                    }
                };
                columns.push(radial.mul(&harmonic[l])?.affine(factor, 0.)?.unsqueeze(1)?);
            }
        }
        Tensor::cat(&columns, 1)
    }

    #[cfg(feature = "fused-sbf-forward")]
    fn sbf_forward_fused(&self, lengths: &[f32], cosines: &[f32]) -> CandleResult<Vec<f32>> {
        if lengths.len() != cosines.len() {
            candle_core::bail!("spherical-basis input length mismatch")
        }
        let mut output = vec![0.0f32; lengths.len() * 16];
        let norms = [
            (0.5 * (1.0 / std::f64::consts::PI).sqrt()) as f32,
            (3.0 / (4.0 * std::f64::consts::PI)).sqrt() as f32,
            (5.0 / (16.0 * std::f64::consts::PI)).sqrt() as f32,
            (7.0 / (16.0 * std::f64::consts::PI)).sqrt() as f32,
        ];
        let factor = self.sbf_factor;
        for row in 0..lengths.len() {
            let r = lengths[row] * 0.2f32;
            let r2 = r * r;
            let r3 = r2 * r;
            let r4 = r3 * r;
            let h = cosines[row].acos().cos();
            let h2 = h * h;
            let harmonics = [
                norms[0],
                h * norms[1],
                (h2 * 3.0f32 - 1.0f32) * norms[2],
                (h * (h2 * 5.0f32 - 3.0f32)) * norms[3],
            ];
            for l in 0..4 {
                for j in 0..4 {
                    let p = |k: usize| self.sbf_coef[l][k][j];
                    let radial = match l {
                        0 => (r * p(0)).sin() / r,
                        1 => {
                            let a = (r * p(0)) * (r * p(1)).cos();
                            let b = (r * p(3)).sin() * p(2);
                            (a + b) / r2
                        }
                        2 => {
                            let a = (r2 * p(0)) * (r * p(1)).sin();
                            let b = (r * p(2)) * (r * p(3)).cos();
                            let c = (r * p(5)).sin() * p(4);
                            ((a - b) + c) / r3
                        }
                        _ => {
                            let a = (r3 * p(0)) * (r * p(1)).cos();
                            let b = (r2 * p(2)) * (r * p(3)).sin();
                            let c = (r * p(4)) * (r * p(5)).cos();
                            let d = (r * p(7)).sin() * p(6);
                            (((a - b) - c) + d) / r4
                        }
                    };
                    output[row * 16 + l * 4 + j] = (radial * harmonics[l]) * factor;
                }
            }
        }
        Ok(output)
    }

    #[cfg(feature = "analytic-sbf-backward")]
    fn sbf_input_gradient_direct(
        &self,
        length: &Tensor,
        cosine: &Tensor,
        output_gradient: &Tensor,
    ) -> CandleResult<(Tensor, Tensor)> {
        let lengths = length.flatten_all()?.to_vec1::<f32>()?;
        let cosines = cosine.flatten_all()?.to_vec1::<f32>()?;
        let upstream = output_gradient.flatten_all()?.to_vec1::<f32>()?;
        if lengths.len() != cosines.len() || upstream.len() != lengths.len() * 16 {
            candle_core::bail!("spherical-basis gradient shape mismatch")
        }

        // Spherical-Bessel radial numerators cancel strongly near zero. Use
        // f64 for the closed-form derivative, then return the model's f32
        // gradient, avoiding catastrophic f32 quotient-rule cancellation.
        let mut length_gradient = vec![0.0_f64; lengths.len()];
        let mut cosine_gradient = vec![0.0_f64; lengths.len()];
        let scale = self.sbf_factor as f64;
        let norm0 = 0.5 * (1.0 / std::f64::consts::PI).sqrt();
        let norm1 = (3.0 / (4.0 * std::f64::consts::PI)).sqrt();
        let norm2 = (5.0 / (16.0 * std::f64::consts::PI)).sqrt();
        let norm3 = (7.0 / (16.0 * std::f64::consts::PI)).sqrt();

        for row in 0..lengths.len() {
            let x = lengths[row] as f64 * 0.2;
            let x2 = x * x;
            let x3 = x2 * x;
            let x4 = x3 * x;
            let cosine_value = cosines[row] as f64;
            let theta = cosine_value.acos();
            let h = theta.cos();
            // This preserves the acos -> cos derivative path used by the
            // reference implementation instead of simplifying cos(acos(x)).
            let dh_dc = theta.sin() / (1.0 - cosine_value * cosine_value).sqrt();
            let harmonics = [
                norm0,
                norm1 * h,
                norm2 * (3.0 * h * h - 1.0),
                norm3 * h * (5.0 * h * h - 3.0),
            ];
            let harmonic_derivatives = [0.0, norm1, norm2 * 6.0 * h, norm3 * (15.0 * h * h - 3.0)];

            for l in 0..4 {
                for j in 0..4 {
                    let p = |k: usize| self.sbf_coef[l][k][j] as f64;
                    let (radial, radial_dx) = match l {
                        0 => {
                            let arg = p(0) * x;
                            let numerator = arg.sin();
                            let derivative = p(0) * arg.cos();
                            (numerator / x, (derivative * x - numerator) / x2)
                        }
                        1 => {
                            let a = x * p(0) * (x * p(1)).cos();
                            let b = p(2) * (x * p(3)).sin();
                            let numerator = a + b;
                            let derivative = p(0) * (x * p(1)).cos()
                                - x * p(0) * p(1) * (x * p(1)).sin()
                                + p(2) * p(3) * (x * p(3)).cos();
                            (numerator / x2, (derivative * x - 2.0 * numerator) / x3)
                        }
                        2 => {
                            let a = x2 * p(0) * (x * p(1)).sin();
                            let b = x * p(2) * (x * p(3)).cos();
                            let c = p(4) * (x * p(5)).sin();
                            let numerator = a - b + c;
                            let derivative = 2.0 * x * p(0) * (x * p(1)).sin()
                                + x2 * p(0) * p(1) * (x * p(1)).cos()
                                - p(2) * (x * p(3)).cos()
                                + x * p(2) * p(3) * (x * p(3)).sin()
                                + p(4) * p(5) * (x * p(5)).cos();
                            (numerator / x3, (derivative * x - 3.0 * numerator) / x4)
                        }
                        _ => {
                            let a = x3 * p(0) * (x * p(1)).cos();
                            let b = x2 * p(2) * (x * p(3)).sin();
                            let c = x * p(4) * (x * p(5)).cos();
                            let d = p(6) * (x * p(7)).sin();
                            let numerator = a - b - c + d;
                            let derivative = 3.0 * x2 * p(0) * (x * p(1)).cos()
                                - x3 * p(0) * p(1) * (x * p(1)).sin()
                                - 2.0 * x * p(2) * (x * p(3)).sin()
                                - x2 * p(2) * p(3) * (x * p(3)).cos()
                                - p(4) * (x * p(5)).cos()
                                + x * p(4) * p(5) * (x * p(5)).sin()
                                + p(6) * p(7) * (x * p(7)).cos();
                            (
                                numerator / x4,
                                (derivative * x - 4.0 * numerator) / (x4 * x),
                            )
                        }
                    };
                    let channel = l * 4 + j;
                    let weight = upstream[row * 16 + channel];
                    length_gradient[row] += weight as f64 * scale * radial_dx * 0.2 * harmonics[l];
                    cosine_gradient[row] +=
                        weight as f64 * scale * radial * harmonic_derivatives[l] * dh_dc;
                }
            }
        }

        Ok((
            Tensor::from_vec(
                length_gradient
                    .into_iter()
                    .map(|value| value as f32)
                    .collect(),
                length.shape(),
                length.device(),
            )?,
            Tensor::from_vec(
                cosine_gradient
                    .into_iter()
                    .map(|value| value as f32)
                    .collect(),
                cosine.shape(),
                cosine.device(),
            )?,
        ))
    }
}

#[cfg(feature = "fused-sbf-forward")]
struct FusedSbfForward {
    evaluator: std::sync::Arc<Evaluator>,
}

#[cfg(feature = "fused-sbf-forward")]
impl CustomOp2 for FusedSbfForward {
    fn name(&self) -> &'static str {
        "mattersim-fused-sbf-forward"
    }

    fn cpu_fwd(
        &self,
        length: &CpuStorage,
        length_layout: &Layout,
        cosine: &CpuStorage,
        cosine_layout: &Layout,
    ) -> CandleResult<(CpuStorage, Shape)> {
        let (CpuStorage::F32(length), CpuStorage::F32(cosine)) = (length, cosine) else {
            candle_core::bail!("fused SBF forward requires f32 CPU tensors")
        };
        let (ls, le) = length_layout
            .contiguous_offsets()
            .ok_or_else(|| candle_core::Error::Msg("noncontiguous SBF length".into()))?;
        let (cs, ce) = cosine_layout
            .contiguous_offsets()
            .ok_or_else(|| candle_core::Error::Msg("noncontiguous SBF cosine".into()))?;
        if le - ls != ce - cs {
            candle_core::bail!("spherical-basis input length mismatch")
        }
        let values = self
            .evaluator
            .sbf_forward_fused(&length[ls..le], &cosine[cs..ce])?;
        let rows = le - ls;
        Ok((CpuStorage::F32(values), Shape::from((rows, 16))))
    }

    fn bwd(
        &self,
        length: &Tensor,
        cosine: &Tensor,
        _result: &Tensor,
        output_gradient: &Tensor,
    ) -> CandleResult<(Option<Tensor>, Option<Tensor>)> {
        let (length_gradient, cosine_gradient) = self.evaluator.sbf_input_gradient_direct(
            &length.detach(),
            &cosine.detach(),
            &output_gradient.detach(),
        )?;
        Ok((Some(length_gradient), Some(cosine_gradient)))
    }
}

#[cfg(test)]
mod tests {
    use super::Evaluator;
    use super::{EnergyReduction, OrderedGraph, PyTorchNorm3, PyTorchSigmoid, PyTorchSilu};
    use candle_core::{Device, Result, Tensor, Var};
    use macer_rust_core::types::Structure;

    #[test]
    fn cpu_empty_narrow_first_order_gradient_accumulation() -> Result<()> {
        let input = Var::zeros((0, 3), candle_core::DType::F32, &Device::Cpu)?;
        let narrow = input.narrow(1, 1, 1)?;
        assert_eq!(narrow.layout().start_offset(), 1);
        assert_eq!(narrow.layout().contiguous_offsets(), Some((0, 0)));
        let loss = narrow.sqr()?.sum_all()?.add(&narrow.sum_all()?)?;
        let gradients = loss.backward()?;
        let gradient = gradients.get(&input).expect("empty input gradient");
        assert_eq!(gradient.dims(), &[0, 3]);
        assert_eq!(gradient.elem_count(), 0);
        Ok(())
    }

    #[test]
    fn nonperiodic_graph_uses_a_finite_helper_cell_without_images() {
        let structure = Structure {
            atomic_numbers: vec![1, 1],
            positions_a: vec![[-1.0, 0.0, 0.0], [1.0, 0.0, 0.0]],
            cell_a: [[0.0; 3]; 3],
            pbc: [false; 3],
        };
        let graph = OrderedGraph::from_structure(&structure).unwrap();
        assert!(graph.cell_a[0][0] > 0.0);
        assert!(graph.offsets.iter().all(|offset| *offset == [0.0; 3]));
        assert!(graph.source.iter().any(|&atom| atom == 0));
        assert!(graph.destination.iter().any(|&atom| atom == 1));
    }

    #[test]
    fn nonperiodic_graph_accepts_isolated_atoms_and_zero_edge_pairs() {
        for (atomic_numbers, positions_a) in [
            (vec![14], vec![[0.0, 0.0, 0.0]]),
            (vec![14, 14], vec![[0.0, 0.0, 0.0], [6.0, 0.0, 0.0]]),
        ] {
            let structure = Structure {
                atomic_numbers,
                positions_a,
                cell_a: [[0.0; 3]; 3],
                pbc: [false; 3],
            };
            let graph = OrderedGraph::from_structure(&structure).unwrap();
            graph.validate().unwrap();
            assert!(graph.source.is_empty());
            assert!(graph.destination.is_empty());
            assert!(graph.offsets.is_empty());
            assert!(graph.triple_first.is_empty());
            assert!(graph.triple_second.is_empty());
        }
    }

    #[test]
    fn reference_scatter_energy_sum_matches_pinned_torch_and_gradient() -> Result<()> {
        // Golden computed by Torch2.5.1 CPU scatter_add; binary fractions avoid
        // language-dependent initialization rounding. Tensor.sum gives a
        // different value, the actual large-structure parity regression.
        let values = (0..3456)
            .map(|i| -7.125f32 + (i % 19) as f32 * 0.0001220703125)
            .collect::<Vec<_>>();
        let input = Var::from_vec(values, 3456, &Device::Cpu)?;
        let output = input.apply_op1(super::ReferenceEnergySum)?;
        assert_eq!(output.to_scalar::<f32>()?, -24620.41796875f32);
        let gradients = output.affine(2.5, 0.)?.backward()?;
        assert!(gradients
            .get(&input)
            .unwrap()
            .to_vec1::<f32>()?
            .iter()
            .all(|x| *x == 2.5));
        Ok(())
    }

    #[test]
    fn balanced_f32_energy_sum_reduces_large_roundoff_and_preserves_gradient() -> Result<()> {
        let values = (0..3456)
            .map(|i| -7.1234f32 + (i % 19) as f32 * 0.0001234)
            .collect::<Vec<_>>();
        let reference = values.iter().map(|x| *x as f64).sum::<f64>();
        let scalar = values.iter().fold(0f32, |a, b| a + b);
        let input = Var::from_vec(values, 3456, &Device::Cpu)?;
        let output = input.apply_op1(super::PairwiseEnergySum)?;
        let balanced = output.to_scalar::<f32>()?;
        assert!((balanced as f64 - reference).abs() < 0.004);
        assert!((balanced as f64 - reference).abs() < (scalar as f64 - reference).abs());
        let gradients = output.backward()?;
        assert!(gradients
            .get(&input)
            .unwrap()
            .to_vec1::<f32>()?
            .iter()
            .all(|x| *x == 1.));
        Ok(())
    }

    #[test]
    fn factor_linear_without_dense_weight_matches_forward_and_input_gradient() -> Result<()> {
        let device = Device::Cpu;
        let down = Tensor::from_vec(vec![0.2f32, -0.3, 0.7, 0.4, 0.1, -0.2], (2, 3), &device)?;
        let up = Tensor::from_vec(
            vec![0.5f32, -0.1, 0.3, 0.8, -0.6, 0.2, 0.4, 0.9],
            (4, 2),
            &device,
        )?;
        let bias = Tensor::from_vec(vec![0.1f32, 0.2, -0.3, 0.4], 4, &device)?;
        let evaluator = Evaluator {
            weights: std::collections::HashMap::from([
                ("test.linear.down.weight".into(), down.clone()),
                ("test.linear.up.weight".into(), up.clone()),
                ("test.linear.bias".into(), bias.clone()),
            ]),
            device: device.clone(),
            num_blocks: 0,
            rbf_dn: [0.; 4],
            rbf_en: [0.; 4],
            sbf_factor: 1.,
            sbf_coef: serde_json::from_str(include_str!("sbf_coefficients.json")).unwrap(),
            graph_cache: std::sync::Mutex::new(None),
            gradient_trace_nodes: std::sync::Mutex::new(Vec::new()),
            profile: std::sync::Arc::new(crate::evaluation::profile::ProfileCollector::default()),
            energy_reduction: EnergyReduction::Default,
        };
        // Dense reconstruction exists only here as an independent test oracle.
        let dense = up.matmul(&down)?;
        let x = Var::from_vec(vec![0.1f32, 0.3, -0.5, 0.7, -0.2, 0.4], (2, 3), &device)?;
        let upstream = Tensor::from_vec(
            vec![0.2f32, -0.4, 0.6, 0.1, 0.7, 0.3, -0.5, 0.8],
            (2, 4),
            &device,
        )?;
        let actual = evaluator.linear(x.as_tensor(), "test")?;
        let expected = x.matmul(&dense.t()?)?.broadcast_add(&bias)?;
        for (a, b) in actual
            .flatten_all()?
            .to_vec1::<f32>()?
            .iter()
            .zip(expected.flatten_all()?.to_vec1::<f32>()?)
        {
            assert!((a - b).abs() < 1e-6);
        }
        let gradient = actual.mul(&upstream)?.sum_all()?.backward()?;
        let expected_gradient = upstream.matmul(&dense)?;
        let compare = |a: &Tensor| -> Result<()> {
            for (a, b) in a
                .flatten_all()?
                .to_vec1::<f32>()?
                .iter()
                .zip(expected_gradient.flatten_all()?.to_vec1::<f32>()?)
            {
                assert!((a - b).abs() < 1e-6);
            }
            Ok(())
        };
        compare(gradient.get(&x).unwrap())?;
        #[cfg(feature = "analytic-gated-backward")]
        compare(&evaluator.linear_input_gradient(&upstream, "test")?)?;
        Ok(())
    }

    #[cfg(feature = "analytic-sbf-backward")]
    #[test]
    fn analytic_sbf_gradient_matches_candle_autograd() -> Result<()> {
        let evaluator = Evaluator {
            weights: std::collections::HashMap::new(),
            device: Device::Cpu,
            num_blocks: 0,
            rbf_dn: [0.0; 4],
            rbf_en: [0.0; 4],
            sbf_factor: 1.0,
            sbf_coef: serde_json::from_str(include_str!("sbf_coefficients.json")).unwrap(),
            graph_cache: std::sync::Mutex::new(None),
            gradient_trace_nodes: std::sync::Mutex::new(Vec::new()),
            profile: std::sync::Arc::new(crate::evaluation::profile::ProfileCollector::default()),
            energy_reduction: EnergyReduction::Default,
        };
        let count = 257;
        let lengths: Vec<f32> = (0..count)
            .map(|i| 0.35 + (i % 113) as f32 * 0.019)
            .collect();
        let cosines: Vec<f32> = (0..count)
            .map(|i| -0.91 + (i % 181) as f32 * 0.0101)
            .collect();
        let upstream: Vec<f32> = (0..count * 16)
            .map(|i| ((i % 29) as f32 - 14.0) / 17.0)
            .collect();
        let length = Var::from_vec(lengths, count, &Device::Cpu)?;
        let cosine = Var::from_vec(cosines, count, &Device::Cpu)?;
        let gradient = Tensor::from_vec(upstream, (count, 16), &Device::Cpu)?;
        let output = evaluator.sbf_direct_reference(&length, &cosine)?;
        let reference_loss = output.mul(&gradient)?.sum_all()?;
        let reference = reference_loss.backward()?;
        let expected_length = reference.get(&length).unwrap().to_vec1::<f32>()?;
        let expected_cosine = reference.get(&cosine).unwrap().to_vec1::<f32>()?;
        let (actual_length, actual_cosine) = evaluator.sbf_input_gradient_direct(
            length.as_tensor(),
            cosine.as_tensor(),
            &gradient,
        )?;
        let actual_length = actual_length.to_vec1::<f32>()?;
        let actual_cosine = actual_cosine.to_vec1::<f32>()?;
        for (name, actual, expected) in [
            ("length", actual_length, expected_length),
            ("cosine", actual_cosine, expected_cosine),
        ] {
            let (max_index, max_error) = actual
                .iter()
                .zip(&expected)
                .enumerate()
                .map(|(i, (a, b))| (i, (a - b).abs()))
                .max_by(|a, b| a.1.total_cmp(&b.1))
                .unwrap_or((0, 0.0));
            assert!(
                max_error <= 1e-4 * expected[max_index].abs().max(1.0),
                "{name} gradient max error {max_error} at {max_index}: {} vs {}",
                actual[max_index],
                expected[max_index]
            );
        }
        #[cfg(feature = "fused-sbf-forward")]
        {
            let fused_length = Var::from_vec(
                (0..count)
                    .map(|i| 0.35 + (i % 113) as f32 * 0.019)
                    .collect::<Vec<_>>(),
                count,
                &Device::Cpu,
            )?;
            let fused_cosine = Var::from_vec(
                (0..count)
                    .map(|i| -0.91 + (i % 181) as f32 * 0.0101)
                    .collect::<Vec<_>>(),
                count,
                &Device::Cpu,
            )?;
            let fused = evaluator.sbf_direct(&fused_length, &fused_cosine)?;
            let reference_values = output.flatten_all()?.to_vec1::<f32>()?;
            let fused_values = fused.flatten_all()?.to_vec1::<f32>()?;
            let max_output_error = reference_values
                .iter()
                .zip(&fused_values)
                .map(|(a, b)| (a - b).abs())
                .fold(0.0f32, f32::max);
            assert!(
                max_output_error <= 2e-6,
                "fused SBF output error {max_output_error}"
            );
            let fused_grads = fused.mul(&gradient)?.sum_all()?.backward()?;
            for (name, actual, expected) in [
                (
                    "length",
                    fused_grads.get(&fused_length).unwrap().to_vec1::<f32>()?,
                    reference.get(&length).unwrap().to_vec1::<f32>()?,
                ),
                (
                    "cosine",
                    fused_grads.get(&fused_cosine).unwrap().to_vec1::<f32>()?,
                    reference.get(&cosine).unwrap().to_vec1::<f32>()?,
                ),
            ] {
                let (max_index, max_error) = actual
                    .iter()
                    .zip(&expected)
                    .enumerate()
                    .map(|(i, (a, b))| (i, (a - b).abs()))
                    .max_by(|a, b| a.1.total_cmp(&b.1))
                    .unwrap_or((0, 0.0));
                assert!(
                    max_error <= 1e-4 * expected[max_index].abs().max(1.0),
                    "fused SBF {name} gradient error {max_error} at {max_index}: {} vs {}",
                    actual[max_index],
                    expected[max_index]
                );
            }
        }
        Ok(())
    }

    #[test]
    fn cpu_first_order_gradient_accumulation_handles_shared_and_subtracted_paths() -> Result<()> {
        // Exercise a large contiguous gradient-add path as well as the
        // shared/subtracted graph.
        let values: Vec<f32> = (0..65_536)
            .map(|index| if index % 2 == 0 { 1.0 } else { 2.0 })
            .collect();
        let input = Var::from_vec(values.clone(), values.len(), &Device::Cpu)?;
        let value = input.as_tensor();
        let square = value.mul(value)?;
        let doubled = value.affine(2.0, 0.0)?;
        let loss = square.sum_all()?.sub(&doubled.sum_all()?)?;
        let gradient = loss
            .backward()?
            .get(&input)
            .expect("input gradient")
            .to_vec1::<f32>()?;
        let expected: Vec<f32> = values.iter().map(|value| 2.0 * value - 2.0).collect();
        assert_eq!(gradient, expected);
        Ok(())
    }

    #[test]
    fn cpu_multiply_gradient_noncontiguous_factor_uses_general_fallback() -> Result<()> {
        let input = Var::from_vec(
            vec![1.0_f32, -2.0, 3.0, -4.0, 5.0, -6.0],
            (2, 3),
            &Device::Cpu,
        )?;
        let factor =
            Tensor::from_vec(vec![2.0_f32, 3.0, 4.0, 5.0, 6.0, 7.0], (3, 2), &Device::Cpu)?
                .transpose(0, 1)?;
        let loss = input.as_tensor().mul(&factor)?.sum_all()?;
        let gradient = loss
            .backward()?
            .get(&input)
            .expect("multiply input gradient")
            .to_vec2::<f32>()?;
        assert_eq!(gradient, vec![vec![2.0, 4.0, 6.0], vec![3.0, 5.0, 7.0]]);
        Ok(())
    }

    #[test]
    fn cpu_norm3_matches_pytorch_vector_norm_rounding_and_gradient() -> Result<()> {
        // These are CuS96 edge vectors from the frame-2 parity fixture. The
        // first distinguishes PyTorch's sequential f32 FMA accumulation from
        // the generic sum-of-squares reduction by one ULP.
        let vectors = vec![
            -0.0003598928451538086_f32,
            0.0007463693618774414,
            2.347179412841797,
            -4.470348358154297e-5,
            0.0003827810287475586,
            -2.3487110137939453,
        ];
        let values = Tensor::from_vec(vectors, (2, 3), &Device::Cpu)?
            .apply_op1(PyTorchNorm3)?
            .to_vec1::<f32>()?;
        assert_eq!(values, vec![2.347179651260376, 2.3487110137939453]);

        let input = Var::from_vec(vec![3.0_f32, 4.0, 0.0], (1, 3), &Device::Cpu)?;
        let norm = input.as_tensor().apply_op1(PyTorchNorm3)?;
        let gradient = norm.sum_all()?.backward()?;
        let gradient = gradient
            .get(&input)
            .expect("norm gradient")
            .to_vec2::<f32>()?;
        assert_eq!(gradient, vec![vec![0.6, 0.8, 0.0]]);
        Ok(())
    }

    #[test]
    fn cpu_sigmoid_matches_exp_forward_and_pytorch_gradient() -> Result<()> {
        let values = vec![-8.0_f32, -1.0, -0.125, 0.0, 0.75, 6.0];
        let input = Tensor::from_vec(values.clone(), (values.len(),), &Device::Cpu)?;
        let expected = input.neg()?.exp()?.affine(1.0, 1.0)?.recip()?;
        let actual = input.apply_op1(PyTorchSigmoid)?;
        assert_eq!(actual.to_vec1::<f32>()?, expected.to_vec1::<f32>()?);

        let input = Var::from_vec(values.clone(), (values.len(),), &Device::Cpu)?;
        let output = input.as_tensor().apply_op1(PyTorchSigmoid)?;
        let weights = Tensor::from_vec(
            vec![0.25_f32, -0.5, 1.5, -2.0, 0.75, 0.125],
            (values.len(),),
            &Device::Cpu,
        )?;
        let loss = output.mul(&weights)?.sum_all()?;
        let gradients = loss.backward()?;
        let actual_gradient = gradients
            .get(&input)
            .expect("sigmoid input gradient")
            .to_vec1::<f32>()?;
        let sigmoid = output.to_vec1::<f32>()?;
        let expected_gradient: Vec<f32> = sigmoid
            .iter()
            .zip(weights.to_vec1::<f32>()?)
            .map(|(&value, weight)| weight * value * (1.0 - value))
            .collect();
        for (actual, expected) in actual_gradient.iter().zip(expected_gradient) {
            assert!((actual - expected).abs() <= 1e-7);
        }
        Ok(())
    }

    #[test]
    fn cpu_silu_matches_candle_forward_and_gradient() -> Result<()> {
        let values = vec![
            -20.0_f32, -10.0, -3.0, -0.125, -1e-7, 0.0, 1e-7, 0.75, 5.0, 9.0, 20.0,
        ];
        let input = Tensor::from_vec(values.clone(), (values.len(),), &Device::Cpu)?;
        let expected = input.silu()?.to_vec1::<f32>()?;
        let actual = input.apply_op1(PyTorchSilu)?.to_vec1::<f32>()?;
        for (actual, expected) in actual.iter().zip(expected) {
            assert!((actual - expected).abs() <= 1e-7, "{actual} != {expected}");
        }

        let input = Var::from_vec(values.clone(), (values.len(),), &Device::Cpu)?;
        let output = input.as_tensor().apply_op1(PyTorchSilu)?;
        let weights = Tensor::from_vec(
            vec![
                0.25_f32, -0.5, 0.75, -1.0, 0.5, -0.75, 0.5, 0.75, -1.0, 0.5, 0.25,
            ],
            (values.len(),),
            &Device::Cpu,
        )?;
        let loss = output.mul(&weights)?.sum_all()?;
        let gradients = loss.backward()?;
        let actual_gradient = gradients
            .get(&input)
            .expect("silu input gradient")
            .to_vec1::<f32>()?;

        let reference_input = Var::from_vec(values.clone(), (values.len(),), &Device::Cpu)?;
        let reference_output = reference_input.as_tensor().silu()?;
        let reference_loss = reference_output.mul(&weights)?.sum_all()?;
        let reference_gradient = reference_loss
            .backward()?
            .get(&reference_input)
            .expect("reference silu input gradient")
            .to_vec1::<f32>()?;
        for (actual, expected) in actual_gradient.iter().zip(reference_gradient) {
            assert!((actual - expected).abs() <= 1e-6, "{actual} != {expected}");
        }

        let strided = Tensor::from_vec(
            vec![1.0_f32, -2.0, 3.0, -4.0, 0.5, -0.75, 1.25, -1.5],
            (2, 4),
            &Device::Cpu,
        )?
        .narrow(1, 1, 2)?;
        let strided_values = strided.to_vec2::<f32>()?;
        let strided_silu = strided.apply_op1(PyTorchSilu)?.to_vec2::<f32>()?;
        let expected_silu: Vec<Vec<f32>> = strided_values
            .iter()
            .map(|row| {
                row.iter()
                    .map(|value| value / (1.0 + (-value).exp()))
                    .collect()
            })
            .collect();
        assert_eq!(strided_silu, expected_silu);

        let strided_sigmoid = strided.apply_op1(PyTorchSigmoid)?.to_vec2::<f32>()?;
        let expected_sigmoid: Vec<Vec<f32>> = strided_values
            .iter()
            .map(|row| {
                row.iter()
                    .map(|value| (1.0 + (-value).exp()).recip())
                    .collect()
            })
            .collect();
        assert_eq!(strided_sigmoid, expected_sigmoid);

        let strided_base = Var::from_vec(
            vec![1.0_f32, -2.0, 3.0, -4.0, 0.5, -0.75, 1.25, -1.5],
            (2, 4),
            &Device::Cpu,
        )?;
        let strided_input = strided_base.as_tensor().narrow(1, 1, 2)?;
        assert_eq!(strided_input.layout().stride(), &[4, 1]);
        let strided_values = strided_input.to_vec2::<f32>()?;
        let strided_output = strided_input.apply_op1(PyTorchSilu)?;
        let strided_weights =
            Tensor::from_vec(vec![0.5_f32, -0.25, 1.25, 0.75], (2, 2), &Device::Cpu)?;
        let strided_loss = strided_output.mul(&strided_weights)?.sum_all()?;
        let strided_gradient = strided_loss
            .backward()?
            .get(&strided_base)
            .expect("strided silu input gradient")
            .to_vec2::<f32>()?;
        let expected_strided_gradient: Vec<Vec<f32>> = strided_values
            .iter()
            .zip(strided_weights.to_vec2::<f32>()?)
            .map(|(row, weights)| {
                let middle: Vec<f32> = row
                    .iter()
                    .zip(weights)
                    .map(|(&value, grad)| {
                        let silu = value / (1.0 + (-value).exp());
                        let sigmoid = (1.0 + (-value).exp()).recip();
                        grad * (sigmoid * (1.0 - silu) + silu)
                    })
                    .collect();
                vec![0.0, middle[0], middle[1], 0.0]
            })
            .collect();
        for (actual, expected) in strided_gradient
            .iter()
            .flatten()
            .zip(expected_strided_gradient.iter().flatten())
        {
            assert!((actual - expected).abs() <= 1e-7);
        }
        Ok(())
    }

    #[test]
    fn cpu_silu_large_backward_matches_candle_across_zero_and_tails() -> Result<()> {
        let count = 16_384;
        let values: Vec<f32> = (0..count)
            .map(|index| match index % 11 {
                0 => -20.0,
                1 => -10.0,
                2 => -3.0,
                3 => -0.125,
                4 => -1e-7,
                5 => 0.0,
                6 => 1e-7,
                7 => 0.75,
                8 => 5.0,
                9 => 9.0,
                _ => 20.0,
            })
            .collect();
        let weights: Vec<f32> = (0..count)
            .map(|index| ((index % 17) as f32 - 8.0) / 8.0)
            .collect();

        let input = Var::from_vec(values.clone(), count, &Device::Cpu)?;
        let output = input.as_tensor().apply_op1(PyTorchSilu)?;
        let loss = output
            .mul(&Tensor::from_vec(weights.clone(), count, &Device::Cpu)?)?
            .sum_all()?;
        let actual = loss
            .backward()?
            .get(&input)
            .expect("large SiLU gradient")
            .to_vec1::<f32>()?;

        let reference_input = Var::from_vec(values, count, &Device::Cpu)?;
        let reference_loss = reference_input
            .as_tensor()
            .silu()?
            .mul(&Tensor::from_vec(weights, count, &Device::Cpu)?)?
            .sum_all()?;
        let expected = reference_loss
            .backward()?
            .get(&reference_input)
            .expect("Candle SiLU gradient")
            .to_vec1::<f32>()?;
        for (index, (actual, expected)) in actual.iter().zip(expected).enumerate() {
            assert!(
                (actual - expected).abs() <= 2e-6,
                "gradient mismatch at {index}: {actual} != {expected}"
            );
        }
        Ok(())
    }

    #[test]
    fn cpu_parallel_custom_ops_match_scalar_results() -> Result<()> {
        let count = 8192;
        let values: Vec<f32> = (0..count)
            .map(|index| ((index % 101) as f32 - 50.0) / 10.0)
            .collect();
        let weights: Vec<f32> = (0..count)
            .map(|index| ((index % 17) as f32 - 8.0) / 8.0)
            .collect();

        let sigmoid_input = Tensor::from_vec(values.clone(), count, &Device::Cpu)?;
        let sigmoid = sigmoid_input.apply_op1(PyTorchSigmoid)?;
        let sigmoid_values = sigmoid.to_vec1::<f32>()?;
        let expected_sigmoid: Vec<f32> = values
            .iter()
            .map(|&value| (1.0 + (-value).exp()).recip())
            .collect();
        assert_eq!(sigmoid_values, expected_sigmoid);

        let sigmoid_input = Var::from_vec(values.clone(), count, &Device::Cpu)?;
        let sigmoid = sigmoid_input.as_tensor().apply_op1(PyTorchSigmoid)?;
        let sigmoid_loss = sigmoid
            .mul(&Tensor::from_vec(weights.clone(), count, &Device::Cpu)?)?
            .sum_all()?;
        let sigmoid_gradient = sigmoid_loss
            .backward()?
            .get(&sigmoid_input)
            .expect("sigmoid gradient")
            .to_vec1::<f32>()?;
        let expected_gradient: Vec<f32> = sigmoid_values
            .iter()
            .zip(&weights)
            .map(|(&value, &weight)| weight * value * (1.0 - value))
            .collect();
        assert_eq!(sigmoid_gradient, expected_gradient);

        let silu_input = Var::from_vec(values.clone(), count, &Device::Cpu)?;
        let silu = silu_input.as_tensor().apply_op1(PyTorchSilu)?;
        let silu_values = silu.to_vec1::<f32>()?;
        let silu_loss = silu
            .mul(&Tensor::from_vec(weights.clone(), count, &Device::Cpu)?)?
            .sum_all()?;
        let silu_gradient = silu_loss
            .backward()?
            .get(&silu_input)
            .expect("silu gradient")
            .to_vec1::<f32>()?;
        for ((&value, &silu), (&gradient, &weight)) in values
            .iter()
            .zip(&silu_values)
            .zip(silu_gradient.iter().zip(&weights))
        {
            let sigmoid = if value == 0.0 { 0.5 } else { silu / value };
            let expected = weight * (sigmoid * (1.0 - silu) + silu);
            assert!((gradient - expected).abs() <= 1e-7);
        }

        let cols = 4096;
        let backing: Vec<f32> = (0..2 * (cols + 1))
            .map(|index| ((index % 31) as f32 - 15.0) / 5.0)
            .collect();
        let strided =
            Tensor::from_vec(backing.clone(), (2, cols + 1), &Device::Cpu)?.narrow(1, 1, cols)?;
        assert_eq!(strided.layout().stride(), &[cols + 1, 1]);
        let strided_sigmoid = strided.apply_op1(PyTorchSigmoid)?.to_vec2::<f32>()?;
        for row in 0..2 {
            for col in 0..cols {
                let value = backing[row * (cols + 1) + col + 1];
                assert_eq!(strided_sigmoid[row][col], (1.0 + (-value).exp()).recip());
            }
        }

        let vectors: Vec<f32> = (0..3 * count)
            .map(|index| ((index % 23) as f32 - 11.0) / 7.0)
            .collect();
        let actual_norms = Tensor::from_vec(vectors.clone(), (count, 3), &Device::Cpu)?
            .apply_op1(PyTorchNorm3)?
            .to_vec1::<f32>()?;
        for (row, &actual) in vectors.chunks_exact(3).zip(&actual_norms) {
            let sum = row[0].mul_add(row[0], 0.0);
            let sum = row[1].mul_add(row[1], sum);
            let sum = row[2].mul_add(row[2], sum);
            assert_eq!(actual, sum.sqrt());
        }
        Ok(())
    }

    #[test]
    fn frozen_linear_matches_matmul_bias_and_input_gradient() -> Result<()> {
        let weights = Tensor::from_vec(
            vec![
                0.2_f32, -0.4, 0.1, 0.3, 0.7, -0.5, -0.8, 0.6, 0.9, 0.15, -0.25, 0.45,
            ],
            (4, 3),
            &Device::Cpu,
        )?;
        let weights_t = weights.t()?;
        let bias = Tensor::from_vec(vec![0.1_f32, -0.2, 0.3, 0.4], 4, &Device::Cpu)?;
        let input_values = vec![1.0_f32, -0.5, 0.25, -0.2, 0.9, 0.4];
        let input = Var::from_vec(input_values.clone(), (2, 3), &Device::Cpu)?;
        let fused = input.as_tensor().frozen_linear(&weights_t, &bias)?;
        let reference = input.as_tensor().matmul(&weights_t)?.broadcast_add(&bias)?;
        let fused_values = fused.to_vec2::<f32>()?;
        let reference_values = reference.to_vec2::<f32>()?;
        for (actual, expected) in fused_values
            .iter()
            .flatten()
            .zip(reference_values.iter().flatten())
        {
            assert!((actual - expected).abs() <= 1e-6);
        }

        let output_weights = Tensor::from_vec(
            vec![0.3_f32, -0.1, 0.5, 0.2, -0.4, 0.8, 0.6, -0.7],
            (2, 4),
            &Device::Cpu,
        )?;
        let fused_loss = fused.mul(&output_weights)?.sum_all()?;
        let fused_gradient = fused_loss
            .backward()?
            .get(&input)
            .expect("fused linear input gradient")
            .to_vec2::<f32>()?;

        let reference_input = Var::from_vec(input_values, (2, 3), &Device::Cpu)?;
        let reference_loss = reference_input
            .as_tensor()
            .matmul(&weights_t)?
            .broadcast_add(&bias)?
            .mul(&output_weights)?
            .sum_all()?;
        let reference_gradient = reference_loss
            .backward()?
            .get(&reference_input)
            .expect("reference linear input gradient")
            .to_vec2::<f32>()?;
        for (actual, expected) in fused_gradient
            .iter()
            .flatten()
            .zip(reference_gradient.iter().flatten())
        {
            assert!((actual - expected).abs() <= 1e-6);
        }
        Ok(())
    }

    #[cfg(feature = "accelerate")]
    #[test]
    fn frozen_linear_accumulates_backward_into_existing_cpu_gradient() -> Result<()> {
        let weights = Tensor::from_vec(
            vec![
                0.2_f32, -0.4, 0.1, 0.3, 0.7, -0.5, -0.8, 0.6, 0.9, 0.15, -0.25, 0.45,
            ],
            (4, 3),
            &Device::Cpu,
        )?;
        let weights_t = weights.t()?;
        let bias = Tensor::from_vec(vec![0.1_f32, -0.2, 0.3, 0.4], 4, &Device::Cpu)?;
        let input = Var::from_vec(
            vec![1.0_f32, -0.5, 0.25, -0.2, 0.9, 0.4],
            (2, 3),
            &Device::Cpu,
        )?;

        // Two independent frozen-linear nodes contribute to the same input.
        // The later node must add its GEMM directly into the first node's
        // accumulated gradient without losing the skip-path contribution.
        let first = input.as_tensor().frozen_linear(&weights_t, &bias)?;
        let second = input.as_tensor().frozen_linear(&weights_t, &bias)?;
        let loss = first
            .sum_all()?
            .add(&second.sum_all()?)?
            .add(&input.as_tensor().sum_all()?)?;
        let actual = loss
            .backward()?
            .get(&input)
            .expect("accumulated frozen-linear input gradient")
            .to_vec2::<f32>()?;

        let weight_values = weights.to_vec2::<f32>()?;
        let row_sum: Vec<f32> = (0..3)
            .map(|input_col| {
                (0..4)
                    .map(|output_row| weight_values[output_row][input_col])
                    .sum::<f32>()
                    .mul_add(2.0, 1.0)
            })
            .collect();
        for row in &actual {
            for (&value, &expected) in row.iter().zip(&row_sum) {
                assert!((value - expected).abs() <= 2e-6, "{value} != {expected}");
            }
        }
        Ok(())
    }
}
