//! Experimental reduced-storage MatterSim weight packages.
//!
//! Candidate files are raw, deterministic payloads ordered by the canonical
//! model manifest. They are expanded to F32 before evaluation; this module
//! does not claim low-precision arithmetic acceleration.

use crate::{validate_weights_bytes, ModelManifest};
use half::f16;
use safetensors::tensor::SafeTensors;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::collections::HashMap;

pub const PRECISION_ARTIFACT_SCHEMA: &str = "macer-rust-precision-artifact-v1";

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum PrecisionEncoding {
    F16Storage,
    W8OutputChannel,
}

impl PrecisionEncoding {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::F16Storage => "f16_storage_fp32_compute",
            Self::W8OutputChannel => "w8_output_channel_fp32_compute",
        }
    }
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct PrecisionArtifactManifest {
    pub schema_version: String,
    pub encoding: PrecisionEncoding,
    pub model_id: String,
    pub source_checkpoint_sha256: String,
    pub source_weights_sha256: String,
    pub artifact_sha256: String,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub full_precision_tensors: Vec<String>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub half_precision_tensors: Vec<String>,
}

fn sha256(bytes: &[u8]) -> String {
    hex::encode(Sha256::digest(bytes))
}

fn read_f32(bytes: &[u8], name: &str) -> Result<Vec<f32>, String> {
    if bytes.len() % 4 != 0 {
        return Err(format!("{name}: F32 payload length is not divisible by 4"));
    }
    Ok(bytes
        .chunks_exact(4)
        .map(|chunk| f32::from_le_bytes(chunk.try_into().expect("four-byte chunk")))
        .collect())
}

fn encode_f32(values: &[f32]) -> Vec<u8> {
    values
        .iter()
        .flat_map(|value| value.to_le_bytes())
        .collect()
}

fn is_linear_weight(name: &str) -> bool {
    name.ends_with(".linear.weight")
}

fn is_neural_weight(name: &str) -> bool {
    is_linear_weight(name) || name.ends_with(".linear.bias")
}

/// Create a deterministic candidate payload from the pinned FP32 package.
/// F16 stores every tensor in half precision. W8 stores linear weights as
/// symmetric per-output-channel I8 plus F32 scales, retaining other tensors
/// as F32. Tensor order is inherited from the validated canonical manifest.
pub fn encode_precision_variant(
    source_manifest: &ModelManifest,
    source_weights: &[u8],
    encoding: PrecisionEncoding,
) -> Result<(Vec<u8>, PrecisionArtifactManifest), String> {
    encode_precision_variant_with_full_precision(source_manifest, source_weights, encoding, &[])
}

/// Build a W8 candidate while keeping selected linear weight tensors in F32.
/// The list is recorded in the sidecar and participates in payload decoding.
pub fn encode_precision_variant_with_full_precision(
    source_manifest: &ModelManifest,
    source_weights: &[u8],
    encoding: PrecisionEncoding,
    full_precision_tensors: &[String],
) -> Result<(Vec<u8>, PrecisionArtifactManifest), String> {
    encode_precision_variant_with_precision_overrides(
        source_manifest,
        source_weights,
        encoding,
        full_precision_tensors,
        &[],
    )
}

/// Build a W8 candidate while selectively retaining linear weights in F32 or
/// F16. This is for accuracy/size screening; all decoded model compute remains
/// F32 until a separately validated arithmetic kernel is introduced.
pub fn encode_precision_variant_with_precision_overrides(
    source_manifest: &ModelManifest,
    source_weights: &[u8],
    encoding: PrecisionEncoding,
    full_precision_tensors: &[String],
    half_precision_tensors: &[String],
) -> Result<(Vec<u8>, PrecisionArtifactManifest), String> {
    validate_weights_bytes(source_manifest, source_weights)?;
    let mut keep = full_precision_tensors.to_vec();
    keep.sort();
    keep.dedup();
    let mut half = half_precision_tensors.to_vec();
    half.sort();
    half.dedup();
    if keep.len() != full_precision_tensors.len()
        || half.len() != half_precision_tensors.len()
        || keep.iter().chain(&half).any(|name| {
            !is_linear_weight(name)
                || !source_manifest
                    .tensors
                    .iter()
                    .any(|spec| &spec.name == name)
        })
        || keep.iter().any(|name| half.binary_search(name).is_ok())
        || (encoding == PrecisionEncoding::F16Storage && (!keep.is_empty() || !half.is_empty()))
    {
        return Err("precision override tensors must be unique source linear weights, disjoint, and only apply to W8".into());
    }
    let keep_set = keep
        .iter()
        .map(String::as_str)
        .collect::<std::collections::HashSet<_>>();
    let half_set = half
        .iter()
        .map(String::as_str)
        .collect::<std::collections::HashSet<_>>();
    let safe = SafeTensors::deserialize(source_weights).map_err(|e| e.to_string())?;
    let mut payload = Vec::new();

    for source_spec in &source_manifest.tensors {
        let view = safe.tensor(&source_spec.name).map_err(|e| e.to_string())?;
        let values = read_f32(view.data(), &source_spec.name)?;
        match encoding {
            PrecisionEncoding::F16Storage => {
                if is_neural_weight(&source_spec.name) {
                    for value in values {
                        if !value.is_finite() {
                            return Err(format!("{}: non-finite source weight", source_spec.name));
                        }
                        let rounded = f16::from_f32(value);
                        if !rounded.is_finite() {
                            return Err(format!(
                                "{}: value overflows F16 storage",
                                source_spec.name
                            ));
                        }
                        payload.extend_from_slice(&rounded.to_bits().to_le_bytes());
                    }
                } else {
                    payload.extend_from_slice(view.data());
                }
            }
            PrecisionEncoding::W8OutputChannel
                if is_linear_weight(&source_spec.name)
                    && half_set.contains(source_spec.name.as_str()) =>
            {
                for value in values {
                    if !value.is_finite() {
                        return Err(format!("{}: non-finite source weight", source_spec.name));
                    }
                    let rounded = f16::from_f32(value);
                    if !rounded.is_finite() {
                        return Err(format!("{}: value overflows F16 storage", source_spec.name));
                    }
                    payload.extend_from_slice(&rounded.to_bits().to_le_bytes());
                }
            }
            PrecisionEncoding::W8OutputChannel
                if is_linear_weight(&source_spec.name)
                    && !keep_set.contains(source_spec.name.as_str()) =>
            {
                if source_spec.shape.len() != 2 {
                    return Err(format!(
                        "{}: output-channel W8 requires a rank-2 linear weight",
                        source_spec.name
                    ));
                }
                let rows = source_spec.shape[0];
                let columns = source_spec.shape[1];
                if values.len() != rows * columns {
                    return Err(format!(
                        "{}: source shape does not match payload",
                        source_spec.name
                    ));
                }
                let mut scales = Vec::with_capacity(rows);
                for row in values.chunks_exact(columns) {
                    if row.iter().any(|value| !value.is_finite()) {
                        return Err(format!("{}: non-finite source weight", source_spec.name));
                    }
                    let max_abs = row.iter().fold(0.0f32, |max, value| max.max(value.abs()));
                    let scale = if max_abs == 0.0 { 1.0 } else { max_abs / 127.0 };
                    scales.push(scale);
                    payload.extend(
                        row.iter()
                            .map(|value| (value / scale).round().clamp(-127.0, 127.0) as i8 as u8),
                    );
                }
                payload.extend(encode_f32(&scales));
            }
            PrecisionEncoding::W8OutputChannel => payload.extend_from_slice(view.data()),
        }
    }

    let artifact = PrecisionArtifactManifest {
        schema_version: PRECISION_ARTIFACT_SCHEMA.into(),
        encoding,
        model_id: source_manifest.model_id.clone(),
        source_checkpoint_sha256: source_manifest.source_checkpoint_sha256.clone(),
        source_weights_sha256: source_manifest.weights_sha256.clone(),
        artifact_sha256: sha256(&payload),
        full_precision_tensors: keep,
        half_precision_tensors: half,
    };
    Ok((payload, artifact))
}

/// Validate and expand an experimental payload to F32 values. The caller must
/// supply the exact canonical source manifest; no tensor order is inferred.
pub fn decode_precision_variant(
    source_manifest: &ModelManifest,
    artifact: &PrecisionArtifactManifest,
    artifact_bytes: &[u8],
) -> Result<HashMap<String, Vec<f32>>, String> {
    source_manifest.validate()?;
    if artifact.schema_version != PRECISION_ARTIFACT_SCHEMA
        || artifact.model_id != source_manifest.model_id
        || artifact.source_checkpoint_sha256 != source_manifest.source_checkpoint_sha256
        || artifact.source_weights_sha256 != source_manifest.weights_sha256
    {
        return Err("precision artifact source identity does not match the pinned model".into());
    }
    if sha256(artifact_bytes) != artifact.artifact_sha256 {
        return Err("precision artifact SHA-256 does not match manifest".into());
    }
    let keep_set = artifact
        .full_precision_tensors
        .iter()
        .map(String::as_str)
        .collect::<std::collections::HashSet<_>>();
    let half_set = artifact
        .half_precision_tensors
        .iter()
        .map(String::as_str)
        .collect::<std::collections::HashSet<_>>();
    if keep_set.len() != artifact.full_precision_tensors.len()
        || artifact
            .full_precision_tensors
            .windows(2)
            .any(|pair| pair[0] >= pair[1])
        || half_set.len() != artifact.half_precision_tensors.len()
        || artifact
            .half_precision_tensors
            .windows(2)
            .any(|pair| pair[0] >= pair[1])
        || keep_set.iter().chain(&half_set).any(|name| {
            !is_linear_weight(name)
                || !source_manifest
                    .tensors
                    .iter()
                    .any(|spec| spec.name == **name)
        })
        || keep_set.iter().any(|name| half_set.contains(name))
        || (artifact.encoding == PrecisionEncoding::F16Storage
            && (!keep_set.is_empty() || !half_set.is_empty()))
    {
        return Err("precision artifact has an invalid full_precision_tensors list".into());
    }

    let expected_size = source_manifest
        .tensors
        .iter()
        .try_fold(0usize, |total, spec| {
            let elements = spec
                .shape
                .iter()
                .try_fold(1usize, |n, d| n.checked_mul(*d))?;
            let encoded = match artifact.encoding {
                PrecisionEncoding::F16Storage => {
                    elements.checked_mul(if is_neural_weight(&spec.name) { 2 } else { 4 })?
                }
                PrecisionEncoding::W8OutputChannel
                    if is_linear_weight(&spec.name) && half_set.contains(spec.name.as_str()) =>
                {
                    elements.checked_mul(2)?
                }
                PrecisionEncoding::W8OutputChannel
                    if is_linear_weight(&spec.name) && !keep_set.contains(spec.name.as_str()) =>
                {
                    if spec.shape.len() != 2 {
                        return None;
                    }
                    elements.checked_add(spec.shape[0].checked_mul(4)?)?
                }
                PrecisionEncoding::W8OutputChannel => elements.checked_mul(4)?,
            };
            total.checked_add(encoded)
        });
    let expected_size = expected_size.ok_or("precision artifact size overflow")?;
    if artifact_bytes.len() != expected_size {
        return Err(format!(
            "precision artifact payload size mismatch: expected {expected_size}, got {}",
            artifact_bytes.len()
        ));
    }

    let mut offset = 0usize;
    let mut decoded = HashMap::with_capacity(source_manifest.tensors.len());
    for spec in &source_manifest.tensors {
        let elements = spec.shape.iter().product::<usize>();
        let values = match artifact.encoding {
            PrecisionEncoding::F16Storage => {
                let bytes_per_element = if is_neural_weight(&spec.name) { 2 } else { 4 };
                let size = elements * bytes_per_element;
                let values = if bytes_per_element == 2 {
                    artifact_bytes[offset..offset + size]
                        .chunks_exact(2)
                        .map(|chunk| {
                            f16::from_bits(u16::from_le_bytes([chunk[0], chunk[1]])).to_f32()
                        })
                        .collect::<Vec<_>>()
                } else {
                    read_f32(&artifact_bytes[offset..offset + size], &spec.name)?
                };
                offset += size;
                values
            }
            PrecisionEncoding::W8OutputChannel
                if is_linear_weight(&spec.name) && half_set.contains(spec.name.as_str()) =>
            {
                let size = elements * 2;
                let values = artifact_bytes[offset..offset + size]
                    .chunks_exact(2)
                    .map(|chunk| f16::from_bits(u16::from_le_bytes([chunk[0], chunk[1]])).to_f32())
                    .collect::<Vec<_>>();
                offset += size;
                values
            }
            PrecisionEncoding::W8OutputChannel
                if is_linear_weight(&spec.name) && !keep_set.contains(spec.name.as_str()) =>
            {
                let rows = spec.shape[0];
                let columns = spec.shape[1];
                let quantized = &artifact_bytes[offset..offset + elements];
                offset += elements;
                let scale_bytes = &artifact_bytes[offset..offset + rows * 4];
                let scales = read_f32(scale_bytes, &format!("{} scales", spec.name))?;
                offset += rows * 4;
                if scales.len() != rows
                    || scales
                        .iter()
                        .any(|scale| !scale.is_finite() || *scale <= 0.0)
                {
                    return Err(format!("{}: invalid output-channel scales", spec.name));
                }
                quantized
                    .chunks_exact(columns)
                    .zip(scales)
                    .flat_map(|(row, scale)| {
                        row.iter().map(move |&value| (value as i8 as f32) * scale)
                    })
                    .collect()
            }
            PrecisionEncoding::W8OutputChannel => {
                let size = elements * 4;
                let values = read_f32(&artifact_bytes[offset..offset + size], &spec.name)?;
                offset += size;
                values
            }
        };
        if values.len() != elements || values.iter().any(|value| !value.is_finite()) {
            return Err(format!("{}: decoded values are invalid", spec.name));
        }
        decoded.insert(spec.name.clone(), values);
    }
    if offset != artifact_bytes.len() {
        return Err("precision artifact has unconsumed bytes".into());
    }
    Ok(decoded)
}

pub fn precision_manifest_json(artifact: &PrecisionArtifactManifest) -> Result<Vec<u8>, String> {
    serde_json::to_vec_pretty(artifact).map_err(|e| e.to_string())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn pinned_1m() -> (ModelManifest, Vec<u8>) {
        let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
        let manifest = ModelManifest::from_json_bytes(
            &std::fs::read(root.join("models/mattersim-1m.json")).unwrap(),
        )
        .unwrap();
        let weights = std::fs::read(root.join("models/mattersim-1m.safetensors")).unwrap();
        (manifest, weights)
    }

    #[test]
    fn f16_storage_roundtrips_to_the_expected_fp32_values_and_stays_under_half_size() {
        let (manifest, source) = pinned_1m();
        let (candidate, artifact) =
            encode_precision_variant(&manifest, &source, PrecisionEncoding::F16Storage).unwrap();
        assert!(candidate.len() * 2 <= source.len());
        let decoded = decode_precision_variant(&manifest, &artifact, &candidate).unwrap();
        let source_tensors = SafeTensors::deserialize(&source).unwrap();
        for spec in &manifest.tensors {
            let source_values = read_f32(
                source_tensors.tensor(&spec.name).unwrap().data(),
                &spec.name,
            )
            .unwrap();
            let expected = if is_neural_weight(&spec.name) {
                source_values
                    .into_iter()
                    .map(|value| f16::from_f32(value).to_f32())
                    .collect::<Vec<_>>()
            } else {
                source_values
            };
            assert_eq!(decoded[&spec.name], expected, "{}", spec.name);
        }
    }

    #[test]
    fn w8_output_channel_scales_roundtrip_and_tampering_is_rejected() {
        let (manifest, source) = pinned_1m();
        let (candidate, artifact) =
            encode_precision_variant(&manifest, &source, PrecisionEncoding::W8OutputChannel)
                .unwrap();
        assert!(candidate.len() * 2 < source.len());
        let decoded = decode_precision_variant(&manifest, &artifact, &candidate).unwrap();
        let source_tensors = SafeTensors::deserialize(&source).unwrap();
        for spec in &manifest.tensors {
            let original = read_f32(
                source_tensors.tensor(&spec.name).unwrap().data(),
                &spec.name,
            )
            .unwrap();
            let approximate = &decoded[&spec.name];
            if is_linear_weight(&spec.name) {
                let columns = spec.shape[1];
                for (source_row, decoded_row) in original
                    .chunks_exact(columns)
                    .zip(approximate.chunks_exact(columns))
                {
                    let max_abs = source_row
                        .iter()
                        .fold(0.0f32, |max, value| max.max(value.abs()));
                    let bound = if max_abs == 0.0 {
                        0.0
                    } else {
                        max_abs / 127.0 / 2.0 + 1e-7
                    };
                    for (&source_value, &decoded_value) in source_row.iter().zip(decoded_row) {
                        assert!((source_value - decoded_value).abs() <= bound);
                    }
                }
            } else {
                assert_eq!(original, *approximate);
            }
        }
        let mut corrupted = candidate;
        corrupted[0] ^= 1;
        assert_eq!(
            decode_precision_variant(&manifest, &artifact, &corrupted).unwrap_err(),
            "precision artifact SHA-256 does not match manifest"
        );
    }

    #[test]
    fn mixed_w8_restores_selected_layers_as_exact_fp32() {
        let (manifest, source) = pinned_1m();
        let kept = manifest
            .tensors
            .iter()
            .find(|spec| is_linear_weight(&spec.name))
            .unwrap()
            .name
            .clone();
        let (candidate, artifact) = encode_precision_variant_with_full_precision(
            &manifest,
            &source,
            PrecisionEncoding::W8OutputChannel,
            std::slice::from_ref(&kept),
        )
        .unwrap();
        let decoded = decode_precision_variant(&manifest, &artifact, &candidate).unwrap();
        let source_tensors = SafeTensors::deserialize(&source).unwrap();
        let exact = read_f32(source_tensors.tensor(&kept).unwrap().data(), &kept).unwrap();
        assert_eq!(decoded[&kept], exact);
        assert_eq!(artifact.full_precision_tensors, vec![kept]);
    }

    #[test]
    fn mixed_w8_stores_selected_linear_weights_as_f16_without_w8_scale_overhead() {
        let (manifest, source) = pinned_1m();
        let selected = "graph_conv.1.edge_layer_atom.linear.weight".to_string();
        let (plain_w8, _) =
            encode_precision_variant(&manifest, &source, PrecisionEncoding::W8OutputChannel)
                .unwrap();
        let (candidate, artifact) = encode_precision_variant_with_precision_overrides(
            &manifest,
            &source,
            PrecisionEncoding::W8OutputChannel,
            &[],
            std::slice::from_ref(&selected),
        )
        .unwrap();
        assert_eq!(candidate.len(), plain_w8.len());
        assert_eq!(artifact.half_precision_tensors, vec![selected.clone()]);
        let decoded = decode_precision_variant(&manifest, &artifact, &candidate).unwrap();
        let source_tensors = SafeTensors::deserialize(&source).unwrap();
        let original =
            read_f32(source_tensors.tensor(&selected).unwrap().data(), &selected).unwrap();
        let expected = original
            .into_iter()
            .map(|value| f16::from_f32(value).to_f32())
            .collect::<Vec<_>>();
        assert_eq!(decoded[&selected], expected);

        let overlap = encode_precision_variant_with_precision_overrides(
            &manifest,
            &source,
            PrecisionEncoding::W8OutputChannel,
            std::slice::from_ref(&selected),
            std::slice::from_ref(&selected),
        );
        assert!(overlap.is_err());
    }
}
