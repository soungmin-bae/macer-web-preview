//! Experimental packed-weight GEMM screen; not selected by any model runtime.
use gemm::{gemm, Parallelism};

pub struct PackedLinear {
    pub outputs: usize,
    pub inputs: usize,
    bits: u8,
    group: usize,
    codes: Vec<u8>,
    scales: Vec<f32>,
}

impl PackedLinear {
    pub fn new(
        weight: &[f32],
        outputs: usize,
        inputs: usize,
        bits: u8,
        group: usize,
    ) -> Result<Self, String> {
        if !(bits == 4 || bits == 8)
            || !(group == 32 || group == 64)
            || outputs == 0
            || inputs == 0
            || outputs > 4096
            || inputs > 4096
            || weight.len() != outputs * inputs
            || !weight.iter().all(|x| x.is_finite())
        {
            return Err("invalid packed-linear probe parameters".into());
        }
        let groups = inputs.div_ceil(group);
        let padded = groups * group;
        let mut codes = vec![0u8; outputs * padded];
        let mut scales = vec![0f32; outputs * groups];
        let limit = ((1u32 << (bits - 1)) - 1) as f32;
        let offset = 1i32 << (bits - 1);
        for row in 0..outputs {
            for g in 0..groups {
                let end = inputs.min((g + 1) * group);
                let start = g * group;
                let max = weight[row * inputs + start..row * inputs + end]
                    .iter()
                    .fold(0f32, |a, x| a.max(x.abs()));
                let scale = if max == 0. { 1. } else { max / limit };
                scales[row * groups + g] = scale;
                for k in start..end {
                    codes[row * padded + k] = ((weight[row * inputs + k] / scale)
                        .round_ties_even()
                        .clamp(-limit, limit) as i32
                        + offset) as u8;
                }
            }
        }
        if bits == 4 {
            codes = codes.chunks_exact(2).map(|x| x[0] | x[1] << 4).collect();
        }
        Ok(Self {
            outputs,
            inputs,
            bits,
            group,
            codes,
            scales,
        })
    }

    pub fn storage_bytes(&self) -> usize {
        self.codes.len() + self.scales.len() * 4
    }

    fn decode_rows(&self, start: usize, rows: usize, scratch: &mut [f32]) {
        let groups = self.inputs.div_ceil(self.group);
        let padded = groups * self.group;
        let offset = (1i32 << (self.bits - 1)) as f32;
        for row in 0..rows {
            for col in 0..self.inputs {
                let index = (start + row) * padded + col;
                let code = if self.bits == 4 {
                    (self.codes[index / 2] >> ((index % 2) * 4)) & 15
                } else {
                    self.codes[index]
                };
                scratch[row * self.inputs + col] =
                    (code as f32 - offset) * self.scales[(start + row) * groups + col / self.group];
            }
        }
    }

    pub fn decoded(&self) -> Vec<f32> {
        let mut out = vec![0.; self.outputs * self.inputs];
        self.decode_rows(0, self.outputs, &mut out);
        out
    }

    pub fn forward_and_input_gradient(
        &self,
        x: &[f32],
        dy: &[f32],
        batch: usize,
    ) -> Result<(Vec<f32>, Vec<f32>), String> {
        if batch == 0
            || batch > 4096
            || x.len() != batch * self.inputs
            || dy.len() != batch * self.outputs
        {
            return Err("invalid packed-linear input sizes".into());
        }
        let mut y = vec![0.; batch * self.outputs];
        let mut dx = vec![0.; batch * self.inputs];
        let mut scratch = vec![0.; 32 * self.inputs];
        for start in (0..self.outputs).step_by(32) {
            let count = (self.outputs - start).min(32);
            self.decode_rows(start, count, &mut scratch);
            // All matrix bounds/strides are established above. GEMM runs serial
            // in both controls and candidates; scratch is retained through both calls.
            unsafe {
                gemm(
                    batch,
                    count,
                    self.inputs,
                    y.as_mut_ptr().add(start),
                    1,
                    self.outputs as isize,
                    false,
                    x.as_ptr(),
                    1,
                    self.inputs as isize,
                    scratch.as_ptr(),
                    self.inputs as isize,
                    1,
                    0f32,
                    1f32,
                    false,
                    false,
                    false,
                    Parallelism::None,
                );
                gemm(
                    batch,
                    self.inputs,
                    count,
                    dx.as_mut_ptr(),
                    1,
                    self.inputs as isize,
                    start != 0,
                    dy.as_ptr().add(start),
                    1,
                    self.outputs as isize,
                    scratch.as_ptr(),
                    1,
                    self.inputs as isize,
                    if start == 0 { 0f32 } else { 1f32 },
                    1f32,
                    false,
                    false,
                    false,
                    Parallelism::None,
                );
            }
        }
        Ok((y, dx))
    }
}

pub fn dense_pair(
    x: &[f32],
    dy: &[f32],
    w: &[f32],
    batch: usize,
    inputs: usize,
    outputs: usize,
) -> (Vec<f32>, Vec<f32>) {
    assert!(
        batch > 0
            && batch <= 4096
            && inputs > 0
            && inputs <= 4096
            && outputs > 0
            && outputs <= 4096
    );
    assert_eq!(x.len(), batch * inputs);
    assert_eq!(dy.len(), batch * outputs);
    assert_eq!(w.len(), outputs * inputs);
    let mut y = vec![0.; batch * outputs];
    let mut dx = vec![0.; batch * inputs];
    unsafe {
        gemm(
            batch,
            outputs,
            inputs,
            y.as_mut_ptr(),
            1,
            outputs as isize,
            false,
            x.as_ptr(),
            1,
            inputs as isize,
            w.as_ptr(),
            inputs as isize,
            1,
            0f32,
            1f32,
            false,
            false,
            false,
            Parallelism::None,
        );
        gemm(
            batch,
            inputs,
            outputs,
            dx.as_mut_ptr(),
            1,
            inputs as isize,
            false,
            dy.as_ptr(),
            1,
            outputs as isize,
            w.as_ptr(),
            1,
            inputs as isize,
            0f32,
            1f32,
            false,
            false,
            false,
            Parallelism::None,
        );
    }
    (y, dx)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn rejects_invalid_shapes_and_keeps_zero_groups_finite() {
        assert!(PackedLinear::new(&[], 0, 0, 4, 32).is_err());
        assert!(PackedLinear::new(&[f32::NAN], 1, 1, 4, 32).is_err());
        assert!(PackedLinear::new(&[1.], 1, 1, 3, 32).is_err());
        let packed = PackedLinear::new(&[0.; 33], 1, 33, 4, 32).unwrap();
        assert!(packed.forward_and_input_gradient(&[], &[], 0).is_err());
        let (y, dx) = packed
            .forward_and_input_gradient(&[1.; 33], &[2.], 1)
            .unwrap();
        assert_eq!(y, vec![0.]);
        assert_eq!(dx, vec![0.; 33]);
    }
    #[test]
    fn packed_forward_and_gradient_match_decoded_dense_with_row_and_column_tails() {
        let (m, k, n) = (7, 70, 35);
        let w: Vec<_> = (0..n * k)
            .map(|i| ((i * 13 % 83) as f32 - 41.) / 100.)
            .collect();
        let x: Vec<_> = (0..m * k).map(|i| (i % 17) as f32 / 19.).collect();
        let dy: Vec<_> = (0..m * n).map(|i| (i % 11) as f32 / 31.).collect();
        for bits in [4, 8] {
            for group in [32, 64] {
                let packed = PackedLinear::new(&w, n, k, bits, group).unwrap();
                let (a, b) = packed.forward_and_input_gradient(&x, &dy, m).unwrap();
                let (c, d) = dense_pair(&x, &dy, &packed.decoded(), m, k, n);
                for (a, b) in a.iter().chain(&b).zip(c.iter().chain(&d)) {
                    assert!((a - b).abs() < 1e-5, "{a} vs {b}");
                }
            }
        }
    }
}

fn multiply(a: &[f32], b: &[f32], m: usize, k: usize, n: usize, transpose_b: bool) -> Vec<f32> {
    assert!(m > 0 && m <= 4096 && k > 0 && k <= 4096 && n > 0 && n <= 4096);
    assert_eq!(a.len(), m * k);
    assert_eq!(b.len(), k * n);
    let mut out = vec![0f32; m * n];
    unsafe {
        gemm(
            m,
            n,
            k,
            out.as_mut_ptr(),
            1,
            n as isize,
            false,
            a.as_ptr(),
            1,
            k as isize,
            b.as_ptr(),
            if transpose_b { k as isize } else { 1 },
            if transpose_b { 1 } else { n as isize },
            0f32,
            1f32,
            false,
            false,
            false,
            Parallelism::None,
        );
    }
    out
}

/// Four GEMMs for a decoded factorized weight, with no activation rounding.
pub fn factorized_pair(
    x: &[f32],
    dy: &[f32],
    down: &[f32],
    up: &[f32],
    batch: usize,
    inputs: usize,
    outputs: usize,
    rank: usize,
) -> (Vec<f32>, Vec<f32>) {
    let hidden = multiply(x, down, batch, inputs, rank, true);
    let y = multiply(&hidden, up, batch, rank, outputs, true);
    let dh = multiply(dy, up, batch, outputs, rank, false);
    let dx = multiply(&dh, down, batch, rank, inputs, false);
    (y, dx)
}

pub fn reconstruct(
    down: &[f32],
    up: &[f32],
    inputs: usize,
    outputs: usize,
    rank: usize,
) -> Vec<f32> {
    multiply(up, down, outputs, rank, inputs, false)
}

#[cfg(test)]
mod factor_tests {
    use super::*;
    #[test]
    fn factor_pair_matches_reconstructed_weight_values_and_input_gradient() {
        let (m, k, n, r) = (7, 70, 35, 9);
        let down: Vec<_> = (0..r * k).map(|i| ((i % 17) as f32 - 8.) * 0.01).collect();
        let up: Vec<_> = (0..n * r).map(|i| ((i % 13) as f32 - 6.) * 0.02).collect();
        let x = vec![0.3; m * k];
        let dy = vec![0.2; m * n];
        let (a, b) = factorized_pair(&x, &dy, &down, &up, m, k, n, r);
        let (c, d) = dense_pair(&x, &dy, &reconstruct(&down, &up, k, n, r), m, k, n);
        for (x, y) in a.iter().chain(&b).zip(c.iter().chain(&d)) {
            assert!((x - y).abs() < 1e-5);
        }
    }
}
