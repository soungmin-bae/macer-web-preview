//! Bounded-row recomputation for frozen-weight MLPs. All atoms/edges retained.
use super::*;
use std::sync::Arc;
#[cfg(feature = "gated-rows-1024")]
pub(super) const GATED_ROWS: usize = 1024;
#[cfg(not(feature = "gated-rows-1024"))]
pub(super) const GATED_ROWS: usize = 512;
#[cfg(feature = "sbf-rows-8192")]
pub(super) const SBF_ROWS: usize = 8192;
#[cfg(not(feature = "sbf-rows-8192"))]
pub(super) const SBF_ROWS: usize = 4096;
pub(super) struct GatedCheckpoint {
    pub evaluator: Arc<Evaluator>,
    pub prefix: String,
    pub layers: usize,
}
impl CustomOp1 for GatedCheckpoint {
    fn name(&self) -> &'static str {
        "mattersim-gated-row-checkpoint"
    }
    fn cpu_fwd(&self, storage: &CpuStorage, layout: &Layout) -> CandleResult<(CpuStorage, Shape)> {
        let profile_start = self.evaluator.profile.start(2);
        let CpuStorage::F32(data) = storage else {
            candle_core::bail!("checkpoint requires f32")
        };
        let (start, end) = layout
            .contiguous_offsets()
            .ok_or_else(|| candle_core::Error::Msg("checkpoint needs contiguous rows".into()))?;
        let width = layout.dims()[1];
        let n = layout.dims()[0];
        let mut out = Vec::new();
        let mut output_width = 0;
        for row in (0..n).step_by(GATED_ROWS) {
            let count = GATED_ROWS.min(n - row);
            let input = Tensor::from_vec(
                data[start + row * width..(start + (row + count) * width).min(end)].to_vec(),
                (count, width),
                &Device::Cpu,
            )?;
            let result = self
                .evaluator
                .gated_direct(&input, &self.prefix, self.layers)?;
            output_width = result.dim(1)?;
            out.extend(result.flatten_all()?.to_vec1::<f32>()?);
        }
        self.evaluator
            .profile
            .record_since("checkpoint.gated.forward", profile_start);
        self.evaluator
            .profile
            .increment("checkpoint.gated.forward_rows", n as u64);
        Ok((CpuStorage::F32(out), Shape::from((n, output_width))))
    }
    fn bwd(&self, arg: &Tensor, _res: &Tensor, grad: &Tensor) -> CandleResult<Option<Tensor>> {
        let profile_start = self.evaluator.profile.start(1);
        let (n, width) = arg.dims2()?;
        let mut output = Vec::with_capacity(n * width);
        for row in (0..n).step_by(GATED_ROWS) {
            let count = GATED_ROWS.min(n - row);
            #[cfg(feature = "analytic-gated-backward")]
            {
                let input = arg.narrow(0, row, count)?.contiguous()?.detach();
                let upstream = grad.narrow(0, row, count)?.contiguous()?.detach();
                let values = self.evaluator.gated_input_gradient_direct(
                    &input,
                    &self.prefix,
                    self.layers,
                    &upstream,
                )?;
                output.extend(values.flatten_all()?.to_vec1::<f32>()?);
                continue;
            }
            #[cfg(not(feature = "analytic-gated-backward"))]
            {
                let input = Var::from_tensor(&arg.narrow(0, row, count)?.contiguous()?.detach())?;
                let result = self
                    .evaluator
                    .gated_direct(&input, &self.prefix, self.layers)?;
                let loss = result
                    .mul(&grad.narrow(0, row, count)?.contiguous()?.detach())?
                    .sum_all()?;
                let grads = loss.backward()?;
                let values = grads
                    .get(&input)
                    .ok_or_else(|| candle_core::Error::Msg("missing checkpoint gradient".into()))?;
                output.extend(values.flatten_all()?.to_vec1::<f32>()?);
            }
        }
        self.evaluator
            .profile
            .record_since("checkpoint.gated.backward_recompute", profile_start);
        self.evaluator
            .profile
            .increment("checkpoint.gated.backward_rows", n as u64);
        Ok(Some(Tensor::from_vec(output, (n, width), &Device::Cpu)?))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn checkpoint_matches_full_mlp_values_and_gradients_with_tail() -> CandleResult<()> {
        let mut weights = HashMap::new();
        for branch in ["g", "sigma"] {
            for (layer, (a, b)) in [(3, 4), (4, 2)].into_iter().enumerate() {
                let key = format!("test.{branch}.{layer}.linear");
                weights.insert(
                    format!("{key}.weight"),
                    Tensor::from_vec(
                        (0..a * b)
                            .map(|i| (i as f32 - 4.) * 0.03)
                            .collect::<Vec<_>>(),
                        (b, a),
                        &Device::Cpu,
                    )?,
                );
                weights.insert(
                    format!("{key}.bias"),
                    Tensor::from_vec(vec![0.1f32; b], b, &Device::Cpu)?,
                );
            }
        }
        let evaluator = Evaluator {
            weights,
            device: Device::Cpu,
            num_blocks: 0,
            rbf_dn: [0.; 4],
            rbf_en: [0.; 4],
            sbf_factor: 0.,
            sbf_coef: vec![],
            graph_cache: Mutex::new(None),
            gradient_trace_nodes: Mutex::new(vec![]),
            profile: std::sync::Arc::new(crate::evaluation::profile::ProfileCollector::default()),
            energy_reduction: super::EnergyReduction::Default,
        };
        let x = Var::from_vec(
            (0..519 * 3)
                .map(|i| (i as f32 % 31. - 15.) / 11.)
                .collect::<Vec<_>>(),
            (519, 3),
            &Device::Cpu,
        )?;
        let direct = evaluator.gated_direct(&x, "test", 2)?;
        let bounded = evaluator.gated(&x, "test", 2)?;
        let dy = direct.sqr()?.sum_all()?.backward()?;
        let by = bounded.sqr()?.sum_all()?.backward()?;
        for (a, b) in direct
            .flatten_all()?
            .to_vec1::<f32>()?
            .iter()
            .zip(bounded.flatten_all()?.to_vec1::<f32>()?)
        {
            assert!((a - b).abs() < 1e-6, "value mismatch: {a} vs {b}");
        }
        for (a, b) in dy
            .get(&x)
            .unwrap()
            .flatten_all()?
            .to_vec1::<f32>()?
            .iter()
            .zip(by.get(&x).unwrap().flatten_all()?.to_vec1::<f32>()?)
        {
            assert!(
                (a - b).abs() < 1e-6,
                "gradient mismatch: {a} vs {b}, delta {}",
                (a - b).abs()
            );
        }

        let make_input = |phase: f32| {
            Var::from_vec(
                (0..519)
                    .map(|i| ((i as f32 + phase) * 0.07).sin())
                    .collect::<Vec<_>>(),
                (519, 1),
                &Device::Cpu,
            )
        };
        let a = make_input(0.0)?;
        let b = make_input(1.0)?;
        let c = make_input(2.0)?;
        let direct_input = Tensor::cat(&[a.as_tensor(), b.as_tensor(), c.as_tensor()], 1)?;
        let direct_output = evaluator.gated_direct(&direct_input, "test", 2)?;
        let bounded_output =
            evaluator.gated_edges(a.as_tensor(), b.as_tensor(), c.as_tensor(), "test", 2)?;
        for (direct, bounded) in direct_output
            .flatten_all()?
            .to_vec1::<f32>()?
            .iter()
            .zip(bounded_output.flatten_all()?.to_vec1::<f32>()?)
        {
            assert!((direct - bounded).abs() < 1e-6);
        }
        let direct_grads = direct_output.sqr()?.sum_all()?.backward()?;
        let bounded_grads = bounded_output.sqr()?.sum_all()?.backward()?;
        for variable in [&a, &b, &c] {
            for (direct, bounded) in direct_grads
                .get(variable)
                .unwrap()
                .flatten_all()?
                .to_vec1::<f32>()?
                .iter()
                .zip(
                    bounded_grads
                        .get(variable)
                        .unwrap()
                        .flatten_all()?
                        .to_vec1::<f32>()?,
                )
            {
                assert!((direct - bounded).abs() < 1e-6);
            }
        }
        Ok(())
    }
}

pub(super) struct BasisCheckpoint {
    pub evaluator: Arc<Evaluator>,
}
impl CustomOp2 for BasisCheckpoint {
    fn name(&self) -> &'static str {
        "mattersim-sbf-row-checkpoint"
    }
    fn cpu_fwd(
        &self,
        a: &CpuStorage,
        la: &Layout,
        b: &CpuStorage,
        lb: &Layout,
    ) -> CandleResult<(CpuStorage, Shape)> {
        let profile_start = self.evaluator.profile.start(2);
        let (CpuStorage::F32(a), CpuStorage::F32(b)) = (a, b) else {
            candle_core::bail!("basis checkpoint needs f32")
        };
        let (sa, ea) = la
            .contiguous_offsets()
            .ok_or_else(|| candle_core::Error::Msg("noncontiguous basis length".into()))?;
        let (sb, eb) = lb
            .contiguous_offsets()
            .ok_or_else(|| candle_core::Error::Msg("noncontiguous basis cosine".into()))?;
        let n = ea - sa;
        if eb - sb != n {
            candle_core::bail!("basis input size mismatch")
        }
        let mut out = Vec::with_capacity(n * 16);
        for row in (0..n).step_by(SBF_ROWS) {
            let count = SBF_ROWS.min(n - row);
            let a = Tensor::from_vec(a[sa + row..sa + row + count].to_vec(), count, &Device::Cpu)?;
            let b = Tensor::from_vec(b[sb + row..sb + row + count].to_vec(), count, &Device::Cpu)?;
            out.extend(
                self.evaluator
                    .sbf_direct(&a, &b)?
                    .flatten_all()?
                    .to_vec1::<f32>()?,
            );
        }
        self.evaluator
            .profile
            .record_since("checkpoint.sbf.forward", profile_start);
        self.evaluator
            .profile
            .increment("checkpoint.sbf.forward_rows", n as u64);
        self.evaluator
            .profile
            .increment("checkpoint.sbf.explicit_output_bytes", (n * 16 * 4) as u64);
        Ok((CpuStorage::F32(out), Shape::from((n, 16))))
    }
    fn bwd(
        &self,
        a: &Tensor,
        b: &Tensor,
        _res: &Tensor,
        grad: &Tensor,
    ) -> CandleResult<(Option<Tensor>, Option<Tensor>)> {
        let profile_start = self.evaluator.profile.start(1);
        let n = a.elem_count();
        let mut ga = Vec::with_capacity(n);
        let mut gb = Vec::with_capacity(n);
        for row in (0..n).step_by(SBF_ROWS) {
            let count = SBF_ROWS.min(n - row);
            #[cfg(feature = "analytic-sbf-backward")]
            {
                let (length_gradient, cosine_gradient) = self.evaluator.sbf_input_gradient_direct(
                    &a.narrow(0, row, count)?.contiguous()?.detach(),
                    &b.narrow(0, row, count)?.contiguous()?.detach(),
                    &grad.narrow(0, row, count)?.contiguous()?.detach(),
                )?;
                ga.extend(length_gradient.to_vec1::<f32>()?);
                gb.extend(cosine_gradient.to_vec1::<f32>()?);
                continue;
            }
            #[cfg(not(feature = "analytic-sbf-backward"))]
            {
                let va = Var::from_tensor(&a.narrow(0, row, count)?.contiguous()?.detach())?;
                let vb = Var::from_tensor(&b.narrow(0, row, count)?.contiguous()?.detach())?;
                let y = self.evaluator.sbf_direct(&va, &vb)?;
                let loss = y
                    .mul(&grad.narrow(0, row, count)?.contiguous()?.detach())?
                    .sum_all()?;
                let grads = loss.backward()?;
                ga.extend(
                    grads
                        .get(&va)
                        .ok_or_else(|| {
                            candle_core::Error::Msg("missing basis length gradient".into())
                        })?
                        .to_vec1::<f32>()?,
                );
                gb.extend(
                    grads
                        .get(&vb)
                        .ok_or_else(|| {
                            candle_core::Error::Msg("missing basis cosine gradient".into())
                        })?
                        .to_vec1::<f32>()?,
                );
            }
        }
        self.evaluator
            .profile
            .record_since("checkpoint.sbf.backward_recompute", profile_start);
        self.evaluator
            .profile
            .increment("checkpoint.sbf.backward_rows", n as u64);
        Ok((
            Some(Tensor::from_vec(ga, a.shape(), &Device::Cpu)?),
            Some(Tensor::from_vec(gb, b.shape(), &Device::Cpu)?),
        ))
    }
}

pub(super) struct BlockCheckpoint {
    pub evaluator: Arc<Evaluator>,
    pub graph: Arc<OrderedGraph>,
    pub block: usize,
    pub n: usize,
    pub e: usize,
    pub width: usize,
}
impl BlockCheckpoint {
    fn run(&self, state: &Tensor, geometry: &Tensor) -> CandleResult<Tensor> {
        let atom = state
            .narrow(0, 0, self.n * self.width)?
            .reshape((self.n, self.width))?;
        let edge = state
            .narrow(0, self.n * self.width, self.e * self.width)?
            .reshape((self.e, self.width))?;
        let pos = geometry.narrow(0, 0, self.n)?;
        let cell = geometry.narrow(0, self.n, 3)?;
        let (a, b) =
            self.evaluator
                .forward_block(&self.graph, self.block, atom, edge, &pos, &cell)?;
        Tensor::cat(&[a.flatten_all()?, b.flatten_all()?], 0)
    }
}
impl CustomOp2 for BlockCheckpoint {
    fn name(&self) -> &'static str {
        "mattersim-block-checkpoint"
    }
    fn cpu_fwd(
        &self,
        a: &CpuStorage,
        la: &Layout,
        b: &CpuStorage,
        lb: &Layout,
    ) -> CandleResult<(CpuStorage, Shape)> {
        let profile_start = self.evaluator.profile.start(2);
        let (CpuStorage::F32(a), CpuStorage::F32(b)) = (a, b) else {
            candle_core::bail!("block checkpoint needs f32")
        };
        let (sa, ea) = la
            .contiguous_offsets()
            .ok_or_else(|| candle_core::Error::Msg("noncontiguous state".into()))?;
        let (sb, eb) = lb
            .contiguous_offsets()
            .ok_or_else(|| candle_core::Error::Msg("noncontiguous geometry".into()))?;
        let a = Tensor::from_vec(a[sa..ea].to_vec(), la.shape(), &Device::Cpu)?;
        let b = Tensor::from_vec(b[sb..eb].to_vec(), lb.shape(), &Device::Cpu)?;
        let out = self.run(&a, &b)?;
        self.evaluator.profile.record_since(
            &format!("checkpoint.block.{}.forward", self.block),
            profile_start,
        );
        self.evaluator.profile.increment(
            "checkpoint.block.forward_state_bytes",
            ((self.n + self.e) * self.width * 4) as u64,
        );
        Ok((CpuStorage::F32(out.to_vec1::<f32>()?), out.shape().clone()))
    }
    fn bwd(
        &self,
        a: &Tensor,
        b: &Tensor,
        _res: &Tensor,
        grad: &Tensor,
    ) -> CandleResult<(Option<Tensor>, Option<Tensor>)> {
        let profile_start = self.evaluator.profile.start(1);
        let va = Var::from_tensor(&a.detach())?;
        let vb = Var::from_tensor(&b.detach())?;
        let recompute_start = self.evaluator.profile.start(2);
        let result = self.run(&va, &vb)?;
        self.evaluator.profile.record_since(
            &format!("checkpoint.block.{}.backward_forward_recompute", self.block),
            recompute_start,
        );
        let gradient_start = self.evaluator.profile.start(2);
        #[cfg(feature = "consuming-checkpoint-backward")]
        let grads = result.backward_consuming_with_gradient(&grad.detach())?;
        #[cfg(not(feature = "consuming-checkpoint-backward"))]
        let grads = result.backward_with_gradient(&grad.detach())?;
        self.evaluator.profile.record_since(
            &format!("checkpoint.block.{}.backward_autodiff", self.block),
            gradient_start,
        );
        self.evaluator.profile.record_since(
            &format!("checkpoint.block.{}.backward_recompute", self.block),
            profile_start,
        );
        self.evaluator.profile.increment(
            "checkpoint.block.backward_state_bytes",
            ((self.n + self.e) * self.width * 4) as u64,
        );
        self.evaluator
            .profile
            .increment("checkpoint.block.backward_calls", 1);
        Ok((grads.get(&va).cloned(), grads.get(&vb).cloned()))
    }
}

pub(super) struct TripleAggregate {
    pub first: Vec<u32>,
    pub second_sources: Vec<u32>,
    pub edges: usize,
    pub profile: Arc<ProfileCollector>,
}
fn f32_slice<'a>(s: &'a CpuStorage, l: &Layout) -> CandleResult<&'a [f32]> {
    let CpuStorage::F32(v) = s else {
        candle_core::bail!("triple aggregate needs f32")
    };
    let (a, b) = l.contiguous_offsets().ok_or_else(|| {
        candle_core::Error::Msg("triple aggregate requires contiguous data".into())
    })?;
    Ok(&v[a..b])
}
impl CustomOp3 for TripleAggregate {
    fn name(&self) -> &'static str {
        "mattersim-fused-triple-aggregate"
    }
    fn cpu_fwd(
        &self,
        a: &CpuStorage,
        la: &Layout,
        b: &CpuStorage,
        lb: &Layout,
        c: &CpuStorage,
        lc: &Layout,
    ) -> CandleResult<(CpuStorage, Shape)> {
        let profile_start = self.profile.start(2);
        let a = f32_slice(a, la)?;
        let b = f32_slice(b, lb)?;
        let c = f32_slice(c, lc)?;
        let width = la.dims()[1];
        let mut out = vec![0f32; self.edges * width];
        for t in 0..self.first.len() {
            let edge = self.first[t] as usize;
            let atom = self.second_sources[t] as usize;
            for k in 0..width {
                out[edge * width + k] += (a[t * width + k] * b[atom * width + k]) * c[t];
            }
        }
        self.profile
            .record_since("triple_aggregate.forward", profile_start);
        self.profile
            .increment("triple_aggregate.forward_triples", self.first.len() as u64);
        Ok((CpuStorage::F32(out), Shape::from((self.edges, width))))
    }
    fn bwd(
        &self,
        a: &Tensor,
        b: &Tensor,
        c: &Tensor,
        _res: &Tensor,
        grad: &Tensor,
    ) -> CandleResult<(Option<Tensor>, Option<Tensor>, Option<Tensor>)> {
        let profile_start = self.profile.start(1);
        let av = a.flatten_all()?.to_vec1::<f32>()?;
        let bv = b.flatten_all()?.to_vec1::<f32>()?;
        let cv = c.flatten_all()?.to_vec1::<f32>()?;
        let gv = grad.flatten_all()?.to_vec1::<f32>()?;
        let width = a.dim(1)?;
        let mut da = vec![0f32; av.len()];
        let mut db = vec![0f32; bv.len()];
        let mut dc = vec![0f32; cv.len()];
        for t in 0..self.first.len() {
            let edge = self.first[t] as usize;
            let atom = self.second_sources[t] as usize;
            for k in 0..width {
                let g = gv[edge * width + k];
                let dg = g * cv[t];
                da[t * width + k] = dg * bv[atom * width + k];
                db[atom * width + k] += dg * av[t * width + k];
                dc[t] += g * (av[t * width + k] * bv[atom * width + k]);
            }
        }
        self.profile
            .record_since("triple_aggregate.backward", profile_start);
        self.profile
            .increment("triple_aggregate.backward_triples", self.first.len() as u64);
        Ok((
            Some(Tensor::from_vec(da, a.shape(), &Device::Cpu)?),
            Some(Tensor::from_vec(db, b.shape(), &Device::Cpu)?),
            Some(Tensor::from_vec(dc, c.shape(), &Device::Cpu)?),
        ))
    }
}

#[cfg(test)]
mod aggregate_tests {
    use super::*;
    #[test]
    fn explicit_output_gradient_matches_weighted_scalar_backward() -> CandleResult<()> {
        let input = Var::from_vec(vec![0.2f32, -0.4, 0.7, 1.1], (2, 2), &Device::Cpu)?;
        let output = input.sqr()?.sin()?;
        let upstream = Tensor::from_vec(vec![0.3f32, -0.8, 1.2, 0.5], (2, 2), &Device::Cpu)?;
        let reference = output.mul(&upstream)?.sum_all()?.backward()?;
        let seeded = output.backward_with_gradient(&upstream)?;
        for (a, b) in reference
            .get(&input)
            .unwrap()
            .flatten_all()?
            .to_vec1::<f32>()?
            .iter()
            .zip(
                seeded
                    .get(&input)
                    .unwrap()
                    .flatten_all()?
                    .to_vec1::<f32>()?,
            )
        {
            assert!((a - b).abs() < 1e-7, "gradient mismatch: {a} vs {b}");
        }
        assert!(output
            .backward_with_gradient(&Tensor::zeros(4, candle_core::DType::F32, &Device::Cpu)?)
            .is_err());
        Ok(())
    }

    #[cfg(feature = "consuming-checkpoint-backward")]
    #[test]
    fn consuming_backward_honors_higher_order_mode() -> CandleResult<()> {
        let higher_order = std::env::var("CANDLE_GRAD_DO_NOT_DETACH")
            .map(|s| !s.is_empty() && s != "0")
            .unwrap_or(false);
        let x = Var::from_vec(vec![0.2f32, -0.4], 2, &Device::Cpu)?;
        let output = x.sqr()?;
        let result = output.backward_consuming_with_gradient(&Tensor::ones(
            2,
            candle_core::DType::F32,
            &Device::Cpu,
        )?);
        assert_eq!(result.is_err(), higher_order);
        if higher_order {
            assert!(result.err().unwrap().to_string().contains("first-order"));
        }
        Ok(())
    }

    #[cfg(feature = "consuming-checkpoint-backward")]
    #[test]
    fn consuming_backward_preserves_shared_graphs_and_leaf_ids() -> CandleResult<()> {
        let x = Var::from_vec(vec![0.2f32, -0.4, 0.7, 1.1], (2, 2), &Device::Cpu)?;
        let shared = x.sqr()?.sin()?;
        let make_root = || shared.sqr()?.add(&shared.exp()?);
        let upstream = Tensor::from_vec(vec![0.3f32, -0.8, 1.2, 0.5], (2, 2), &Device::Cpu)?;
        let reference = make_root()?.backward_with_gradient(&upstream)?;
        let retained = make_root()?;
        let consumed = retained
            .clone()
            .backward_consuming_with_gradient(&upstream)?;
        let again = retained.backward_with_gradient(&upstream)?;
        let exclusive = make_root()?.backward_consuming_with_gradient(&upstream)?;
        for grads in [&consumed, &again, &exclusive] {
            let expected = reference.get(&x).unwrap().flatten_all()?.to_vec1::<f32>()?;
            let actual = grads.get(&x).unwrap().flatten_all()?.to_vec1::<f32>()?;
            assert_eq!(actual, expected);
        }
        // An externally retained intermediate must still support another root.
        let after = shared.exp()?.backward_with_gradient(&upstream)?;
        let fresh = x.sqr()?.sin()?.exp()?.backward_with_gradient(&upstream)?;
        assert_eq!(
            after.get(&x).unwrap().to_vec2::<f32>()?,
            fresh.get(&x).unwrap().to_vec2::<f32>()?
        );
        Ok(())
    }

    #[cfg(feature = "consuming-checkpoint-backward")]
    #[test]
    fn consuming_backward_releases_exclusive_branched_graph_correctly() -> CandleResult<()> {
        let x = Var::from_vec(vec![0.2f32, -0.4, 0.7, 1.1], (2, 2), &Device::Cpu)?;
        let make_root = || {
            let internal = x.sqr()?.sin()?;
            internal.sqr()?.add(&internal.exp()?)
        };
        let seed = Tensor::from_vec(vec![0.3f32, -0.8, 1.2, 0.5], (2, 2), &Device::Cpu)?;
        let expected = make_root()?.backward_with_gradient(&seed)?;
        let actual = make_root()?.backward_consuming_with_gradient(&seed)?;
        assert_eq!(
            actual.get(&x).unwrap().to_vec2::<f32>()?,
            expected.get(&x).unwrap().to_vec2::<f32>()?
        );
        assert!(make_root()?
            .backward_consuming_with_gradient(&Tensor::zeros(
                4,
                candle_core::DType::F32,
                &Device::Cpu
            )?)
            .is_err());
        Ok(())
    }

    #[test]
    fn fused_triple_matches_tensor_scatter_and_all_three_gradients() -> CandleResult<()> {
        let a = Var::from_vec(vec![0.1f32, 0.3, 0.7, 0.2, -0.4, 0.8], (3, 2), &Device::Cpu)?;
        let b = Var::from_vec(vec![0.2f32, 0.9, -0.3, 0.7], (2, 2), &Device::Cpu)?;
        let c = Var::from_vec(vec![0.4f32, 0.6, 0.8], (3, 1), &Device::Cpu)?;
        let first = vec![0, 1, 0];
        let second = vec![1, 0, 1];
        let f = Tensor::from_vec(first.clone(), 3, &Device::Cpu)?;
        let s = Tensor::from_vec(second.clone(), 3, &Device::Cpu)?;
        let direct = Tensor::zeros((2, 2), candle_core::DType::F32, &Device::Cpu)?.index_add(
            &f,
            &a.mul(&b.index_select(&s, 0)?)?.broadcast_mul(&c)?,
            0,
        )?;
        let fused = a.apply_op3(
            &b,
            &c,
            TripleAggregate {
                first,
                second_sources: second,
                edges: 2,
                profile: std::sync::Arc::new(
                    crate::evaluation::profile::ProfileCollector::default(),
                ),
            },
        )?;
        let dg = direct.sqr()?.sum_all()?.backward()?;
        let fg = fused.sqr()?.sum_all()?.backward()?;
        for var in [&a, &b, &c] {
            for (x, y) in dg
                .get(var)
                .unwrap()
                .flatten_all()?
                .to_vec1::<f32>()?
                .iter()
                .zip(fg.get(var).unwrap().flatten_all()?.to_vec1::<f32>()?)
            {
                assert!((x - y).abs() < 1e-6, "{x} vs {y}");
            }
        }
        Ok(())
    }

    #[test]
    fn complete_block_recomputation_matches_eager_energy_and_geometry_gradient() -> CandleResult<()>
    {
        let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
        let evaluator = Evaluator::from_bytes(
            &std::fs::read(root.join("models/mattersim-1m.json")).unwrap(),
            &std::fs::read(root.join("models/mattersim-1m.safetensors")).unwrap(),
            Device::Cpu,
        )
        .map_err(candle_core::Error::Msg)?;
        let mut positions = vec![];
        let basis = [
            [0., 0., 0.],
            [0., 0.5, 0.5],
            [0.5, 0., 0.5],
            [0.5, 0.5, 0.],
            [0.25, 0.25, 0.25],
            [0.25, 0.75, 0.75],
            [0.75, 0.25, 0.75],
            [0.75, 0.75, 0.25],
        ];
        for i in 0..3 {
            for j in 0..3 {
                for k in 0..3 {
                    for b in basis {
                        let idx = positions.len() as f64;
                        positions.push([
                            (i as f64 + b[0]) * 5.43 + 0.017 * idx.sin(),
                            (j as f64 + b[1]) * 5.43,
                            (k as f64 + b[2]) * 5.43,
                        ]);
                    }
                }
            }
        }
        let n = positions.len();
        let structure = Structure {
            atomic_numbers: vec![14; n],
            positions_a: positions,
            cell_a: [[16.29, 0., 0.], [0., 16.29, 0.], [0., 0., 16.29]],
            pbc: [true; 3],
        };
        let graph = OrderedGraph::from_structure(&structure).map_err(candle_core::Error::Msg)?;
        let p = Var::from_vec(
            graph
                .positions_a
                .iter()
                .flatten()
                .copied()
                .collect::<Vec<_>>(),
            (n, 3),
            &Device::Cpu,
        )?;
        let c = Var::from_vec(
            graph.cell_a.iter().flatten().copied().collect::<Vec<_>>(),
            (3, 3),
            &Device::Cpu,
        )?;
        let full = evaluator.forward(&graph, &p, &c)?;
        let bounded = evaluator.forward_checkpointed(&graph, &p, &c)?;
        assert!((full.to_scalar::<f32>()? - bounded.to_scalar::<f32>()?).abs() / (n as f32) < 1e-5);
        let fg = full.backward()?;
        let bg = bounded.backward()?;
        for variable in [&p, &c] {
            for (x, y) in fg
                .get(variable)
                .unwrap()
                .flatten_all()?
                .to_vec1::<f32>()?
                .iter()
                .zip(bg.get(variable).unwrap().flatten_all()?.to_vec1::<f32>()?)
            {
                assert!((x - y).abs() < 1e-4, "{x} vs {y}");
            }
        }
        Ok(())
    }
}

pub(super) struct ConcatGated {
    pub evaluator: Arc<Evaluator>,
    pub prefix: String,
    pub layers: usize,
}
impl CustomOp3 for ConcatGated {
    fn name(&self) -> &'static str {
        "mattersim-concat-gated-checkpoint"
    }
    fn cpu_fwd(
        &self,
        a: &CpuStorage,
        la: &Layout,
        b: &CpuStorage,
        lb: &Layout,
        c: &CpuStorage,
        lc: &Layout,
    ) -> CandleResult<(CpuStorage, Shape)> {
        let a = f32_slice(a, la)?;
        let b = f32_slice(b, lb)?;
        let c = f32_slice(c, lc)?;
        let n = la.dims()[0];
        let wa = la.dims()[1];
        let wb = lb.dims()[1];
        let wc = lc.dims()[1];
        let width = wa + wb + wc;
        let mut out = vec![];
        let mut ow = 0;
        for row in (0..n).step_by(GATED_ROWS) {
            let count = GATED_ROWS.min(n - row);
            let mut packed = Vec::with_capacity(count * width);
            for r in row..row + count {
                packed.extend_from_slice(&a[r * wa..(r + 1) * wa]);
                packed.extend_from_slice(&b[r * wb..(r + 1) * wb]);
                packed.extend_from_slice(&c[r * wc..(r + 1) * wc]);
            }
            let x = Tensor::from_vec(packed, (count, width), &Device::Cpu)?;
            let y = self.evaluator.gated_direct(&x, &self.prefix, self.layers)?;
            ow = y.dim(1)?;
            out.extend(y.flatten_all()?.to_vec1::<f32>()?);
        }
        Ok((CpuStorage::F32(out), Shape::from((n, ow))))
    }
    fn bwd(
        &self,
        a: &Tensor,
        b: &Tensor,
        c: &Tensor,
        _res: &Tensor,
        grad: &Tensor,
    ) -> CandleResult<(Option<Tensor>, Option<Tensor>, Option<Tensor>)> {
        let n = a.dim(0)?;
        let wa = a.dim(1)?;
        let wb = b.dim(1)?;
        let wc = c.dim(1)?;
        let width = wa + wb + wc;
        let mut ga = Vec::with_capacity(n * wa);
        let mut gb = Vec::with_capacity(n * wb);
        let mut gc = Vec::with_capacity(n * wc);
        for row in (0..n).step_by(GATED_ROWS) {
            let count = GATED_ROWS.min(n - row);
            #[cfg(feature = "analytic-gated-backward")]
            {
                let x = Tensor::cat(
                    &[
                        a.narrow(0, row, count)?,
                        b.narrow(0, row, count)?,
                        c.narrow(0, row, count)?,
                    ],
                    1,
                )?
                .detach();
                let upstream = grad.narrow(0, row, count)?.contiguous()?.detach();
                let g = self.evaluator.gated_input_gradient_direct(
                    &x,
                    &self.prefix,
                    self.layers,
                    &upstream,
                )?;
                for r in g.flatten_all()?.to_vec1::<f32>()?.chunks_exact(width) {
                    ga.extend_from_slice(&r[..wa]);
                    gb.extend_from_slice(&r[wa..wa + wb]);
                    gc.extend_from_slice(&r[wa + wb..]);
                }
                continue;
            }
            #[cfg(not(feature = "analytic-gated-backward"))]
            {
                let x = Var::from_tensor(
                    &Tensor::cat(
                        &[
                            a.narrow(0, row, count)?,
                            b.narrow(0, row, count)?,
                            c.narrow(0, row, count)?,
                        ],
                        1,
                    )?
                    .detach(),
                )?;
                let y = self.evaluator.gated_direct(&x, &self.prefix, self.layers)?;
                let grads = y
                    .mul(&grad.narrow(0, row, count)?.contiguous()?.detach())?
                    .sum_all()?
                    .backward()?;
                let g = grads
                    .get(&x)
                    .ok_or_else(|| candle_core::Error::Msg("missing concat gradient".into()))?
                    .flatten_all()?
                    .to_vec1::<f32>()?;
                for r in g.chunks_exact(width) {
                    ga.extend_from_slice(&r[..wa]);
                    gb.extend_from_slice(&r[wa..wa + wb]);
                    gc.extend_from_slice(&r[wa + wb..]);
                }
            }
        }
        Ok((
            Some(Tensor::from_vec(ga, a.shape(), &Device::Cpu)?),
            Some(Tensor::from_vec(gb, b.shape(), &Device::Cpu)?),
            Some(Tensor::from_vec(gc, c.shape(), &Device::Cpu)?),
        ))
    }
}
