//! Explicit dense mixed-precision bundle reader. Factor execution is a separate
//! kernel version; unsupported architectures never reconstruct dense weights.
use crate::{ModelManifest, TensorSpec, REFERENCE_1M_WEIGHTS_SHA256};
use half::f16;
use serde::Serialize;
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::collections::{BTreeMap, HashMap};

#[derive(Clone, Debug, Serialize)]
pub struct BundleIdentity {
    pub bundle_id: String,
    pub policy_id: String,
    pub policy_role: String,
    pub kernel_version: String,
    pub source_weights_sha256: String,
}

pub struct DecodedBundle {
    pub source: ModelManifest,
    pub values: HashMap<String, Vec<f32>>,
    pub identity: BundleIdentity,
    pub factors: Vec<FactorLayout>,
}

pub struct FactorLayout {
    pub module: String,
    pub inputs: usize,
    pub outputs: usize,
    pub rank: usize,
    pub bias: bool,
}

fn hash(bytes: &[u8]) -> String {
    hex::encode(Sha256::digest(bytes))
}
fn text<'a>(value: &'a Value, key: &str) -> Result<&'a str, String> {
    value
        .get(key)
        .and_then(Value::as_str)
        .ok_or_else(|| format!("missing string {key}"))
}
fn canonical(value: Value) -> Value {
    match value {
        Value::Object(map) => Value::Object(
            map.into_iter()
                .collect::<BTreeMap<_, _>>()
                .into_iter()
                .map(|(k, v)| (k, canonical(v)))
                .collect(),
        ),
        Value::Array(a) => Value::Array(a.into_iter().map(canonical).collect()),
        v => v,
    }
}
fn integer(value: &Value) -> Result<usize, String> {
    usize::try_from(value.as_u64().ok_or("invalid integer")?).map_err(|_| "integer overflow".into())
}
fn neural(name: &str) -> bool {
    name.contains(".linear.") && (name.ends_with(".weight") || name.ends_with(".bias"))
}

fn decode_payload(
    specs: &[TensorSpec],
    header: &Value,
    payload: &[u8],
) -> Result<HashMap<String, Vec<f32>>, String> {
    let tensors = header["tensors"]
        .as_object()
        .ok_or("missing tensor descriptors")?;
    if tensors.len() != specs.len() {
        return Err("tensor set differs from source".into());
    }
    let mut spans = Vec::new();
    let mut values = HashMap::new();
    for spec in specs {
        let entry = tensors
            .get(&spec.name)
            .ok_or_else(|| format!("missing tensor {}", spec.name))?;
        let shape: Vec<usize> = entry["shape"]
            .as_array()
            .ok_or("missing shape")?
            .iter()
            .map(integer)
            .collect::<Result<_, _>>()?;
        if shape != spec.shape || spec.dtype != "F32" {
            return Err(format!("source shape/type mismatch: {}", spec.name));
        }
        let count = shape
            .iter()
            .try_fold(1usize, |a, b| a.checked_mul(*b))
            .ok_or("tensor size overflow")?;
        if count == 0 || count > 16000000 {
            return Err("invalid tensor size".into());
        }
        let offsets: Vec<usize> = entry["offsets"]
            .as_array()
            .ok_or("missing offsets")?
            .iter()
            .map(integer)
            .collect::<Result<_, _>>()?;
        if offsets.len() < 2
            || offsets.iter().any(|x| *x > payload.len())
            || offsets.windows(2).any(|x| x[0] > x[1])
        {
            return Err("invalid tensor offsets".into());
        }
        let bits = integer(&entry["bits"])?;
        let mut data = Vec::with_capacity(count);
        if bits == 16 || bits == 32 {
            if bits == 16 && !neural(&spec.name) {
                return Err("FP16 geometry/basis tensor forbidden".into());
            }
            if offsets.len() != 2 || offsets[1] - offsets[0] != count * (bits / 8) {
                return Err("float payload size mismatch".into());
            }
            let raw = &payload[offsets[0]..offsets[1]];
            if bits == 16 {
                data.extend(
                    raw.chunks_exact(2)
                        .map(|x| f16::from_bits(u16::from_le_bytes([x[0], x[1]])).to_f32()),
                );
            } else {
                data.extend(
                    raw.chunks_exact(4)
                        .map(|x| f32::from_le_bytes(x.try_into().unwrap())),
                );
            }
        } else if bits == 4 || bits == 8 {
            if shape.len() != 2
                || !(spec.name.contains(".linear.") && spec.name.ends_with(".weight"))
                || offsets.len() != 3
            {
                return Err("invalid quantized matrix".into());
            }
            let group = integer(&entry["group_size"])?;
            if group != 32 && group != 64 {
                return Err("unsupported group size".into());
            }
            let (rows, cols) = (shape[0], shape[1]);
            let groups = cols.div_ceil(group);
            let padded = rows
                .checked_mul(groups)
                .and_then(|n| n.checked_mul(group))
                .ok_or("packed size overflow")?;
            if offsets[1] - offsets[0] != padded * bits / 8
                || offsets[2] - offsets[1] != rows * groups * 4
            {
                return Err("packed payload size mismatch".into());
            }
            let codes = &payload[offsets[0]..offsets[1]];
            let scales: Vec<_> = payload[offsets[1]..offsets[2]]
                .chunks_exact(4)
                .map(|x| f32::from_le_bytes(x.try_into().unwrap()))
                .collect();
            if scales.iter().any(|x| !x.is_finite() || *x <= 0.) {
                return Err("invalid quantization scale".into());
            }
            for row in 0..rows {
                for col in 0..cols {
                    let index = row * groups * group + col;
                    let code = if bits == 4 {
                        (codes[index / 2] >> ((index % 2) * 4)) & 15
                    } else {
                        codes[index]
                    };
                    data.push(
                        (code as i16 - (1i16 << (bits - 1))) as f32
                            * scales[row * groups + col / group],
                    );
                }
            }
        } else {
            return Err("unsupported tensor encoding".into());
        }
        if data.iter().any(|x| !x.is_finite()) {
            return Err("non-finite decoded model".into());
        }
        spans.push((offsets[0], *offsets.last().unwrap()));
        values.insert(spec.name.clone(), data);
    }
    spans.sort_unstable();
    let mut end = 0;
    for (start, stop) in spans {
        if start != end {
            return Err("overlapping tensors or unused bytes".into());
        }
        end = stop;
    }
    if end != payload.len() {
        return Err("trailing model bytes".into());
    }
    Ok(values)
}

fn decode_neural_f16_payload(
    specs: &[TensorSpec],
    payload: &[u8],
) -> Result<HashMap<String, Vec<f32>>, String> {
    decode_neural_f16_bias_payload(specs, payload, None)
}

fn decode_neural_f16_bias_payload(
    specs: &[TensorSpec],
    payload: &[u8],
    fp32_bias_mask: Option<&[u8]>,
) -> Result<HashMap<String, Vec<f32>>, String> {
    if let Some(mask) = fp32_bias_mask {
        if mask.len() != specs.len().div_ceil(8)
            || (specs.len() % 8 != 0 && mask.last().copied().unwrap_or(0) >> (specs.len() % 8) != 0)
        {
            return Err("invalid compact bias mask length/padding".into());
        }
    }
    let mut offset = 0usize;
    let mut values = HashMap::new();
    for (index, spec) in specs.iter().enumerate() {
        let fp32_bias = fp32_bias_mask
            .map(|mask| mask[index / 8] & (1 << (index % 8)) != 0)
            .unwrap_or(false);
        if fp32_bias
            && !(spec.name.contains(".linear.")
                && spec.name.ends_with(".bias")
                && spec.shape.len() == 1)
        {
            return Err("compact precision flag must name a neural bias".into());
        }
        let count = spec
            .shape
            .iter()
            .try_fold(1usize, |a, b| a.checked_mul(*b))
            .ok_or("compact tensor size overflow")?;
        if count == 0 || count > 16000000 {
            return Err("invalid compact tensor size".into());
        }
        let item_size = if neural(&spec.name) && !fp32_bias {
            2
        } else {
            4
        };
        let end = offset
            .checked_add(count * item_size)
            .ok_or("compact offset overflow")?;
        let raw = payload.get(offset..end).ok_or("truncated compact tensor")?;
        let data: Vec<f32> = if item_size == 2 {
            raw.chunks_exact(2)
                .map(|x| f16::from_bits(u16::from_le_bytes([x[0], x[1]])).to_f32())
                .collect()
        } else {
            raw.chunks_exact(4)
                .map(|x| f32::from_le_bytes(x.try_into().unwrap()))
                .collect()
        };
        if data.iter().any(|x| !x.is_finite()) {
            return Err("nonfinite compact tensor".into());
        }
        values.insert(spec.name.clone(), data);
        offset = end;
    }
    if offset != payload.len() {
        return Err("trailing compact model bytes".into());
    }
    Ok(values)
}

pub fn decode_bundle(
    source_bytes: &[u8],
    manifest_bytes: &[u8],
    artifact: &[u8],
    role: &str,
) -> Result<DecodedBundle, String> {
    if source_bytes.len() > 1048576
        || manifest_bytes.len() > 1048576
        || artifact.len() > 64 * 1024 * 1024
        || artifact.len() < 8
    {
        return Err("bundle size limit".into());
    }
    if role != "relax" && role != "phonon" {
        return Err("unknown policy role".into());
    }
    let source = ModelManifest::from_json_bytes(source_bytes)?;
    if source.weights_sha256 != REFERENCE_1M_WEIGHTS_SHA256 {
        return Err("optimized bundle requires pinned MatterSim1M source".into());
    }
    let mut manifest: Value = serde_json::from_slice(manifest_bytes).map_err(|e| e.to_string())?;
    let factor_kernel = text(&manifest, "kernel_version")? == "factorized-fp32-v1";
    let mixed_bias = text(&manifest, "kernel_version")? == "dense-f16-bias-fp32-v1";
    let compact_f16 = [
        "dense-f16-fp32-v1",
        "dense-f16-fp32-v2",
        "dense-f16-fp32-v3",
        "dense-f16-bias-fp32-v1",
    ]
    .contains(&text(&manifest, "kernel_version")?);
    if text(&manifest, "schema")? != "macer-optimized-bundle-v1"
        || !(factor_kernel
            || compact_f16
            || text(&manifest, "kernel_version")? == "mixed-dense-fp32-v1")
    {
        return Err("unsupported bundle/kernel".into());
    }
    let bundle_id = text(&manifest, "bundle_id")?.to_string();
    manifest
        .as_object_mut()
        .ok_or("invalid bundle manifest")?
        .remove("bundle_id");
    if hash(&serde_json::to_vec(&canonical(manifest.clone())).map_err(|e| e.to_string())?)
        != bundle_id
    {
        return Err("bundle identity mismatch".into());
    }
    if text(&manifest["source_manifest"], "path")? != "source-model.json"
        || text(&manifest["source_manifest"], "sha256")? != hash(source_bytes)
        || text(&manifest, "source_weights_sha256")? != source.weights_sha256
    {
        return Err("source identity mismatch".into());
    }
    if manifest["tensors"]
        .as_object()
        .ok_or("missing shared tensor set")?
        .len()
        != 1
    {
        return Err("unsupported tensor-set layout".into());
    }
    let shared = &manifest["tensors"]["shared"];
    if text(shared, "path")? != "weights.bin"
        || text(shared, "format")?
            != if mixed_bias {
                "macer-mattersim-neural-f16-bias-v1"
            } else if compact_f16 {
                "macer-mattersim-neural-f16-v1"
            } else {
                "macer-mattersim-groupwise-v1"
            }
        || text(shared, "sha256")? != hash(artifact)
    {
        return Err("artifact identity mismatch".into());
    }
    if manifest["policies"]
        .as_object()
        .ok_or("missing policies")?
        .len()
        != 2
    {
        return Err("expected Relax and phonon policies".into());
    }
    for name in ["relax", "phonon"] {
        if text(&manifest["policies"][name], "tensor_set")? != "shared"
            || text(&manifest["policies"][name], "id")?
                != format!(
                    "{}:{}",
                    if mixed_bias {
                        "dense-f16-bias"
                    } else if text(&manifest, "kernel_version")? == "dense-f16-fp32-v3" {
                        "dense-f16-v3"
                    } else if text(&manifest, "kernel_version")? == "dense-f16-fp32-v2" {
                        "dense-f16-v2"
                    } else if compact_f16 {
                        "dense-f16"
                    } else if factor_kernel {
                        "factorized"
                    } else {
                        "mixed-dense"
                    },
                    hash(artifact)
                )
        {
            return Err("unsupported policy descriptor".into());
        }
    }
    if compact_f16 {
        let pinned: ModelManifest =
            serde_json::from_str(include_str!("../../../models/mattersim-1m.json"))
                .map_err(|e| e.to_string())?;
        if source != pinned {
            return Err("compact source architecture differs".into());
        }
        let expected_magic = if mixed_bias {
            b"MCRF16\x00\x02"
        } else {
            b"MCRF16\x00\x01"
        };
        if &artifact[..8] != expected_magic {
            return Err("invalid dense-FP16 magic/version".into());
        }
        let values = if mixed_bias {
            let offset = 8 + source.tensors.len().div_ceil(8);
            let mask = artifact
                .get(8..offset)
                .ok_or("truncated compact bias mask")?;
            let payload = artifact
                .get(offset..)
                .ok_or("truncated compact bias payload")?;
            decode_neural_f16_bias_payload(&source.tensors, payload, Some(mask))?
        } else {
            decode_neural_f16_payload(&source.tensors, &artifact[8..])?
        };
        let identity = BundleIdentity {
            bundle_id,
            policy_id: text(&manifest["policies"][role], "id")?.into(),
            policy_role: role.into(),
            kernel_version: text(&manifest, "kernel_version")?.into(),
            source_weights_sha256: source.weights_sha256.clone(),
        };
        return Ok(DecodedBundle {
            source,
            values,
            identity,
            factors: Vec::new(),
        });
    }
    let header_size = usize::try_from(u64::from_le_bytes(artifact[..8].try_into().unwrap()))
        .map_err(|_| "header size overflow")?;
    if header_size > 1048576 || header_size > artifact.len() - 8 {
        return Err("invalid artifact header".into());
    }
    let header: Value =
        serde_json::from_slice(&artifact[8..8 + header_size]).map_err(|e| e.to_string())?;
    if text(&header, "schema")? != "macer-mattersim-groupwise-v1"
        || text(&header, "source_weights_sha256")? != source.weights_sha256
        || integer(&header["units"])? != 128
    {
        return Err("artifact architecture/source mismatch".into());
    }
    let layers = header
        .get("factorized_layers")
        .and_then(Value::as_array)
        .ok_or("missing factor declarations")?;
    if !factor_kernel && !layers.is_empty() {
        return Err("factor execution needs a separate kernel version".into());
    }
    if factor_kernel && layers.is_empty() {
        return Err("factor kernel requires factors".into());
    }
    let mut specs = source.tensors.clone();
    let mut factors = Vec::new();
    let mut seen = std::collections::HashSet::new();
    for layer in layers {
        let module = layer.as_str().ok_or("invalid factor module")?;
        if !module.ends_with(".linear") || !seen.insert(module.to_string()) {
            return Err("invalid/duplicate factor module".into());
        }
        let original = source
            .tensors
            .iter()
            .find(|x| x.name == format!("{module}.weight"))
            .ok_or("factor module not in source")?;
        if original.shape.len() != 2 {
            return Err("factor source is not a matrix".into());
        }
        let (outputs, inputs) = (original.shape[0], original.shape[1]);
        let down = format!("{module}.down.weight");
        let up = format!("{module}.up.weight");
        let rank = integer(&header["tensors"][&down]["shape"][0])?;
        if ![16, 32, 64].contains(&rank) || rank >= inputs.min(outputs) {
            return Err("invalid factor rank".into());
        }
        let bias = source
            .tensors
            .iter()
            .any(|x| x.name == format!("{module}.bias"));
        specs.retain(|x| x.name != original.name && x.name != format!("{module}.bias"));
        specs.push(TensorSpec {
            name: down,
            dtype: "F32".into(),
            shape: vec![rank, inputs],
        });
        specs.push(TensorSpec {
            name: up,
            dtype: "F32".into(),
            shape: vec![outputs, rank],
        });
        if bias {
            specs.push(TensorSpec {
                name: format!("{module}.up.bias"),
                dtype: "F32".into(),
                shape: vec![outputs],
            });
        }
        factors.push(FactorLayout {
            module: module.into(),
            inputs,
            outputs,
            rank,
            bias,
        });
    }
    let values = decode_payload(&specs, &header, &artifact[8 + header_size..])?;
    let identity = BundleIdentity {
        bundle_id,
        policy_id: text(&manifest["policies"][role], "id")?.to_string(),
        policy_role: role.into(),
        kernel_version: text(&manifest, "kernel_version")?.into(),
        source_weights_sha256: source.weights_sha256.clone(),
    };
    Ok(DecodedBundle {
        source,
        values,
        identity,
        factors,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn compact_bias_precision_mask_preserves_fp32_and_rejects_invalid_flags() {
        let specs = vec![
            TensorSpec {
                name: "test.linear.weight".into(),
                dtype: "F32".into(),
                shape: vec![1, 2],
            },
            TensorSpec {
                name: "test.linear.bias".into(),
                dtype: "F32".into(),
                shape: vec![1],
            },
            TensorSpec {
                name: "rbf.factor".into(),
                dtype: "F32".into(),
                shape: vec![1],
            },
        ];
        let mut bytes = Vec::new();
        bytes.extend(f16::from_f32(0.12345).to_bits().to_le_bytes());
        bytes.extend(f16::from_f32(-0.34567).to_bits().to_le_bytes());
        bytes.extend(0.12345679f32.to_le_bytes());
        bytes.extend(0.8765432f32.to_le_bytes());
        let decoded = decode_neural_f16_bias_payload(&specs, &bytes, Some(&[2])).unwrap();
        assert_eq!(decoded["test.linear.bias"], vec![0.12345679]);
        assert_eq!(decoded["rbf.factor"], vec![0.8765432]);
        assert_eq!(
            decoded["test.linear.weight"][0],
            f16::from_f32(0.12345).to_f32()
        );
        for mask in [vec![], vec![2, 0], vec![1], vec![4], vec![128]] {
            assert!(decode_neural_f16_bias_payload(&specs, &bytes, Some(&mask)).is_err());
        }
        assert!(decode_neural_f16_bias_payload(&specs, &bytes[..11], Some(&[2])).is_err());
        let mut trailing = bytes.clone();
        trailing.push(0);
        assert!(decode_neural_f16_bias_payload(&specs, &trailing, Some(&[2])).is_err());
        bytes[4..8].copy_from_slice(&f32::NAN.to_le_bytes());
        assert!(decode_neural_f16_bias_payload(&specs, &bytes, Some(&[2])).is_err());
    }

    #[test]
    fn compact_f16_keeps_physics_f32_and_rejects_truncation_trailing_nonfinite() {
        let specs = vec![
            TensorSpec {
                name: "test.linear.weight".into(),
                dtype: "F32".into(),
                shape: vec![1, 2],
            },
            TensorSpec {
                name: "rbf.factor".into(),
                dtype: "F32".into(),
                shape: vec![1],
            },
        ];
        let mut bytes = Vec::new();
        bytes.extend(f16::from_f32(0.12345).to_bits().to_le_bytes());
        bytes.extend(f16::from_f32(-0.34567).to_bits().to_le_bytes());
        bytes.extend(0.12345679f32.to_le_bytes());
        let decoded = decode_neural_f16_payload(&specs, &bytes).unwrap();
        assert_eq!(decoded["rbf.factor"], vec![0.12345679]);
        assert_eq!(
            decoded["test.linear.weight"][0],
            f16::from_f32(0.12345).to_f32()
        );
        assert!(decode_neural_f16_payload(&specs, &bytes[..bytes.len() - 1]).is_err());
        let mut trailing = bytes.clone();
        trailing.push(0);
        assert!(decode_neural_f16_payload(&specs, &trailing).is_err());
        bytes[..2].copy_from_slice(&f16::INFINITY.to_bits().to_le_bytes());
        assert!(decode_neural_f16_payload(&specs, &bytes).is_err());
    }

    #[test]
    fn mixed_payload_decodes_row_tail_and_rejects_geometry_half_precision() {
        let spec = TensorSpec {
            name: "test.linear.weight".into(),
            dtype: "F32".into(),
            shape: vec![1, 3],
        };
        for bits in [4, 8] {
            let mut codes =
                vec![if bits == 4 { 0x88 } else { 128 }; if bits == 4 { 16 } else { 32 }];
            if bits == 4 {
                codes[0] = 0x69;
                codes[1] = 0x8b;
            } else {
                codes[..3].copy_from_slice(&[129, 126, 131]);
            }
            let end = codes.len();
            codes.extend(0.25f32.to_le_bytes());
            let h = serde_json::json!({"tensors":{(spec.name.clone()):{"shape":[1,3],"bits":bits,"group_size":32,"offsets":[0,end,end+4]}}});
            let v = decode_payload(&[spec.clone()], &h, &codes).unwrap();
            assert_eq!(v[&spec.name], vec![0.25, -0.5, 0.75]);
            let mut trailing = codes.clone();
            trailing.push(0);
            assert!(decode_payload(&[spec.clone()], &h, &trailing).is_err());
        }
        let spec = TensorSpec {
            name: "rbf.fnr_weights".into(),
            dtype: "F32".into(),
            shape: vec![1],
        };
        let h = serde_json::json!({"tensors":{(spec.name.clone()):{"shape":[1],"bits":16,"offsets":[0,2]}}});
        assert!(decode_payload(&[spec], &h, &[0, 0]).is_err());
    }
}
