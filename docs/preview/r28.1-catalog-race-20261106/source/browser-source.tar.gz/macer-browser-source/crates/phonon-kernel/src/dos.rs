//! Mesh DOS: phonors tetrahedron weights at central mesh vertices; Gaussian alternative.
use crate::{
    tetrahedron::{integration_weight, relative_grid_address, WeightFunction},
    KernelError,
};
/// Return atom-major density arrays for a contiguous batch of mesh vertices.
pub fn dos_chunk(
    mesh: [usize; 3],
    microzone: [[f64; 3]; 3],
    frequencies: &[f64],
    weights: &[f64],
    grid: &[f64],
    atoms: usize,
    start: usize,
    count: usize,
    sigma: f64,
) -> Result<Vec<f64>, KernelError> {
    let nq = mesh
        .iter()
        .try_fold(1usize, |a, &n| a.checked_mul(n))
        .ok_or(KernelError::InvalidDimensions)?;
    let nb = atoms.checked_mul(3).ok_or(KernelError::InvalidDimensions)?;
    if atoms == 0
        || mesh.iter().any(|&n| n < 2)
        || frequencies.len() != nq * nb
        || weights.len() != count * nb * atoms
        || start + count > nq
        || grid.len() < 2
        || !grid.windows(2).all(|w| w[1] > w[0])
    {
        return Err(KernelError::InvalidDimensions);
    }
    if !frequencies
        .iter()
        .chain(weights)
        .chain(grid)
        .all(|x| x.is_finite())
        || !sigma.is_finite()
        || sigma < 0.
        || !microzone.iter().flatten().all(|x| x.is_finite())
    {
        return Err(KernelError::NonFiniteInput);
    }
    let (addresses, _) = relative_grid_address(microzone);
    let nf = grid.len();
    let mut out = vec![0.; atoms * nf];
    for local in 0..count {
        let qi = start + local;
        let coord = [
            qi % mesh[0],
            (qi / mesh[0]) % mesh[1],
            qi / (mesh[0] * mesh[1]),
        ];
        for mode in 0..nb {
            let mut tet = [[0.; 4]; 24];
            let (lo, hi) = if sigma == 0. {
                for t in 0..24 {
                    for v in 0..4 {
                        let c: [usize; 3] = std::array::from_fn(|a| {
                            (coord[a] as i64 + addresses[t][v][a]).rem_euclid(mesh[a] as i64)
                                as usize
                        });
                        let j = c[0] + mesh[0] * (c[1] + mesh[1] * c[2]);
                        tet[t][v] = frequencies[j * nb + mode];
                    }
                }
                (
                    tet.iter().flatten().copied().fold(f64::INFINITY, f64::min),
                    tet.iter()
                        .flatten()
                        .copied()
                        .fold(f64::NEG_INFINITY, f64::max),
                )
            } else {
                let f = frequencies[qi * nb + mode];
                (f - 6. * sigma, f + 6. * sigma)
            };
            let first = grid.partition_point(|&x| x < lo);
            let last = grid.partition_point(|&x| x <= hi);
            for k in first..last {
                let density = if sigma == 0. {
                    integration_weight(grid[k], &tet, WeightFunction::I)
                } else {
                    let d = (grid[k] - frequencies[qi * nb + mode]) / sigma;
                    (-d * d / 2.).exp() / (sigma * (2. * std::f64::consts::PI).sqrt())
                } / nq as f64;
                if !density.is_finite() {
                    return Err(KernelError::NonFiniteInput);
                }
                for atom in 0..atoms {
                    out[atom * nf + k] += density * weights[(local * nb + mode) * atoms + atom];
                }
            }
        }
    }
    Ok(out)
}
