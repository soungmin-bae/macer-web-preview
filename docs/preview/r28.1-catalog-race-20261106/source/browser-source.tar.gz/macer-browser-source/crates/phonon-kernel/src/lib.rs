//! Python-free, single-thread phonon kernels.
//!
//! The dynamical-matrix block accumulation follows the algorithm in
//! `phonors` 0.3.0 (`src/dynmat.rs`, BSD-3-Clause), commit
//! `ca6eac4464cea519fef1d6d8018b4d13c20fa84d`. This small safe-slice
//! implementation deliberately excludes its PyO3/NumPy and Rayon layers.
//! See `third_party/licenses/phonors-v0.3.0-LICENSE` for the license.

use std::f64::consts::PI;

mod diagonalize;
mod dos;
mod tetrahedron;
pub use dos::dos_chunk;
mod force_constants;
mod nac;

#[cfg(target_arch = "wasm32")]
mod wasm_api;

pub type Complex64 = [f64; 2];
pub type Vec3 = [f64; 3];

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum KernelError {
    InvalidDimensions,
    InvalidMapping,
    InvalidMultiplicity,
    InvalidMass,
    NonFiniteInput,
    NonHermitian,
    EigenFailure,
}

#[derive(Clone, Copy)]
pub struct DynamicalMatrixInput<'a> {
    /// Full force constants, flattened as `[primitive row, supercell atom, α, β]`.
    pub force_constants: &'a [f64],
    pub q: Vec3,
    /// Shortest vectors, flattened behind the offsets in `multiplicity_start`.
    pub shortest_vectors: &'a [Vec3],
    /// Each pair is `[multiplicity, first_shortest_vector_index]`, in
    /// `[supercell_atom, primitive_atom]` order.
    pub multiplicity_start: &'a [[usize; 2]],
    pub masses: &'a [f64],
    pub supercell_to_primitive: &'a [usize],
    pub primitive_to_force_constant_row: &'a [usize],
    pub primitive_atoms: usize,
    pub supercell_atoms: usize,
}

pub use diagonalize::{diagonalize_hermitian, EigenResult};
pub use force_constants::{
    force_constants_from_central_forces, force_constants_full_from_symmetry_reduced_rows,
    force_constants_row_from_symmetry_reduced_forces, perm_trans_symmetrize_compact_fc,
    perm_trans_symmetrize_full_fc, ForcePair, SymmetryReducedDisplacementSet,
};
pub use nac::{get_recip_dipole_dipole, get_recip_dipole_dipole_q0};

/// Builds one Hermitian dynamical matrix at a reciprocal-coordinate q-point.
/// Output is row-major `[3N, 3N]`, with each complex entry `[real, imaginary]`.
/// Force constants are in eV/Å²; mass and frequency-unit conversions are left
/// to the caller, matching the phonors kernel boundary.
pub fn dynamical_matrix_at_q(
    input: DynamicalMatrixInput<'_>,
) -> Result<Vec<Complex64>, KernelError> {
    let np = input.primitive_atoms;
    let ns = input.supercell_atoms;
    let compact_fc_len = np
        .checked_mul(ns)
        .and_then(|v| v.checked_mul(9))
        .ok_or(KernelError::InvalidDimensions)?;
    let full_fc_len = ns
        .checked_mul(ns)
        .and_then(|v| v.checked_mul(9))
        .ok_or(KernelError::InvalidDimensions)?;
    if np == 0
        || ns == 0
        || input.masses.len() != np
        || input.supercell_to_primitive.len() != ns
        || input.primitive_to_force_constant_row.len() != np
        || input.multiplicity_start.len() != np * ns
        || (input.force_constants.len() != compact_fc_len
            && input.force_constants.len() != full_fc_len)
    {
        return Err(KernelError::InvalidDimensions);
    }
    if !input.q.iter().all(|v| v.is_finite())
        || !input.force_constants.iter().all(|v| v.is_finite())
        || !input
            .shortest_vectors
            .iter()
            .flatten()
            .all(|v| v.is_finite())
    {
        return Err(KernelError::NonFiniteInput);
    }
    if input.masses.iter().any(|m| !m.is_finite() || *m <= 0.0) {
        return Err(KernelError::InvalidMass);
    }
    let fc_rows = input.force_constants.len() / (ns * 9);
    if input.supercell_to_primitive.iter().any(|&i| i >= fc_rows)
        || input
            .primitive_to_force_constant_row
            .iter()
            .any(|&i| i >= fc_rows)
    {
        return Err(KernelError::InvalidMapping);
    }
    for &[count, start] in input.multiplicity_start {
        if count == 0
            || start
                .checked_add(count)
                .is_none_or(|end| end > input.shortest_vectors.len())
        {
            return Err(KernelError::InvalidMultiplicity);
        }
    }

    let bands = np.checked_mul(3).ok_or(KernelError::InvalidDimensions)?;
    let matrix_len = bands
        .checked_mul(bands)
        .ok_or(KernelError::InvalidDimensions)?;
    let mut matrix = vec![[0.0; 2]; matrix_len];
    for i in 0..np {
        for j in 0..np {
            let mut block = [[[0.0; 2]; 3]; 3];
            for k in 0..ns {
                if input.supercell_to_primitive[k] != input.primitive_to_force_constant_row[j] {
                    continue;
                }
                let [count, start] = input.multiplicity_start[k * np + i];
                let mut cos_phase = 0.0;
                let mut sin_phase = 0.0;
                for vector in &input.shortest_vectors[start..start + count] {
                    let phase = 2.0
                        * PI
                        * (input.q[0] * vector[0]
                            + input.q[1] * vector[1]
                            + input.q[2] * vector[2]);
                    cos_phase += phase.cos() / count as f64;
                    sin_phase += phase.sin() / count as f64;
                }
                let base = input.primitive_to_force_constant_row[i] * ns * 9 + k * 9;
                for alpha in 0..3 {
                    for beta in 0..3 {
                        let fc = input.force_constants[base + alpha * 3 + beta];
                        block[alpha][beta][0] += fc * cos_phase;
                        block[alpha][beta][1] += fc * sin_phase;
                    }
                }
            }
            let scale = (input.masses[i] * input.masses[j]).sqrt();
            for alpha in 0..3 {
                for beta in 0..3 {
                    let row = i * 3 + alpha;
                    let col = j * 3 + beta;
                    matrix[row * bands + col] =
                        [block[alpha][beta][0] / scale, block[alpha][beta][1] / scale];
                }
            }
        }
    }
    hermitianize(&mut matrix, bands);
    Ok(matrix)
}

fn hermitianize(matrix: &mut [Complex64], n: usize) {
    for i in 0..n {
        for j in i..n {
            let ij = i * n + j;
            let ji = j * n + i;
            let re = (matrix[ij][0] + matrix[ji][0]) * 0.5;
            let im = (matrix[ij][1] - matrix[ji][1]) * 0.5;
            matrix[ij] = [re, im];
            matrix[ji] = [re, -im];
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn gamma_sums_force_constants_and_mass_weights() {
        let fc = [
            2.0, 0.0, 0.0, 0.0, 4.0, 0.0, 0.0, 0.0, 6.0, -1.0, 0.0, 0.0, 0.0, -2.0, 0.0, 0.0, 0.0,
            -3.0,
        ];
        let input = DynamicalMatrixInput {
            force_constants: &fc,
            q: [0.0; 3],
            shortest_vectors: &[[0.0; 3], [1.0, 0.0, 0.0]],
            multiplicity_start: &[[1, 0], [1, 1]],
            masses: &[2.0],
            supercell_to_primitive: &[0, 0],
            primitive_to_force_constant_row: &[0],
            primitive_atoms: 1,
            supercell_atoms: 2,
        };
        let dm = dynamical_matrix_at_q(input).unwrap();
        assert_eq!(dm[0], [0.5, 0.0]);
        assert_eq!(dm[4], [1.0, 0.0]);
        assert_eq!(dm[8], [1.5, 0.0]);
    }

    #[test]
    fn invalid_multiplicity_is_reported_without_panicking() {
        let input = DynamicalMatrixInput {
            force_constants: &[0.0; 18],
            q: [0.0; 3],
            shortest_vectors: &[[0.0; 3]],
            multiplicity_start: &[[2, 0], [1, 0]],
            masses: &[1.0],
            supercell_to_primitive: &[0, 0],
            primitive_to_force_constant_row: &[0],
            primitive_atoms: 1,
            supercell_atoms: 2,
        };
        assert_eq!(
            dynamical_matrix_at_q(input),
            Err(KernelError::InvalidMultiplicity)
        );
    }
}
