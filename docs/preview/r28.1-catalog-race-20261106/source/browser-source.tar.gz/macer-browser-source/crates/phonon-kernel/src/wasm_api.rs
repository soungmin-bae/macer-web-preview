use wasm_bindgen::prelude::*;

use crate::{
    diagonalize_hermitian, dynamical_matrix_at_q, force_constants_from_central_forces,
    force_constants_full_from_symmetry_reduced_rows,
    force_constants_row_from_symmetry_reduced_forces, perm_trans_symmetrize_compact_fc,
    perm_trans_symmetrize_full_fc, DynamicalMatrixInput, ForcePair, SymmetryReducedDisplacementSet,
    Vec3,
};

fn error(value: impl std::fmt::Debug) -> JsValue {
    JsValue::from_str(&format!("phonon kernel error: {value:?}"))
}

fn triples(values: &[f64]) -> Result<Vec<Vec3>, JsValue> {
    if values.len() % 3 != 0 {
        return Err(JsValue::from_str("expected a flat array of 3-vectors"));
    }
    Ok(values.chunks_exact(3).map(|v| [v[0], v[1], v[2]]).collect())
}

fn pairs(values: &[u32]) -> Result<Vec<[usize; 2]>, JsValue> {
    if values.len() % 2 != 0 {
        return Err(JsValue::from_str("expected a flat array of integer pairs"));
    }
    Ok(values
        .chunks_exact(2)
        .map(|v| [v[0] as usize, v[1] as usize])
        .collect())
}

#[wasm_bindgen]
pub fn phonon_dynamical_matrix_at_q(
    force_constants: &[f64],
    q: &[f64],
    shortest_vectors_flat: &[f64],
    multiplicity_start_flat: &[u32],
    masses: &[f64],
    supercell_to_primitive: &[u32],
    primitive_to_fc_row: &[u32],
    primitive_atoms: usize,
    supercell_atoms: usize,
) -> Result<Vec<f64>, JsValue> {
    if q.len() != 3 {
        return Err(JsValue::from_str("q must contain three coordinates"));
    }
    let vectors = triples(shortest_vectors_flat)?;
    let mappings = pairs(multiplicity_start_flat)?;
    let matrix = dynamical_matrix_at_q(DynamicalMatrixInput {
        force_constants,
        q: [q[0], q[1], q[2]],
        shortest_vectors: &vectors,
        multiplicity_start: &mappings,
        masses,
        supercell_to_primitive: &supercell_to_primitive
            .iter()
            .map(|&v| v as usize)
            .collect::<Vec<_>>(),
        primitive_to_force_constant_row: &primitive_to_fc_row
            .iter()
            .map(|&v| v as usize)
            .collect::<Vec<_>>(),
        primitive_atoms,
        supercell_atoms,
    })
    .map_err(error)?;
    Ok(matrix.into_iter().flat_map(|z| z).collect())
}

#[wasm_bindgen]
pub fn phonon_eigenpairs(
    matrix_interleaved: &[f64],
    dimension: usize,
) -> Result<Vec<f64>, JsValue> {
    if matrix_interleaved.len() % 2 != 0 {
        return Err(JsValue::from_str(
            "complex matrix values must be real/imaginary pairs",
        ));
    }
    let matrix: Vec<[f64; 2]> = matrix_interleaved
        .chunks_exact(2)
        .map(|v| [v[0], v[1]])
        .collect();
    let result = diagonalize_hermitian(&matrix, dimension).map_err(error)?;
    let mut output = result.values;
    output.extend(result.vectors.into_iter().flat_map(|z| z));
    Ok(output)
}

#[wasm_bindgen]
pub fn phonon_force_constants_central(
    n_atoms: usize,
    displaced_dofs: &[u32],
    displacements: &[f64],
    force_plus: &[f64],
    force_minus: &[f64],
) -> Result<Vec<f64>, JsValue> {
    if displaced_dofs.len() % 2 != 0 {
        return Err(JsValue::from_str(
            "displaced_dofs must contain atom/axis pairs",
        ));
    }
    let dofs = pairs(displaced_dofs)?;
    let dof_count = dofs.len();
    let force_len = n_atoms
        .checked_mul(3)
        .ok_or_else(|| JsValue::from_str("atom count is too large"))?;
    let packed_force_len = dof_count
        .checked_mul(force_len)
        .ok_or_else(|| JsValue::from_str("force arrays are too large"))?;
    if displacements.len() != dof_count
        || force_plus.len() != packed_force_len
        || force_minus.len() != packed_force_len
    {
        return Err(JsValue::from_str(
            "force/displacement arrays have incompatible lengths",
        ));
    }
    let pairs: Vec<ForcePair<'_>> = (0..dof_count)
        .map(|i| ForcePair {
            displaced_atom: dofs[i][0],
            axis: dofs[i][1],
            displacement: displacements[i],
            forces_plus: &force_plus[i * force_len..(i + 1) * force_len],
            forces_minus: &force_minus[i * force_len..(i + 1) * force_len],
        })
        .collect();
    force_constants_from_central_forces(n_atoms, &pairs).map_err(error)
}

#[wasm_bindgen]
pub fn phonon_force_constants_reduced_row(
    n_atoms: usize,
    displacements_flat: &[f64],
    forces_flat: &[f64],
    site_rotations_cartesian_flat: &[f64],
    atom_permutations: &[u32],
) -> Result<Vec<f64>, JsValue> {
    let displacements = triples(displacements_flat)?;
    force_constants_row_from_symmetry_reduced_forces(
        n_atoms,
        SymmetryReducedDisplacementSet {
            displacements: &displacements,
            forces: forces_flat,
            site_rotations_cartesian: site_rotations_cartesian_flat,
            atom_permutations: &atom_permutations
                .iter()
                .map(|&v| v as usize)
                .collect::<Vec<_>>(),
        },
    )
    .map_err(error)
}

#[wasm_bindgen]
pub fn phonon_force_constants_expand_reduced_rows(
    n_atoms: usize,
    representative_atoms: &[u32],
    representative_fc_rows: &[f64],
    rotations_cartesian_flat: &[f64],
    atom_permutations: &[u32],
) -> Result<Vec<f64>, JsValue> {
    force_constants_full_from_symmetry_reduced_rows(
        n_atoms,
        &representative_atoms
            .iter()
            .map(|&v| v as usize)
            .collect::<Vec<_>>(),
        representative_fc_rows,
        rotations_cartesian_flat,
        &atom_permutations
            .iter()
            .map(|&v| v as usize)
            .collect::<Vec<_>>(),
    )
    .map_err(error)
}

#[wasm_bindgen]
pub fn phonon_symmetrize_full_fc(
    fc: &[f64],
    n_atoms: usize,
    level: usize,
) -> Result<Vec<f64>, JsValue> {
    let mut output = fc.to_vec();
    perm_trans_symmetrize_full_fc(&mut output, n_atoms, level).map_err(error)?;
    Ok(output)
}

#[wasm_bindgen]
pub fn phonon_symmetrize_compact_fc(
    fc: &[f64],
    permutations: &[u32],
    s2pp: &[u32],
    p2s: &[u32],
    nsym_list: &[u32],
    n_satom: usize,
    level: usize,
) -> Result<Vec<f64>, JsValue> {
    let mut output = fc.to_vec();
    perm_trans_symmetrize_compact_fc(
        &mut output,
        &permutations.iter().map(|&v| v as usize).collect::<Vec<_>>(),
        &s2pp.iter().map(|&v| v as usize).collect::<Vec<_>>(),
        &p2s.iter().map(|&v| v as usize).collect::<Vec<_>>(),
        &nsym_list.iter().map(|&v| v as usize).collect::<Vec<_>>(),
        n_satom,
        level,
    )
    .map_err(error)?;
    Ok(output)
}

/// Reciprocal Niggli reduction used by the HPKOT triclinic path convention.
#[wasm_bindgen]
pub fn phonon_niggli_reduce(rows: &[f64]) -> Result<Vec<f64>, JsValue> {
    if rows.len() != 9 || rows.iter().any(|x| !x.is_finite()) {
        return Err(JsValue::from_str("expected three finite lattice vectors"));
    }
    let lattice = moyo::base::Lattice::from_basis([
        [rows[0], rows[1], rows[2]],
        [rows[3], rows[4], rows[5]],
        [rows[6], rows[7], rows[8]],
    ]);
    if lattice.basis.determinant().abs() < 1e-12 {
        return Err(JsValue::from_str("singular lattice"));
    }
    let (reduced, _) = lattice.niggli_reduce().map_err(error)?;
    Ok(reduced.basis.as_slice().to_vec())
}

fn tensors(values: &[f64]) -> Result<Vec<[[f64; 3]; 3]>, JsValue> {
    if values.len() % 9 != 0 || values.iter().any(|v| !v.is_finite()) {
        return Err(JsValue::from_str("expected finite 3 by 3 tensors"));
    }
    Ok(values
        .chunks_exact(9)
        .map(|v| [[v[0], v[1], v[2]], [v[3], v[4], v[5]], [v[6], v[7], v[8]]])
        .collect())
}

/// Gonze-Lee reciprocal sum (phonopy default, without real-space terms).
/// An empty q0 buffer requests only the unscaled diagonal drift tensor.
#[wasm_bindgen]
pub fn phonon_gonze_reciprocal(
    g_vectors: &[f64],
    q_cart: &[f64],
    direction_cart: &[f64],
    born_flat: &[f64],
    dielectric_flat: &[f64],
    positions_flat: &[f64],
    factor: f64,
    lambda: f64,
    q0_flat: &[f64],
) -> Result<Vec<f64>, JsValue> {
    let born = tensors(born_flat)?;
    let dielectric = tensors(dielectric_flat)?;
    let positions = triples(positions_flat)?;
    let g = triples(g_vectors)?;
    let np = born.len();
    if np == 0
        || np > 512
        || dielectric.len() != 1
        || positions.len() != np
        || q_cart.len() != 3
        || (!direction_cart.is_empty() && direction_cart.len() != 3)
        || !factor.is_finite()
        || factor <= 0.0
        || !lambda.is_finite()
        || lambda <= 0.0
        || g_vectors
            .iter()
            .chain(q_cart)
            .chain(direction_cart)
            .chain(positions_flat)
            .chain(q0_flat)
            .any(|x| !x.is_finite())
    {
        return Err(JsValue::from_str("invalid Gonze dimensions or parameters"));
    }
    if q0_flat.is_empty() {
        let mut q0 = vec![[0.0; 2]; np * 9];
        crate::nac::get_recip_dipole_dipole_q0(
            &mut q0,
            &g,
            np,
            &born,
            &dielectric[0],
            &positions,
            lambda,
        );
        return Ok(q0.into_iter().flatten().collect());
    }
    if q0_flat.len() != np * 18 {
        return Err(JsValue::from_str("invalid Gonze q0 tensor"));
    }
    let q0: Vec<[f64; 2]> = q0_flat.chunks_exact(2).map(|x| [x[0], x[1]]).collect();
    let mut dd = vec![[0.0; 2]; np * np * 9];
    let direction = if direction_cart.is_empty() {
        None
    } else {
        Some([direction_cart[0], direction_cart[1], direction_cart[2]])
    };
    crate::nac::get_recip_dipole_dipole(
        &mut dd,
        &q0,
        &g,
        np,
        [q_cart[0], q_cart[1], q_cart[2]],
        direction,
        &born,
        &dielectric[0],
        &positions,
        factor,
        lambda,
    );
    Ok(dd.into_iter().flatten().collect())
}

#[wasm_bindgen]
pub fn phonon_dos_chunk(
    mesh: &[u32],
    microzone: &[f64],
    frequencies: &[f64],
    weights: &[f64],
    grid: &[f64],
    atoms: usize,
    start: usize,
    count: usize,
    sigma: f64,
) -> Result<Vec<f64>, JsValue> {
    if mesh.len() != 3 || microzone.len() != 9 {
        return Err(JsValue::from_str("DOS mesh/microzone dimensions"));
    }
    crate::dos_chunk(
        [mesh[0] as usize, mesh[1] as usize, mesh[2] as usize],
        std::array::from_fn(|i| std::array::from_fn(|j| microzone[i * 3 + j])),
        frequencies,
        weights,
        grid,
        atoms,
        start,
        count,
        sigma,
    )
    .map_err(error)
}
