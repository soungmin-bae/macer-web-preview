use wasm_bindgen::prelude::*;

#[wasm_bindgen]
pub fn benchmark_factorized_linear(
    batch: usize,
    inputs: usize,
    outputs: usize,
    rank: usize,
) -> Result<String, JsValue> {
    use macer_rust_model::packed_linear_probe::{dense_pair, factorized_pair, reconstruct};
    if batch == 0
        || batch > 1024
        || inputs == 0
        || inputs > 512
        || outputs == 0
        || outputs > 512
        || rank == 0
        || rank > inputs.min(outputs)
    {
        return Err(JsValue::from_str("invalid factor probe dimensions"));
    }
    let down: Vec<_> = (0..rank * inputs)
        .map(|i| ((i * 13 % 83) as f32 - 41.) * 0.01)
        .collect();
    let up: Vec<_> = (0..outputs * rank)
        .map(|i| ((i * 7 % 47) as f32 - 23.) * 0.01)
        .collect();
    let x: Vec<_> = (0..batch * inputs).map(|i| (i % 17) as f32 / 19.).collect();
    let dy: Vec<_> = (0..batch * outputs)
        .map(|i| (i % 11) as f32 / 31.)
        .collect();
    let weight = reconstruct(&down, &up, inputs, outputs, rank);
    let (a, b) = dense_pair(&x, &dy, &weight, batch, inputs, outputs);
    let (c, d) = factorized_pair(&x, &dy, &down, &up, batch, inputs, outputs, rank);
    let max_error = a
        .iter()
        .chain(&b)
        .zip(c.iter().chain(&d))
        .map(|(x, y)| (x - y).abs())
        .fold(0f32, f32::max);
    let mut dense_ms = Vec::new();
    let mut factorized_ms = Vec::new();
    for pair in 0..7 {
        for candidate in if pair % 2 == 0 {
            [false, true]
        } else {
            [true, false]
        } {
            let start = packed_probe_now();
            if candidate {
                std::hint::black_box(factorized_pair(
                    &x, &dy, &down, &up, batch, inputs, outputs, rank,
                ));
                factorized_ms.push(packed_probe_now() - start);
            } else {
                std::hint::black_box(dense_pair(&x, &dy, &weight, batch, inputs, outputs));
                dense_ms.push(packed_probe_now() - start);
            }
        }
    }
    Ok(serde_json::json!({"batch":batch,"inputs":inputs,"outputs":outputs,"rank":rank,"dense_ms":dense_ms,"factorized_ms":factorized_ms,
        "max_abs_output_gradient_error":max_error,"decoded_factor_bytes":(down.len()+up.len())*4,"dense_bytes":weight.len()*4,
        "scope":"Decoded F32 factor kernels only, including intermediate allocation. No quantized model accuracy, model-load or whole-Relax speed claim."}).to_string())
}

#[wasm_bindgen]
extern "C" {
    #[wasm_bindgen(js_namespace = performance, js_name = now)]
    fn packed_probe_now() -> f64;
}

/// Diagnostic only: packed weights are decoded one output tile at a time,
/// shared by forward and input-gradient GEMM. Includes allocation and unpack.
#[wasm_bindgen]
pub fn benchmark_packed_linear(
    batch: usize,
    inputs: usize,
    outputs: usize,
    bits: u8,
    group: usize,
) -> Result<String, JsValue> {
    use macer_rust_model::packed_linear_probe::{dense_pair, PackedLinear};
    if batch == 0 || inputs == 0 || outputs == 0 || batch > 1024 || inputs > 512 || outputs > 512 {
        return Err(JsValue::from_str("invalid benchmark dimensions"));
    }
    let w: Vec<_> = (0..outputs * inputs)
        .map(|i| ((i * 13 % 83) as f32 - 41.) / 100.)
        .collect();
    let x: Vec<_> = (0..batch * inputs).map(|i| (i % 17) as f32 / 19.).collect();
    let dy: Vec<_> = (0..batch * outputs)
        .map(|i| (i % 11) as f32 / 31.)
        .collect();
    let packed =
        PackedLinear::new(&w, outputs, inputs, bits, group).map_err(|e| JsValue::from_str(&e))?;
    let decoded = packed.decoded();
    let (reference_y, reference_dx) = dense_pair(&x, &dy, &decoded, batch, inputs, outputs);
    let (y, dx) = packed
        .forward_and_input_gradient(&x, &dy, batch)
        .map_err(|e| JsValue::from_str(&e))?;
    let max_error = y
        .iter()
        .chain(&dx)
        .zip(reference_y.iter().chain(&reference_dx))
        .map(|(a, b)| (a - b).abs())
        .fold(0f32, f32::max);
    let mut dense_ms = Vec::new();
    let mut packed_ms = Vec::new();
    for pair in 0..7 {
        for candidate in if pair % 2 == 0 {
            [false, true]
        } else {
            [true, false]
        } {
            let start = packed_probe_now();
            if candidate {
                std::hint::black_box(
                    packed
                        .forward_and_input_gradient(&x, &dy, batch)
                        .map_err(|e| JsValue::from_str(&e))?,
                );
                packed_ms.push(packed_probe_now() - start);
            } else {
                std::hint::black_box(dense_pair(&x, &dy, &decoded, batch, inputs, outputs));
                dense_ms.push(packed_probe_now() - start);
            }
        }
    }
    Ok(serde_json::json!({"schema":"macer-packed-linear-probe-v1", "batch":batch,"inputs":inputs,"outputs":outputs,
        "bits":bits,"group":group,"dense_ms":dense_ms,"packed_ms":packed_ms,
        "max_abs_output_gradient_error":max_error,"packed_weight_bytes":packed.storage_bytes(),
        "dense_weight_bytes":decoded.len()*4,"scope":"Local WASM forward plus input-gradient kernel only; not model or Relax speed evidence."}).to_string())
}
