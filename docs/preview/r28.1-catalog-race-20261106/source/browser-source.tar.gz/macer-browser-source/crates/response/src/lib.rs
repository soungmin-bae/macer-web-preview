//! Standalone response-model kernels shared by native verification and browser WASM.
//!
//! This crate deliberately has no dependency on MatterSim, NEP, or Relax.

use candle_core::{DType, Device, Tensor, Var};
use safetensors::{Dtype as SafeDtype, SafeTensors};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::collections::BTreeMap;

fn softplus_f64(input: &Tensor) -> candle_core::Result<Tensor> {
    // Algebraically identical to log(1 + exp(x)), but stable for large |x|.
    // Candle's CPU where_cond kernel does not currently support F64.
    input
        .relu()?
        .broadcast_add(&(input.abs()?.neg()?.exp()? + 1.0)?.log()?)
}

fn cutoff_envelope(radius: &Tensor) -> candle_core::Result<Tensor> {
    let device = radius.device();
    let t = radius
        .broadcast_sub(&Tensor::full(0.9 * CUTOFF, radius.shape(), device)?)?
        .broadcast_div(&Tensor::full(0.1 * CUTOFF, radius.shape(), device)?)?
        .clamp(0.0f64, 1.0f64)?;
    let t2 = t.sqr()?;
    let t3 = t2.broadcast_mul(&t)?;
    let t4 = t3.broadcast_mul(&t)?;
    let t5 = t4.broadcast_mul(&t)?;
    1.0 + t3
        .affine(-10.0, 0.0)?
        .broadcast_add(&t4.affine(15.0, 0.0)?)?
        .broadcast_add(&t5.affine(-6.0, 0.0)?)?
}

#[derive(Debug, Clone, Serialize, PartialEq)]
pub struct ProbeResult {
    pub output: f64,
    pub input_gradient: Vec<f64>,
    pub max_finite_difference_error: f64,
}

const CHECKPOINT_SHA256: &str = "972dfa5c77a99369a91878c97928941506d3dba4deb3ab2e9c9cddd64b61ca6a";
const BORN_CHECKPOINT_SHA256: &str =
    "dbc9bbc1e39a3e390b7f0285d2290ce12193f0ce99ce5f8ca00aa6eb2f19fa8d";
const DIELECTRIC_CHECKPOINT_SHA256: &str =
    "3fa8bc824b8107f9db8a48bb7dbc3ba76890d4a2d4432bac5c9aafbfd9587d4b";
const MODEL_ID: &str = "cgcnn-response-expanded-v2-raman";
const BORN_MODEL_ID: &str = "cgcnn-expanded-v2-born-asr";
const MAX_ATOMS: usize = 256;
const MAX_EDGES: usize = 2_000_000;
const MAX_IMAGE_CANDIDATES_PER_PAIR: u128 = 1_000_000;
const MAX_RESPONSE_WORKSPACE_BYTES: usize = 256 * 1024 * 1024;
// Baseline estimate for retained edge-side tensors and the reverse-mode tape.
const ESTIMATED_BYTES_PER_EDGE: usize = 16 * 1024;
const ESTIMATED_BYTES_PER_ATOM: usize = 64 * 1024;
// Node 22.13 wasm32 measurements on repeated Si cells (36/128/256 atoms) found
// committed linear-memory high-water marks 1.57–1.62x above the baseline. Keep
// a 1.7x estimate margin before applying the unchanged 256 MiB workspace cap.
// Raw measurements: evidence/cgcnn_browser_port_2026-11-03/c3-memory-r1/.
const WORKSPACE_HEADROOM_NUMERATOR: usize = 17;
const WORKSPACE_HEADROOM_DENOMINATOR: usize = 10;
const CUTOFF: f64 = 5.0;
const SKIN: f64 = 0.35;
const HIDDEN: usize = 32;
const RBF_CHANNELS: usize = 16;

#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ModelManifest {
    pub schema: String,
    pub model_id: String,
    #[serde(alias = "checkpointSHA256")]
    pub checkpoint_sha256: String,
    pub weights_file: String,
    #[serde(alias = "weightsSHA256")]
    pub weights_sha256: String,
    pub weights_bytes: usize,
    #[serde(alias = "bestEpoch")]
    pub epoch: usize,
    pub dtype: String,
    pub architecture: ArchitectureManifest,
    pub support: ElementSupport,
    pub tensors: Vec<ResponseTensorSpec>,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct ResponseTensorSpec {
    pub name: String,
    pub dtype: String,
    pub shape: Vec<usize>,
    pub elements: usize,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ArchitectureManifest {
    pub hidden: usize,
    pub layers: usize,
    pub radial_channels: usize,
    pub cutoff_angstrom: f64,
    #[serde(alias = "candidateSkinAngstrom")]
    pub skin_angstrom: f64,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ElementSupport {
    pub minimum_training_atoms: usize,
    pub minimum_training_structures: usize,
    pub supported_atomic_numbers: Vec<u16>,
    pub sparse_atomic_numbers: Vec<u16>,
    #[serde(default)]
    pub atom_counts: BTreeMap<String, usize>,
    #[serde(default)]
    pub structure_counts: BTreeMap<String, usize>,
    #[serde(default)]
    pub accuracy_qualified_atomic_numbers: Vec<u16>,
    pub interpretation: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ResponseMode {
    pub mode_index: usize,
    pub frequency_thz: f64,
    pub frequency_cm: f64,
    pub tensor_real: Vec<f64>,
    pub tensor_imag: Vec<f64>,
    pub activity: f64,
    pub activity_per_volume: f64,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RamanResponse {
    pub schema: String,
    pub model_id: String,
    pub checkpoint_sha256: String,
    pub runtime: String,
    pub n_atoms: usize,
    pub edge_count: usize,
    pub estimated_workspace_bytes: usize,
    pub alpha_cell: [[f64; 3]; 3],
    pub coordinate_jacobian_six_packed: Vec<f64>,
    pub modes: Vec<ResponseMode>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BornResponse {
    pub schema: String,
    pub model_id: String,
    pub checkpoint_sha256: String,
    pub runtime: String,
    pub n_atoms: usize,
    pub edge_count: usize,
    pub raw: Vec<[[f64; 3]; 3]>,
    pub subtracted_atom_mean: [[f64; 3]; 3],
    pub projected: Vec<[[f64; 3]; 3]>,
    pub raw_tensor_sum: [[f64; 3]; 3],
    pub projected_tensor_sum: [[f64; 3]; 3],
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DielectricResponse {
    pub schema: String,
    pub model_id: String,
    pub checkpoint_sha256: String,
    pub runtime: String,
    pub n_atoms: usize,
    pub edge_count: usize,
    pub log_epsilon: [[f64; 3]; 3],
    pub epsilon_infinity: [[f64; 3]; 3],
    pub epsilon_eigenvalues: [f64; 3],
}

#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ResponseGeometry {
    pub cell: [[f64; 3]; 3],
    pub fractional_positions: Vec<[f64; 3]>,
    pub atomic_numbers: Vec<u16>,
    pub masses_amu: Vec<f64>,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct GammaMode {
    pub frequency_thz: f64,
    /// Atom-major Cartesian real and imaginary components, each of length 3N.
    pub eigenvector_real: Vec<f64>,
    pub eigenvector_imag: Vec<f64>,
}

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord, Serialize)]
pub struct PeriodicEdge {
    pub i: usize,
    pub j: usize,
    pub image: [i32; 3],
}

#[derive(Debug, Clone, Serialize)]
pub struct GraphDiagnostic {
    pub edge_count: usize,
    pub canonical_edges: Vec<PeriodicEdge>,
}

#[derive(Debug)]
struct Weights {
    tensors: BTreeMap<String, Tensor>,
}

/// Response jobs supported by the common browser inference boundary.
/// Task identity is explicit so a missing model cannot be silently substituted.
#[derive(Debug, Clone, Copy, Deserialize, Serialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum ResponseTask {
    Raman,
    Born,
    Dielectric,
    NacResponse,
}

#[derive(Debug, Clone, Deserialize, Serialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub struct ResponseModelIdentity {
    pub task: ResponseTask,
    pub model_id: String,
    pub checkpoint_sha256: String,
    pub weights_sha256: String,
    pub runtime: String,
}

impl Weights {
    /// Load an exact tensor set shared by all response task models.
    fn from_safetensors(
        weights_bytes: &[u8],
        specs: &[ResponseTensorSpec],
        expected_sha256: &str,
    ) -> Result<Self, String> {
        let actual_hash = sha256_hex(weights_bytes);
        if actual_hash != expected_sha256 {
            return Err(format!(
                "Response weights hash mismatch: expected {expected_sha256}, received {actual_hash}"
            ));
        }
        let safe = SafeTensors::deserialize(weights_bytes)
            .map_err(|error| format!("Response safetensors parse failed: {error}"))?;
        let safe_names = safe
            .names()
            .into_iter()
            .collect::<std::collections::BTreeSet<_>>();
        let spec_names = specs
            .iter()
            .map(|spec| spec.name.as_str())
            .collect::<std::collections::BTreeSet<_>>();
        if safe_names != spec_names || spec_names.len() != specs.len() {
            return Err(
                "Response safetensors tensor names do not exactly match the manifest.".into(),
            );
        }
        let mut tensors = BTreeMap::new();
        for spec in specs {
            let view = safe
                .tensor(&spec.name)
                .map_err(|error| format!("Response tensor {} is missing: {error}", spec.name))?;
            if view.dtype() != SafeDtype::F64 || view.shape() != spec.shape.as_slice() {
                return Err(format!(
                    "Response tensor {} has unexpected dtype or shape",
                    spec.name
                ));
            }
            if spec.elements != spec.shape.iter().product::<usize>() {
                return Err(format!(
                    "Response tensor {} has inconsistent element count in manifest",
                    spec.name
                ));
            }
            let values = view
                .data()
                .chunks_exact(8)
                .map(|bytes| f64::from_le_bytes(bytes.try_into().expect("8-byte chunk")))
                .collect::<Vec<_>>();
            let tensor = Tensor::from_vec(values, spec.shape.clone(), &Device::Cpu)
                .map_err(|error| format!("Response tensor {} load failed: {error}", spec.name))?;
            let runtime_name = spec
                .name
                .strip_prefix("raw_model.")
                .unwrap_or(&spec.name)
                .to_string();
            if tensors.insert(runtime_name.clone(), tensor).is_some() {
                return Err(format!(
                    "Response tensors collide after wrapper-prefix normalization: {runtime_name}"
                ));
            }
        }
        Ok(Self { tensors })
    }
}

impl Weights {
    fn weight(&self, name: &str) -> candle_core::Result<&Tensor> {
        self.tensors
            .get(name)
            .ok_or_else(|| response_error(format!("missing CGCNN tensor {name}")))
    }

    fn linear(&self, x: &Tensor, prefix: &str) -> candle_core::Result<Tensor> {
        let weight = self.weight(&format!("{prefix}.weight"))?;
        let bias = self.weight(&format!("{prefix}.bias"))?;
        Ok(x.matmul(&weight.transpose(0, 1)?)?
            .broadcast_add(&bias.reshape((1, bias.dim(0)?))?)?)
    }

    fn run_backbone(
        &self,
        geometry: &ResponseGeometry,
        graph: &BuiltGraph,
        positions: &Tensor,
    ) -> candle_core::Result<(Tensor, Tensor, Tensor, Tensor, Tensor, Tensor)> {
        let device = Device::Cpu;
        let atom_ids = Tensor::from_vec(
            geometry
                .atomic_numbers
                .iter()
                .map(|&z| z as u32)
                .collect::<Vec<_>>(),
            geometry.atomic_numbers.len(),
            &device,
        )?;
        let mut h = self
            .weight("backbone.embedding.weight")?
            .embedding(&atom_ids)?;
        let edge_i = Tensor::from_vec(
            graph
                .edges
                .iter()
                .map(|edge| edge.i as u32)
                .collect::<Vec<_>>(),
            graph.edges.len(),
            &device,
        )?;
        let edge_j = Tensor::from_vec(
            graph
                .edges
                .iter()
                .map(|edge| edge.j as u32)
                .collect::<Vec<_>>(),
            graph.edges.len(),
            &device,
        )?;
        let shifts = Tensor::from_vec(
            graph
                .shift_cart
                .iter()
                .flatten()
                .copied()
                .collect::<Vec<_>>(),
            (graph.edges.len(), 3),
            &device,
        )?;
        let pos_i = positions.index_select(&edge_i, 0)?;
        let pos_j = positions.index_select(&edge_j, 0)?;
        let delta = pos_j.broadcast_sub(&pos_i)?.broadcast_add(&shifts)?;
        let radius = delta.sqr()?.sum_keepdim(1)?.sqrt()?;
        let unit = delta.broadcast_div(&radius)?;
        let envelope = cutoff_envelope(&radius)?;
        let centers = Tensor::from_vec(
            (0..RBF_CHANNELS)
                .map(|i| CUTOFF * i as f64 / (RBF_CHANNELS - 1) as f64)
                .collect::<Vec<_>>(),
            (1, RBF_CHANNELS),
            &device,
        )?;
        let radial_delta =
            (radius.broadcast_sub(&centers)? / (CUTOFF / (RBF_CHANNELS - 1) as f64))?;
        let rbf = radial_delta
            .sqr()?
            .affine(-0.5, 0.0)?
            .exp()?
            .broadcast_mul(&envelope)?;
        let degree = Tensor::zeros((geometry.atomic_numbers.len(), 1), DType::F64, &device)?
            .index_add(&edge_i, &envelope, 0)?
            .maximum(1.0f64)?;
        let degree_scale = degree.sqrt()?.recip()?;

        for layer in 0..3 {
            let hi = h.index_select(&edge_i, 0)?;
            let hj = h.index_select(&edge_j, 0)?;
            let edge_state = Tensor::cat(&[hi, hj, rbf.clone()], 1)?;
            let gate = (self
                .linear(&edge_state, &format!("backbone.filter.{layer}"))?
                .neg()?
                .exp()?
                + 1.0)?
                .recip()?;
            let core = softplus_f64(&self.linear(&edge_state, &format!("backbone.core.{layer}"))?)?;
            let msg = gate.broadcast_mul(&core)?.broadcast_mul(&envelope)?;
            let aggregate =
                Tensor::zeros((geometry.atomic_numbers.len(), HIDDEN), DType::F64, &device)?
                    .index_add(&edge_i, &msg, 0)?
                    .broadcast_mul(&degree_scale)?;
            let update_input = Tensor::cat(&[h.clone(), aggregate], 1)?;
            let proposal =
                softplus_f64(&self.linear(&update_input, &format!("backbone.update.{layer}"))?)?;
            let residual = h.broadcast_add(&proposal)?;
            let mean = residual.mean_keepdim(1)?;
            let centered = residual.broadcast_sub(&mean)?;
            let variance = centered.sqr()?.mean_keepdim(1)?;
            let normalized = centered.broadcast_div(
                &variance
                    .broadcast_add(&Tensor::full(1e-5f64, variance.shape(), &device)?)?
                    .sqrt()?,
            )?;
            let weight = self
                .weight(&format!("backbone.norm.{layer}.weight"))?
                .reshape((1, HIDDEN))?;
            let bias = self
                .weight(&format!("backbone.norm.{layer}.bias"))?
                .reshape((1, HIDDEN))?;
            h = normalized.broadcast_mul(&weight)?.broadcast_add(&bias)?;
        }
        Ok((h, edge_i, edge_j, unit, rbf, envelope))
    }
}

#[derive(Debug)]
pub struct CgcnnRamanModel {
    manifest: ModelManifest,
    weights: Weights,
}

fn response_error(message: impl Into<String>) -> candle_core::Error {
    candle_core::Error::Msg(message.into())
}

fn sha256_hex(bytes: &[u8]) -> String {
    let digest = Sha256::digest(bytes);
    digest.iter().map(|byte| format!("{byte:02x}")).collect()
}

impl CgcnnRamanModel {
    pub fn from_bundle(weights_bytes: &[u8], manifest_bytes: &[u8]) -> Result<Self, String> {
        let manifest: ModelManifest = serde_json::from_slice(manifest_bytes)
            .map_err(|error| format!("CGCNN manifest parse failed: {error}"))?;
        if manifest.schema != "macer-cgcnn-response-bundle-v1"
            || manifest.model_id != MODEL_ID
            || manifest.checkpoint_sha256 != CHECKPOINT_SHA256
            || manifest.dtype != "F64"
            || manifest.epoch != 37
            || manifest.architecture.hidden != HIDDEN
            || manifest.architecture.layers != 3
            || manifest.architecture.radial_channels != RBF_CHANNELS
            || (manifest.architecture.cutoff_angstrom - CUTOFF).abs() > 1e-12
            || (manifest.architecture.skin_angstrom - SKIN).abs() > 1e-12
        {
            return Err(
                "CGCNN bundle identity or architecture does not match the frozen Raman v2 runtime."
                    .into(),
            );
        }
        let weights =
            Weights::from_safetensors(weights_bytes, &manifest.tensors, &manifest.weights_sha256)?;
        if weights.tensors.len() != 31 || manifest.tensors.len() != 31 {
            return Err(format!(
                "CGCNN expected 31 tensors, found {}",
                weights.tensors.len()
            ));
        }
        Ok(Self { manifest, weights })
    }

    pub fn manifest(&self) -> &ModelManifest {
        &self.manifest
    }

    /// Stable task/model identity for the common response boundary.
    pub fn identity(&self) -> ResponseModelIdentity {
        ResponseModelIdentity {
            task: ResponseTask::Raman,
            model_id: self.manifest.model_id.clone(),
            checkpoint_sha256: self.manifest.checkpoint_sha256.clone(),
            weights_sha256: self.manifest.weights_sha256.clone(),
            runtime: "rust-wasm-cpu-f64".into(),
        }
    }

    pub fn validate_support(&self, atomic_numbers: &[u16]) -> Result<(), String> {
        let supported = self
            .manifest
            .support
            .supported_atomic_numbers
            .iter()
            .copied()
            .collect::<std::collections::BTreeSet<_>>();
        let sparse = self
            .manifest
            .support
            .sparse_atomic_numbers
            .iter()
            .copied()
            .collect::<std::collections::BTreeSet<_>>();
        let missing = atomic_numbers
            .iter()
            .copied()
            .filter(|z| !supported.contains(z) && !sparse.contains(z))
            .collect::<std::collections::BTreeSet<_>>();
        if !missing.is_empty() {
            return Err(format!(
                "CGCNN has no training structures for atomic number(s) {missing:?}."
            ));
        }
        // Coverage counts describe the training data, not measured accuracy.
        // Sparse but observed elements remain available for user-requested previews.
        Ok(())
    }

    pub fn diagnose_graph(&self, geometry: &ResponseGeometry) -> Result<GraphDiagnostic, String> {
        build_graph(geometry, MAX_EDGES).map(|graph| GraphDiagnostic {
            edge_count: graph.edges.len(),
            canonical_edges: graph.edges,
        })
    }

    pub fn estimate_workspace_bytes(&self, geometry: &ResponseGeometry) -> Result<usize, String> {
        estimate_workspace_bytes(geometry)
    }

    pub fn predict(
        &self,
        geometry: &ResponseGeometry,
        modes: &[GammaMode],
    ) -> Result<RamanResponse, String> {
        self.validate_support(&geometry.atomic_numbers)?;
        validate_geometry(geometry, modes)?;
        let estimated_workspace_bytes = estimate_workspace_bytes(geometry)?;
        if estimated_workspace_bytes > MAX_RESPONSE_WORKSPACE_BYTES {
            return Err(format!(
                "CGCNN response preflight estimates {} MiB of working memory, above the 256 MiB limit; no graph or autodiff tape was allocated.",
                (estimated_workspace_bytes + 1024 * 1024 - 1) / (1024 * 1024)
            ));
        }
        let graph = build_graph(geometry, MAX_EDGES)?;
        let n = geometry.atomic_numbers.len();
        let mut positions = Vec::with_capacity(n * 3);
        for frac in &geometry.fractional_positions {
            for cart in 0..3 {
                positions.push(
                    (0..3)
                        .map(|axis| frac[axis] * geometry.cell[axis][cart])
                        .sum::<f64>(),
                );
            }
        }
        let pos = Var::from_vec(positions, (n, 3), &Device::Cpu).map_err(|e| e.to_string())?;
        let (h, edge_i, edge_j, unit, rbf, envelope) = self
            .weights
            .run_backbone(geometry, &graph, &pos)
            .map_err(|e| e.to_string())?;
        let hi = h.index_select(&edge_i, 0).map_err(|e| e.to_string())?;
        let hj = h.index_select(&edge_j, 0).map_err(|e| e.to_string())?;
        let edge_state = Tensor::cat(&[hi, hj, rbf], 1).map_err(|e| e.to_string())?;
        let iso = self
            .weights
            .linear(&h, "iso_head")
            .map_err(|e| e.to_string())?
            .sum_all()
            .map_err(|e| e.to_string())?;
        let hidden_edge = self
            .weights
            .linear(&edge_state, "edge_anisotropy.0")
            .map_err(|e| e.to_string())?
            .silu()
            .map_err(|e| e.to_string())?;
        let coeff = self
            .weights
            .linear(&hidden_edge, "edge_anisotropy.2")
            .map_err(|e| e.to_string())?
            .broadcast_mul(&envelope)
            .map_err(|e| e.to_string())?;
        let ux = unit.narrow(1, 0, 1).map_err(|e| e.to_string())?;
        let uy = unit.narrow(1, 1, 1).map_err(|e| e.to_string())?;
        let uz = unit.narrow(1, 2, 1).map_err(|e| e.to_string())?;
        let coeff_half = coeff.affine(0.5, 0.0).map_err(|e| e.to_string())?;
        let alpha_component =
            |a: &Tensor, b: &Tensor, diagonal: bool| -> candle_core::Result<Tensor> {
                let dyad = a.broadcast_mul(b)?;
                let dyad = if diagonal {
                    dyad.affine(1.0, -1.0 / 3.0)?
                } else {
                    dyad
                };
                let anisotropic = coeff_half.broadcast_mul(&dyad)?.sum_all()?;
                if diagonal {
                    Ok(iso.broadcast_add(&anisotropic)?)
                } else {
                    Ok(anisotropic)
                }
            };
        let components = vec![
            alpha_component(&ux, &ux, true),
            alpha_component(&uy, &uy, true),
            alpha_component(&uz, &uz, true),
            alpha_component(&ux, &uy, false),
            alpha_component(&ux, &uz, false),
            alpha_component(&uy, &uz, false),
        ]
        .into_iter()
        .map(|x| x.map_err(|e| e.to_string()))
        .collect::<Result<Vec<_>, _>>()?;
        let alpha6 = components
            .iter()
            .map(|x| x.to_vec0::<f64>().map_err(|e| e.to_string()))
            .collect::<Result<Vec<_>, _>>()?;
        let jacobian = components
            .iter()
            .enumerate()
            .map(|(k, scalar)| {
                let grad = scalar.backward().map_err(|e| e.to_string())?;
                let values = grad
                    .get(&pos)
                    .ok_or_else(|| "CGCNN coordinate Jacobian was not produced".to_string())?
                    .flatten_all()
                    .map_err(|e| e.to_string())?
                    .to_vec1::<f64>()
                    .map_err(|e| e.to_string())?;
                Ok(values
                    .into_iter()
                    .map(|value| {
                        if k >= 3 {
                            value * std::f64::consts::SQRT_2
                        } else {
                            value
                        }
                    })
                    .collect::<Vec<_>>())
            })
            .collect::<Result<Vec<_>, String>>()?;
        let alpha = [
            [alpha6[0], alpha6[3], alpha6[4]],
            [alpha6[3], alpha6[1], alpha6[5]],
            [alpha6[4], alpha6[5], alpha6[2]],
        ];
        let volume = determinant(geometry.cell).abs();
        let volume_scale = volume.sqrt();
        let root_mass = geometry
            .masses_amu
            .iter()
            .map(|m| m.sqrt())
            .collect::<Vec<_>>();
        let mut out_modes = Vec::with_capacity(modes.len());
        for (mode_index, mode) in modes.iter().enumerate() {
            let mut lanes = [[0.0; 6]; 2];
            for component in 0..6 {
                for atom in 0..n {
                    for cart in 0..3 {
                        let flat = atom * 3 + cart;
                        lanes[0][component] += jacobian[component][flat]
                            * mode.eigenvector_real[flat]
                            / root_mass[atom]
                            / volume_scale;
                        lanes[1][component] += jacobian[component][flat]
                            * mode.eigenvector_imag[flat]
                            / root_mass[atom]
                            / volume_scale;
                    }
                }
            }
            let mut real = [0.0f64; 9];
            let mut imag = [0.0f64; 9];
            real[0] = lanes[0][0];
            real[4] = lanes[0][1];
            real[8] = lanes[0][2];
            imag[0] = lanes[1][0];
            imag[4] = lanes[1][1];
            imag[8] = lanes[1][2];
            for (lane, tensor) in [(0, &mut real), (1, &mut imag)] {
                let scale = std::f64::consts::FRAC_1_SQRT_2;
                let values = &lanes[lane];
                tensor[1] = values[3] * scale;
                tensor[3] = tensor[1];
                tensor[2] = values[4] * scale;
                tensor[6] = tensor[2];
                tensor[5] = values[5] * scale;
                tensor[7] = tensor[5];
            }
            let activity = powder_activity(&real, &imag);
            out_modes.push(ResponseMode {
                mode_index,
                frequency_thz: mode.frequency_thz,
                frequency_cm: mode.frequency_thz * 33.35640951981521,
                tensor_real: real.to_vec(),
                tensor_imag: imag.to_vec(),
                activity,
                activity_per_volume: activity / volume,
            });
        }
        Ok(RamanResponse {
            schema: "macer-cgcnn-browser-response-v1".into(),
            model_id: MODEL_ID.into(),
            checkpoint_sha256: CHECKPOINT_SHA256.into(),
            runtime: "rust-native-candle-f64".into(),
            n_atoms: n,
            edge_count: graph.edges.len(),
            estimated_workspace_bytes,
            alpha_cell: alpha,
            coordinate_jacobian_six_packed: jacobian.into_iter().flatten().collect(),
            modes: out_modes,
        })
    }
}

#[derive(Debug)]
pub struct CgcnnBornModel {
    manifest: ModelManifest,
    weights: Weights,
}

impl CgcnnBornModel {
    pub fn from_bundle(weights_bytes: &[u8], manifest_bytes: &[u8]) -> Result<Self, String> {
        let manifest: ModelManifest = serde_json::from_slice(manifest_bytes)
            .map_err(|error| format!("CGCNN Born manifest parse failed: {error}"))?;
        if manifest.schema != "macer-cgcnn-common-task-bundle-v1"
            || manifest.model_id != BORN_MODEL_ID
            || manifest.checkpoint_sha256 != BORN_CHECKPOINT_SHA256
            || manifest.dtype != "F64"
            || manifest.epoch != 14
            || manifest.architecture.hidden != HIDDEN
            || manifest.architecture.layers != 3
            || manifest.architecture.radial_channels != RBF_CHANNELS
            || (manifest.architecture.cutoff_angstrom - CUTOFF).abs() > 1e-12
            || (manifest.architecture.skin_angstrom - SKIN).abs() > 1e-12
        {
            return Err("CGCNN Born bundle identity or architecture does not match the frozen Born v2 runtime.".into());
        }
        let weights =
            Weights::from_safetensors(weights_bytes, &manifest.tensors, &manifest.weights_sha256)?;
        if weights.tensors.len() != 35 || manifest.tensors.len() != 35 {
            return Err(format!(
                "CGCNN Born expected 35 tensors, found {}",
                weights.tensors.len()
            ));
        }
        Ok(Self { manifest, weights })
    }

    pub fn identity(&self) -> ResponseModelIdentity {
        ResponseModelIdentity {
            task: ResponseTask::Born,
            model_id: self.manifest.model_id.clone(),
            checkpoint_sha256: self.manifest.checkpoint_sha256.clone(),
            weights_sha256: self.manifest.weights_sha256.clone(),
            runtime: "rust-native-candle-f64".into(),
        }
    }

    pub fn validate_support(&self, atomic_numbers: &[u16]) -> Result<(), String> {
        validate_model_support(&self.manifest, atomic_numbers)
    }

    pub fn predict(&self, geometry: &ResponseGeometry) -> Result<BornResponse, String> {
        validate_born_geometry(geometry)?;
        self.validate_support(&geometry.atomic_numbers)?;
        let graph = build_graph(geometry, MAX_EDGES)?;
        let n = geometry.atomic_numbers.len();
        let positions = geometry
            .fractional_positions
            .iter()
            .flat_map(|frac| {
                (0..3).map(move |cart| {
                    (0..3)
                        .map(|axis| frac[axis] * geometry.cell[axis][cart])
                        .sum::<f64>()
                })
            })
            .collect::<Vec<_>>();
        let pos =
            Tensor::from_vec(positions, (n, 3), &Device::Cpu).map_err(|error| error.to_string())?;
        let (h, _edge_i, _edge_j, unit, rbf, envelope) = self
            .weights
            .run_backbone(geometry, &graph, &pos)
            .map_err(|error| error.to_string())?;
        let hi = h
            .index_select(
                &Tensor::from_vec(
                    graph
                        .edges
                        .iter()
                        .map(|edge| edge.i as u32)
                        .collect::<Vec<_>>(),
                    graph.edges.len(),
                    &Device::Cpu,
                )
                .map_err(|e| e.to_string())?,
                0,
            )
            .map_err(|e| e.to_string())?;
        let hj = h
            .index_select(
                &Tensor::from_vec(
                    graph
                        .edges
                        .iter()
                        .map(|edge| edge.j as u32)
                        .collect::<Vec<_>>(),
                    graph.edges.len(),
                    &Device::Cpu,
                )
                .map_err(|e| e.to_string())?,
                0,
            )
            .map_err(|e| e.to_string())?;
        let edge_state = Tensor::cat(&[hi, hj, rbf], 1).map_err(|e| e.to_string())?;
        let vector_coeff = self
            .weights
            .linear(&edge_state, "vector_edge")
            .and_then(|x| x.tanh())
            .and_then(|x| x.broadcast_mul(&envelope))
            .map_err(|e| e.to_string())?
            .flatten_all()
            .map_err(|e| e.to_string())?
            .to_vec1::<f64>()
            .map_err(|e| e.to_string())?;
        let direct_coeff = self
            .weights
            .linear(&edge_state, "direct_dyad_edge")
            .and_then(|x| x.tanh())
            .and_then(|x| x.broadcast_mul(&envelope))
            .map_err(|e| e.to_string())?
            .flatten_all()
            .map_err(|e| e.to_string())?
            .to_vec1::<f64>()
            .map_err(|e| e.to_string())?;
        let unit_values = unit
            .flatten_all()
            .map_err(|e| e.to_string())?
            .to_vec1::<f64>()
            .map_err(|e| e.to_string())?;
        let envelope_values = envelope
            .flatten_all()
            .map_err(|e| e.to_string())?
            .to_vec1::<f64>()
            .map_err(|e| e.to_string())?;
        let mut degree = vec![0.0; n];
        let mut vectors = vec![[[0.0; 3]; 4]; n];
        let mut direct = vec![[[0.0; 3]; 3]; n];
        for (edge_index, edge) in graph.edges.iter().enumerate() {
            let env = envelope_values[edge_index];
            degree[edge.i] += env;
            let u = &unit_values[edge_index * 3..edge_index * 3 + 3];
            for channel in 0..4 {
                let c = vector_coeff[edge_index * 4 + channel];
                for cart in 0..3 {
                    vectors[edge.i][channel][cart] += c * u[cart];
                }
                let d = direct_coeff[edge_index * 4 + channel];
                for a in 0..3 {
                    for b in 0..3 {
                        direct[edge.i][a][b] +=
                            d * (u[a] * u[b] - if a == b { 1.0 / 3.0 } else { 0.0 });
                    }
                }
            }
        }
        for atom in 0..n {
            let scale = degree[atom].max(1.0).sqrt().recip();
            for channel in 0..4 {
                for cart in 0..3 {
                    vectors[atom][channel][cart] *= scale;
                }
            }
        }
        let scalar = self
            .weights
            .linear(&h, "scalar_head")
            .map_err(|e| e.to_string())?
            .flatten_all()
            .map_err(|e| e.to_string())?
            .to_vec1::<f64>()
            .map_err(|e| e.to_string())?;
        let symmetric = self
            .weights
            .linear(&h, "symmetric_head")
            .map_err(|e| e.to_string())?
            .flatten_all()
            .map_err(|e| e.to_string())?
            .to_vec1::<f64>()
            .map_err(|e| e.to_string())?;
        let antisymmetric = self
            .weights
            .linear(&h, "antisymmetric_head")
            .map_err(|e| e.to_string())?
            .flatten_all()
            .map_err(|e| e.to_string())?
            .to_vec1::<f64>()
            .map_err(|e| e.to_string())?;
        const SYM_PAIRS: [(usize, usize); 10] = [
            (0, 0),
            (0, 1),
            (0, 2),
            (0, 3),
            (1, 1),
            (1, 2),
            (1, 3),
            (2, 2),
            (2, 3),
            (3, 3),
        ];
        const ANTI_PAIRS: [(usize, usize); 6] = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)];
        let mut raw = vec![[[0.0; 3]; 3]; n];
        for atom in 0..n {
            for a in 0..3 {
                raw[atom][a][a] = scalar[atom];
            }
            for (k, (va, vb)) in SYM_PAIRS.iter().copied().enumerate() {
                let coeff = symmetric[atom * 10 + k];
                let dot = (0..3)
                    .map(|c| vectors[atom][va][c] * vectors[atom][vb][c])
                    .sum::<f64>();
                for a in 0..3 {
                    for b in 0..3 {
                        let sym = 0.5
                            * (vectors[atom][va][a] * vectors[atom][vb][b]
                                + vectors[atom][vb][a] * vectors[atom][va][b]);
                        raw[atom][a][b] += coeff * (sym - if a == b { dot / 3.0 } else { 0.0 });
                    }
                }
            }
            for a in 0..3 {
                for b in 0..3 {
                    raw[atom][a][b] += direct[atom][a][b];
                }
            }
            for (k, (va, vb)) in ANTI_PAIRS.iter().copied().enumerate() {
                let coeff = antisymmetric[atom * 6 + k];
                for a in 0..3 {
                    for b in 0..3 {
                        raw[atom][a][b] += coeff
                            * (vectors[atom][va][a] * vectors[atom][vb][b]
                                - vectors[atom][vb][a] * vectors[atom][va][b]);
                    }
                }
            }
        }
        let mut mean = [[0.0; 3]; 3];
        for tensor in &raw {
            for a in 0..3 {
                for b in 0..3 {
                    mean[a][b] += tensor[a][b] / n as f64;
                }
            }
        }
        let projected = raw
            .iter()
            .map(|tensor| {
                let mut out = *tensor;
                for a in 0..3 {
                    for b in 0..3 {
                        out[a][b] -= mean[a][b];
                    }
                }
                out
            })
            .collect::<Vec<_>>();
        let mut raw_sum = [[0.0; 3]; 3];
        let mut projected_sum = [[0.0; 3]; 3];
        for tensor in &raw {
            for a in 0..3 {
                for b in 0..3 {
                    raw_sum[a][b] += tensor[a][b];
                }
            }
        }
        for tensor in &projected {
            for a in 0..3 {
                for b in 0..3 {
                    projected_sum[a][b] += tensor[a][b];
                }
            }
        }
        Ok(BornResponse {
            schema: "macer-cgcnn-born-response-v1".into(),
            model_id: self.manifest.model_id.clone(),
            checkpoint_sha256: self.manifest.checkpoint_sha256.clone(),
            runtime: "rust-native-candle-f64".into(),
            n_atoms: n,
            edge_count: graph.edges.len(),
            raw,
            subtracted_atom_mean: mean,
            projected,
            raw_tensor_sum: raw_sum,
            projected_tensor_sum: projected_sum,
        })
    }
}

#[derive(Debug)]
pub struct CgcnnDielectricModel {
    manifest: ModelManifest,
    weights: Weights,
}

impl CgcnnDielectricModel {
    pub fn from_bundle(weights_bytes: &[u8], manifest_bytes: &[u8]) -> Result<Self, String> {
        let manifest: ModelManifest = serde_json::from_slice(manifest_bytes)
            .map_err(|error| format!("CGCNN dielectric manifest parse failed: {error}"))?;
        if manifest.schema != "macer-cgcnn-common-task-bundle-v1"
            || manifest.model_id != "cgcnn-expanded-v2-electronic-dielectric"
            || manifest.checkpoint_sha256 != DIELECTRIC_CHECKPOINT_SHA256
            || manifest.dtype != "F64"
            || manifest.epoch != 34
            || manifest.architecture.hidden != HIDDEN
            || manifest.architecture.layers != 3
            || manifest.architecture.radial_channels != RBF_CHANNELS
            || (manifest.architecture.cutoff_angstrom - CUTOFF).abs() > 1e-12
            || (manifest.architecture.skin_angstrom - SKIN).abs() > 1e-12
        {
            return Err("CGCNN dielectric bundle identity or architecture does not match the frozen dielectric v2 runtime.".into());
        }
        let weights =
            Weights::from_safetensors(weights_bytes, &manifest.tensors, &manifest.weights_sha256)?;
        if weights.tensors.len() != 31 || manifest.tensors.len() != 31 {
            return Err(format!(
                "CGCNN dielectric expected 31 tensors, found {}",
                weights.tensors.len()
            ));
        }
        Ok(Self { manifest, weights })
    }

    pub fn identity(&self) -> ResponseModelIdentity {
        ResponseModelIdentity {
            task: ResponseTask::Dielectric,
            model_id: self.manifest.model_id.clone(),
            checkpoint_sha256: self.manifest.checkpoint_sha256.clone(),
            weights_sha256: self.manifest.weights_sha256.clone(),
            runtime: "rust-native-candle-f64".into(),
        }
    }

    pub fn validate_support(&self, atomic_numbers: &[u16]) -> Result<(), String> {
        validate_model_support(&self.manifest, atomic_numbers)
    }

    pub fn predict(&self, geometry: &ResponseGeometry) -> Result<DielectricResponse, String> {
        validate_born_geometry(geometry)?;
        self.validate_support(&geometry.atomic_numbers)?;
        let graph = build_graph(geometry, MAX_EDGES)?;
        let n = geometry.atomic_numbers.len();
        let positions = geometry
            .fractional_positions
            .iter()
            .flat_map(|frac| {
                (0..3).map(move |cart| {
                    (0..3)
                        .map(|axis| frac[axis] * geometry.cell[axis][cart])
                        .sum::<f64>()
                })
            })
            .collect::<Vec<_>>();
        let pos = Tensor::from_vec(positions, (n, 3), &Device::Cpu).map_err(|e| e.to_string())?;
        let (h, edge_i, edge_j, unit, rbf, envelope) = self
            .weights
            .run_backbone(geometry, &graph, &pos)
            .map_err(|e| e.to_string())?;
        let hi = h.index_select(&edge_i, 0).map_err(|e| e.to_string())?;
        let hj = h.index_select(&edge_j, 0).map_err(|e| e.to_string())?;
        let edge_state = Tensor::cat(&[hi, hj, rbf], 1).map_err(|e| e.to_string())?;
        let scalar_nodes = self
            .weights
            .linear(&h, "iso_head")
            .map_err(|e| e.to_string())?
            .flatten_all()
            .map_err(|e| e.to_string())?
            .to_vec1::<f64>()
            .map_err(|e| e.to_string())?;
        let iso = 8.0 * (scalar_nodes.iter().sum::<f64>() / n as f64).tanh();
        let edge_coeff = self
            .weights
            .linear(&edge_state, "edge_anisotropy.0")
            .and_then(|x| x.silu())
            .and_then(|x| self.weights.linear(&x, "edge_anisotropy.2"))
            .and_then(|x| x.tanh())
            .and_then(|x| x.affine(8.0, 0.0))
            .and_then(|x| x.broadcast_mul(&envelope))
            .map_err(|e| e.to_string())?
            .flatten_all()
            .map_err(|e| e.to_string())?
            .to_vec1::<f64>()
            .map_err(|e| e.to_string())?;
        let unit_values = unit
            .flatten_all()
            .map_err(|e| e.to_string())?
            .to_vec1::<f64>()
            .map_err(|e| e.to_string())?;
        let mut log_epsilon = [[0.0; 3]; 3];
        for a in 0..3 {
            log_epsilon[a][a] = iso;
        }
        for (edge_index, _edge) in graph.edges.iter().enumerate() {
            let u = &unit_values[edge_index * 3..edge_index * 3 + 3];
            let coefficient = 0.5 * edge_coeff[edge_index] / n as f64;
            for a in 0..3 {
                for b in 0..3 {
                    log_epsilon[a][b] +=
                        coefficient * (u[a] * u[b] - if a == b { 1.0 / 3.0 } else { 0.0 });
                }
            }
        }
        let (eigenvalues, eigenvectors) = symmetric_eigen_3x3(log_epsilon)?;
        let epsilon_eigenvalues = eigenvalues.map(f64::exp);
        if epsilon_eigenvalues
            .iter()
            .any(|x| !x.is_finite() || *x <= 0.0)
        {
            return Err("CGCNN dielectric matrix exponential produced a non-finite or non-positive eigenvalue.".into());
        }
        let mut epsilon_infinity = [[0.0; 3]; 3];
        for a in 0..3 {
            for b in 0..3 {
                for k in 0..3 {
                    epsilon_infinity[a][b] +=
                        eigenvectors[a][k] * epsilon_eigenvalues[k] * eigenvectors[b][k];
                }
            }
        }
        Ok(DielectricResponse {
            schema: "macer-cgcnn-dielectric-response-v1".into(),
            model_id: self.manifest.model_id.clone(),
            checkpoint_sha256: self.manifest.checkpoint_sha256.clone(),
            runtime: "rust-native-candle-f64".into(),
            n_atoms: n,
            edge_count: graph.edges.len(),
            log_epsilon,
            epsilon_infinity,
            epsilon_eigenvalues,
        })
    }
}

fn symmetric_eigen_3x3(mut a: [[f64; 3]; 3]) -> Result<([f64; 3], [[f64; 3]; 3]), String> {
    let mut v = [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]];
    for _ in 0..64 {
        let mut p = 0;
        let mut q = 1;
        let mut largest = a[0][1].abs();
        for (i, j) in [(0, 2), (1, 2)] {
            if a[i][j].abs() > largest {
                p = i;
                q = j;
                largest = a[i][j].abs();
            }
        }
        if largest <= 1e-15 * a.iter().flatten().map(|x| x.abs()).fold(1.0, f64::max) {
            break;
        }
        let tau = (a[q][q] - a[p][p]) / (2.0 * a[p][q]);
        let t = if tau >= 0.0 {
            1.0 / (tau + (1.0 + tau * tau).sqrt())
        } else {
            -1.0 / (-tau + (1.0 + tau * tau).sqrt())
        };
        let c = 1.0 / (1.0 + t * t).sqrt();
        let s = t * c;
        let app = a[p][p];
        let aqq = a[q][q];
        let apq = a[p][q];
        a[p][p] = app - t * apq;
        a[q][q] = aqq + t * apq;
        a[p][q] = 0.0;
        a[q][p] = 0.0;
        for r in 0..3 {
            if r != p && r != q {
                let arp = a[r][p];
                let arq = a[r][q];
                a[r][p] = c * arp - s * arq;
                a[p][r] = a[r][p];
                a[r][q] = s * arp + c * arq;
                a[q][r] = a[r][q];
            }
        }
        for r in 0..3 {
            let vrp = v[r][p];
            let vrq = v[r][q];
            v[r][p] = c * vrp - s * vrq;
            v[r][q] = s * vrp + c * vrq;
        }
    }
    let mut pairs = [(a[0][0], 0usize), (a[1][1], 1usize), (a[2][2], 2usize)];
    pairs.sort_by(|x, y| x.0.total_cmp(&y.0));
    let values = [pairs[0].0, pairs[1].0, pairs[2].0];
    let vectors = std::array::from_fn(|row| std::array::from_fn(|col| v[row][pairs[col].1]));
    if values.iter().any(|x| !x.is_finite()) || vectors.iter().flatten().any(|x| !x.is_finite()) {
        return Err("CGCNN dielectric symmetric eigensolver failed with non-finite values.".into());
    }
    Ok((values, vectors))
}

fn validate_model_support(manifest: &ModelManifest, atomic_numbers: &[u16]) -> Result<(), String> {
    let supported = manifest
        .support
        .supported_atomic_numbers
        .iter()
        .copied()
        .collect::<std::collections::BTreeSet<_>>();
    let sparse = manifest
        .support
        .sparse_atomic_numbers
        .iter()
        .copied()
        .collect::<std::collections::BTreeSet<_>>();
    let missing = atomic_numbers
        .iter()
        .copied()
        .filter(|z| !supported.contains(z) && !sparse.contains(z))
        .collect::<std::collections::BTreeSet<_>>();
    if missing.is_empty() {
        Ok(())
    } else {
        Err(format!(
            "CGCNN response has no training structures for atomic number(s) {missing:?}."
        ))
    }
}

fn validate_born_geometry(geometry: &ResponseGeometry) -> Result<(), String> {
    let n = geometry.atomic_numbers.len();
    if n == 0
        || n > MAX_ATOMS
        || geometry.fractional_positions.len() != n
        || geometry.masses_amu.len() != n
    {
        return Err(format!("CGCNN Born accepts 1–{MAX_ATOMS} atoms with matching positions and masses; received {n}."));
    }
    if geometry
        .cell
        .iter()
        .flatten()
        .chain(geometry.fractional_positions.iter().flatten())
        .chain(geometry.masses_amu.iter())
        .any(|x| !x.is_finite())
        || determinant(geometry.cell).abs() < 1e-8
        || geometry.masses_amu.iter().any(|mass| *mass <= 0.0)
    {
        return Err("CGCNN Born requires finite coordinates, a nonsingular periodic cell, and positive masses.".into());
    }
    Ok(())
}

#[derive(Debug)]
struct BuiltGraph {
    edges: Vec<PeriodicEdge>,
    shift_cart: Vec<[f64; 3]>,
}

fn validate_geometry(geometry: &ResponseGeometry, modes: &[GammaMode]) -> Result<(), String> {
    let n = geometry.atomic_numbers.len();
    if n == 0
        || n > MAX_ATOMS
        || geometry.fractional_positions.len() != n
        || geometry.masses_amu.len() != n
    {
        return Err(format!("CGCNN browser runtime accepts 1–{MAX_ATOMS} atoms with matching positions and masses; received {n}."));
    }
    if geometry
        .cell
        .iter()
        .flatten()
        .chain(geometry.fractional_positions.iter().flatten())
        .chain(geometry.masses_amu.iter())
        .any(|x| !x.is_finite())
        || determinant(geometry.cell).abs() < 1e-8
        || geometry.masses_amu.iter().any(|m| *m <= 0.0)
    {
        return Err(
            "CGCNN requires finite coordinates, a nonsingular periodic cell, and positive masses."
                .into(),
        );
    }
    if modes.len() != 3 * n {
        return Err(format!(
            "CGCNN Γ response requires exactly 3N modes; received {} for N={n}.",
            modes.len()
        ));
    }
    for (index, mode) in modes.iter().enumerate() {
        if !mode.frequency_thz.is_finite()
            || mode.eigenvector_real.len() != 3 * n
            || mode.eigenvector_imag.len() != 3 * n
            || mode
                .eigenvector_real
                .iter()
                .chain(mode.eigenvector_imag.iter())
                .any(|x| !x.is_finite())
        {
            return Err(format!(
                "Gamma mode {} has incomplete or nonfinite frequency/eigenvectors.",
                index + 1
            ));
        }
        let norm = mode
            .eigenvector_real
            .iter()
            .chain(mode.eigenvector_imag.iter())
            .map(|x| x * x)
            .sum::<f64>();
        if (norm - 1.0).abs() > 1e-6 {
            return Err(format!(
                "Gamma mode {} eigenvector norm is {norm:.9}; expected 1.",
                index + 1
            ));
        }
    }
    Ok(())
}

fn determinant(m: [[f64; 3]; 3]) -> f64 {
    m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
        - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
        + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0])
}

fn inverse(m: [[f64; 3]; 3]) -> ([[f64; 3]; 3], f64) {
    let d = determinant(m);
    let out = [
        [
            (m[1][1] * m[2][2] - m[1][2] * m[2][1]) / d,
            (m[0][2] * m[2][1] - m[0][1] * m[2][2]) / d,
            (m[0][1] * m[1][2] - m[0][2] * m[1][1]) / d,
        ],
        [
            (m[1][2] * m[2][0] - m[1][0] * m[2][2]) / d,
            (m[0][0] * m[2][2] - m[0][2] * m[2][0]) / d,
            (m[0][2] * m[1][0] - m[0][0] * m[1][2]) / d,
        ],
        [
            (m[1][0] * m[2][1] - m[1][1] * m[2][0]) / d,
            (m[0][1] * m[2][0] - m[0][0] * m[2][1]) / d,
            (m[0][0] * m[1][1] - m[0][1] * m[1][0]) / d,
        ],
    ];
    (out, d)
}

fn estimate_workspace_bytes(geometry: &ResponseGeometry) -> Result<usize, String> {
    let n = geometry.atomic_numbers.len();
    if n == 0 || n > MAX_ATOMS || geometry.fractional_positions.len() != n {
        return Err(format!(
            "CGCNN memory preflight accepts 1–{MAX_ATOMS} atoms with matching coordinates."
        ));
    }
    let (inv, det) = inverse(geometry.cell);
    if !det.is_finite() || det.abs() < 1e-8 {
        return Err("CGCNN periodic cell is singular.".into());
    }
    let cutoff = CUTOFF + SKIN;
    let mut edges = 0usize;
    for i in 0..n {
        for j in 0..n {
            let delta_frac = [
                geometry.fractional_positions[j][0] - geometry.fractional_positions[i][0],
                geometry.fractional_positions[j][1] - geometry.fractional_positions[i][1],
                geometry.fractional_positions[j][2] - geometry.fractional_positions[i][2],
            ];
            let mut lo = [0i32; 3];
            let mut hi = [0i32; 3];
            let mut candidate_images = 1u128;
            for axis in 0..3 {
                let reciprocal_norm =
                    (inv[0][axis].powi(2) + inv[1][axis].powi(2) + inv[2][axis].powi(2)).sqrt();
                let bound = cutoff * reciprocal_norm + 1e-12;
                lo[axis] = (-delta_frac[axis] - bound).ceil() as i32;
                hi[axis] = (-delta_frac[axis] + bound).floor() as i32;
                candidate_images = candidate_images
                    .checked_mul((i64::from(hi[axis]) - i64::from(lo[axis]) + 1).max(0) as u128)
                    .ok_or_else(|| "CGCNN periodic image count overflowed.".to_string())?;
            }
            if candidate_images > MAX_IMAGE_CANDIDATES_PER_PAIR {
                return Err(format!(
                    "CGCNN periodic image search exceeds the per-atom-pair preflight limit ({MAX_IMAGE_CANDIDATES_PER_PAIR}); no graph was allocated."
                ));
            }
            for sx in lo[0]..=hi[0] {
                for sy in lo[1]..=hi[1] {
                    for sz in lo[2]..=hi[2] {
                        let image = [sx, sy, sz];
                        if i == j && image == [0, 0, 0] {
                            continue;
                        }
                        let mut delta = [0.0; 3];
                        for c in 0..3 {
                            delta[c] = (0..3)
                                .map(|axis| delta_frac[axis] * geometry.cell[axis][c])
                                .sum::<f64>()
                                + sx as f64 * geometry.cell[0][c]
                                + sy as f64 * geometry.cell[1][c]
                                + sz as f64 * geometry.cell[2][c];
                        }
                        let distance2 = delta.iter().map(|x| x * x).sum::<f64>();
                        if distance2 < cutoff * cutoff {
                            edges = edges.checked_add(1).ok_or_else(|| {
                                "CGCNN periodic edge count overflowed.".to_string()
                            })?;
                            if edges > MAX_EDGES {
                                return Err(format!(
                                    "CGCNN graph exceeds the {MAX_EDGES}-edge safety limit; no graph was allocated."
                                ));
                            }
                        }
                    }
                }
            }
        }
    }
    let baseline = n
        .checked_mul(ESTIMATED_BYTES_PER_ATOM)
        .and_then(|bytes| {
            edges
                .checked_mul(ESTIMATED_BYTES_PER_EDGE)
                .and_then(|edge_bytes| bytes.checked_add(edge_bytes))
        })
        .and_then(|bytes| bytes.checked_add(n * 3 * 6 * std::mem::size_of::<f64>()))
        .ok_or_else(|| "CGCNN response memory estimate overflowed.".to_string())?;
    apply_workspace_headroom(baseline)
}

fn apply_workspace_headroom(baseline_bytes: usize) -> Result<usize, String> {
    baseline_bytes
        .checked_mul(WORKSPACE_HEADROOM_NUMERATOR)
        .and_then(|bytes| bytes.checked_add(WORKSPACE_HEADROOM_DENOMINATOR - 1))
        .map(|bytes| bytes / WORKSPACE_HEADROOM_DENOMINATOR)
        .ok_or_else(|| "CGCNN response memory estimate overflowed.".to_string())
}

fn build_graph(geometry: &ResponseGeometry, max_edges: usize) -> Result<BuiltGraph, String> {
    build_graph_with_skin(geometry, max_edges, SKIN)
}

fn build_graph_with_skin(
    geometry: &ResponseGeometry,
    max_edges: usize,
    skin_angstrom: f64,
) -> Result<BuiltGraph, String> {
    if !skin_angstrom.is_finite() || skin_angstrom < SKIN {
        return Err(format!(
            "CGCNN candidate skin must be finite and at least the model's {} Å skin.",
            SKIN
        ));
    }
    let (inv, det) = inverse(geometry.cell);
    if !det.is_finite() || det.abs() < 1e-8 {
        return Err("CGCNN periodic cell is singular.".into());
    }
    let cutoff = CUTOFF + skin_angstrom;
    let mut edges = Vec::new();
    let mut shift_cart = Vec::new();
    for i in 0..geometry.atomic_numbers.len() {
        for j in 0..geometry.atomic_numbers.len() {
            let delta_frac = [
                geometry.fractional_positions[j][0] - geometry.fractional_positions[i][0],
                geometry.fractional_positions[j][1] - geometry.fractional_positions[i][1],
                geometry.fractional_positions[j][2] - geometry.fractional_positions[i][2],
            ];
            let mut lo = [0i32; 3];
            let mut hi = [0i32; 3];
            for axis in 0..3 {
                let reciprocal_norm =
                    (inv[0][axis].powi(2) + inv[1][axis].powi(2) + inv[2][axis].powi(2)).sqrt();
                let bound = cutoff * reciprocal_norm + 1e-12;
                lo[axis] = (-delta_frac[axis] - bound).ceil() as i32;
                hi[axis] = (-delta_frac[axis] + bound).floor() as i32;
            }
            for sx in lo[0]..=hi[0] {
                for sy in lo[1]..=hi[1] {
                    for sz in lo[2]..=hi[2] {
                        let image = [sx, sy, sz];
                        if i == j && image == [0, 0, 0] {
                            continue;
                        }
                        let shift = [
                            sx as f64 * geometry.cell[0][0]
                                + sy as f64 * geometry.cell[1][0]
                                + sz as f64 * geometry.cell[2][0],
                            sx as f64 * geometry.cell[0][1]
                                + sy as f64 * geometry.cell[1][1]
                                + sz as f64 * geometry.cell[2][1],
                            sx as f64 * geometry.cell[0][2]
                                + sy as f64 * geometry.cell[1][2]
                                + sz as f64 * geometry.cell[2][2],
                        ];
                        let mut delta = [0.0; 3];
                        for c in 0..3 {
                            delta[c] = (0..3)
                                .map(|axis| delta_frac[axis] * geometry.cell[axis][c])
                                .sum::<f64>()
                                + shift[c];
                        }
                        let r2 = delta.iter().map(|x| x * x).sum::<f64>();
                        if r2 < cutoff * cutoff {
                            if edges.len() >= max_edges {
                                return Err(format!("CGCNN graph exceeds edge budget ({max_edges}); no edges were silently removed."));
                            }
                            edges.push(PeriodicEdge { i, j, image });
                            shift_cart.push(shift);
                        }
                    }
                }
            }
        }
    }
    let mut order = (0..edges.len()).collect::<Vec<_>>();
    order.sort_by_key(|&k| edges[k].clone());
    let edges = order.iter().map(|&k| edges[k].clone()).collect::<Vec<_>>();
    shift_cart = order.iter().map(|&k| shift_cart[k]).collect();
    Ok(BuiltGraph { edges, shift_cart })
}

fn powder_activity(real: &[f64; 9], imag: &[f64; 9]) -> f64 {
    let norm = |index: usize| real[index] * real[index] + imag[index] * imag[index];
    let diff = |a: usize, b: usize| {
        let dr = real[a] - real[b];
        let di = imag[a] - imag[b];
        dr * dr + di * di
    };
    let tr_re = (real[0] + real[4] + real[8]) / 3.0;
    let tr_im = (imag[0] + imag[4] + imag[8]) / 3.0;
    let mean = tr_re * tr_re + tr_im * tr_im;
    let gamma = 0.5 * (diff(0, 4) + diff(4, 8) + diff(8, 0) + 6.0 * (norm(1) + norm(2) + norm(5)));
    (45.0 * mean + 7.0 * gamma).max(0.0)
}

fn probe_forward(values: &[f64]) -> candle_core::Result<Tensor> {
    let device = Device::Cpu;
    let x = Tensor::from_vec(values.to_vec(), (2, 2), &device)?;
    let gather_ids = Tensor::from_vec(vec![0u32, 1, 0], 3, &device)?;
    let destination_ids = Tensor::from_vec(vec![0u32, 1, 0], 3, &device)?;
    let gathered = x.embedding(&gather_ids)?;
    let weight = Tensor::from_vec(vec![0.2f64, -0.4, 0.3, 0.5], (2, 2), &device)?;
    let linear = gathered.matmul(&weight.transpose(0, 1)?)?;
    let sigmoid = (linear.neg()?.exp()? + 1.0)?.recip()?;
    let softplus = softplus_f64(&linear)?;
    let gated = sigmoid.mul(&softplus)?;
    let zero = Tensor::zeros((2, 2), DType::F64, &device)?;
    let aggregate = zero.index_add(&destination_ids, &gated, 0)?;
    let mean = aggregate.mean_keepdim(1)?;
    let centered = aggregate.broadcast_sub(&mean)?;
    let variance = centered.sqr()?.mean_keepdim(1)?;
    let normalized = centered.broadcast_div(
        &variance
            .broadcast_add(&Tensor::full(1e-5f64, variance.shape(), &device)?)?
            .sqrt()?,
    )?;
    let gain = Tensor::from_vec(vec![1.1f64, 0.9], (1, 2), &device)?;
    let bias = Tensor::from_vec(vec![0.03f64, -0.02], (1, 2), &device)?;
    let affine = normalized.broadcast_mul(&gain)?.broadcast_add(&bias)?;
    affine.silu()?.sqr()?.sum_all()
}

/// Exercises F64 matmul, gather/scatter, sigmoid/softplus, population
/// LayerNorm, SiLU and reverse-mode differentiation on CPU/WASM.
pub fn run_f64_autograd_probe() -> candle_core::Result<ProbeResult> {
    let values = vec![0.2f64, -0.3, 0.4, 0.7];
    let x = Var::from_vec(values.clone(), (2, 2), &Device::Cpu)?;
    let output = probe_forward(&values)?;
    let scalar = output.to_vec0::<f64>()?;
    // Rebuild with a tracked input because probe_forward accepts ordinary inputs.
    let gather_ids = Tensor::from_vec(vec![0u32, 1, 0], 3, &Device::Cpu)?;
    let destination_ids = Tensor::from_vec(vec![0u32, 1, 0], 3, &Device::Cpu)?;
    let gathered = x.embedding(&gather_ids)?;
    let weight = Tensor::from_vec(vec![0.2f64, -0.4, 0.3, 0.5], (2, 2), &Device::Cpu)?;
    let linear = gathered.matmul(&weight.transpose(0, 1)?)?;
    let sigmoid = (linear.neg()?.exp()? + 1.0)?.recip()?;
    let softplus = softplus_f64(&linear)?;
    let aggregate = Tensor::zeros((2, 2), DType::F64, &Device::Cpu)?.index_add(
        &destination_ids,
        &sigmoid.mul(&softplus)?,
        0,
    )?;
    let mean = aggregate.mean_keepdim(1)?;
    let centered = aggregate.broadcast_sub(&mean)?;
    let variance = centered.sqr()?.mean_keepdim(1)?;
    let normalized = centered.broadcast_div(
        &variance
            .broadcast_add(&Tensor::full(1e-5f64, variance.shape(), &Device::Cpu)?)?
            .sqrt()?,
    )?;
    let gain = Tensor::from_vec(vec![1.1f64, 0.9], (1, 2), &Device::Cpu)?;
    let bias = Tensor::from_vec(vec![0.03f64, -0.02], (1, 2), &Device::Cpu)?;
    let tracked = normalized
        .broadcast_mul(&gain)?
        .broadcast_add(&bias)?
        .silu()?
        .sqr()?
        .sum_all()?;
    let grads = tracked.backward()?;
    let gradient = grads
        .get(&x)
        .ok_or_else(|| candle_core::Error::Msg("probe input gradient is missing".into()))?
        .flatten_all()?
        .to_vec1::<f64>()?;
    let mut max_error: f64 = 0.0;
    for i in 0..values.len() {
        let h = 1e-5;
        let mut plus = values.clone();
        let mut minus = values.clone();
        plus[i] += h;
        minus[i] -= h;
        let fd = (probe_forward(&plus)?.to_vec0::<f64>()?
            - probe_forward(&minus)?.to_vec0::<f64>()?)
            / (2.0 * h);
        max_error = max_error.max((fd - gradient[i]).abs());
    }
    Ok(ProbeResult {
        output: scalar,
        input_gradient: gradient,
        max_finite_difference_error: max_error,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn model_with_element_support(supported: &[u16], sparse: &[u16]) -> CgcnnRamanModel {
        CgcnnRamanModel {
            manifest: ModelManifest {
                schema: "macer-cgcnn-response-bundle-v1".into(),
                model_id: MODEL_ID.into(),
                checkpoint_sha256: CHECKPOINT_SHA256.into(),
                weights_file: "weights.safetensors".into(),
                weights_sha256: String::new(),
                weights_bytes: 0,
                epoch: 37,
                dtype: "F64".into(),
                architecture: ArchitectureManifest {
                    hidden: HIDDEN,
                    layers: 3,
                    radial_channels: RBF_CHANNELS,
                    cutoff_angstrom: CUTOFF,
                    skin_angstrom: SKIN,
                },
                support: ElementSupport {
                    minimum_training_atoms: 20,
                    minimum_training_structures: 3,
                    supported_atomic_numbers: supported.to_vec(),
                    sparse_atomic_numbers: sparse.to_vec(),
                    atom_counts: BTreeMap::new(),
                    structure_counts: BTreeMap::new(),
                    accuracy_qualified_atomic_numbers: Vec::new(),
                    interpretation: "Coverage only; not accuracy qualified.".into(),
                },
                tensors: Vec::new(),
            },
            weights: Weights {
                tensors: BTreeMap::new(),
            },
        }
    }

    fn gradient_fd_max_error<F>(values: &[f64], shape: Vec<usize>, forward: F) -> f64
    where
        F: Fn(&Tensor) -> candle_core::Result<Tensor>,
    {
        let input = Var::from_vec(values.to_vec(), shape.clone(), &Device::Cpu).unwrap();
        let scalar = forward(&input).unwrap();
        let gradient = scalar
            .backward()
            .unwrap()
            .get(&input)
            .unwrap()
            .flatten_all()
            .unwrap()
            .to_vec1::<f64>()
            .unwrap();
        let mut max_error: f64 = 0.0;
        for index in 0..values.len() {
            let step = 1e-6;
            let mut plus = values.to_vec();
            let mut minus = values.to_vec();
            plus[index] += step;
            minus[index] -= step;
            let plus = Tensor::from_vec(plus, shape.clone(), &Device::Cpu).unwrap();
            let minus = Tensor::from_vec(minus, shape.clone(), &Device::Cpu).unwrap();
            let plus_value = forward(&plus).unwrap().to_vec0::<f64>().unwrap();
            let minus_value = forward(&minus).unwrap().to_vec0::<f64>().unwrap();
            let finite_difference = (plus_value - minus_value) / (2.0 * step);
            let error = (finite_difference - gradient[index]).abs()
                / gradient[index].abs().max(finite_difference.abs()).max(1.0);
            max_error = max_error.max(error);
        }
        max_error
    }

    #[test]
    fn f64_autograd_composite_ops_match_finite_difference() {
        let result = run_f64_autograd_probe().unwrap();
        assert!(result.output.is_finite());
        assert_eq!(result.input_gradient.len(), 4);
        assert!(result.input_gradient.iter().all(|x| x.is_finite()));
        assert!(
            result.max_finite_difference_error < 2e-7,
            "FD max error {}",
            result.max_finite_difference_error
        );
    }

    #[test]
    fn f64_linear_input_gradient_matches_finite_difference() {
        let weight = Tensor::from_vec(vec![0.2, -0.4, 0.3, 0.5], (2, 2), &Device::Cpu).unwrap();
        let error = gradient_fd_max_error(&[0.2, -0.3, 0.4, 0.7], vec![2, 2], |x| {
            x.matmul(&weight.transpose(0, 1)?)?.sqr()?.sum_all()
        });
        assert!(error < 2e-8, "linear gradient relative error {error}");
    }

    #[test]
    fn f64_sigmoid_softplus_silu_gradients_match_finite_difference() {
        let error = gradient_fd_max_error(&[-3.2, -0.4, 0.7, 4.1], vec![4], |x| {
            let sigmoid = (x.neg()?.exp()? + 1.0)?.recip()?;
            let smooth = softplus_f64(x)?;
            sigmoid.broadcast_mul(&smooth)?.silu()?.sqr()?.sum_all()
        });
        assert!(error < 2e-8, "activation gradient relative error {error}");
    }

    #[test]
    fn f64_population_layer_norm_gradient_matches_finite_difference() {
        let gain = Tensor::from_vec(vec![1.1, 0.9, 1.2], (1, 3), &Device::Cpu).unwrap();
        let bias = Tensor::from_vec(vec![0.03, -0.02, 0.07], (1, 3), &Device::Cpu).unwrap();
        let error = gradient_fd_max_error(&[0.2, -0.3, 0.4, 0.7, 0.1, -0.6], vec![2, 3], |x| {
            let mean = x.mean_keepdim(1)?;
            let centered = x.broadcast_sub(&mean)?;
            let variance = centered.sqr()?.mean_keepdim(1)?;
            let normalized = centered.broadcast_div(
                &variance
                    .broadcast_add(&Tensor::full(1e-5, variance.shape(), &Device::Cpu)?)?
                    .sqrt()?,
            )?;
            normalized
                .broadcast_mul(&gain)?
                .broadcast_add(&bias)?
                .sqr()?
                .sum_all()
        });
        assert!(error < 2e-8, "LayerNorm gradient relative error {error}");
    }

    #[test]
    fn f64_gather_scatter_gradient_matches_finite_difference() {
        let gather_ids = Tensor::from_vec(vec![0u32, 1, 0], 3, &Device::Cpu).unwrap();
        let destinations = Tensor::from_vec(vec![0u32, 1, 0], 3, &Device::Cpu).unwrap();
        let probe =
            Tensor::from_vec(vec![0.7, -0.2, 0.3, 0.9, -0.4, 0.6], (3, 2), &Device::Cpu).unwrap();
        let error = gradient_fd_max_error(&[0.2, -0.3, 0.4, 0.7], vec![2, 2], |x| {
            let gathered = x.embedding(&gather_ids)?;
            let messages = gathered.broadcast_mul(&probe)?;
            Tensor::zeros((2, 2), DType::F64, &Device::Cpu)?
                .index_add(&destinations, &messages, 0)?
                .sqr()?
                .sum_all()
        });
        assert!(
            error < 2e-8,
            "gather/scatter gradient relative error {error}"
        );
    }

    #[test]
    fn f64_periodic_direction_dyad_gradient_matches_finite_difference() {
        let shift = Tensor::from_vec(vec![1.3, -0.8, 0.4], (1, 3), &Device::Cpu).unwrap();
        let error = gradient_fd_max_error(&[0.2, -0.3, 0.4, 1.7, 0.6, -0.2], vec![2, 3], |x| {
            let delta = x
                .narrow(0, 1, 1)?
                .broadcast_sub(&x.narrow(0, 0, 1)?)?
                .broadcast_add(&shift)?;
            let radius = delta.sqr()?.sum_keepdim(1)?.sqrt()?;
            let unit = delta.broadcast_div(&radius)?;
            let ux = unit.narrow(1, 0, 1)?;
            let uy = unit.narrow(1, 1, 1)?;
            let uz = unit.narrow(1, 2, 1)?;
            ux.broadcast_mul(&uy)?
                .broadcast_add(&uy.broadcast_mul(&uz)?.affine(0.3, 0.0)?)?
                .sum_all()
        });
        assert!(
            error < 2e-8,
            "direction/dyad gradient relative error {error}"
        );
    }

    #[test]
    fn cutoff_shoulder_value_and_gradient_are_continuous() {
        for radius in [
            4.5 - 1e-5,
            4.5,
            4.5 + 1e-5,
            4.75,
            5.0 - 1e-5,
            5.0,
            5.0 + 1e-5,
        ] {
            let error =
                gradient_fd_max_error(&[radius], vec![1], |r| cutoff_envelope(r)?.sum_all());
            assert!(
                error < 2e-8,
                "envelope derivative mismatch at {radius} Å: {error}"
            );
        }
        for radius in [5.0, 5.35, 5.6] {
            let value = cutoff_envelope(&Tensor::from_vec(vec![radius], 1, &Device::Cpu).unwrap())
                .unwrap()
                .sum_all()
                .unwrap()
                .to_vec0::<f64>()
                .unwrap();
            assert_eq!(value, 0.0, "envelope at {radius} Å");
        }
    }

    #[test]
    fn enlarged_candidate_skin_adds_only_zero_envelope_edges() {
        let geometry = ResponseGeometry {
            cell: [[20.0, 0.0, 0.0], [0.0, 20.0, 0.0], [0.0, 0.0, 20.0]],
            fractional_positions: vec![[0.0, 0.0, 0.0], [0.28, 0.0, 0.0]],
            atomic_numbers: vec![14, 14],
            masses_amu: vec![28.085, 28.085],
        };
        let standard = build_graph(&geometry, MAX_EDGES).unwrap();
        let enlarged = build_graph_with_skin(&geometry, MAX_EDGES, 1.0).unwrap();
        assert!(standard.edges.is_empty());
        assert_eq!(enlarged.edges.len(), 2);
        for shift in enlarged.shift_cart {
            let radius = (5.6f64 + shift[0]).hypot(shift[1]).hypot(shift[2]);
            assert!(
                radius > CUTOFF,
                "unexpected active-range edge at {radius} Å"
            );
            let envelope =
                cutoff_envelope(&Tensor::from_vec(vec![radius], 1, &Device::Cpu).unwrap())
                    .unwrap()
                    .sum_all()
                    .unwrap()
                    .to_vec0::<f64>()
                    .unwrap();
            assert_eq!(
                envelope, 0.0,
                "extra skin edge has nonzero weight at {radius} Å"
            );
        }
    }

    #[test]
    fn workspace_preflight_headroom_rounds_up_and_checks_overflow() {
        assert_eq!(apply_workspace_headroom(10).unwrap(), 17);
        assert_eq!(apply_workspace_headroom(11).unwrap(), 19);
        assert!(apply_workspace_headroom(usize::MAX).is_err());
    }

    #[test]
    fn element_coverage_guard_accepts_observed_including_cobalt_and_rejects_unseen() {
        let model = model_with_element_support(&[14, 8, 41], &[24, 27]);
        assert!(model.validate_support(&[14, 8]).is_ok());

        assert!(model.validate_support(&[14, 24]).is_ok());
        assert!(model.validate_support(&[27, 41, 8]).is_ok());

        let unseen_error = model.validate_support(&[14, 118]).unwrap_err();
        assert!(
            unseen_error.contains("no training structures"),
            "{unseen_error}"
        );
        assert!(unseen_error.contains("118"), "{unseen_error}");
    }

    #[test]
    fn bundle_loader_rejects_weights_before_parsing_safetensors_when_hash_is_wrong() {
        let weights = [0x5au8, 0xa5, 0x11];
        let mut manifest = model_with_element_support(&[14], &[]).manifest;
        manifest.weights_sha256 = "0".repeat(64);
        manifest.weights_bytes = weights.len();
        let error = CgcnnRamanModel::from_bundle(&weights, &serde_json::to_vec(&manifest).unwrap())
            .unwrap_err();
        assert!(error.contains("weights hash mismatch"), "{error}");
    }

    #[test]
    fn common_task_identity_is_explicit_and_serializable() {
        let identity = ResponseModelIdentity {
            task: ResponseTask::Dielectric,
            model_id: "cgcnn-expanded-v2-electronic-dielectric".into(),
            checkpoint_sha256: "a".repeat(64),
            weights_sha256: "b".repeat(64),
            runtime: "rust-wasm-cpu-f64".into(),
        };
        let json = serde_json::to_value(&identity).unwrap();
        assert_eq!(json["task"], "dielectric");
        assert_eq!(json["modelId"], identity.model_id);
        assert_eq!(json["checkpointSha256"], identity.checkpoint_sha256);
        let restored: ResponseModelIdentity = serde_json::from_value(json).unwrap();
        assert_eq!(restored, identity);
    }
}
