use macer_rust_response::{
    run_f64_autograd_probe, BornResponse, CgcnnBornModel, CgcnnDielectricModel, CgcnnRamanModel,
    DielectricResponse, GammaMode, RamanResponse, ResponseGeometry, ResponseModelIdentity,
    ResponseTask,
};
use serde::{Deserialize, Serialize};
use wasm_bindgen::prelude::*;

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct PredictRequest {
    geometry: ResponseGeometry,
    modes: Vec<GammaMode>,
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct NacBundleManifest {
    schema: String,
    born: NacBundlePart,
    dielectric: NacBundlePart,
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct NacBundlePart {
    offset: usize,
    bytes: usize,
    manifest_json: String,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct NacResponseIdentity {
    task: &'static str,
    runtime: &'static str,
    born: ResponseModelIdentity,
    dielectric: ResponseModelIdentity,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct NacResponseOutput {
    schema: &'static str,
    task: &'static str,
    models: NacResponseIdentity,
    born: BornResponse,
    dielectric: DielectricResponse,
}

fn nac_models_from_bundle(
    weights: &[u8],
    manifest_json: &str,
) -> Result<(CgcnnBornModel, CgcnnDielectricModel), String> {
    let bundle: NacBundleManifest = serde_json::from_str(manifest_json)
        .map_err(|error| format!("Invalid composite NAC bundle manifest: {error}"))?;
    if bundle.schema != "macer-cgcnn-nac-bundle-v1" {
        return Err("Unsupported composite NAC bundle schema.".into());
    }
    let born_end = bundle
        .born
        .offset
        .checked_add(bundle.born.bytes)
        .ok_or_else(|| "Composite NAC Born byte range overflowed.".to_string())?;
    let dielectric_end = bundle
        .dielectric
        .offset
        .checked_add(bundle.dielectric.bytes)
        .ok_or_else(|| "Composite NAC dielectric byte range overflowed.".to_string())?;
    if bundle.born.offset != 0
        || bundle.born.bytes == 0
        || bundle.dielectric.offset != born_end
        || bundle.dielectric.bytes == 0
        || dielectric_end != weights.len()
    {
        return Err("Composite NAC bundle ranges must be contiguous, non-overlapping, and cover all weights.".into());
    }
    let born = CgcnnBornModel::from_bundle(
        &weights[bundle.born.offset..born_end],
        bundle.born.manifest_json.as_bytes(),
    )?;
    let dielectric = CgcnnDielectricModel::from_bundle(
        &weights[bundle.dielectric.offset..dielectric_end],
        bundle.dielectric.manifest_json.as_bytes(),
    )?;
    Ok((born, dielectric))
}

#[wasm_bindgen]
pub struct CgcnnResponseSession {
    task: ResponseTask,
    raman: Option<CgcnnRamanModel>,
    born: Option<CgcnnBornModel>,
    dielectric: Option<CgcnnDielectricModel>,
}

#[wasm_bindgen]
impl CgcnnResponseSession {
    /// Common task-aware session entry point. Existing Raman sessions remain
    /// available through CgcnnRamanSession; each task loads only its own bundle.
    #[wasm_bindgen(constructor)]
    pub fn new(task: &str, weights: &[u8], manifest_json: &str) -> Result<Self, JsValue> {
        let task = match task {
            "raman" => ResponseTask::Raman,
            "born" => ResponseTask::Born,
            "dielectric" => ResponseTask::Dielectric,
            "nac-response" => ResponseTask::NacResponse,
            other => {
                return Err(JsValue::from_str(&format!(
                    "Unknown response task: {other}"
                )))
            }
        };
        match task {
            ResponseTask::Raman => {
                let raman = CgcnnRamanModel::from_bundle(weights, manifest_json.as_bytes())
                    .map_err(|error| JsValue::from_str(&error))?;
                Ok(Self {
                    task,
                    raman: Some(raman),
                    born: None,
                    dielectric: None,
                })
            }
            ResponseTask::Born => {
                let born = CgcnnBornModel::from_bundle(weights, manifest_json.as_bytes())
                    .map_err(|error| JsValue::from_str(&error))?;
                Ok(Self {
                    task,
                    raman: None,
                    born: Some(born),
                    dielectric: None,
                })
            }
            ResponseTask::Dielectric => {
                let dielectric =
                    CgcnnDielectricModel::from_bundle(weights, manifest_json.as_bytes())
                        .map_err(|error| JsValue::from_str(&error))?;
                Ok(Self {
                    task,
                    raman: None,
                    born: None,
                    dielectric: Some(dielectric),
                })
            }
            ResponseTask::NacResponse => {
                let (born, dielectric) = nac_models_from_bundle(weights, manifest_json)
                    .map_err(|error| JsValue::from_str(&error))?;
                Ok(Self {
                    task,
                    raman: None,
                    born: Some(born),
                    dielectric: Some(dielectric),
                })
            }
        }
    }

    pub fn identity_json(&self) -> Result<String, JsValue> {
        if self.task == ResponseTask::NacResponse {
            let born = self
                .born
                .as_ref()
                .ok_or_else(|| JsValue::from_str("Response session is disposed."))?;
            let dielectric = self
                .dielectric
                .as_ref()
                .ok_or_else(|| JsValue::from_str("Response session is disposed."))?;
            let mut born_identity = born.identity();
            born_identity.runtime = "rust-wasm-cpu-f64".into();
            let mut dielectric_identity = dielectric.identity();
            dielectric_identity.runtime = "rust-wasm-cpu-f64".into();
            let identity = NacResponseIdentity {
                task: "nac-response",
                runtime: "rust-wasm-cpu-f64",
                born: born_identity,
                dielectric: dielectric_identity,
            };
            return serde_json::to_string(&identity)
                .map_err(|error| JsValue::from_str(&error.to_string()));
        }
        let identity: ResponseModelIdentity = if let Some(model) = self.raman.as_ref() {
            model.identity()
        } else if let Some(model) = self.born.as_ref() {
            let mut identity = model.identity();
            identity.runtime = "rust-wasm-cpu-f64".into();
            identity
        } else if let Some(model) = self.dielectric.as_ref() {
            let mut identity = model.identity();
            identity.runtime = "rust-wasm-cpu-f64".into();
            identity
        } else {
            return Err(JsValue::from_str("Response session is disposed."));
        };
        serde_json::to_string(&identity).map_err(|error| JsValue::from_str(&error.to_string()))
    }

    pub fn predict_raman_json(&self, request_json: &str) -> Result<String, JsValue> {
        if self.task != ResponseTask::Raman {
            return Err(JsValue::from_str(
                "The loaded response task cannot produce Raman output.",
            ));
        }
        let model = self
            .raman
            .as_ref()
            .ok_or_else(|| JsValue::from_str("Response session is disposed."))?;
        let request: PredictRequest = serde_json::from_str(request_json).map_err(|error| {
            JsValue::from_str(&format!("Invalid Raman response request: {error}"))
        })?;
        let response = model
            .predict(&request.geometry, &request.modes)
            .map_err(|error| JsValue::from_str(&error))?;
        serde_json::to_string(&response).map_err(|error| JsValue::from_str(&error.to_string()))
    }

    pub fn predict_born_json(&self, geometry_json: &str) -> Result<String, JsValue> {
        if self.task != ResponseTask::Born {
            return Err(JsValue::from_str(
                "The loaded response task cannot produce Born output.",
            ));
        }
        let model = self
            .born
            .as_ref()
            .ok_or_else(|| JsValue::from_str("Response session is disposed."))?;
        let geometry: ResponseGeometry = serde_json::from_str(geometry_json).map_err(|error| {
            JsValue::from_str(&format!("Invalid Born response request: {error}"))
        })?;
        let response: BornResponse = model
            .predict(&geometry)
            .map_err(|error| JsValue::from_str(&error))?;
        serde_json::to_string(&response).map_err(|error| JsValue::from_str(&error.to_string()))
    }

    pub fn predict_dielectric_json(&self, geometry_json: &str) -> Result<String, JsValue> {
        if self.task != ResponseTask::Dielectric {
            return Err(JsValue::from_str(
                "The loaded response task cannot produce dielectric output.",
            ));
        }
        let model = self
            .dielectric
            .as_ref()
            .ok_or_else(|| JsValue::from_str("Response session is disposed."))?;
        let geometry: ResponseGeometry = serde_json::from_str(geometry_json).map_err(|error| {
            JsValue::from_str(&format!("Invalid dielectric response request: {error}"))
        })?;
        let response: DielectricResponse = model
            .predict(&geometry)
            .map_err(|error| JsValue::from_str(&error))?;
        serde_json::to_string(&response).map_err(|error| JsValue::from_str(&error.to_string()))
    }

    /// Predict both task-specific response tensors from one finalized primitive.
    /// The Born and dielectric checkpoints stay separate and retain their own hashes.
    pub fn predict_nac_json(&self, geometry_json: &str) -> Result<String, JsValue> {
        if self.task != ResponseTask::NacResponse {
            return Err(JsValue::from_str(
                "The loaded response task cannot produce NAC inputs.",
            ));
        }
        let born_model = self
            .born
            .as_ref()
            .ok_or_else(|| JsValue::from_str("Response session is disposed."))?;
        let dielectric_model = self
            .dielectric
            .as_ref()
            .ok_or_else(|| JsValue::from_str("Response session is disposed."))?;
        let geometry: ResponseGeometry = serde_json::from_str(geometry_json).map_err(|error| {
            JsValue::from_str(&format!("Invalid NAC response request: {error}"))
        })?;
        let mut born = born_model
            .predict(&geometry)
            .map_err(|error| JsValue::from_str(&error))?;
        let mut dielectric = dielectric_model
            .predict(&geometry)
            .map_err(|error| JsValue::from_str(&error))?;
        born.runtime = "rust-wasm-cpu-f64".into();
        dielectric.runtime = "rust-wasm-cpu-f64".into();
        let mut born_identity = born_model.identity();
        born_identity.runtime = "rust-wasm-cpu-f64".into();
        let mut dielectric_identity = dielectric_model.identity();
        dielectric_identity.runtime = "rust-wasm-cpu-f64".into();
        let output = NacResponseOutput {
            schema: "macer-cgcnn-nac-response-v1",
            task: "nac-response",
            models: NacResponseIdentity {
                task: "nac-response",
                runtime: "rust-wasm-cpu-f64",
                born: born_identity,
                dielectric: dielectric_identity,
            },
            born,
            dielectric,
        };
        serde_json::to_string(&output).map_err(|error| JsValue::from_str(&error.to_string()))
    }

    pub fn dispose(&mut self) {
        self.raman = None;
        self.born = None;
        self.dielectric = None;
    }
}

#[wasm_bindgen]
pub struct CgcnnRamanSession {
    model: Option<CgcnnRamanModel>,
}

#[wasm_bindgen]
impl CgcnnRamanSession {
    #[wasm_bindgen(constructor)]
    pub fn new(weights: &[u8], manifest_json: &str) -> Result<CgcnnRamanSession, JsValue> {
        let model = CgcnnRamanModel::from_bundle(weights, manifest_json.as_bytes())
            .map_err(|error| JsValue::from_str(&error))?;
        Ok(Self { model: Some(model) })
    }

    pub fn model_identity_json(&self) -> Result<String, JsValue> {
        let model = self
            .model
            .as_ref()
            .ok_or_else(|| JsValue::from_str("CGCNN session is disposed."))?;
        serde_json::to_string(model.manifest())
            .map_err(|error| JsValue::from_str(&error.to_string()))
    }

    /// Typed identity API for the common response worker. The legacy
    /// `model_identity_json` method remains unchanged for existing clients.
    pub fn response_identity_json(&self) -> Result<String, JsValue> {
        let model = self
            .model
            .as_ref()
            .ok_or_else(|| JsValue::from_str("CGCNN session is disposed."))?;
        serde_json::to_string(&model.identity())
            .map_err(|error| JsValue::from_str(&error.to_string()))
    }

    pub fn predict_json(&self, request_json: &str) -> Result<String, JsValue> {
        let model = self
            .model
            .as_ref()
            .ok_or_else(|| JsValue::from_str("CGCNN session is disposed."))?;
        let request: PredictRequest = serde_json::from_str(request_json)
            .map_err(|error| JsValue::from_str(&format!("Invalid CGCNN Raman request: {error}")))?;
        let response: RamanResponse = model
            .predict(&request.geometry, &request.modes)
            .map_err(|error| JsValue::from_str(&error))?;
        serde_json::to_string(&response).map_err(|error| JsValue::from_str(&error.to_string()))
    }

    pub fn preflight_json(&self, geometry_json: &str) -> Result<String, JsValue> {
        let model = self
            .model
            .as_ref()
            .ok_or_else(|| JsValue::from_str("CGCNN session is disposed."))?;
        let geometry: ResponseGeometry = serde_json::from_str(geometry_json)
            .map_err(|error| JsValue::from_str(&format!("Invalid CGCNN geometry: {error}")))?;
        model
            .validate_support(&geometry.atomic_numbers)
            .map_err(|error| JsValue::from_str(&error))?;
        let estimated_workspace_bytes = model
            .estimate_workspace_bytes(&geometry)
            .map_err(|error| JsValue::from_str(&error))?;
        let limit_bytes = 256 * 1024 * 1024usize;
        if estimated_workspace_bytes > limit_bytes {
            return Err(JsValue::from_str(&format!(
                "CGCNN response preflight estimates {} MiB of working memory, above the 256 MiB limit; no graph or autodiff tape was allocated.",
                (estimated_workspace_bytes + 1024 * 1024 - 1) / (1024 * 1024)
            )));
        }
        serde_json::to_string(&serde_json::json!({
            "estimatedWorkspaceBytes": estimated_workspace_bytes,
            "limitBytes": limit_bytes
        }))
        .map_err(|error| JsValue::from_str(&error.to_string()))
    }

    pub fn dispose(&mut self) {
        self.model = None;
    }
}

#[wasm_bindgen]
pub fn f64_autograd_probe_json() -> Result<String, JsValue> {
    let result = run_f64_autograd_probe()
        .map_err(|error| JsValue::from_str(&format!("Candle F64 probe failed: {error}")))?;
    serde_json::to_string(&result).map_err(|error| JsValue::from_str(&error.to_string()))
}
