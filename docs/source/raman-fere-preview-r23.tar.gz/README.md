# RamanDB FERE preview r23 source overlay

This archive contains the fitted Raman coefficient bundle, browser response kernel/worker/runtime/UI, saved Si Gamma phonon example, RamanDB attribution, and the Pages integration patch. It is a source overlay for the existing macer-web-preview repository, not a standalone application.

Base repository commit: `a7c297b2bea8e0d84b2f32cf6d83d849c2834956`. Apply `patches/r23-pages-integration.patch` at the repository root and copy the files under `web/` and `third_party/` into the matching `docs/` paths. The archive includes fitted coefficients but not the RamanDB archive or raw response labels.

The saved Si example is a real previously calculated NEP Gamma phonon result; it does not contain source Raman labels. See `third_party/licenses/ramandb/NOTICE.md` for attribution and license.
