# Source and build notes
Rust1.99.1, wasm-bindgen0.2.129, Node22.13.1; original browser package hashes are
in package-manifest.json. Sources preserve original per-component licenses.
Install rustup target wasm32-unknown-unknown and wasm-bindgen-cli0.2.129.
Build Rust kernels with cargo build --locked --release --target wasm32-unknown-unknown
-p macer-rust-wasm -p macer-rust-wasm-nep -p macer-rust-phonon-kernel.
Use wasm-bindgen --target web on generated wasm modules, with output names
macer_rust_wasm, macer_rust_wasm_nep and phonon_kernel respectively.
Rebuild viewer adapter with esbuild0.25.11, three0.182.0 and --bundle --format=iife.
CPU/WebGPU runtime wrappers are JavaScript source, with shader sources included.
Dependency sources are included; Cargo.lock pins registry versions. Original project
patches use vendor/candle-core and vendor/candle-kernels. Development conversion
uses export_checkpoint.py with Python/PyTorch; these are not browser requirements.
Model text/converted weights and Moyo's prebuilt MIT/Apache WASM are provided by
this same site, with their licenses/provenance. Source and binary builds can differ
with compiler/target-feature options; public preview does not claim bitwise rebuilds.
