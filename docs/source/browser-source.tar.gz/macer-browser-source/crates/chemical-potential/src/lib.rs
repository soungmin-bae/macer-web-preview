//! Portable f64 chemical-potential polytope solver for systems of up to six elements.
//! Inputs carry total energies in eV; phase inequalities are normalized to eV/atom.

use serde::{Deserialize, Serialize};
use std::collections::BTreeSet;

pub mod api;
#[cfg(target_arch = "wasm32")]
mod wasm_api;

const MAX_ELEMENTS: usize = 6;
const FEASIBILITY_TOL: f64 = 1e-10;
const ACTIVE_TOL: f64 = 1e-7;
const VERTEX_TOL: f64 = 1e-7;
const PIVOT_TOL: f64 = 1e-12;
const NEAR_PIVOT_TOL: f64 = 1e-9;

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct CpdModelIdentity {
    pub model_id: String,
    pub weights_sha256: String,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct CpdPhaseEnergy {
    pub phase_id: String,
    /// Atom counts in CpdInput.elements order; exact integer repeats are supported.
    pub atom_counts: Vec<u32>,
    pub total_energy_ev: f64,
    pub energy_unit: String,
    pub model: CpdModelIdentity,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct CpdElementReference {
    pub element: String,
    /// References an ordered unary phase present in CpdInput.phases.
    pub phase_id: String,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct CpdInput {
    pub elements: Vec<String>,
    pub target_phase_id: String,
    pub model: CpdModelIdentity,
    /// CPD is currently supported only at zero external pressure.
    #[serde(default)]
    pub pressure_gpa: f64,
    pub phases: Vec<CpdPhaseEnergy>,
    pub elemental_references: Vec<CpdElementReference>,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CpdConstraintKind {
    ElementalUpperBound,
    CompetingPhase,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct CpdConstraint {
    pub constraint_id: String,
    pub kind: CpdConstraintKind,
    pub phase_id: Option<String>,
    pub composition_fraction: Vec<f64>,
    pub bound_ev_per_atom: f64,
    pub original_atom_counts: Vec<u32>,
    pub original_phase_total_energy_ev: Option<f64>,
    pub original_formation_energy_ev: Option<f64>,
    pub energy_unit: String,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct CpdVertex {
    pub delta_mu_ev_per_atom: Vec<f64>,
    pub active_constraint_ids: Vec<String>,
    pub target_residual_ev_per_atom: f64,
    pub max_inequality_violation_ev_per_atom: f64,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct CpdFacet {
    pub constraint_id: String,
    pub vertex_indices: Vec<usize>,
    pub affine_dimension: usize,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CpdStatus {
    Stable,
    Unstable,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct CpdDiagnostics {
    pub generated_intersections: usize,
    pub singular_intersections: usize,
    pub near_singular_intersections: usize,
    pub max_target_residual_ev_per_atom: Option<f64>,
    pub max_inequality_violation_ev_per_atom: Option<f64>,
    pub numerical_tolerance_ev_per_atom: f64,
    pub vertex_merge_tolerance_ev: f64,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct CpdResult {
    pub schema: String,
    pub schema_version: u32,
    pub status: CpdStatus,
    pub elements: Vec<String>,
    pub target_phase_id: String,
    pub model: CpdModelIdentity,
    pub pressure_gpa: f64,
    pub energy_convention: String,
    pub target_atom_counts: Vec<u32>,
    pub target_total_energy_ev: f64,
    pub target_formation_energy_ev: f64,
    pub target_formation_energy_ev_per_atom: f64,
    pub elemental_reference_phase_ids: Vec<String>,
    pub references_mu0_ev_per_atom: Vec<f64>,
    pub input_phase_energies: Vec<CpdPhaseEnergy>,
    pub constraints: Vec<CpdConstraint>,
    pub vertices: Vec<CpdVertex>,
    pub facets: Vec<CpdFacet>,
    pub dimension: Option<usize>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub unbounded_below_elements: Vec<String>,
    pub diagnostics: CpdDiagnostics,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub stabilization: Option<TargetStabilization>,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct TargetStabilization {
    pub policy: String,
    pub original_status: CpdStatus,
    pub original_total_energy_ev: f64,
    pub original_formation_energy_ev_per_atom: f64,
    pub hull_formation_energy_ev_per_atom: f64,
    pub above_hull_ev_per_atom: f64,
    pub buffer_ev_per_atom: f64,
    pub signed_change_ev_per_atom: f64,
    /// Atom-fraction weights, with zero dopant content.
    pub decomposition: Vec<(String, f64)>,
}

#[derive(Clone)]
struct Constraint {
    row: CpdConstraint,
    coeff: Vec<f64>,
}

#[derive(Default)]
struct SolveStats {
    singular: usize,
    near_singular: usize,
}

/// Preserve raw phase energies and derive reservoirs for metastable targets.
/// Dual supporting planes are accepted only with a nonnegative primal mixture
/// certificate at the same energy.
pub fn compute_cpd_with_stabilization(input: &CpdInput) -> Result<CpdResult, String> {
    let original = compute_cpd(input)?;
    if original.status == CpdStatus::Stable {
        return Ok(original);
    }
    let target = input.phases.iter().find(|p| p.phase_id == input.target_phase_id).unwrap();
    let host: Vec<usize> = target.atom_counts.iter().enumerate()
        .filter_map(|(i, &n)| (n > 0).then_some(i)).collect();
    let mu0 = &original.references_mu0_ev_per_atom;
    let rows: Vec<_> = input.phases.iter().filter(|p| p.phase_id != target.phase_id &&
        p.atom_counts.iter().enumerate().all(|(i, &n)| n == 0 || host.contains(&i)))
        .map(|p| {
            let (fraction, energy) = formation_per_atom(p, mu0);
            (p.phase_id.clone(), host.iter().map(|&i| fraction[i]).collect::<Vec<_>>(), energy)
        }).collect();
    let n = host.len();
    let mut count = 1_u128;
    for i in 0..n {
        count = count.saturating_mul(rows.len().saturating_sub(i) as u128) / (i + 1) as u128;
    }
    if count.saturating_mul(rows.len() as u128).saturating_mul(n as u128) > 10_000_000 {
        return Err("Hull diagnosis exceeds the scalar-operation budget. Reduce the selected phases.".into());
    }
    let (fraction, target_h) = formation_per_atom(target, mu0);
    let composition: Vec<_> = host.iter().map(|&i| fraction[i]).collect();
    let mut certificate = None;
    combinations(rows.len(), n, |ids| {
        let matrix: Vec<_> = ids.iter().map(|&i| rows[i].1.clone()).collect();
        let energies: Vec<_> = ids.iter().map(|&i| rows[i].2).collect();
        let Some((plane, _)) = solve_small(&matrix, &energies) else { return; };
        if rows.iter().any(|(_, a, e)| dot(a, &plane) > e + FEASIBILITY_TOL) { return; }
        let transpose: Vec<Vec<f64>> = (0..n).map(|j| matrix.iter().map(|r| r[j]).collect()).collect();
        let Some((weights, _)) = solve_small(&transpose, &composition) else { return; };
        if weights.iter().any(|&w| w < -FEASIBILITY_TOL) { return; }
        let hull = dot(&weights, &energies);
        if (hull - dot(&composition, &plane)).abs() > ACTIVE_TOL { return; }
        let decomposition = ids.iter().zip(weights.iter()).filter(|(_, w)| **w > 0.0)
            .map(|(&i, &w)| (rows[i].0.clone(), w)).collect::<Vec<_>>();
        if certificate.is_none() { certificate = Some((hull, decomposition)); }
    });
    let (hull, decomposition) = certificate.ok_or("Could not certify the selected-phase convex hull.")?;
    let distance = target_h - hull;
    if distance <= 1e-8 {
        return Err("No CPD vertices, but the target is not certifiably above hull. Check numerical conditioning.".into());
    }
    let buffer = 1e-5;
    let change = -(distance + buffer);
    let mut effective = input.clone();
    let corrected = effective.phases.iter_mut().find(|p| p.phase_id == target.phase_id).unwrap();
    corrected.total_energy_ev += change * target.atom_counts.iter().map(|&x| x as f64).sum::<f64>();
    let mut result = compute_cpd(&effective)?;
    if result.status != CpdStatus::Stable {
        return Err("Minimum hull correction did not produce certified CPD vertices.".into());
    }
    result.input_phase_energies = input.phases.clone();
    result.stabilization = Some(TargetStabilization {
        policy: "minimum-hull-buffer-v1".into(), original_status: original.status,
        original_total_energy_ev: target.total_energy_ev,
        original_formation_energy_ev_per_atom: target_h,
        hull_formation_energy_ev_per_atom: hull, above_hull_ev_per_atom: distance,
        buffer_ev_per_atom: buffer, signed_change_ev_per_atom: change, decomposition,
    });
    Ok(result)
}

/// Computes delta chemical-potential vertices satisfying the target equality
/// and every elemental/competing-phase inequality. Same-composition polymorphs
/// stay separate constraints and can make the selected target unstable.
pub fn compute_cpd(input: &CpdInput) -> Result<CpdResult, String> {
    validate_input(input)?;
    let n = input.elements.len();
    let get_phase = |id: &str| input.phases.iter().find(|p| p.phase_id == id).unwrap();

    let mut reference_indices = vec![None; n];
    for reference in &input.elemental_references {
        let index = input
            .elements
            .iter()
            .position(|e| e == &reference.element)
            .unwrap();
        reference_indices[index] = Some(reference.phase_id.as_str());
    }
    let mut mu0 = vec![0.0; n];
    for (i, phase_id) in reference_indices.iter().enumerate() {
        let phase = get_phase(phase_id.unwrap());
        let atom_total = atom_total(&phase.atom_counts);
        if phase.atom_counts[i] == 0
            || phase
                .atom_counts
                .iter()
                .enumerate()
                .any(|(j, &c)| j != i && c != 0)
        {
            return Err(format!(
                "Reference phase {} is not unary {}.",
                phase.phase_id, input.elements[i]
            ));
        }
        mu0[i] = phase.total_energy_ev / atom_total as f64;
        if !mu0[i].is_finite() {
            return Err(format!(
                "Elemental reference {} is not finite after normalization.",
                input.elements[i]
            ));
        }
    }
    for phase in &input.phases {
        for i in 0..n {
            if phase.atom_counts[i] > 0
                && phase
                    .atom_counts
                    .iter()
                    .enumerate()
                    .all(|(j, &c)| j == i || c == 0)
            {
                let epa = phase.total_energy_ev / atom_total(&phase.atom_counts) as f64;
                if epa < mu0[i] - FEASIBILITY_TOL {
                    return Err(format!(
                        "Reference for {} is above unary phase {}.",
                        input.elements[i], phase.phase_id
                    ));
                }
            }
        }
        let (_, formation_per_atom) = formation_per_atom(phase, &mu0);
        if !formation_per_atom.is_finite() || !formation_total(phase, &mu0).is_finite() {
            return Err(format!(
                "Phase {} formation energy is not finite after normalization.",
                phase.phase_id
            ));
        }
    }

    let target = get_phase(&input.target_phase_id);
    let (target_fraction, target_h) = formation_per_atom(target, &mu0);
    let mut constraints = Vec::new();
    for (i, element) in input.elements.iter().enumerate() {
        let mut coeff = vec![0.0; n];
        coeff[i] = 1.0;
        let reference = get_phase(reference_indices[i].unwrap());
        constraints.push(Constraint {
            row: CpdConstraint {
                constraint_id: format!("element:{element}"),
                kind: CpdConstraintKind::ElementalUpperBound,
                phase_id: Some(reference.phase_id.clone()),
                composition_fraction: coeff.clone(),
                bound_ev_per_atom: 0.0,
                original_atom_counts: reference.atom_counts.clone(),
                original_phase_total_energy_ev: Some(reference.total_energy_ev),
                original_formation_energy_ev: Some(0.0),
                energy_unit: "eV".into(),
            },
            coeff,
        });
    }
    // The selected elemental references are already represented exactly by
    // Δμ_i <= 0. Keep non-reference unary polymorphs as competitors.
    let reference_phase_ids = reference_indices
        .iter()
        .filter_map(|id| *id)
        .collect::<BTreeSet<_>>();
    let mut competitors: Vec<&CpdPhaseEnergy> = input
        .phases
        .iter()
        .filter(|p| {
            p.phase_id != input.target_phase_id
                && !reference_phase_ids.contains(p.phase_id.as_str())
        })
        .collect();
    competitors.sort_by(|a, b| a.phase_id.cmp(&b.phase_id));
    for phase in competitors {
        let (fraction, h) = formation_per_atom(phase, &mu0);
        constraints.push(Constraint {
            row: CpdConstraint {
                constraint_id: format!("phase:{}", phase.phase_id),
                kind: CpdConstraintKind::CompetingPhase,
                phase_id: Some(phase.phase_id.clone()),
                composition_fraction: fraction.clone(),
                bound_ev_per_atom: h,
                original_atom_counts: phase.atom_counts.clone(),
                original_phase_total_energy_ev: Some(phase.total_energy_ev),
                original_formation_energy_ev: Some(formation_total(phase, &mu0)),
                energy_unit: "eV".into(),
            },
            coeff: fraction,
        });
    }
    constraints.sort_by(|a, b| a.row.constraint_id.cmp(&b.row.constraint_id));

    let choose = n - 1;
    let mut stats = SolveStats::default();
    let mut generated = 0usize;
    let mut candidate_points: Vec<Vec<f64>> = Vec::new();
    combinations(constraints.len(), choose, |indices| {
        generated += 1;
        let mut matrix = vec![target_fraction.clone()];
        let mut rhs = vec![target_h];
        for &i in indices {
            matrix.push(constraints[i].coeff.clone());
            rhs.push(constraints[i].row.bound_ev_per_atom);
        }
        let Some((point, near)) = solve_small(&matrix, &rhs) else {
            stats.singular += 1;
            return;
        };
        if near {
            stats.near_singular += 1;
        }
        if !feasible(&point, target_h, &target_fraction, &constraints) {
            return;
        }
        if !candidate_points
            .iter()
            .any(|old| max_distance(old, &point) <= VERTEX_TOL)
        {
            candidate_points.push(point);
        }
    });
    candidate_points.sort_by(|a, b| lexicographic(a, b));

    let mut vertices = Vec::with_capacity(candidate_points.len());
    for point in candidate_points {
        let target_residual = (dot(&target_fraction, &point) - target_h).abs();
        let max_violation = constraints
            .iter()
            .map(|c| (dot(&c.coeff, &point) - c.row.bound_ev_per_atom).max(0.0))
            .fold(0.0, f64::max);
        let active_constraint_ids = constraints
            .iter()
            .filter(|c| (dot(&c.coeff, &point) - c.row.bound_ev_per_atom).abs() <= ACTIVE_TOL)
            .map(|c| c.row.constraint_id.clone())
            .collect();
        vertices.push(CpdVertex {
            delta_mu_ev_per_atom: point,
            active_constraint_ids,
            target_residual_ev_per_atom: target_residual,
            max_inequality_violation_ev_per_atom: max_violation,
        });
    }
    // Elemental bounds rule out all positive recession components. The
    // target equality then permits a negative ray only along absent species.
    let unbounded_axes = target
        .atom_counts
        .iter()
        .enumerate()
        .filter_map(|(axis, &count)| (count == 0 && !vertices.is_empty()).then_some(axis))
        .collect::<Vec<_>>();
    let dimension = (!vertices.is_empty()).then(|| {
        dimension_with_rays(
            vertices
                .iter()
                .map(|v| v.delta_mu_ev_per_atom.clone())
                .collect(),
            unbounded_axes.iter().copied(),
        )
    });
    let facets = facets(
        &vertices,
        &constraints,
        dimension.unwrap_or(0),
        &unbounded_axes,
    );
    let status = if vertices.is_empty() {
        CpdStatus::Unstable
    } else {
        CpdStatus::Stable
    };
    let max_target = vertices
        .iter()
        .map(|v| v.target_residual_ev_per_atom)
        .reduce(f64::max);
    let max_violation = vertices
        .iter()
        .map(|v| v.max_inequality_violation_ev_per_atom)
        .reduce(f64::max);
    Ok(CpdResult {
        stabilization: None,
        schema: "macer-cpd-result-v1".into(),
        schema_version: 1,
        status,
        elements: input.elements.clone(),
        target_phase_id: input.target_phase_id.clone(),
        model: input.model.clone(),
        pressure_gpa: input.pressure_gpa,
        energy_convention: "total_energy_eV_at_zero_pressure".into(),
        target_atom_counts: target.atom_counts.clone(),
        target_total_energy_ev: target.total_energy_ev,
        target_formation_energy_ev: formation_total(target, &mu0),
        target_formation_energy_ev_per_atom: target_h,
        elemental_reference_phase_ids: reference_indices
            .iter()
            .map(|id| id.unwrap().to_string())
            .collect(),
        references_mu0_ev_per_atom: mu0,
        input_phase_energies: input.phases.clone(),
        constraints: constraints.into_iter().map(|c| c.row).collect(),
        vertices,
        facets,
        dimension,
        unbounded_below_elements: unbounded_axes
            .iter()
            .map(|&axis| input.elements[axis].clone())
            .collect(),
        diagnostics: CpdDiagnostics {
            generated_intersections: generated,
            singular_intersections: stats.singular,
            near_singular_intersections: stats.near_singular,
            max_target_residual_ev_per_atom: max_target,
            max_inequality_violation_ev_per_atom: max_violation,
            numerical_tolerance_ev_per_atom: FEASIBILITY_TOL,
            vertex_merge_tolerance_ev: VERTEX_TOL,
        },
    })
}

fn validate_input(input: &CpdInput) -> Result<(), String> {
    let n = input.elements.len();
    if !(1..=MAX_ELEMENTS).contains(&n) {
        return Err("CPD supports one to six elements.".into());
    }
    if !input.pressure_gpa.is_finite() {
        return Err("External pressure must be finite.".into());
    }
    if input.pressure_gpa != 0.0 {
        return Err(
            "CPD currently requires zero pressure; enthalpy phases are not implemented.".into(),
        );
    }
    let mut elements = BTreeSet::new();
    if input
        .elements
        .iter()
        .any(|e| !valid_symbol(e) || !elements.insert(e.as_str()))
    {
        return Err("Chemical-system elements must be unique valid symbols.".into());
    }
    if input.model.model_id.trim().is_empty()
        || input.model.weights_sha256.len() != 64
        || !input
            .model
            .weights_sha256
            .bytes()
            .all(|b| b.is_ascii_hexdigit())
    {
        return Err("CPD model identity is invalid.".into());
    }
    if input.phases.is_empty() {
        return Err("CPD requires at least one phase energy.".into());
    }
    let mut ids = BTreeSet::new();
    for phase in &input.phases {
        if phase.phase_id.trim().is_empty() || !ids.insert(phase.phase_id.as_str()) {
            return Err("Phase identities must be nonempty and unique.".into());
        }
        if phase.atom_counts.len() != n || phase.atom_counts.iter().all(|&x| x == 0) {
            return Err(format!("Phase {} has invalid atom counts.", phase.phase_id));
        }
        if !phase.total_energy_ev.is_finite() {
            return Err(format!("Phase {} energy must be finite.", phase.phase_id));
        }
        if phase.energy_unit != "eV" {
            return Err(format!(
                "Phase {} energy must be expressed in eV.",
                phase.phase_id
            ));
        }
        if phase.model != input.model {
            return Err(format!(
                "Phase {} uses a different energy model identity.",
                phase.phase_id
            ));
        }
    }
    if !ids.contains(input.target_phase_id.as_str()) {
        return Err("Target phase ID is missing.".into());
    }
    if input.elemental_references.len() != n {
        return Err("Exactly one elemental reference is required for every system element.".into());
    }
    let mut refs = BTreeSet::new();
    for reference in &input.elemental_references {
        if !elements.contains(reference.element.as_str())
            || !refs.insert(reference.element.as_str())
        {
            return Err("Elemental references must uniquely cover the chemical system.".into());
        }
        if !ids.contains(reference.phase_id.as_str()) {
            return Err(format!(
                "Reference phase {} is missing.",
                reference.phase_id
            ));
        }
    }
    Ok(())
}

fn valid_symbol(s: &str) -> bool {
    let mut c = s.chars();
    matches!(c.next(),Some(x) if x.is_ascii_uppercase())
        && matches!(c.next(), None | Some('a'..='z'))
        && c.next().is_none()
}
fn atom_total(counts: &[u32]) -> u64 {
    counts.iter().map(|&x| u64::from(x)).sum()
}
fn formation_per_atom(phase: &CpdPhaseEnergy, mu0: &[f64]) -> (Vec<f64>, f64) {
    let total = atom_total(&phase.atom_counts) as f64;
    let fractions = phase
        .atom_counts
        .iter()
        .map(|&n| f64::from(n) / total)
        .collect::<Vec<_>>();
    let h = phase.total_energy_ev / total - dot(&fractions, mu0);
    (fractions, h)
}
fn formation_total(phase: &CpdPhaseEnergy, mu0: &[f64]) -> f64 {
    phase.total_energy_ev
        - phase
            .atom_counts
            .iter()
            .zip(mu0)
            .map(|(&n, &mu)| f64::from(n) * mu)
            .sum::<f64>()
}
fn combinations<F: FnMut(&[usize])>(count: usize, choose: usize, mut f: F) {
    fn recurse<F: FnMut(&[usize])>(
        count: usize,
        choose: usize,
        start: usize,
        current: &mut Vec<usize>,
        f: &mut F,
    ) {
        if current.len() == choose {
            f(current);
            return;
        }
        let needed = choose - current.len();
        if count < needed || start > count - needed {
            return;
        }
        for i in start..=count - needed {
            current.push(i);
            recurse(count, choose, i + 1, current, f);
            current.pop();
        }
    }
    recurse(count, choose, 0, &mut Vec::with_capacity(choose), &mut f);
}
fn solve_small(a: &[Vec<f64>], b: &[f64]) -> Option<(Vec<f64>, bool)> {
    let n = b.len();
    if !(1..=MAX_ELEMENTS).contains(&n) || a.len() != n || a.iter().any(|r| r.len() != n) {
        return None;
    }
    let mut m = vec![vec![0.0; n + 1]; n];
    for i in 0..n {
        m[i][..n].copy_from_slice(&a[i]);
        m[i][n] = b[i];
    }
    let mut near = false;
    for col in 0..n {
        let pivot = (col..n).max_by(|&i, &j| m[i][col].abs().total_cmp(&m[j][col].abs()))?;
        let value = m[pivot][col].abs();
        if value <= PIVOT_TOL {
            return None;
        }
        if value <= NEAR_PIVOT_TOL {
            near = true;
        }
        m.swap(col, pivot);
        let divisor = m[col][col];
        for j in col..=n {
            m[col][j] /= divisor;
        }
        for i in 0..n {
            if i != col {
                let factor = m[i][col];
                for j in col..=n {
                    m[i][j] -= factor * m[col][j];
                }
            }
        }
    }
    let x = (0..n).map(|i| m[i][n]).collect::<Vec<_>>();
    x.iter().all(|v| v.is_finite()).then_some((x, near))
}
fn feasible(x: &[f64], h: f64, target: &[f64], constraints: &[Constraint]) -> bool {
    (dot(target, x) - h).abs() <= FEASIBILITY_TOL
        && constraints
            .iter()
            .all(|c| dot(&c.coeff, x) - c.row.bound_ev_per_atom <= FEASIBILITY_TOL)
}
fn facets(
    vertices: &[CpdVertex],
    constraints: &[Constraint],
    dim: usize,
    unbounded_axes: &[usize],
) -> Vec<CpdFacet> {
    if vertices.is_empty() || dim == 0 {
        return Vec::new();
    }
    let mut out = Vec::new();
    for c in constraints {
        let ids = vertices
            .iter()
            .enumerate()
            .filter_map(|(i, v)| {
                v.active_constraint_ids
                    .contains(&c.row.constraint_id)
                    .then_some(i)
            })
            .collect::<Vec<_>>();
        if ids.is_empty() {
            continue;
        }
        let points = ids
            .iter()
            .map(|&i| vertices[i].delta_mu_ev_per_atom.clone())
            .collect::<Vec<_>>();
        let subdim = dimension_with_rays(
            points,
            unbounded_axes
                .iter()
                .copied()
                .filter(|&axis| c.coeff[axis] == 0.0),
        );
        if subdim + 1 == dim {
            out.push(CpdFacet {
                constraint_id: c.row.constraint_id.clone(),
                vertex_indices: ids,
                affine_dimension: subdim,
            });
        }
    }
    out
}
fn dimension_with_rays(mut points: Vec<Vec<f64>>, axes: impl Iterator<Item = usize>) -> usize {
    let origin = points[0].clone();
    for axis in axes {
        let mut point = origin.clone();
        point[axis] -= 1.0;
        points.push(point);
    }
    affine_dimension(&points)
}
fn affine_dimension(points: &[Vec<f64>]) -> usize {
    if points.len() <= 1 {
        return 0;
    }
    let origin = &points[0];
    let rows = points
        .iter()
        .skip(1)
        .map(|p| p.iter().zip(origin).map(|(a, b)| a - b).collect::<Vec<_>>())
        .collect::<Vec<_>>();
    matrix_rank(rows, VERTEX_TOL)
}
fn matrix_rank(mut a: Vec<Vec<f64>>, tol: f64) -> usize {
    if a.is_empty() {
        return 0;
    }
    let rows = a.len();
    let cols = a[0].len();
    let mut rank = 0;
    for col in 0..cols {
        if rank >= rows {
            break;
        }
        let pivot = (rank..rows)
            .max_by(|&i, &j| a[i][col].abs().total_cmp(&a[j][col].abs()))
            .unwrap();
        if a[pivot][col].abs() <= tol {
            continue;
        }
        a.swap(rank, pivot);
        let divisor = a[rank][col];
        for j in col..cols {
            a[rank][j] /= divisor;
        }
        for i in 0..rows {
            if i != rank {
                let q = a[i][col];
                for j in col..cols {
                    a[i][j] -= q * a[rank][j];
                }
            }
        }
        rank += 1;
    }
    rank
}
fn dot(a: &[f64], b: &[f64]) -> f64 {
    a.iter().zip(b).map(|(x, y)| x * y).sum()
}
fn max_distance(a: &[f64], b: &[f64]) -> f64 {
    a.iter()
        .zip(b)
        .map(|(x, y)| (x - y).abs())
        .fold(0.0, f64::max)
}
fn lexicographic(a: &[f64], b: &[f64]) -> std::cmp::Ordering {
    for (x, y) in a.iter().zip(b) {
        let c = x.total_cmp(y);
        if c != std::cmp::Ordering::Equal {
            return c;
        }
    }
    a.len().cmp(&b.len())
}

#[cfg(test)]
mod tests {
    use super::*;
    fn model() -> CpdModelIdentity {
        CpdModelIdentity {
            model_id: "synthetic-fixed-energy-oracle".into(),
            weights_sha256: "a".repeat(64),
        }
    }
    fn phase(id: &str, counts: &[u32], energy: f64) -> CpdPhaseEnergy {
        CpdPhaseEnergy {
            phase_id: id.into(),
            atom_counts: counts.into(),
            total_energy_ev: energy,
            energy_unit: "eV".into(),
            model: model(),
        }
    }
    #[test]
    fn extrinsic_dopant_keeps_the_host_equality_and_has_no_lower_bound() {
        let elements: Vec<String> = ["Ga", "As", "Zn"].map(str::to_owned).into();
        let elemental_references = elements
            .iter()
            .map(|element| CpdElementReference {
                element: element.clone(),
                phase_id: element.clone(),
            })
            .collect();
        let r = compute_cpd(&CpdInput {
            elements,
            phases: vec![
                phase("Ga", &[1, 0, 0], 0.0),
                phase("As", &[0, 1, 0], 0.0),
                phase("Zn", &[0, 0, 1], 0.0),
                phase("GaAs", &[1, 1, 0], -1.0),
                phase("ZnAs", &[0, 1, 1], -0.5),
            ],
            elemental_references,
            target_phase_id: "GaAs".into(),
            model: model(),
            pressure_gpa: 0.0,
        })
        .unwrap();
        assert_points(
            &coords(&r),
            &[vec![-1., 0., -0.5], vec![-0.5, -0.5, 0.], vec![0., -1., 0.]],
            1e-10,
        );
        assert_eq!(r.dimension, Some(2));
        assert_eq!(r.unbounded_below_elements, ["Zn"]);
        assert_eq!(r.facets.len(), 4);
    }

    #[test]
    fn ternary_host_with_a_dopant_has_three_independent_potential_dimensions() {
        let elements: Vec<String> = ["Sr", "Ti", "O", "La"].map(str::to_owned).into();
        let mut phases = Vec::new();
        let elemental_references = elements
            .iter()
            .enumerate()
            .map(|(axis, element)| {
                let mut counts = vec![0; 4];
                counts[axis] = 1;
                phases.push(phase(element, &counts, 0.0));
                CpdElementReference {
                    element: element.clone(),
                    phase_id: element.clone(),
                }
            })
            .collect();
        phases.push(phase("SrTiO3", &[1, 1, 3, 0], -3.0));
        phases.push(phase("La2O3", &[0, 0, 3, 2], -2.0));
        let r = compute_cpd(&CpdInput {
            elements,
            phases,
            elemental_references,
            target_phase_id: "SrTiO3".into(),
            model: model(),
            pressure_gpa: 0.0,
        })
        .unwrap();
        assert_points(
            &coords(&r),
            &[
                vec![-3., 0., 0., -1.],
                vec![-1., 0., -2. / 3., 0.],
                vec![0., -3., 0., -1.],
                vec![0., -1., -2. / 3., 0.],
                vec![0., 0., -1., 0.],
            ],
            1e-10,
        );
        assert_eq!(r.dimension, Some(3));
        assert_eq!(r.unbounded_below_elements, ["La"]);
    }

    #[test]
    fn three_coupled_dopants_in_a_six_element_system() {
        let elements: Vec<String> = ["Sr", "Ti", "O", "La", "Ca", "Zr"]
            .map(str::to_owned)
            .into();
        let mut phases = Vec::new();
        let elemental_references = elements
            .iter()
            .enumerate()
            .map(|(axis, element)| {
                let mut counts = vec![0; 6];
                counts[axis] = 1;
                phases.push(phase(element, &counts, 0.0));
                CpdElementReference {
                    element: element.clone(),
                    phase_id: element.clone(),
                }
            })
            .collect();
        phases.push(phase("SrTiO3", &[1, 1, 3, 0, 0, 0], -3.0));
        phases.push(phase("LaCaZr", &[0, 0, 0, 1, 1, 1], -1.0));
        let request = CpdInput {
            elements,
            phases,
            elemental_references,
            target_phase_id: "SrTiO3".into(),
            model: model(),
            pressure_gpa: 0.0,
        };
        let response = api::compute_cpd_json(&serde_json::to_string(&request).unwrap()).unwrap();
        let r: CpdResult = serde_json::from_value(
            serde_json::from_str::<serde_json::Value>(&response).unwrap()["result"].clone(),
        )
        .unwrap();
        let expected = [[-3., 0., 0.], [0., -3., 0.], [0., 0., -1.]]
            .into_iter()
            .flat_map(|host| {
                [[-1., 0., 0.], [0., -1., 0.], [0., 0., -1.]]
                    .map(|dopants| [host, dopants].concat())
            })
            .collect::<Vec<_>>();
        assert_points(&coords(&r), &expected, 1e-10);
        assert_eq!(r.dimension, Some(5));
        assert_eq!(r.unbounded_below_elements, ["La", "Ca", "Zr"]);
        assert!(r.vertices.iter().all(|v| v
            .active_constraint_ids
            .iter()
            .any(|id| id.contains("LaCaZr"))));
    }

    #[test]
    fn quaternary_simplex_retains_four_coordinates_and_facets() {
        let elements: Vec<String> = ["K", "Zr", "P", "O"].map(str::to_owned).into();
        let mut phases = Vec::new();
        let elemental_references = elements
            .iter()
            .enumerate()
            .map(|(axis, element)| {
                let mut counts = vec![0; 4];
                counts[axis] = 1;
                phases.push(phase(element, &counts, 0.0));
                CpdElementReference {
                    element: element.clone(),
                    phase_id: element.clone(),
                }
            })
            .collect();
        phases.push(phase("target", &[1, 2, 3, 12], -12.0));
        let r = compute_cpd(&CpdInput {
            elements,
            phases,
            elemental_references,
            target_phase_id: "target".into(),
            model: model(),
            pressure_gpa: 0.0,
        })
        .unwrap();
        assert_points(
            &coords(&r),
            &[
                vec![-12., 0., 0., 0.],
                vec![0., -6., 0., 0.],
                vec![0., 0., -4., 0.],
                vec![0., 0., 0., -1.],
            ],
            1e-10,
        );
        assert_eq!(r.dimension, Some(3));
        assert_eq!(r.facets.len(), 4);
    }

    fn binary(target: f64, extra: Vec<CpdPhaseEnergy>) -> CpdInput {
        let mut phases = vec![
            phase("li-ref", &[1, 0], 0.0),
            phase("f-ref", &[0, 1], 0.0),
            phase("target-lif", &[1, 1], target),
        ];
        phases.extend(extra);
        CpdInput {
            elements: vec!["Li".into(), "F".into()],
            target_phase_id: "target-lif".into(),
            model: model(),
            pressure_gpa: 0.0,
            phases,
            elemental_references: vec![
                CpdElementReference {
                    element: "Li".into(),
                    phase_id: "li-ref".into(),
                },
                CpdElementReference {
                    element: "F".into(),
                    phase_id: "f-ref".into(),
                },
            ],
        }
    }
    fn coords(r: &CpdResult) -> Vec<Vec<f64>> {
        r.vertices
            .iter()
            .map(|v| v.delta_mu_ev_per_atom.clone())
            .collect()
    }
    fn assert_points(actual: &[Vec<f64>], expected: &[Vec<f64>], tol: f64) {
        assert_eq!(actual.len(), expected.len(), "actual {actual:?}");
        for p in expected {
            assert!(
                actual.iter().any(|q| max_distance(p, q) <= tol),
                "missing {p:?} from {actual:?}"
            );
        }
    }

    #[test]
    fn binary_ab_hand_oracle() {
        let r = compute_cpd(&binary(-2.0, vec![])).unwrap();
        assert_eq!(r.status, CpdStatus::Stable);
        assert_eq!(r.dimension, Some(1));
        assert_points(&coords(&r), &[vec![-2.0, 0.0], vec![0.0, -2.0]], 1e-12);
        assert!(r.diagnostics.max_target_residual_ev_per_atom.unwrap() <= 1e-8);
        assert!(r.diagnostics.max_inequality_violation_ev_per_atom.unwrap() <= 1e-8);
    }

    #[test]
    fn unary_reference_target_is_a_zero_dimensional_point() {
        let input = CpdInput {
            elements: vec!["Li".into()],
            target_phase_id: "li-metal".into(),
            model: model(),
            pressure_gpa: 0.0,
            phases: vec![phase("li-metal", &[1], -1.25)],
            elemental_references: vec![CpdElementReference {
                element: "Li".into(),
                phase_id: "li-metal".into(),
            }],
        };
        let result = compute_cpd(&input).unwrap();
        assert_eq!(result.status, CpdStatus::Stable);
        assert_eq!(result.dimension, Some(0));
        assert_points(&coords(&result), &[vec![0.0]], 1e-12);
        assert_eq!(result.target_formation_energy_ev, 0.0);
    }
    #[test]
    fn binary_ab_plus_a2b_clips_line() {
        let r = compute_cpd(&binary(-2.0, vec![phase("li2f", &[2, 1], -3.0)])).unwrap();
        assert_points(&coords(&r), &[vec![-2.0, 0.0], vec![-1.0, -1.0]], 1e-12);
        assert!(r.facets.iter().any(|f| f.constraint_id == "phase:li2f"));
    }
    #[test]
    fn ternary_abc_hand_oracle() {
        let input = CpdInput {
            elements: vec!["Li".into(), "F".into(), "Na".into()],
            target_phase_id: "target".into(),
            model: model(),
            pressure_gpa: 0.0,
            phases: vec![
                phase("li-ref", &[1, 0, 0], 0.0),
                phase("f-ref", &[0, 1, 0], 0.0),
                phase("na-ref", &[0, 0, 1], 0.0),
                phase("target", &[1, 1, 1], -3.0),
            ],
            elemental_references: vec![
                CpdElementReference {
                    element: "Li".into(),
                    phase_id: "li-ref".into(),
                },
                CpdElementReference {
                    element: "F".into(),
                    phase_id: "f-ref".into(),
                },
                CpdElementReference {
                    element: "Na".into(),
                    phase_id: "na-ref".into(),
                },
            ],
        };
        let r = compute_cpd(&input).unwrap();
        assert_eq!(r.dimension, Some(2));
        assert_points(
            &coords(&r),
            &[
                vec![-3.0, 0.0, 0.0],
                vec![0.0, -3.0, 0.0],
                vec![0.0, 0.0, -3.0],
            ],
            1e-12,
        );
        assert_eq!(r.facets.len(), 3);
    }
    #[test]
    fn positive_target_and_lower_same_formula_polymorph_are_unstable() {
        let positive = compute_cpd(&binary(0.2, vec![])).unwrap();
        assert_eq!(positive.status, CpdStatus::Unstable);
        assert!(positive.vertices.is_empty());
        let poly =
            compute_cpd(&binary(-2.0, vec![phase("lif-lower-poly", &[1, 1], -2.2)])).unwrap();
        assert_eq!(poly.status, CpdStatus::Unstable);
        assert!(poly.vertices.is_empty());
        assert!(poly
            .constraints
            .iter()
            .any(|c| c.constraint_id == "phase:lif-lower-poly"));
    }
    #[test]
    fn repeat_and_element_permutation_preserve_region() {
        let base = compute_cpd(&binary(-2.0, vec![phase("li2f", &[2, 1], -3.0)])).unwrap();
        let repeated = CpdInput {
            elements: vec!["Li".into(), "F".into()],
            target_phase_id: "target-r".into(),
            model: model(),
            pressure_gpa: 0.0,
            phases: vec![
                phase("li-r", &[10, 0], 0.0),
                phase("f-r", &[0, 10], 0.0),
                phase("target-r", &[10, 10], -20.0),
                phase("li2f-r", &[20, 10], -30.0),
            ],
            elemental_references: vec![
                CpdElementReference {
                    element: "Li".into(),
                    phase_id: "li-r".into(),
                },
                CpdElementReference {
                    element: "F".into(),
                    phase_id: "f-r".into(),
                },
            ],
        };
        let repeated = compute_cpd(&repeated).unwrap();
        assert_eq!(coords(&base), coords(&repeated));
        let permuted = CpdInput {
            elements: vec!["F".into(), "Li".into()],
            target_phase_id: "target-lif".into(),
            model: model(),
            pressure_gpa: 0.0,
            phases: vec![
                phase("li-ref", &[0, 1], 0.0),
                phase("f-ref", &[1, 0], 0.0),
                phase("target-lif", &[1, 1], -2.0),
                phase("li2f", &[1, 2], -3.0),
            ],
            elemental_references: vec![
                CpdElementReference {
                    element: "F".into(),
                    phase_id: "f-ref".into(),
                },
                CpdElementReference {
                    element: "Li".into(),
                    phase_id: "li-ref".into(),
                },
            ],
        };
        let permuted = compute_cpd(&permuted).unwrap();
        let mapped = permuted
            .vertices
            .iter()
            .map(|v| vec![v.delta_mu_ev_per_atom[1], v.delta_mu_ev_per_atom[0]])
            .collect::<Vec<_>>();
        assert_points(&coords(&base), &mapped, 1e-12);
    }
    #[test]
    fn coincident_polymorphs_keep_both_active_ids() {
        let r = compute_cpd(&binary(
            -2.0,
            vec![
                phase("lif-poly-a", &[1, 1], -2.0),
                phase("lif-poly-b", &[2, 2], -4.0),
            ],
        ))
        .unwrap();
        assert!(r.vertices.iter().all(|v| v
            .active_constraint_ids
            .contains(&"phase:lif-poly-a".to_string())
            && v.active_constraint_ids
                .contains(&"phase:lif-poly-b".to_string())));
    }

    #[test]
    fn degenerate_region_collapses_to_a_point_and_keeps_active_phases() {
        let r = compute_cpd(&binary(
            -2.0,
            vec![phase("li2f", &[2, 1], -3.0), phase("lif2", &[1, 2], -3.0)],
        ))
        .unwrap();
        assert_eq!(r.status, CpdStatus::Stable);
        assert_eq!(r.dimension, Some(0));
        assert_points(&coords(&r), &[vec![-1.0, -1.0]], 1e-12);
        assert!(r.vertices[0]
            .active_constraint_ids
            .contains(&"phase:li2f".to_string()));
        assert!(r.vertices[0]
            .active_constraint_ids
            .contains(&"phase:lif2".to_string()));
    }

    #[test]
    fn nearly_parallel_constraint_is_reported_and_phase_order_is_invariant() {
        let base = binary(-2.0, vec![phase("li2f", &[2, 1], -3.0)]);
        let mut reordered = base.clone();
        reordered.phases.reverse();
        let reordered_result = compute_cpd(&reordered).unwrap();
        let base_result = compute_cpd(&base).unwrap();
        assert_eq!(coords(&base_result), coords(&reordered_result));

        let a = u32::MAX - 1;
        let b = u32::MAX;
        let near = phase("almost-lif", &[a, b], -f64::from(a) - f64::from(b));
        let near_result = compute_cpd(&binary(-2.0, vec![near])).unwrap();
        assert!(near_result.diagnostics.near_singular_intersections > 0);
        assert_eq!(near_result.status, CpdStatus::Stable);
        assert!(
            near_result
                .diagnostics
                .max_target_residual_ev_per_atom
                .unwrap()
                <= 1e-8
        );
    }

    #[test]
    fn provenance_is_exported_and_nonzero_pressure_is_rejected() {
        let r = compute_cpd(&binary(-2.0, vec![phase("li2f", &[2, 1], -3.0)])).unwrap();
        assert_eq!(r.pressure_gpa, 0.0);
        assert_eq!(r.energy_convention, "total_energy_eV_at_zero_pressure");
        assert_eq!(r.target_atom_counts, vec![1, 1]);
        assert_eq!(r.target_total_energy_ev, -2.0);
        assert_eq!(r.target_formation_energy_ev, -2.0);
        assert_eq!(r.elemental_reference_phase_ids, vec!["li-ref", "f-ref"]);
        assert_eq!(r.input_phase_energies.len(), 4);
        let compound = r
            .constraints
            .iter()
            .find(|c| c.constraint_id == "phase:li2f")
            .unwrap();
        assert_eq!(compound.original_atom_counts, vec![2, 1]);
        assert_eq!(compound.original_phase_total_energy_ev, Some(-3.0));
        assert_eq!(compound.original_formation_energy_ev, Some(-3.0));

        let mut nonzero = binary(-2.0, vec![]);
        nonzero.pressure_gpa = 1.0;
        assert!(compute_cpd(&nonzero).unwrap_err().contains("zero pressure"));
        let mut nan_pressure = binary(-2.0, vec![]);
        nan_pressure.pressure_gpa = f64::NAN;
        assert!(compute_cpd(&nan_pressure)
            .unwrap_err()
            .contains("pressure must be finite"));
    }

    #[test]
    fn absent_pressure_field_defaults_to_zero_and_lower_unary_reference_rejects() {
        let mut value = serde_json::to_value(binary(-2.0, vec![])).unwrap();
        value.as_object_mut().unwrap().remove("pressure_gpa");
        let decoded: CpdInput = serde_json::from_value(value).unwrap();
        assert_eq!(decoded.pressure_gpa, 0.0);
        assert_eq!(compute_cpd(&decoded).unwrap().status, CpdStatus::Stable);

        let input = binary(-2.0, vec![phase("lower-li", &[2, 0], -0.2)]);
        assert!(compute_cpd(&input)
            .unwrap_err()
            .contains("Reference for Li is above unary phase lower-li"));
    }

    #[test]
    fn rejects_nonfinite_normalized_formation_energy() {
        let mut input = binary(-2.0, vec![]);
        input.phases[0].total_energy_ev = f64::MAX;
        input.phases[2].atom_counts = vec![3, 1];
        input.phases[2].total_energy_ev = f64::MAX;
        assert!(compute_cpd(&input)
            .unwrap_err()
            .contains("not finite after normalization"));
    }

    #[test]
    fn missing_nan_unit_and_model_mismatch_reject() {
        let mut x = binary(-2.0, vec![]);
        x.elemental_references.pop();
        assert!(compute_cpd(&x).unwrap_err().contains("Exactly one"));
        let mut x = binary(-2.0, vec![]);
        x.phases[2].total_energy_ev = f64::NAN;
        assert!(compute_cpd(&x).unwrap_err().contains("finite"));
        let mut x = binary(-2.0, vec![]);
        x.phases[2].energy_unit = "eV/atom".into();
        assert!(compute_cpd(&x).unwrap_err().contains("expressed in eV"));
        let mut x = binary(-2.0, vec![]);
        x.phases[2].model.model_id = "other".into();
        assert!(compute_cpd(&x)
            .unwrap_err()
            .contains("different energy model"));
    }
}
