//! Bounded JSON interface shared by native and WASM callers.

use crate::{compute_cpd_with_stabilization, CpdInput, CpdResult, MAX_ELEMENTS};
use serde::Serialize;

pub const MAX_INPUT_JSON_BYTES: usize = 4 * 1024 * 1024;
pub const MAX_PHASE_COUNT: usize = 4096;
pub const MAX_ESTIMATED_SCALAR_OPERATIONS: u128 = 10_000_000;

#[derive(Serialize)]
struct Units {
    total_energy: &'static str,
    formation_energy: &'static str,
    energy_per_atom: &'static str,
    chemical_potential: &'static str,
    pressure: &'static str,
}

#[derive(Serialize)]
struct CpdApiResponse {
    schema: &'static str,
    schema_version: u32,
    units: Units,
    result: CpdResult,
}

/// Parses, bounds and computes a CPD request. This exact JSON boundary is used
/// by both native integrations and the browser WASM export.
pub fn compute_cpd_json(input_json: &str) -> Result<String, String> {
    if input_json.len() > MAX_INPUT_JSON_BYTES {
        return Err(format!(
            "CPD JSON input exceeds the {} byte limit.",
            MAX_INPUT_JSON_BYTES
        ));
    }
    let input: CpdInput = serde_json::from_str(input_json)
        .map_err(|error| format!("Invalid CPD JSON input: {error}"))?;
    if input.phases.len() > MAX_PHASE_COUNT {
        return Err(format!(
            "CPD phase count {} exceeds the {} phase limit.",
            input.phases.len(),
            MAX_PHASE_COUNT
        ));
    }
    if !(1..=MAX_ELEMENTS).contains(&input.elements.len()) {
        return Err(format!("CPD supports one to {MAX_ELEMENTS} elements."));
    }
    let work = estimate_scalar_operations(input.elements.len(), input.phases.len())
        .ok_or_else(|| "CPD operation estimate overflowed.".to_string())?;
    if work > MAX_ESTIMATED_SCALAR_OPERATIONS {
        return Err(format!(
            "CPD request exceeds the estimated {} scalar-operation budget (estimate {work}).",
            MAX_ESTIMATED_SCALAR_OPERATIONS
        ));
    }
    let result = compute_cpd_with_stabilization(&input)?;
    let response = CpdApiResponse {
        schema: "macer-cpd-api-response-v1",
        schema_version: 1,
        units: Units {
            total_energy: "eV",
            formation_energy: "eV",
            energy_per_atom: "eV/atom",
            chemical_potential: "eV/atom",
            pressure: "GPa",
        },
        result,
    };
    serde_json::to_string(&response)
        .map_err(|error| format!("Could not serialize CPD result: {error}"))
}

/// Conservative preflight for the current vertex-enumeration solver. It uses
/// all input phases as possible constraints, so work cannot be undercounted.
fn estimate_scalar_operations(element_count: usize, phase_count: usize) -> Option<u128> {
    if !(1..=MAX_ELEMENTS).contains(&element_count) {
        return Some(u128::MAX);
    }
    let constraints = (element_count as u128).checked_add(phase_count as u128)?;
    let mut intersections = 1_u128;
    for i in 1..element_count as u128 {
        intersections = intersections
            .checked_mul(constraints.checked_sub(i - 1)?)?
            .checked_div(i)?;
    }
    intersections
        .checked_mul(constraints)?
        .checked_mul(element_count as u128)
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    fn input_json() -> String {
        let identity = json!({
            "model_id":"synthetic-api-fixture",
            "weights_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"
        });
        json!({
            "elements":["Li","F"],
            "target_phase_id":"target",
            "model":identity,
            "pressure_gpa":0.0,
            "phases":[
                {"phase_id":"li-ref","atom_counts":[1,0],"total_energy_ev":0.0,"energy_unit":"eV","model":identity},
                {"phase_id":"f-ref","atom_counts":[0,1],"total_energy_ev":0.0,"energy_unit":"eV","model":identity},
                {"phase_id":"target","atom_counts":[1,1],"total_energy_ev":-2.0,"energy_unit":"eV","model":identity}
            ],
            "elemental_references":[{"element":"Li","phase_id":"li-ref"},{"element":"F","phase_id":"f-ref"}]
        }).to_string()
    }

    #[test]
    fn hull_mixture_and_cell_scaling_have_identical_reservoirs() {
        let mut input: serde_json::Value = serde_json::from_str(&input_json()).unwrap();
        input["phases"][2]["total_energy_ev"] = json!(2.0);
        let solve = |value: &serde_json::Value| -> serde_json::Value {
            serde_json::from_str(&compute_cpd_json(&value.to_string()).unwrap()).unwrap()
        };
        let original = solve(&input);
        assert!((original["result"]["stabilization"]["above_hull_ev_per_atom"].as_f64().unwrap()-1.0).abs()<1e-12);
        assert_eq!(original["result"]["stabilization"]["decomposition"].as_array().unwrap().len(), 2);
        input["phases"][2]["total_energy_ev"] = json!(8.0);
        input["phases"][2]["atom_counts"] = json!([4,4]);
        let repeated = solve(&input);
        assert_eq!(original["result"]["vertices"], repeated["result"]["vertices"]);
    }

    #[test]
    fn above_hull_correction_preserves_raw_energy_and_certifies_vertices() {
        let mut input: serde_json::Value = serde_json::from_str(&input_json()).unwrap();
        let mut lower = input["phases"][2].clone();
        lower["phase_id"] = json!("lower-polymorph");
        lower["total_energy_ev"] = json!(-2.2);
        input["phases"].as_array_mut().unwrap().push(lower);
        let response: serde_json::Value = serde_json::from_str(&compute_cpd_json(&input.to_string()).unwrap()).unwrap();
        let result = &response["result"];
        let shift = &result["stabilization"];
        assert!((shift["above_hull_ev_per_atom"].as_f64().unwrap() - 0.1).abs() < 1e-12);
        assert!((shift["signed_change_ev_per_atom"].as_f64().unwrap() + 0.10001).abs() < 1e-12);
        assert_eq!(shift["original_status"], "unstable");
        assert_eq!(result["input_phase_energies"][2]["total_energy_ev"], -2.0);
        assert!(!result["vertices"].as_array().unwrap().is_empty());
        for vertex in result["vertices"].as_array().unwrap() {
            assert!(vertex["target_residual_ev_per_atom"].as_f64().unwrap() < 1e-10);
            assert!(vertex["max_inequality_violation_ev_per_atom"].as_f64().unwrap() < 1e-10);
        }
    }

    #[test]
    fn json_api_returns_result_and_explicit_unit_metadata() {
        let result: serde_json::Value =
            serde_json::from_str(&compute_cpd_json(&input_json()).unwrap()).unwrap();
        assert_eq!(result["schema"], "macer-cpd-api-response-v1");
        assert_eq!(result["units"]["total_energy"], "eV");
        assert_eq!(result["units"]["energy_per_atom"], "eV/atom");
        assert_eq!(result["units"]["chemical_potential"], "eV/atom");
        assert_eq!(result["units"]["pressure"], "GPa");
        assert_eq!(result["result"]["vertices"].as_array().unwrap().len(), 2);
    }

    #[test]
    fn json_api_rejects_invalid_and_over_budget_before_solve() {
        assert!(compute_cpd_json("{")
            .unwrap_err()
            .contains("Invalid CPD JSON"));
        assert!(compute_cpd_json(&" ".repeat(MAX_INPUT_JSON_BYTES + 1))
            .unwrap_err()
            .contains("byte limit"));
        assert!(estimate_scalar_operations(3, 1000).unwrap() > MAX_ESTIMATED_SCALAR_OPERATIONS);
        assert!(estimate_scalar_operations(3, 100).unwrap() <= MAX_ESTIMATED_SCALAR_OPERATIONS);
        assert_eq!(estimate_scalar_operations(0, 1), Some(u128::MAX));
    }
}
