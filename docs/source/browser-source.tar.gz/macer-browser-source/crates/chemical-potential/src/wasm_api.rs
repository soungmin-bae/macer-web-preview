use wasm_bindgen::prelude::*;

/// JSON-in/JSON-out function for the dedicated browser Worker.
#[wasm_bindgen]
pub fn compute_cpd_json(input_json: &str) -> Result<String, JsValue> {
    crate::api::compute_cpd_json(input_json).map_err(|message| JsValue::from_str(&message))
}
