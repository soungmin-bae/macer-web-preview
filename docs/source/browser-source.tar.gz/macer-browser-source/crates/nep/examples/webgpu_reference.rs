//! Independent native f64 E/F/stress/virial reference at supplied GPU geometries.
use macer_rust_core::Structure;
use macer_rust_nep::{nep89::Nep4ZblModel, nep89_evaluator};
use std::{env, fs};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = env::args().skip(1).collect();
    if args.len() != 3 {
        return Err("usage: webgpu_reference MODEL INPUT-ROWS.json OUTPUT.json".into());
    }
    let model = Nep4ZblModel::from_bytes(&fs::read(&args[0])?)?;
    let input: Vec<serde_json::Value> = serde_json::from_slice(&fs::read(&args[1])?)?;
    let mut rows = Vec::new();
    for row in input {
        let structure: Structure = serde_json::from_value(row["structure"].clone())?;
        let evaluated = nep89_evaluator::evaluate(&model, &structure)?;
        rows.push(serde_json::json!({"name":row["name"],"structure":structure,"evaluation":{
            "energy_ev":evaluated.total_energy_ev(),"forces_ev_per_a":evaluated.forces_ev_per_a,
            "stress_ev_per_a3":evaluated.stress_ev_per_a3.unwrap_or([[0.;3];3]),
            "energies_ev":evaluated.atomic_energies_ev,"per_atom_virial_ev":evaluated.per_atom_virial_ev,
        }}));
    }
    fs::write(
        &args[2],
        serde_json::to_vec_pretty(
            &serde_json::json!({"model_sha256":model.source_sha256,"rows":rows}),
        )?,
    )?;
    Ok(())
}
