//! Type-specific single-hidden-layer NEP4 energy network.

use crate::nep89::Nep4ZblModel;

#[derive(Clone, Debug, PartialEq)]
pub struct NepNetworkOutput {
    /// Per-atom site energies in eV, preserving input atom order.
    pub atomic_energies_ev: Vec<f64>,
    /// Derivative of each site's energy with respect to scaled descriptors.
    pub d_energy_d_descriptor: Vec<Vec<f64>>,
}

impl NepNetworkOutput {
    pub fn total_energy_ev(&self) -> f64 {
        self.atomic_energies_ev.iter().sum()
    }
}

/// Evaluate the NEP4 type-specific network on already-computed, q-scaled
/// descriptor rows. This stage has no structure or filesystem dependencies.
pub fn evaluate_network(
    model: &Nep4ZblModel,
    atomic_numbers: &[u8],
    descriptors: &[Vec<f64>],
) -> Result<NepNetworkOutput, String> {
    let config = &model.config;
    if config.model_type != 0 {
        return Err("NEP network supports only scalar potential model type 0".into());
    }
    if atomic_numbers.len() != descriptors.len() {
        return Err("NEP atom and descriptor counts do not match".into());
    }
    let descriptor_count = config.descriptor_count()?;
    if descriptors
        .iter()
        .any(|row| row.len() != descriptor_count || row.iter().any(|value| !value.is_finite()))
    {
        return Err("NEP descriptor row has an invalid dimension or value".into());
    }
    let neural_count = config.neural_parameter_count()?;
    if model.parameters.len() < neural_count {
        return Err("NEP model is missing neural-network parameters".into());
    }
    let hidden = config.hidden_neurons;
    let per_type = descriptor_count
        .checked_add(2)
        .and_then(|width| width.checked_mul(hidden))
        .ok_or_else(|| "NEP network parameter dimension overflow".to_owned())?;
    let type_count = config.element_symbols.len();
    let bias_index = per_type
        .checked_mul(type_count)
        .ok_or_else(|| "NEP network bias offset overflow".to_owned())?;
    let output_bias = *model
        .parameters
        .get(bias_index)
        .ok_or_else(|| "NEP model is missing the network output bias".to_owned())?;
    let mut atomic_energies_ev = Vec::with_capacity(atomic_numbers.len());
    let mut d_energy_d_descriptor = Vec::with_capacity(atomic_numbers.len());

    for (atom, (&atomic_number, descriptor)) in atomic_numbers.iter().zip(descriptors).enumerate() {
        let type_index = config
            .type_index_for_atomic_number(atomic_number)
            .ok_or_else(|| {
                format!("NEP model does not support atomic number {atomic_number} at atom {atom}")
            })?;
        let type_offset = type_index
            .checked_mul(per_type)
            .ok_or_else(|| "NEP type parameter offset overflow".to_owned())?;
        let weights_offset = type_offset;
        let hidden_bias_offset = weights_offset + hidden * descriptor_count;
        let output_weights_offset = hidden_bias_offset + hidden;
        let mut energy = -output_bias;
        let mut gradient = vec![0.0; descriptor_count];

        for neuron in 0..hidden {
            let weights_start = weights_offset + neuron * descriptor_count;
            let weights_end = weights_start + descriptor_count;
            let weights = model
                .parameters
                .get(weights_start..weights_end)
                .ok_or_else(|| "NEP model has a truncated input-weight block".to_owned())?;
            let bias = *model
                .parameters
                .get(hidden_bias_offset + neuron)
                .ok_or_else(|| "NEP model has a truncated hidden-bias block".to_owned())?;
            let output_weight = *model
                .parameters
                .get(output_weights_offset + neuron)
                .ok_or_else(|| "NEP model has a truncated output-weight block".to_owned())?;
            let activation = (weights
                .iter()
                .zip(descriptor)
                .map(|(weight, value)| weight * value)
                .sum::<f64>()
                - bias)
                .tanh();
            let activation_derivative = 1.0 - activation * activation;
            energy += output_weight * activation;
            let derivative_scale = output_weight * activation_derivative;
            for (component, weight) in weights.iter().enumerate() {
                gradient[component] += derivative_scale * weight;
            }
        }
        if !energy.is_finite() || gradient.iter().any(|value| !value.is_finite()) {
            return Err(format!(
                "NEP network produced a non-finite result at atom {atom}"
            ));
        }
        atomic_energies_ev.push(energy);
        d_energy_d_descriptor.push(gradient);
    }

    Ok(NepNetworkOutput {
        atomic_energies_ev,
        d_energy_d_descriptor,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::nep89_descriptors::{angular_descriptors, radial_descriptors};
    use crate::nep89_neighbors::NepNeighborGraph;
    use macer_rust_core::Structure;

    #[test]
    fn official_nep89_si8_network_energy_matches_pinned_cpu_reference_when_supplied() {
        let Some(model_path) = std::env::var_os("MACER_NEP89_MODEL") else {
            eprintln!("skipping NEP_CPU network comparison: model env is unset");
            return;
        };
        let model = Nep4ZblModel::from_bytes(&std::fs::read(model_path).unwrap()).unwrap();
        let reference: serde_json::Value = serde_json::from_str(include_str!(
            "../../../evidence/nep89_reference_2026-10-25/oracle-results.json"
        ))
        .unwrap();
        let structure = Structure {
            atomic_numbers: vec![14; 8],
            positions_a: vec![
                [0.0, 0.0, 0.0],
                [0.0, 2.715, 2.715],
                [2.715, 0.0, 2.715],
                [2.715, 2.715, 0.0],
                [1.3575, 1.3575, 1.3575],
                [1.3575, 4.0725, 4.0725],
                [4.0725, 1.3575, 4.0725],
                [4.0725, 4.0725, 1.3575],
            ],
            cell_a: [[5.43, 0.0, 0.0], [0.0, 5.43, 0.0], [0.0, 0.0, 5.43]],
            pbc: [true; 3],
        };
        let graph = NepNeighborGraph::for_structure(&structure, model.config.cutoff_a[0]).unwrap();
        let mut descriptors = radial_descriptors(&model, &structure, &graph).unwrap();
        let angular = angular_descriptors(&model, &structure, &graph).unwrap();
        for (row, angular_row) in descriptors.iter_mut().zip(angular) {
            row.extend(angular_row);
        }
        let output = evaluate_network(&model, &structure.atomic_numbers, &descriptors).unwrap();
        let expected = reference["reference_output"]["energy_ev"].as_f64().unwrap();
        let delta = (output.total_energy_ev() - expected).abs();
        println!(
            "NEP89 Si8 type-specific ANN total_energy_ev={:.17e} reference={expected:.17e} abs_delta={delta:.17e}",
            output.total_energy_ev()
        );
        assert!(delta <= 1.0e-10, "NEP ANN energy mismatch: {delta}");
        assert_eq!(
            output.atomic_energies_ev.len(),
            structure.atomic_numbers.len()
        );
        assert!(output
            .d_energy_d_descriptor
            .iter()
            .all(|row| row.len() == model.config.descriptor_count().unwrap()));
    }
}
