//! Universal ZBL pair energy and radial derivative for NEP4-ZBL.

use crate::nep89::Nep4ZblModel;

const COEFFICIENTS: [(f64, f64); 4] = [
    (0.18175, 3.1998),
    (0.50986, 0.94229),
    (0.28022, 0.4029),
    (0.02817, 0.20162),
];
const COULOMB_EV_ANGSTROM: f64 = 14.399645;
const ZBL_SCREENING_FACTOR_PER_ANGSTROM: f64 = 2.134563;

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct NepZblPairEvaluation {
    pub energy_ev: f64,
    /// dE/dr in eV/angstrom.
    pub d_energy_d_distance_ev_per_a: f64,
}

pub fn evaluate_zbl_pair(
    model: &Nep4ZblModel,
    atomic_number_a: u8,
    atomic_number_b: u8,
    distance_a: f64,
) -> Result<NepZblPairEvaluation, String> {
    if !distance_a.is_finite() || distance_a <= 0.0 {
        return Err("ZBL pair distance must be finite and positive".into());
    }
    let [inner_cutoff_a, outer_cutoff_a] = model.config.zbl_transition_a;
    if distance_a >= outer_cutoff_a {
        return Ok(NepZblPairEvaluation {
            energy_ev: 0.0,
            d_energy_d_distance_ev_per_a: 0.0,
        });
    }
    if atomic_number_a == 0 || atomic_number_b == 0 {
        return Err("ZBL atomic numbers must be positive".into());
    }

    let z_a = f64::from(atomic_number_a);
    let z_b = f64::from(atomic_number_b);
    let screening_inverse_a = ZBL_SCREENING_FACTOR_PER_ANGSTROM * (z_a.powf(0.23) + z_b.powf(0.23));
    let mut screened_potential = 0.0;
    let mut screened_derivative = 0.0;
    for (amplitude, exponent) in COEFFICIENTS {
        let term = amplitude * (-exponent * screening_inverse_a * distance_a).exp();
        screened_potential += term;
        screened_derivative -= exponent * screening_inverse_a * term;
    }

    let (cutoff, cutoff_derivative) = if distance_a < inner_cutoff_a {
        (1.0, 0.0)
    } else {
        let width = outer_cutoff_a - inner_cutoff_a;
        if width <= 0.0 {
            return Err("ZBL outer cutoff must be greater than its inner cutoff".into());
        }
        let phase = std::f64::consts::PI * (distance_a - inner_cutoff_a) / width;
        (
            0.5 * (1.0 + phase.cos()),
            -0.5 * phase.sin() * std::f64::consts::PI / width,
        )
    };
    let prefactor = COULOMB_EV_ANGSTROM * z_a * z_b;
    let inverse_distance = 1.0 / distance_a;
    let energy = prefactor * screened_potential * inverse_distance * cutoff;
    let derivative = prefactor
        * ((screened_derivative * inverse_distance
            - screened_potential * inverse_distance * inverse_distance)
            * cutoff
            + screened_potential * inverse_distance * cutoff_derivative);
    if !energy.is_finite() || !derivative.is_finite() {
        return Err("ZBL pair evaluation produced a non-finite result".into());
    }
    Ok(NepZblPairEvaluation {
        energy_ev: energy,
        d_energy_d_distance_ev_per_a: derivative,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn zbl_radial_derivative_matches_finite_difference_across_switch_region() {
        let Some(model_path) = std::env::var_os("MACER_NEP89_MODEL") else {
            eprintln!("skipping NEP89 ZBL derivative comparison: model env is unset");
            return;
        };
        let model = Nep4ZblModel::from_bytes(&std::fs::read(model_path).unwrap()).unwrap();
        // The inner cutoff is C1 but not C2. Keep the central-difference
        // derivative check in smooth regions and exercise exact cutoffs below.
        let mut maximum_smooth_region_delta = 0.0f64;
        for distance in [0.7, 1.25, 1.75, 1.95] {
            let actual = evaluate_zbl_pair(&model, 14, 14, distance).unwrap();
            let step = 1.0e-6;
            let before = evaluate_zbl_pair(&model, 14, 14, distance - step)
                .unwrap()
                .energy_ev;
            let after = evaluate_zbl_pair(&model, 14, 14, distance + step)
                .unwrap()
                .energy_ev;
            let finite_difference = (after - before) / (2.0 * step);
            let delta = (actual.d_energy_d_distance_ev_per_a - finite_difference).abs();
            maximum_smooth_region_delta = maximum_smooth_region_delta.max(delta);
            assert!(
                delta < 2.0e-5,
                "ZBL derivative differs at r={distance}: analytic {}, finite difference {finite_difference}",
                actual.d_energy_d_distance_ev_per_a
            );
        }
        let inner = evaluate_zbl_pair(&model, 14, 14, model.config.zbl_transition_a[0]).unwrap();
        assert!(inner.energy_ev.is_finite());
        assert!(inner.d_energy_d_distance_ev_per_a.is_finite());
        let outer = evaluate_zbl_pair(&model, 14, 14, model.config.zbl_transition_a[1]).unwrap();
        assert_eq!(outer.energy_ev, 0.0);
        assert_eq!(outer.d_energy_d_distance_ev_per_a, 0.0);
        println!(
            "NEP89 ZBL smooth-region derivative max_abs_delta={maximum_smooth_region_delta:.17e} eV/A"
        );
    }

    #[test]
    fn zbl_inner_switch_derivative_matches_one_sided_finite_differences_when_model_is_supplied() {
        let Some(model_path) = std::env::var_os("MACER_NEP89_MODEL") else {
            eprintln!("skipping NEP_CPU ZBL switch derivative check: model env is unset");
            return;
        };
        let model = Nep4ZblModel::from_bytes(&std::fs::read(model_path).unwrap()).unwrap();
        let boundary = model.config.zbl_transition_a[0];
        let at_boundary = evaluate_zbl_pair(&model, 14, 14, boundary).unwrap();
        let mut boundary_results = Vec::new();
        for step in [1.0e-6, 1.0e-7, 1.0e-8] {
            let left = evaluate_zbl_pair(&model, 14, 14, boundary - step)
                .unwrap()
                .energy_ev;
            let right = evaluate_zbl_pair(&model, 14, 14, boundary + step)
                .unwrap()
                .energy_ev;
            let left_derivative = (at_boundary.energy_ev - left) / step;
            let right_derivative = (right - at_boundary.energy_ev) / step;
            boundary_results.push((
                step,
                (at_boundary.d_energy_d_distance_ev_per_a - left_derivative).abs(),
                (at_boundary.d_energy_d_distance_ev_per_a - right_derivative).abs(),
            ));
        }
        for (step, left_delta, right_delta) in &boundary_results {
            println!(
                "NEP89 ZBL inner-switch one-sided h={step:.1e} left_delta={left_delta:.17e} right_delta={right_delta:.17e} eV/A"
            );
        }
        let (_, left_delta, right_delta) = boundary_results.last().unwrap();
        assert!(*left_delta < 2.0e-5 && *right_delta < 2.0e-5);
    }
}
