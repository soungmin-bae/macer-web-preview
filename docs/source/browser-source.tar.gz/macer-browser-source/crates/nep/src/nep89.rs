//! Strict parser for the GPUMD `nep4_zbl` text potential format.
//!
//! This module parses caller-supplied bytes only. It does not read files,
//! fetch checkpoints, or embed the NEP89 weights in the application.

use sha2::{Digest, Sha256};

pub const NEP89_REFERENCE_SHA256: &str =
    "75168ece02e840e4a32644f982b78d43cba697f5b64b4c8134ab66c7a8c28be1";
pub const NEP89_REFERENCE_BYTES: usize = 15_622_195;
const MAX_MODEL_BYTES: usize = 256 * 1024 * 1024;
const MAX_MODEL_PARAMETERS: usize = 20_000_000;

const ELEMENT_SYMBOLS: [&str; 118] = [
    "H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne", "Na", "Mg", "Al", "Si", "P", "S", "Cl",
    "Ar", "K", "Ca", "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn", "Ga", "Ge", "As",
    "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr", "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In",
    "Sn", "Sb", "Te", "I", "Xe", "Cs", "Ba", "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb",
    "Dy", "Ho", "Er", "Tm", "Yb", "Lu", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg", "Tl",
    "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th", "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk",
    "Cf", "Es", "Fm", "Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs", "Mt", "Ds", "Rg", "Cn", "Nh",
    "Fl", "Mc", "Lv", "Ts", "Og",
];

#[derive(Clone, Debug, PartialEq)]
pub struct Nep4ZblConfig {
    pub element_symbols: Vec<String>,
    pub atomic_numbers: Vec<u8>,
    pub zbl_transition_a: [f64; 2],
    pub cutoff_a: [f64; 2],
    pub cutoff_bins: [usize; 2],
    pub n_max: [usize; 2],
    pub basis_size: [usize; 2],
    pub l_max: [usize; 3],
    pub hidden_neurons: usize,
    pub model_type: usize,
}

impl Nep4ZblConfig {
    /// Resolve a chemical atomic number to the exact `type` index from the
    /// model header. Unsupported elements return `None`.
    pub fn type_index_for_atomic_number(&self, atomic_number: u8) -> Option<usize> {
        self.atomic_numbers
            .iter()
            .position(|candidate| *candidate == atomic_number)
    }

    /// Number of descriptor components for the GPUMD NEP4 header convention.
    pub fn descriptor_count(&self) -> Result<usize, String> {
        let radial = self.n_max[0]
            .checked_add(1)
            .ok_or_else(|| "radial descriptor dimension overflow".to_owned())?;
        let angular_radial = self.n_max[1]
            .checked_add(1)
            .ok_or_else(|| "angular descriptor dimension overflow".to_owned())?;
        let three_body = angular_radial
            .checked_mul(self.l_max[0])
            .ok_or_else(|| "three-body descriptor dimension overflow".to_owned())?;
        let four_and_five_body = angular_radial
            .checked_mul(usize::from(self.l_max[1] > 0) + usize::from(self.l_max[2] > 0))
            .ok_or_else(|| "four/five-body descriptor dimension overflow".to_owned())?;
        radial
            .checked_add(three_body)
            .and_then(|n| n.checked_add(four_and_five_body))
            .ok_or_else(|| "descriptor dimension overflow".to_owned())
    }

    pub fn descriptor_parameter_count(&self) -> Result<usize, String> {
        let types_squared = self
            .element_symbols
            .len()
            .checked_mul(self.element_symbols.len())
            .ok_or_else(|| "type pair count overflow".to_owned())?;
        let radial = self.n_max[0]
            .checked_add(1)
            .and_then(|n| n.checked_mul(self.basis_size[0].checked_add(1)?))
            .ok_or_else(|| "radial coefficient count overflow".to_owned())?;
        let angular = self.n_max[1]
            .checked_add(1)
            .and_then(|n| n.checked_mul(self.basis_size[1].checked_add(1)?))
            .ok_or_else(|| "angular coefficient count overflow".to_owned())?;
        types_squared
            .checked_mul(
                radial
                    .checked_add(angular)
                    .ok_or_else(|| "descriptor coefficient count overflow".to_owned())?,
            )
            .ok_or_else(|| "descriptor coefficient count overflow".to_owned())
    }

    pub fn neural_parameter_count(&self) -> Result<usize, String> {
        let per_type = self
            .descriptor_count()?
            .checked_add(2)
            .ok_or_else(|| "neural parameter count overflow".to_owned())?;
        per_type
            .checked_mul(self.hidden_neurons)
            .and_then(|n| n.checked_mul(self.element_symbols.len()))
            .and_then(|n| n.checked_add(1))
            .ok_or_else(|| "neural parameter count overflow".to_owned())
    }

    pub fn parameter_count(&self) -> Result<usize, String> {
        self.descriptor_parameter_count()?
            .checked_add(self.neural_parameter_count()?)
            .ok_or_else(|| "total parameter count overflow".to_owned())
    }

    /// GPUMD stores one additional value per descriptor beyond trainable
    /// network/descriptor coefficients. Keep those values in the original
    /// file-order vector until their evaluator-specific role is assigned.
    pub fn runtime_parameter_count(&self) -> Result<usize, String> {
        self.parameter_count()?
            .checked_add(self.descriptor_count()?)
            .ok_or_else(|| "runtime parameter count overflow".to_owned())
    }
}

/// Parsed NEP4-ZBL model parameters, retaining file order and f64 precision.
#[derive(Clone, Debug, PartialEq)]
pub struct Nep4ZblModel {
    pub config: Nep4ZblConfig,
    /// Neural-network and descriptor coefficients in GPUMD file order.
    pub parameters: Vec<f64>,
    /// One descriptor scaling value per descriptor, stored after coefficients.
    pub descriptor_scales: Vec<f64>,
    pub source_sha256: String,
    pub source_bytes: usize,
}

impl Nep4ZblModel {
    /// Parse supported GPUMD NEP4-ZBL bytes. Unknown variants fail closed.
    pub fn from_bytes(bytes: &[u8]) -> Result<Self, String> {
        if bytes.len() > MAX_MODEL_BYTES {
            return Err(format!(
                "model exceeds the {MAX_MODEL_BYTES}-byte parser limit"
            ));
        }
        let text = std::str::from_utf8(bytes).map_err(|e| format!("model is not UTF-8: {e}"))?;
        let mut lines = text.lines().enumerate().filter_map(|(line_no, raw)| {
            let content = raw.split('#').next().unwrap_or("").trim();
            (!content.is_empty()).then_some((line_no + 1, content))
        });

        let (line_no, header) = lines.next().ok_or("model is empty")?;
        let mut header = header.split_whitespace();
        let variant = header.next().unwrap_or_default();
        if variant != "nep4_zbl" {
            return Err(format!(
                "unsupported NEP model variant `{variant}` on line {line_no}; expected `nep4_zbl`"
            ));
        }
        let type_count = parse_usize(header.next(), "type count", line_no)?;
        if type_count == 0 || type_count > ELEMENT_SYMBOLS.len() {
            return Err(format!(
                "invalid element type count {type_count} on line {line_no}"
            ));
        }
        let mut symbols = Vec::with_capacity(type_count);
        let mut atomic_numbers = Vec::with_capacity(type_count);
        for index in 0..type_count {
            let symbol = header.next().ok_or_else(|| {
                format!("missing element symbol {index} in model header on line {line_no}")
            })?;
            let atomic_number = ELEMENT_SYMBOLS
                .iter()
                .position(|candidate| *candidate == symbol)
                .map(|value| value + 1)
                .ok_or_else(|| format!("unknown element symbol `{symbol}` on line {line_no}"))?;
            if symbols.iter().any(|existing| existing == symbol) {
                return Err(format!(
                    "duplicate element symbol `{symbol}` on line {line_no}"
                ));
            }
            symbols.push(symbol.to_owned());
            atomic_numbers.push(atomic_number as u8);
        }
        if header.next().is_some() {
            return Err(format!(
                "unexpected field in model header on line {line_no}"
            ));
        }

        let (
            zbl_transition_a,
            cutoff_a,
            cutoff_bins,
            n_max,
            basis_size,
            l_max,
            hidden_neurons,
            model_type,
        ) = {
            let (line, tokens) = next_header(&mut lines, "zbl")?;
            expect_keyword(&tokens, "zbl", 3, line)?;
            let zbl = [
                parse_f64(&tokens[1], "ZBL inner transition", line)?,
                parse_f64(&tokens[2], "ZBL outer transition", line)?,
            ];
            if zbl[0] < 0.0 || zbl[1] <= zbl[0] {
                return Err(format!("invalid ZBL transition radii on line {line}"));
            }

            let (line, tokens) = next_header(&mut lines, "cutoff")?;
            expect_keyword(&tokens, "cutoff", 5, line)?;
            let cutoffs = [
                parse_f64(&tokens[1], "radial cutoff", line)?,
                parse_f64(&tokens[2], "angular cutoff", line)?,
            ];
            let bins = [
                parse_usize(Some(&tokens[3]), "radial cutoff bins", line)?,
                parse_usize(Some(&tokens[4]), "angular cutoff bins", line)?,
            ];
            if cutoffs.iter().any(|value| *value <= 0.0) || bins.contains(&0) {
                return Err(format!("invalid cutoff values on line {line}"));
            }

            let (line, tokens) = next_header(&mut lines, "n_max")?;
            expect_keyword(&tokens, "n_max", 3, line)?;
            let n_max = [
                parse_usize(Some(&tokens[1]), "radial n_max", line)?,
                parse_usize(Some(&tokens[2]), "angular n_max", line)?,
            ];

            let (line, tokens) = next_header(&mut lines, "basis_size")?;
            expect_keyword(&tokens, "basis_size", 3, line)?;
            let basis = [
                parse_usize(Some(&tokens[1]), "radial basis size", line)?,
                parse_usize(Some(&tokens[2]), "angular basis size", line)?,
            ];

            let (line, tokens) = next_header(&mut lines, "l_max")?;
            expect_keyword(&tokens, "l_max", 4, line)?;
            let l_max = [
                parse_usize(Some(&tokens[1]), "three-body l_max", line)?,
                parse_usize(Some(&tokens[2]), "four-body flag", line)?,
                parse_usize(Some(&tokens[3]), "five-body flag", line)?,
            ];

            let (line, tokens) = next_header(&mut lines, "ANN")?;
            expect_keyword(&tokens, "ANN", 3, line)?;
            let hidden = parse_usize(Some(&tokens[1]), "hidden neuron count", line)?;
            let model_type = parse_usize(Some(&tokens[2]), "model type", line)?;
            if hidden == 0 {
                return Err(format!(
                    "hidden neuron count must be positive on line {line}"
                ));
            }
            if model_type != 0 {
                return Err(format!(
                    "unsupported temperature/model type {model_type} on line {line}"
                ));
            }
            (zbl, cutoffs, bins, n_max, basis, l_max, hidden, model_type)
        };

        let config = Nep4ZblConfig {
            element_symbols: symbols,
            atomic_numbers,
            zbl_transition_a,
            cutoff_a,
            cutoff_bins,
            n_max,
            basis_size,
            l_max,
            hidden_neurons,
            model_type,
        };
        let trainable_count = config.parameter_count()?;
        let expected = config.runtime_parameter_count()?;
        if expected > MAX_MODEL_PARAMETERS {
            return Err(format!(
                "model requires {expected} parameters, exceeding parser limit {MAX_MODEL_PARAMETERS}"
            ));
        }
        let mut parameters = Vec::with_capacity(expected);
        for (line_no, line) in lines {
            for token in line.split_whitespace() {
                let value = token.parse::<f64>().map_err(|_| {
                    format!("unexpected token `{token}` in model parameters on line {line_no}")
                })?;
                if !value.is_finite() {
                    return Err(format!("non-finite parameter on line {line_no}"));
                }
                parameters.push(value);
                if parameters.len() > expected {
                    return Err(format!(
                        "model has more than the expected {expected} parameters (extra value on line {line_no})"
                    ));
                }
            }
        }
        if parameters.len() != expected {
            return Err(format!(
                "model parameter count mismatch: expected {expected}, found {}",
                parameters.len()
            ));
        }

        let descriptor_scales = parameters.split_off(trainable_count);
        Ok(Self {
            config,
            parameters,
            descriptor_scales,
            source_sha256: hex::encode(Sha256::digest(bytes)),
            source_bytes: bytes.len(),
        })
    }

    /// Coefficients after the per-element neural-network blocks, in the
    /// radial-then-angular GPUMD file order.
    pub fn descriptor_coefficients(&self) -> Result<&[f64], String> {
        let offset = self.config.neural_parameter_count()?;
        self.parameters
            .get(offset..)
            .ok_or_else(|| "model is missing neural-network parameters".to_owned())
    }
}

fn next_header<'a>(
    lines: &mut impl Iterator<Item = (usize, &'a str)>,
    name: &str,
) -> Result<(usize, Vec<&'a str>), String> {
    let (line, content) = lines
        .next()
        .ok_or_else(|| format!("model ended before `{name}` header"))?;
    Ok((line, content.split_whitespace().collect()))
}

fn expect_keyword(
    tokens: &[&str],
    expected: &str,
    count: usize,
    line: usize,
) -> Result<(), String> {
    if tokens.len() != count || tokens.first().copied() != Some(expected) {
        return Err(format!(
            "invalid `{expected}` header on line {line}: expected {count} fields"
        ));
    }
    Ok(())
}

fn parse_usize(value: Option<&str>, field: &str, line: usize) -> Result<usize, String> {
    value
        .ok_or_else(|| format!("missing {field} on line {line}"))?
        .parse::<usize>()
        .map_err(|_| format!("invalid {field} on line {line}"))
}

fn parse_f64(value: &str, field: &str, line: usize) -> Result<f64, String> {
    let parsed = value
        .parse::<f64>()
        .map_err(|_| format!("invalid {field} on line {line}"))?;
    if !parsed.is_finite() {
        return Err(format!("non-finite {field} on line {line}"));
    }
    Ok(parsed)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn tiny_model(parameters: &str) -> String {
        format!(
            "nep4_zbl 2 H Si\nzbl 1 2\ncutoff 6 5 20 20\nn_max 0 0\nbasis_size 0 0\nl_max 0 0 0\nANN 1 0\n{parameters}"
        )
    }

    #[test]
    fn parses_configuration_and_element_order() {
        let parsed = Nep4ZblModel::from_bytes("nep4_zbl 2 H Si\nzbl 1 2\ncutoff 6 5 20 20\nn_max 0 0\nbasis_size 0 0\nl_max 0 0 0\nANN 1 0\n0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15".as_bytes()).unwrap();
        assert_eq!(parsed.config.element_symbols, ["H", "Si"]);
        assert_eq!(parsed.config.atomic_numbers, [1, 14]);
        assert_eq!(parsed.config.type_index_for_atomic_number(14), Some(1));
        assert_eq!(parsed.config.type_index_for_atomic_number(8), None);
        assert_eq!(parsed.config.descriptor_count().unwrap(), 1);
        assert_eq!(parsed.config.descriptor_parameter_count().unwrap(), 8);
        assert_eq!(parsed.config.neural_parameter_count().unwrap(), 7);
        assert_eq!(parsed.config.parameter_count().unwrap(), 15);
        assert_eq!(parsed.config.runtime_parameter_count().unwrap(), 16);
        assert_eq!(parsed.parameters.len(), 15);
        assert_eq!(parsed.descriptor_scales, [15.0]);
    }

    #[test]
    fn rejects_unknown_variant_bad_mapping_and_wrong_parameter_count() {
        let unknown = tiny_model("0 1 2 3 4 5 6 7").replace("nep4_zbl", "nep5");
        assert!(Nep4ZblModel::from_bytes(unknown.as_bytes())
            .unwrap_err()
            .contains("unsupported NEP model variant"));
        let duplicate = tiny_model("0 1 2 3 4 5 6 7").replace("H Si", "H H");
        assert!(Nep4ZblModel::from_bytes(duplicate.as_bytes())
            .unwrap_err()
            .contains("duplicate element"));
        assert!(Nep4ZblModel::from_bytes(tiny_model("0 1").as_bytes())
            .unwrap_err()
            .contains("parameter count mismatch"));
        assert!(Nep4ZblModel::from_bytes(
            tiny_model("0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16").as_bytes(),
        )
        .unwrap_err()
        .contains("more than the expected"));
    }

    #[test]
    fn rejects_non_finite_and_unsupported_model_type() {
        assert!(
            Nep4ZblModel::from_bytes(tiny_model("0 1 2 3 4 5 6 NaN").as_bytes())
                .unwrap_err()
                .contains("non-finite")
        );
        let temp = tiny_model("0 1 2 3 4 5 6 7").replace("ANN 1 0", "ANN 1 1");
        assert!(Nep4ZblModel::from_bytes(temp.as_bytes())
            .unwrap_err()
            .contains("unsupported temperature/model type"));
    }

    #[test]
    fn parses_hash_pinned_official_nep89_file_when_supplied() {
        let Some(path) = std::env::var_os("MACER_NEP89_MODEL") else {
            eprintln!("skipping official NEP89 parse: MACER_NEP89_MODEL is unset");
            return;
        };
        let bytes = std::fs::read(path).expect("read externally supplied official model");
        let model = Nep4ZblModel::from_bytes(&bytes).expect("parse official NEP89 model");
        assert_eq!(model.source_sha256, NEP89_REFERENCE_SHA256);
        assert_eq!(model.source_bytes, NEP89_REFERENCE_BYTES);
        assert_eq!(model.config.element_symbols.len(), 89);
        assert_eq!(model.config.atomic_numbers[13], 14);
        assert_eq!(model.config.zbl_transition_a, [1.0, 2.0]);
        assert_eq!(model.config.cutoff_a, [6.0, 5.0]);
        assert_eq!(model.config.cutoff_bins, [274, 158]);
        assert_eq!(model.config.n_max, [4, 4]);
        assert_eq!(model.config.basis_size, [8, 8]);
        assert_eq!(model.config.l_max, [4, 2, 1]);
        assert_eq!(model.config.hidden_neurons, 80);
        assert_eq!(model.config.descriptor_count().unwrap(), 35);
        assert_eq!(model.config.parameter_count().unwrap(), 976_331);
        assert_eq!(model.config.runtime_parameter_count().unwrap(), 976_366);
        assert_eq!(model.parameters.len(), 976_331);
        assert_eq!(model.descriptor_scales.len(), 35);
        println!(
            "official NEP89 parsed: bytes={} sha256={} types={} descriptors={} trainable_parameters={} descriptor_scales={} runtime_values={}",
            model.source_bytes,
            model.source_sha256,
            model.config.element_symbols.len(),
            model.config.descriptor_count().unwrap(),
            model.config.parameter_count().unwrap(),
            model.descriptor_scales.len(),
            model.config.runtime_parameter_count().unwrap()
        );
    }
}
