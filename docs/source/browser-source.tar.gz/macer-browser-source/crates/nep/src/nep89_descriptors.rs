//! NEP descriptor kernels implemented from the published NEP model equations.

use crate::nep89::Nep4ZblModel;
use crate::nep89_neighbors::NepNeighborGraph;
use macer_rust_core::Structure;

const C3B: [&[f64]; 4] = [
    &[0.238732414637843, 0.119366207318922, 0.119366207318922],
    &[
        0.099471839432435,
        0.596831036594608,
        0.596831036594608,
        0.149207759148652,
        0.149207759148652,
    ],
    &[
        0.139260575205408,
        0.104445431404056,
        0.104445431404056,
        1.044454314040563,
        1.044454314040563,
        0.174075719006761,
        0.174075719006761,
    ],
    &[
        0.011190581936149,
        0.223811638722978,
        0.223811638722978,
        0.111905819361489,
        0.111905819361489,
        1.566681471060845,
        1.566681471060845,
        0.195835183882606,
        0.195835183882606,
    ],
];

const C4B_222: [f64; 5] = [
    -0.007499480826664,
    -0.134990654879954,
    0.067495327439977,
    0.404971964639861,
    -0.809943929279723,
];
const C5B_1111: [f64; 3] = [0.026596810706114, 0.053193621412227, 0.026596810706114];

/// Evaluate the configured radial descriptor components for every atom.
/// Values are returned after the model's per-descriptor `q_scaler` is applied.
pub fn radial_descriptors(
    model: &Nep4ZblModel,
    structure: &Structure,
    graph: &NepNeighborGraph,
) -> Result<Vec<Vec<f64>>, String> {
    structure.validate()?;
    let config = &model.config;
    let atom_count = structure.atomic_numbers.len();
    let type_count = config.element_symbols.len();
    let component_count = config.n_max[0]
        .checked_add(1)
        .ok_or_else(|| "radial descriptor dimension overflow".to_owned())?;
    if graph.center_offsets.len() != atom_count + 1 {
        return Err("NEP graph atom count does not match structure".into());
    }
    if graph.cutoff_a + 1.0e-10 < config.cutoff_a[0] {
        return Err("NEP graph cutoff is smaller than model radial cutoff".into());
    }
    if model.descriptor_scales.len() != config.descriptor_count()? {
        return Err("descriptor scale count does not match model dimensions".into());
    }
    let coefficients = model.descriptor_coefficients()?;
    if coefficients.len() != config.descriptor_parameter_count()? {
        return Err("descriptor coefficient count does not match model dimensions".into());
    }
    let basis_count = config.basis_size[0]
        .checked_add(1)
        .ok_or_else(|| "radial basis dimension overflow".to_owned())?;
    let cutoff = config.cutoff_a[0];
    let mut result = vec![vec![0.0; component_count]; atom_count];

    for center in 0..atom_count {
        let center_type = config
            .type_index_for_atomic_number(structure.atomic_numbers[center])
            .ok_or_else(|| {
                format!(
                    "element with atomic number {} is not supported by NEP model",
                    structure.atomic_numbers[center]
                )
            })?;
        let neighbors = graph
            .within_cutoff_for_center(center, cutoff)
            .ok_or_else(|| "invalid NEP radial cutoff".to_owned())?;
        for edge in neighbors {
            if edge.distance_a >= cutoff {
                continue;
            }
            let neighbor_type = config
                .type_index_for_atomic_number(structure.atomic_numbers[edge.neighbor as usize])
                .ok_or_else(|| {
                    format!(
                        "element with atomic number {} is not supported by NEP model",
                        structure.atomic_numbers[edge.neighbor as usize]
                    )
                })?;
            let basis = radial_basis(edge.distance_a, cutoff, basis_count);
            for n in 0..component_count {
                let mut contribution = 0.0;
                for k in 0..basis_count {
                    let coefficient_index = (n * basis_count + k) * type_count * type_count
                        + center_type * type_count
                        + neighbor_type;
                    contribution += basis[k] * coefficients[coefficient_index];
                }
                result[center][n] += contribution;
            }
        }
        for component in 0..component_count {
            result[center][component] *= model.descriptor_scales[component];
        }
    }
    Ok(result)
}

/// Evaluate the angular invariant descriptors in the model's descriptor order.
/// The returned vectors omit the radial prefix, but retain the NEP group-major
/// layout: all angular radial orders for l=1, then l=2, and so on.
pub fn angular_descriptors(
    model: &Nep4ZblModel,
    structure: &Structure,
    graph: &NepNeighborGraph,
) -> Result<Vec<Vec<f64>>, String> {
    structure.validate()?;
    let config = &model.config;
    let atom_count = structure.atomic_numbers.len();
    if graph.center_offsets.len() != atom_count + 1 {
        return Err("NEP graph atom count does not match structure".into());
    }
    let cutoff = config.cutoff_a[1];
    if graph.cutoff_a + 1.0e-10 < cutoff {
        return Err("NEP graph cutoff is smaller than model angular cutoff".into());
    }
    if model.descriptor_scales.len() != config.descriptor_count()? {
        return Err("descriptor scale count does not match model dimensions".into());
    }
    let coefficients = model.descriptor_coefficients()?;
    if coefficients.len() != config.descriptor_parameter_count()? {
        return Err("descriptor coefficient count does not match model dimensions".into());
    }

    // NEP89's `l_max` header uses l_max[0] for the 3-body maximum and
    // nonzero l_max[1..] flags for q222 and q1111, respectively.
    let l_max = config.l_max[0];
    if l_max > 4 {
        return Err(format!(
            "NEP angular kernels currently support three-body l_max <= 4, found {l_max}"
        ));
    }
    let has_q222 = config.l_max[1] != 0;
    let has_q1111 = config.l_max[2] != 0;
    if has_q222 && l_max < 2 {
        return Err("NEP q222 descriptor requires three-body l_max >= 2".into());
    }
    if has_q1111 && l_max < 1 {
        return Err("NEP q1111 descriptor requires three-body l_max >= 1".into());
    }
    let angular_group_count = l_max + usize::from(has_q222) + usize::from(has_q1111);
    let n_max_plus_one = config.n_max[1]
        .checked_add(1)
        .ok_or_else(|| "angular descriptor dimension overflow".to_owned())?;
    let expected_count = angular_group_count
        .checked_mul(n_max_plus_one)
        .ok_or_else(|| "angular descriptor dimension overflow".to_owned())?;
    let radial_count = config.n_max[0]
        .checked_add(1)
        .ok_or_else(|| "radial descriptor dimension overflow".to_owned())?;
    if config.descriptor_count()? != radial_count + expected_count {
        return Err("NEP header descriptor dimensions are inconsistent".into());
    }
    if expected_count == 0 {
        return Ok(vec![Vec::new(); atom_count]);
    }

    let type_count = config.element_symbols.len();
    let type_pair_count = type_count
        .checked_mul(type_count)
        .ok_or_else(|| "NEP element-pair dimension overflow".to_owned())?;
    let radial_basis_count = config.basis_size[0]
        .checked_add(1)
        .ok_or_else(|| "radial basis dimension overflow".to_owned())?;
    let radial_parameter_count = radial_count
        .checked_mul(radial_basis_count)
        .and_then(|value| value.checked_mul(type_pair_count))
        .ok_or_else(|| "NEP radial coefficient dimension overflow".to_owned())?;
    let basis_count = config.basis_size[1]
        .checked_add(1)
        .ok_or_else(|| "angular basis dimension overflow".to_owned())?;
    let mut result = vec![vec![0.0; expected_count]; atom_count];

    for center in 0..atom_count {
        let center_type = config
            .type_index_for_atomic_number(structure.atomic_numbers[center])
            .ok_or_else(|| {
                format!(
                    "element with atomic number {} is not supported by NEP model",
                    structure.atomic_numbers[center]
                )
            })?;
        let neighbors = graph
            .within_cutoff_for_center(center, cutoff)
            .ok_or_else(|| "invalid NEP angular cutoff".to_owned())?;
        // One real spherical-harmonic sum for each angular radial order n.
        let mut harmonic_sums = vec![vec![0.0; 25]; n_max_plus_one];
        for edge in neighbors {
            if edge.distance_a >= cutoff {
                continue;
            }
            if !edge.distance_a.is_finite() || edge.distance_a <= 0.0 {
                return Err("NEP angular neighbor has an invalid distance".into());
            }
            let neighbor_type = config
                .type_index_for_atomic_number(structure.atomic_numbers[edge.neighbor as usize])
                .ok_or_else(|| {
                    format!(
                        "element with atomic number {} is not supported by NEP model",
                        structure.atomic_numbers[edge.neighbor as usize]
                    )
                })?;
            let basis = radial_basis(edge.distance_a, cutoff, basis_count);
            let direction = edge.displacement_a.map(|value| value / edge.distance_a);
            let harmonics = real_harmonics_through_four(direction);
            for n in 0..n_max_plus_one {
                let mut radial_weight = 0.0;
                for (k, basis_value) in basis.iter().enumerate() {
                    let coefficient_index = radial_parameter_count
                        + (n * basis_count + k) * type_pair_count
                        + center_type * type_count
                        + neighbor_type;
                    radial_weight += basis_value * coefficients[coefficient_index];
                }
                for l in 1..=l_max {
                    let offset = l * l - 1;
                    let width = 2 * l + 1;
                    for m in 0..width {
                        harmonic_sums[n][offset + m] += radial_weight * harmonics[offset + m];
                    }
                }
            }
        }

        for n in 0..n_max_plus_one {
            let sums = &harmonic_sums[n];
            let mut group = 0;
            for l in 1..=l_max {
                let offset = l * l - 1;
                let mut invariant = C3B[l - 1][0] * sums[offset] * sums[offset];
                for m in 1..=l {
                    invariant += 2.0
                        * C3B[l - 1][2 * m - 1]
                        * sums[offset + 2 * m - 1]
                        * sums[offset + 2 * m - 1];
                    invariant +=
                        2.0 * C3B[l - 1][2 * m] * sums[offset + 2 * m] * sums[offset + 2 * m];
                }
                write_scaled_angular(
                    model,
                    &mut result[center],
                    radial_count,
                    n_max_plus_one,
                    group,
                    n,
                    invariant,
                );
                group += 1;
            }
            if has_q222 {
                let s = sums;
                let invariant = C4B_222[0] * s[3].powi(3)
                    + C4B_222[1] * s[3] * (s[4].powi(2) + s[5].powi(2))
                    + C4B_222[2] * s[3] * (s[6].powi(2) + s[7].powi(2))
                    + C4B_222[3] * s[6] * (s[5].powi(2) - s[4].powi(2))
                    + C4B_222[4] * s[4] * s[5] * s[7];
                write_scaled_angular(
                    model,
                    &mut result[center],
                    radial_count,
                    n_max_plus_one,
                    group,
                    n,
                    invariant,
                );
                group += 1;
            }
            if has_q1111 {
                let s0_sq = sums[0] * sums[0];
                let s1_sq_plus_s2_sq = sums[1] * sums[1] + sums[2] * sums[2];
                let invariant = C5B_1111[0] * s0_sq * s0_sq
                    + C5B_1111[1] * s0_sq * s1_sq_plus_s2_sq
                    + C5B_1111[2] * s1_sq_plus_s2_sq * s1_sq_plus_s2_sq;
                write_scaled_angular(
                    model,
                    &mut result[center],
                    radial_count,
                    n_max_plus_one,
                    group,
                    n,
                    invariant,
                );
            }
        }
    }
    Ok(result)
}

fn write_scaled_angular(
    model: &Nep4ZblModel,
    descriptors: &mut [f64],
    radial_count: usize,
    n_max_plus_one: usize,
    group: usize,
    n: usize,
    value: f64,
) {
    let index = group * n_max_plus_one + n;
    descriptors[index] = value * model.descriptor_scales[radial_count + index];
}

/// Real solid-harmonic components in the ordering used by the NEP invariant
/// contractions: for each l, m=0 followed by real/imaginary m=1..l.
fn real_harmonics_through_four([x, y, z]: [f64; 3]) -> [f64; 24] {
    let x2 = x * x;
    let y2 = y * y;
    let z2 = z * z;
    let xy = x * y;
    let z3 = z2 * z;
    let z4 = z2 * z2;
    let x3 = x2 * x;
    let y3 = y2 * y;
    let mut values = [0.0; 24];
    values[0..3].copy_from_slice(&[z, x, y]);
    values[3..8].copy_from_slice(&[3.0 * z2 - 1.0, z * x, z * y, x2 - y2, 2.0 * xy]);
    values[8..15].copy_from_slice(&[
        5.0 * z3 - 3.0 * z,
        (5.0 * z2 - 1.0) * x,
        (5.0 * z2 - 1.0) * y,
        z * (x2 - y2),
        2.0 * z * xy,
        x3 - 3.0 * x * y2,
        3.0 * x2 * y - y3,
    ]);
    values[15..24].copy_from_slice(&[
        35.0 * z4 - 30.0 * z2 + 3.0,
        (7.0 * z3 - 3.0 * z) * x,
        (7.0 * z3 - 3.0 * z) * y,
        (7.0 * z2 - 1.0) * (x2 - y2),
        2.0 * (7.0 * z2 - 1.0) * xy,
        z * (x3 - 3.0 * x * y2),
        z * (3.0 * x2 * y - y3),
        x4_minus_6x2y2_plus_y4(x, y),
        4.0 * xy * (x2 - y2),
    ]);
    values
}

fn x4_minus_6x2y2_plus_y4(x: f64, y: f64) -> f64 {
    let x2 = x * x;
    let y2 = y * y;
    x2 * x2 - 6.0 * x2 * y2 + y2 * y2
}

fn radial_basis(distance_a: f64, cutoff_a: f64, count: usize) -> Vec<f64> {
    let x = 2.0 * (distance_a / cutoff_a - 1.0).powi(2) - 1.0;
    let cutoff_function = 0.5 * (1.0 + (std::f64::consts::PI * distance_a / cutoff_a).cos());
    let mut basis = Vec::with_capacity(count);
    let mut t_previous = 1.0;
    let mut t_current = x;
    for index in 0..count {
        let chebyshev = match index {
            0 => 1.0,
            1 => x,
            _ => {
                let next = 2.0 * x * t_current - t_previous;
                t_previous = t_current;
                t_current = next;
                next
            }
        };
        basis.push(0.5 * (chebyshev + 1.0) * cutoff_function);
    }
    basis
}

/// Radial basis values and their analytic derivatives with respect to distance.
fn radial_basis_with_derivative(
    distance_a: f64,
    cutoff_a: f64,
    count: usize,
) -> (Vec<f64>, Vec<f64>) {
    let scaled = distance_a / cutoff_a - 1.0;
    let x = 2.0 * scaled * scaled - 1.0;
    let dx_dr = 4.0 * scaled / cutoff_a;
    let phase = std::f64::consts::PI * distance_a / cutoff_a;
    let cutoff = 0.5 * (1.0 + phase.cos());
    let cutoff_derivative = -0.5 * phase.sin() * std::f64::consts::PI / cutoff_a;
    let mut values = Vec::with_capacity(count);
    let mut derivatives = Vec::with_capacity(count);
    let (mut t_previous, mut dt_previous) = (1.0, 0.0);
    let (mut t_current, mut dt_current) = (x, dx_dr);
    for index in 0..count {
        let (chebyshev, derivative) = match index {
            0 => (1.0, 0.0),
            1 => (x, dx_dr),
            _ => {
                let next = 2.0 * x * t_current - t_previous;
                let next_derivative = 2.0 * dx_dr * t_current + 2.0 * x * dt_current - dt_previous;
                t_previous = t_current;
                dt_previous = dt_current;
                t_current = next;
                dt_current = next_derivative;
                (next, next_derivative)
            }
        };
        values.push(0.5 * (chebyshev + 1.0) * cutoff);
        derivatives.push(0.5 * (derivative * cutoff + (chebyshev + 1.0) * cutoff_derivative));
    }
    (values, derivatives)
}

/// Per-central-atom, per-neighbor derivatives of every q-scaled descriptor.
/// The outer dimensions follow graph centers and each center's graph edge order.
/// The innermost Cartesian vector is d(q_scaled)/d(displacement_a).
pub fn descriptor_edge_gradients(
    model: &Nep4ZblModel,
    structure: &Structure,
    graph: &NepNeighborGraph,
) -> Result<Vec<Vec<Vec<[f64; 3]>>>, String> {
    structure.validate()?;
    let config = &model.config;
    let atom_count = structure.atomic_numbers.len();
    if graph.center_offsets.len() != atom_count + 1 {
        return Err("NEP graph atom count does not match structure".into());
    }
    if model.descriptor_scales.len() != config.descriptor_count()? {
        return Err("descriptor scale count does not match model dimensions".into());
    }
    let coefficients = model.descriptor_coefficients()?;
    if coefficients.len() != config.descriptor_parameter_count()? {
        return Err("descriptor coefficient count does not match model dimensions".into());
    }

    let radial_count = config.n_max[0] + 1;
    let angular_n_count = config.n_max[1] + 1;
    let descriptor_count = config.descriptor_count()?;
    let type_count = config.element_symbols.len();
    let pair_count = type_count
        .checked_mul(type_count)
        .ok_or_else(|| "NEP element-pair dimension overflow".to_owned())?;
    let radial_basis_count = config.basis_size[0] + 1;
    let angular_basis_count = config.basis_size[1] + 1;
    let radial_cutoff = config.cutoff_a[0];
    let angular_cutoff = config.cutoff_a[1];
    if graph.cutoff_a + 1.0e-10 < radial_cutoff.max(angular_cutoff) {
        return Err("NEP graph cutoff is smaller than a descriptor cutoff".into());
    }
    let l_max = config.l_max[0];
    if l_max > 4 {
        return Err(format!(
            "NEP angular gradients support l_max <= 4, found {l_max}"
        ));
    }
    let has_q222 = config.l_max[1] != 0;
    let has_q1111 = config.l_max[2] != 0;
    let group_count = l_max + usize::from(has_q222) + usize::from(has_q1111);
    if descriptor_count != radial_count + group_count * angular_n_count {
        return Err("NEP descriptor dimensions are inconsistent".into());
    }

    let mut result = Vec::with_capacity(atom_count);
    for center in 0..atom_count {
        let edges = graph
            .for_center(center)
            .ok_or_else(|| "NEP graph is missing a center row".to_owned())?;
        let center_type = config
            .type_index_for_atomic_number(structure.atomic_numbers[center])
            .ok_or_else(|| format!("unsupported NEP element at atom {center}"))?;
        let mut edge_gradients = vec![vec![[0.0; 3]; descriptor_count]; edges.len()];

        // Radial descriptor derivatives.
        for (edge_index, edge) in edges.iter().enumerate() {
            let distance = edge.distance_a;
            if distance >= radial_cutoff {
                continue;
            }
            let neighbor_type = config
                .type_index_for_atomic_number(structure.atomic_numbers[edge.neighbor as usize])
                .ok_or_else(|| format!("unsupported NEP element at atom {}", edge.neighbor))?;
            let (_, basis_derivatives) =
                radial_basis_with_derivative(distance, radial_cutoff, radial_basis_count);
            let direction = edge.displacement_a.map(|value| value / distance);
            for n in 0..radial_count {
                let mut derivative = 0.0;
                for (k, basis_derivative) in basis_derivatives.iter().enumerate() {
                    let coefficient_index = (n * radial_basis_count + k) * pair_count
                        + center_type * type_count
                        + neighbor_type;
                    derivative += basis_derivative * coefficients[coefficient_index];
                }
                let scale = model.descriptor_scales[n] * derivative;
                for axis in 0..3 {
                    edge_gradients[edge_index][n][axis] = scale * direction[axis];
                }
            }
        }

        // Angular invariant values and their partial derivatives with respect
        // to the 24 real spherical-harmonic sums, one vector per radial order.
        let mut harmonic_sums = vec![[0.0; 24]; angular_n_count];
        for edge in edges.iter().filter(|edge| edge.distance_a < angular_cutoff) {
            let neighbor_type = config
                .type_index_for_atomic_number(structure.atomic_numbers[edge.neighbor as usize])
                .ok_or_else(|| format!("unsupported NEP element at atom {}", edge.neighbor))?;
            let basis = radial_basis(edge.distance_a, angular_cutoff, angular_basis_count);
            let direction = edge.displacement_a.map(|value| value / edge.distance_a);
            let harmonics = real_harmonics_through_four(direction);
            for n in 0..angular_n_count {
                let mut weight = 0.0;
                for (k, basis_value) in basis.iter().enumerate() {
                    let coefficient_index = radial_count * radial_basis_count * pair_count
                        + (n * angular_basis_count + k) * pair_count
                        + center_type * type_count
                        + neighbor_type;
                    weight += basis_value * coefficients[coefficient_index];
                }
                for l in 1..=l_max {
                    let offset = l * l - 1;
                    for m in 0..(2 * l + 1) {
                        harmonic_sums[n][offset + m] += weight * harmonics[offset + m];
                    }
                }
            }
        }

        let mut invariant_partials = vec![vec![[0.0; 24]; group_count]; angular_n_count];
        for n in 0..angular_n_count {
            invariant_partials[n] =
                angular_invariant_partials(&harmonic_sums[n], l_max, has_q222, has_q1111);
        }

        // Chain dE/dq through each angular edge contribution. For a given
        // edge, dS_m/dR = w'(r) u Y_lm + w(r) dY_lm/dR.
        for (edge_index, edge) in edges.iter().enumerate() {
            let distance = edge.distance_a;
            if distance >= angular_cutoff {
                continue;
            }
            let neighbor_type = config
                .type_index_for_atomic_number(structure.atomic_numbers[edge.neighbor as usize])
                .ok_or_else(|| format!("unsupported NEP element at atom {}", edge.neighbor))?;
            let (basis, basis_derivatives) =
                radial_basis_with_derivative(distance, angular_cutoff, angular_basis_count);
            let direction = edge.displacement_a.map(|value| value / distance);
            let harmonics = real_harmonics_through_four(direction);
            let harmonic_direction_gradients = real_harmonic_direction_gradients(direction);
            let mut harmonic_position_gradients = [[0.0; 3]; 24];
            for m in 0..24 {
                let projection = dot3(harmonic_direction_gradients[m], direction);
                for axis in 0..3 {
                    harmonic_position_gradients[m][axis] = (harmonic_direction_gradients[m][axis]
                        - projection * direction[axis])
                        / distance;
                }
            }
            for n in 0..angular_n_count {
                let mut weight = 0.0;
                let mut weight_derivative = 0.0;
                for k in 0..angular_basis_count {
                    let coefficient_index = radial_count * radial_basis_count * pair_count
                        + (n * angular_basis_count + k) * pair_count
                        + center_type * type_count
                        + neighbor_type;
                    weight += basis[k] * coefficients[coefficient_index];
                    weight_derivative += basis_derivatives[k] * coefficients[coefficient_index];
                }
                let mut group = 0;
                for l in 1..=l_max {
                    let offset = l * l - 1;
                    let end = offset + 2 * l + 1;
                    let mut gradient = [0.0; 3];
                    for m in offset..end {
                        let partial = invariant_partials[n][group][m];
                        for axis in 0..3 {
                            let ds = weight_derivative * direction[axis] * harmonics[m]
                                + weight * harmonic_position_gradients[m][axis];
                            gradient[axis] += partial * ds;
                        }
                    }
                    let descriptor_index = radial_count + group * angular_n_count + n;
                    let scale = model.descriptor_scales[descriptor_index];
                    for axis in 0..3 {
                        edge_gradients[edge_index][descriptor_index][axis] +=
                            scale * gradient[axis];
                    }
                    group += 1;
                }
                if has_q222 {
                    let mut gradient = [0.0; 3];
                    for m in 3..8 {
                        let partial = invariant_partials[n][group][m];
                        for axis in 0..3 {
                            let ds = weight_derivative * direction[axis] * harmonics[m]
                                + weight * harmonic_position_gradients[m][axis];
                            gradient[axis] += partial * ds;
                        }
                    }
                    let descriptor_index = radial_count + group * angular_n_count + n;
                    let scale = model.descriptor_scales[descriptor_index];
                    for axis in 0..3 {
                        edge_gradients[edge_index][descriptor_index][axis] +=
                            scale * gradient[axis];
                    }
                    group += 1;
                }
                if has_q1111 {
                    let mut gradient = [0.0; 3];
                    for m in 0..3 {
                        let partial = invariant_partials[n][group][m];
                        for axis in 0..3 {
                            let ds = weight_derivative * direction[axis] * harmonics[m]
                                + weight * harmonic_position_gradients[m][axis];
                            gradient[axis] += partial * ds;
                        }
                    }
                    let descriptor_index = radial_count + group * angular_n_count + n;
                    let scale = model.descriptor_scales[descriptor_index];
                    for axis in 0..3 {
                        edge_gradients[edge_index][descriptor_index][axis] +=
                            scale * gradient[axis];
                    }
                }
            }
        }
        result.push(edge_gradients);
    }
    Ok(result)
}

fn angular_invariant_partials(
    sums: &[f64; 24],
    l_max: usize,
    has_q222: bool,
    has_q1111: bool,
) -> Vec<[f64; 24]> {
    let mut result = Vec::with_capacity(l_max + usize::from(has_q222) + usize::from(has_q1111));
    for l in 1..=l_max {
        let offset = l * l - 1;
        let mut partials = [0.0; 24];
        partials[offset] = 2.0 * C3B[l - 1][0] * sums[offset];
        for m in 1..=l {
            partials[offset + 2 * m - 1] = 4.0 * C3B[l - 1][2 * m - 1] * sums[offset + 2 * m - 1];
            partials[offset + 2 * m] = 4.0 * C3B[l - 1][2 * m] * sums[offset + 2 * m];
        }
        result.push(partials);
    }
    if has_q222 {
        let [s3, s4, s5, s6, s7] = [sums[3], sums[4], sums[5], sums[6], sums[7]];
        let [a, b, c, d, e] = C4B_222;
        let mut partials = [0.0; 24];
        partials[3] = 3.0 * a * s3 * s3 + b * (s4 * s4 + s5 * s5) + c * (s6 * s6 + s7 * s7);
        partials[4] = 2.0 * b * s3 * s4 - 2.0 * d * s6 * s4 + e * s5 * s7;
        partials[5] = 2.0 * b * s3 * s5 + 2.0 * d * s6 * s5 + e * s4 * s7;
        partials[6] = 2.0 * c * s3 * s6 + d * (s5 * s5 - s4 * s4);
        partials[7] = 2.0 * c * s3 * s7 + e * s4 * s5;
        result.push(partials);
    }
    if has_q1111 {
        let s0 = sums[0];
        let s1 = sums[1];
        let s2 = sums[2];
        let a = s0 * s0;
        let b = s1 * s1 + s2 * s2;
        let mut partials = [0.0; 24];
        partials[0] = 4.0 * C5B_1111[0] * s0 * s0 * s0 + 2.0 * C5B_1111[1] * s0 * b;
        partials[1] = 2.0 * C5B_1111[1] * a * s1 + 4.0 * C5B_1111[2] * b * s1;
        partials[2] = 2.0 * C5B_1111[1] * a * s2 + 4.0 * C5B_1111[2] * b * s2;
        result.push(partials);
    }
    result
}

fn dot3(left: [f64; 3], right: [f64; 3]) -> f64 {
    left[0] * right[0] + left[1] * right[1] + left[2] * right[2]
}

fn real_harmonic_direction_gradients([x, y, z]: [f64; 3]) -> [[f64; 3]; 24] {
    let x2 = x * x;
    let y2 = y * y;
    let z2 = z * z;
    let x3 = x2 * x;
    let y3 = y2 * y;
    [
        [0.0, 0.0, 1.0],
        [1.0, 0.0, 0.0],
        [0.0, 1.0, 0.0],
        [0.0, 0.0, 6.0 * z],
        [z, 0.0, x],
        [0.0, z, y],
        [2.0 * x, -2.0 * y, 0.0],
        [2.0 * y, 2.0 * x, 0.0],
        [0.0, 0.0, 15.0 * z2 - 3.0],
        [5.0 * z2 - 1.0, 0.0, 10.0 * z * x],
        [0.0, 5.0 * z2 - 1.0, 10.0 * z * y],
        [2.0 * z * x, -2.0 * z * y, x2 - y2],
        [2.0 * z * y, 2.0 * z * x, 2.0 * x * y],
        [3.0 * x2 - 3.0 * y2, -6.0 * x * y, 0.0],
        [6.0 * x * y, 3.0 * x2 - 3.0 * y2, 0.0],
        [0.0, 0.0, 140.0 * z2 * z - 60.0 * z],
        [7.0 * z2 * z - 3.0 * z, 0.0, (21.0 * z2 - 3.0) * x],
        [0.0, 7.0 * z2 * z - 3.0 * z, (21.0 * z2 - 3.0) * y],
        [
            2.0 * x * (7.0 * z2 - 1.0),
            -2.0 * y * (7.0 * z2 - 1.0),
            14.0 * z * (x2 - y2),
        ],
        [
            2.0 * y * (7.0 * z2 - 1.0),
            2.0 * x * (7.0 * z2 - 1.0),
            28.0 * z * x * y,
        ],
        [
            z * (3.0 * x2 - 3.0 * y2),
            -6.0 * z * x * y,
            x3 - 3.0 * x * y2,
        ],
        [
            6.0 * z * x * y,
            z * (3.0 * x2 - 3.0 * y2),
            3.0 * x2 * y - y3,
        ],
        [4.0 * x3 - 12.0 * x * y2, -12.0 * x2 * y + 4.0 * y3, 0.0],
        [12.0 * x2 * y - 4.0 * y3, 4.0 * x3 - 12.0 * x * y2, 0.0],
    ]
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn radial_chebyshev_basis_has_expected_cutoff_values() {
        let at_zero = radial_basis(0.0, 2.0, 4);
        assert_eq!(at_zero, [1.0, 1.0, 1.0, 1.0]);
        let at_cutoff = radial_basis(2.0, 2.0, 4);
        assert!(at_cutoff.iter().all(|value| value.abs() < 1.0e-15));
    }

    #[test]
    fn radial_components_match_pinned_nep_cpu_si8_reference_when_supplied() {
        let (Some(model_path), Some(reference_path)) = (
            std::env::var_os("MACER_NEP89_MODEL"),
            std::env::var_os("MACER_NEP89_STAGE_REFERENCE"),
        ) else {
            eprintln!(
                "skipping NEP_CPU radial descriptor comparison: model/reference env is unset"
            );
            return;
        };
        let model = Nep4ZblModel::from_bytes(&std::fs::read(model_path).unwrap()).unwrap();
        let reference: serde_json::Value =
            serde_json::from_slice(&std::fs::read(reference_path).unwrap()).unwrap();
        let structure = Structure {
            atomic_numbers: vec![14; 8],
            positions_a: vec![
                [0.0, 0.0, 0.0],
                [0.0, 2.715, 2.715],
                [2.715, 0.0, 2.715],
                [2.715, 2.715, 0.0],
                [1.3575, 1.3575, 1.3575],
                [1.3575, 4.0725, 4.0725],
                [4.0725, 1.3575, 4.0725],
                [4.0725, 4.0725, 1.3575],
            ],
            cell_a: [[5.43, 0.0, 0.0], [0.0, 5.43, 0.0], [0.0, 0.0, 5.43]],
            pbc: [true; 3],
        };
        let graph = NepNeighborGraph::for_structure(&structure, 6.0).unwrap();
        let actual = radial_descriptors(&model, &structure, &graph).unwrap();
        let expected = reference["descriptors_by_atom"].as_array().unwrap();
        let mut max_delta = 0.0f64;
        for atom in 0..structure.atomic_numbers.len() {
            for component in 0..model.config.n_max[0] + 1 {
                let expected_value = expected[atom][component].as_f64().unwrap();
                let delta = (actual[atom][component] - expected_value).abs();
                max_delta = max_delta.max(delta);
                assert!(
                    delta <= 1.0e-10,
                    "radial descriptor mismatch at atom {atom}, component {component}: actual {}, expected {expected_value}, delta {delta}",
                    actual[atom][component]
                );
            }
        }
        println!("NEP89 Si8 radial descriptor max_abs_delta={max_delta:.17e}");
    }

    #[test]
    fn angular_components_match_pinned_nep_cpu_si8_reference_when_supplied() {
        let (Some(model_path), Some(reference_path)) = (
            std::env::var_os("MACER_NEP89_MODEL"),
            std::env::var_os("MACER_NEP89_STAGE_REFERENCE"),
        ) else {
            eprintln!(
                "skipping NEP_CPU angular descriptor comparison: model/reference env is unset"
            );
            return;
        };
        let model = Nep4ZblModel::from_bytes(&std::fs::read(model_path).unwrap()).unwrap();
        let reference: serde_json::Value =
            serde_json::from_slice(&std::fs::read(reference_path).unwrap()).unwrap();
        let structure = Structure {
            atomic_numbers: vec![14; 8],
            positions_a: vec![
                [0.0, 0.0, 0.0],
                [0.0, 2.715, 2.715],
                [2.715, 0.0, 2.715],
                [2.715, 2.715, 0.0],
                [1.3575, 1.3575, 1.3575],
                [1.3575, 4.0725, 4.0725],
                [4.0725, 1.3575, 4.0725],
                [4.0725, 4.0725, 1.3575],
            ],
            cell_a: [[5.43, 0.0, 0.0], [0.0, 5.43, 0.0], [0.0, 0.0, 5.43]],
            pbc: [true; 3],
        };
        let graph = NepNeighborGraph::for_structure(&structure, 6.0).unwrap();
        let actual = angular_descriptors(&model, &structure, &graph).unwrap();
        let expected = reference["descriptors_by_atom"].as_array().unwrap();
        let radial_count = model.config.n_max[0] + 1;
        let angular_count = model.config.descriptor_count().unwrap() - radial_count;
        let mut max_delta = 0.0f64;
        let mut max_expected = 0.0f64;
        for atom in 0..structure.atomic_numbers.len() {
            for component in 0..angular_count {
                let expected_value = expected[atom][radial_count + component].as_f64().unwrap();
                max_expected = max_expected.max(expected_value.abs());
                let delta = (actual[atom][component] - expected_value).abs();
                max_delta = max_delta.max(delta);
                assert!(
                    delta <= 1.0e-10,
                    "angular descriptor mismatch at atom {atom}, component {component}: actual {}, expected {expected_value}, delta {delta}",
                    actual[atom][component]
                );
            }
        }
        println!(
            "NEP89 Si8 angular descriptor max_abs_delta={max_delta:.17e} max_abs_reference={max_expected:.17e}"
        );
    }

    #[test]
    fn angular_descriptors_and_neighbor_cutoffs_match_skew_and_boundary_references() {
        let Some(model_path) = std::env::var_os("MACER_NEP89_MODEL") else {
            eprintln!("skipping NEP_CPU fixture comparisons: model env is unset");
            return;
        };
        let model = Nep4ZblModel::from_bytes(&std::fs::read(model_path).unwrap()).unwrap();
        let fixtures = [
            (
                "skew_mixed",
                include_str!("../../../reference/fixtures/nep89/skew_mixed.input"),
                include_str!(
                    "../../../evidence/nep89_graph_2026-10-25/skew_mixed-stage-reference.json"
                ),
                true,
            ),
            (
                "cutoff_boundary",
                include_str!("../../../reference/fixtures/nep89/cutoff_boundary.input"),
                include_str!(
                    "../../../evidence/nep89_graph_2026-10-25/cutoff_boundary-stage-reference.json"
                ),
                true,
            ),
            (
                "skew_self_image",
                include_str!("../../../reference/fixtures/nep89/skew_self_image.input"),
                include_str!(
                    "../../../evidence/nep89_graph_2026-10-25/skew_self_image-stage-reference.json"
                ),
                true,
            ),
            (
                "nonperiodic_mixed",
                include_str!("../../../reference/fixtures/nep89/nonperiodic_mixed.input"),
                include_str!(
                    "../../../evidence/nep89_graph_2026-10-25/nonperiodic_mixed-stage-reference.json"
                ),
                false,
            ),
        ];
        for (name, input, reference_json, pbc) in fixtures {
            let structure = structure_from_reference_input(input, &model, pbc);
            let reference: serde_json::Value = serde_json::from_str(reference_json).unwrap();
            let graph =
                NepNeighborGraph::for_structure(&structure, model.config.cutoff_a[0]).unwrap();
            let mut max_edge_delta = [0.0f64; 2];
            for (center, edges) in reference["neighbors_by_atom"]
                .as_array()
                .unwrap()
                .iter()
                .enumerate()
            {
                for (kind, key, cutoff) in [
                    (0, "radial", model.config.cutoff_a[0]),
                    (1, "angular", model.config.cutoff_a[1]),
                ] {
                    let expected_edges = edges[key].as_array().unwrap();
                    let actual_edges = graph.within_cutoff_for_center(center, cutoff).unwrap();
                    assert_eq!(
                        actual_edges.len(),
                        expected_edges.len(),
                        "{name} {key} neighbor count differs at center {center}"
                    );
                    for (edge, expected) in actual_edges.iter().zip(expected_edges) {
                        assert_eq!(
                            edge.neighbor as usize,
                            expected[0].as_u64().unwrap() as usize
                        );
                        for axis in 0..3 {
                            let delta = (edge.displacement_a[axis]
                                - expected[axis + 1].as_f64().unwrap())
                            .abs();
                            max_edge_delta[kind] = max_edge_delta[kind].max(delta);
                            assert!(
                                delta < 1.0e-10,
                                "{name} {key} displacement differs at center {center}, axis {axis}: {delta}"
                            );
                        }
                    }
                }
            }

            let actual = angular_descriptors(&model, &structure, &graph).unwrap();
            let actual_radial = radial_descriptors(&model, &structure, &graph).unwrap();
            let expected = reference["descriptors_by_atom"].as_array().unwrap();
            let radial_count = model.config.n_max[0] + 1;
            let angular_count = model.config.descriptor_count().unwrap() - radial_count;
            let mut max_delta = 0.0f64;
            let mut max_expected = 0.0f64;
            for atom in 0..structure.atomic_numbers.len() {
                for component in 0..radial_count {
                    let expected_value = expected[atom][component].as_f64().unwrap();
                    let delta = (actual_radial[atom][component] - expected_value).abs();
                    assert!(
                        delta < 1.0e-10,
                        "{name} radial descriptor differs at atom {atom}, component {component}: actual {}, expected {expected_value}, delta {delta}",
                        actual_radial[atom][component]
                    );
                }
                for component in 0..angular_count {
                    let expected_value = expected[atom][radial_count + component].as_f64().unwrap();
                    max_expected = max_expected.max(expected_value.abs());
                    let delta = (actual[atom][component] - expected_value).abs();
                    max_delta = max_delta.max(delta);
                    assert!(
                        delta < 1.0e-10,
                        "{name} angular descriptor differs at atom {atom}, component {component}: actual {}, expected {expected_value}, delta {delta}",
                        actual[atom][component]
                    );
                }
            }
            println!(
                "NEP89 {name} radial/angular edge max_abs_delta={:.17e}/{:.17e} angular descriptor max_abs_delta={max_delta:.17e} max_abs_reference={max_expected:.17e}",
                max_edge_delta[0], max_edge_delta[1]
            );
        }
    }

    fn structure_from_reference_input(
        input: &str,
        model: &Nep4ZblModel,
        periodic: bool,
    ) -> Structure {
        let mut fields = input.split_whitespace();
        let atom_count = fields.next().unwrap().parse::<usize>().unwrap();
        let mut cell = [[0.0; 3]; 3];
        for value in cell.iter_mut().flatten() {
            *value = fields.next().unwrap().parse().unwrap();
        }
        let mut atomic_numbers = Vec::with_capacity(atom_count);
        let mut positions_a = Vec::with_capacity(atom_count);
        for _ in 0..atom_count {
            let symbol = fields.next().unwrap();
            let type_index = model
                .config
                .element_symbols
                .iter()
                .position(|candidate| candidate == symbol)
                .unwrap();
            atomic_numbers.push(model.config.atomic_numbers[type_index]);
            positions_a.push([
                fields.next().unwrap().parse().unwrap(),
                fields.next().unwrap().parse().unwrap(),
                fields.next().unwrap().parse().unwrap(),
            ]);
        }
        assert!(fields.next().is_none());
        Structure {
            atomic_numbers,
            positions_a,
            cell_a: cell,
            pbc: [periodic; 3],
        }
    }

    #[test]
    fn descriptor_values_are_translation_rotation_and_atom_order_invariant() {
        let Some(model_path) = std::env::var_os("MACER_NEP89_MODEL") else {
            eprintln!("skipping NEP_CPU descriptor invariance test: model env is unset");
            return;
        };
        let model = Nep4ZblModel::from_bytes(&std::fs::read(model_path).unwrap()).unwrap();
        let reference = structure_from_reference_input(
            include_str!("../../../reference/fixtures/nep89/skew_mixed.input"),
            &model,
            true,
        );
        let base = all_descriptors(&model, &reference);

        let shift = [1.271, -2.413, 0.917];
        let mut translated = reference.clone();
        for position in &mut translated.positions_a {
            for axis in 0..3 {
                position[axis] += shift[axis];
            }
        }
        assert_descriptors_close(&base, &all_descriptors(&model, &translated), 1.0e-10);

        let rotate = |[x, y, z]: [f64; 3]| [-y, x, z];
        let mut rotated = reference.clone();
        rotated.cell_a = reference.cell_a.map(rotate);
        rotated.positions_a = reference.positions_a.iter().copied().map(rotate).collect();
        assert_descriptors_close(&base, &all_descriptors(&model, &rotated), 1.0e-10);

        let permutation = [4, 2, 0, 3, 1];
        let permuted = Structure {
            atomic_numbers: permutation
                .iter()
                .map(|&index| reference.atomic_numbers[index])
                .collect(),
            positions_a: permutation
                .iter()
                .map(|&index| reference.positions_a[index])
                .collect(),
            cell_a: reference.cell_a,
            pbc: reference.pbc,
        };
        let permuted_descriptors = all_descriptors(&model, &permuted);
        for (new_index, &old_index) in permutation.iter().enumerate() {
            assert_descriptors_close(
                std::slice::from_ref(&base[old_index]),
                std::slice::from_ref(&permuted_descriptors[new_index]),
                1.0e-10,
            );
        }
    }

    fn all_descriptors(model: &Nep4ZblModel, structure: &Structure) -> Vec<Vec<f64>> {
        let graph = NepNeighborGraph::for_structure(structure, model.config.cutoff_a[0]).unwrap();
        let mut radial = radial_descriptors(model, structure, &graph).unwrap();
        let angular = angular_descriptors(model, structure, &graph).unwrap();
        for (radial, angular) in radial.iter_mut().zip(angular) {
            radial.extend(angular);
        }
        radial
    }

    fn assert_descriptors_close(expected: &[Vec<f64>], actual: &[Vec<f64>], tolerance: f64) {
        assert_eq!(expected.len(), actual.len());
        for (atom, (expected, actual)) in expected.iter().zip(actual).enumerate() {
            assert_eq!(expected.len(), actual.len());
            for (component, (&expected, &actual)) in expected.iter().zip(actual).enumerate() {
                let delta = (expected - actual).abs();
                assert!(
                    delta <= tolerance,
                    "descriptor invariance failed at atom {atom}, component {component}: expected {expected}, actual {actual}, delta {delta}"
                );
            }
        }
    }
}
