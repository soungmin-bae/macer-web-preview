//! NEP-specific periodic image neighbor enumeration.
//!
//! The graph is independent of the MatterSim graph: an edge identifies both
//! atom indices and the lattice image, so a small cell can contain several
//! edges with the same atom pair and can include non-central self images.

use macer_rust_core::Structure;

const BOUNDARY_EPS_A: f64 = 1.0e-10;
const MAX_EDGES: usize = 20_000_000;

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct NepNeighbor {
    pub center: u32,
    pub neighbor: u32,
    /// Integer translation applied to the neighbor's cell image.
    pub image: [i32; 3],
    /// Cartesian `r_neighbor(image) - r_center`, in Å.
    pub displacement_a: [f64; 3],
    pub distance_a: f64,
}

#[derive(Clone, Debug, PartialEq)]
pub struct NepNeighborGraph {
    pub cutoff_a: f64,
    pub neighbors: Vec<NepNeighbor>,
    /// Start/end offsets per center atom into `neighbors`.
    pub center_offsets: Vec<usize>,
}

impl NepNeighborGraph {
    pub fn for_structure(structure: &Structure, cutoff_a: f64) -> Result<Self, String> {
        structure.validate()?;
        if !cutoff_a.is_finite() || cutoff_a <= 0.0 {
            return Err("NEP neighbor cutoff must be finite and positive".into());
        }
        let atom_count = structure.atomic_numbers.len();
        if atom_count > u32::MAX as usize {
            return Err("NEP neighbor graph exceeds the u32 atom index contract".into());
        }

        let pbc = structure.pbc;
        let periodic = pbc.iter().any(|&enabled| enabled);
        let cell = structure.cell_a;
        let volume = determinant(cell);
        if periodic && (!volume.is_finite() || volume.abs() < 1.0e-12) {
            return Err("periodic NEP neighbor graph requires a nonsingular cell".into());
        }
        let reciprocal = if periodic {
            [
                scale(cross(cell[1], cell[2]), 1.0 / volume),
                scale(cross(cell[2], cell[0]), 1.0 / volume),
                scale(cross(cell[0], cell[1]), 1.0 / volume),
            ]
        } else {
            [[0.0; 3]; 3]
        };

        let mut neighbors = Vec::new();
        let mut center_offsets = Vec::with_capacity(atom_count + 1);
        center_offsets.push(0);
        let cutoff2 = cutoff_a * cutoff_a;
        for center in 0..atom_count {
            for neighbor in 0..atom_count {
                let delta = sub(
                    structure.positions_a[neighbor],
                    structure.positions_a[center],
                );
                let ranges = image_ranges(delta, reciprocal, pbc, cutoff_a)?;
                let ordered = [
                    ordered_image_values(ranges[0])?,
                    ordered_image_values(ranges[1])?,
                    ordered_image_values(ranges[2])?,
                ];
                // NEP_CPU's cell traversal visits zero, positive images, then
                // negative images, with the last lattice axis varying fastest.
                for &ix in &ordered[0] {
                    for &iy in &ordered[1] {
                        for &iz in &ordered[2] {
                            let image = [ix, iy, iz];
                            let displacement = add_image(delta, cell, image);
                            let distance2 = dot(displacement, displacement);
                            // GPUMD/NEP_CPU use a strict distance < cutoff
                            // predicate. Keep exact-boundary pairs out of the
                            // returned graph so descriptor and reference edge
                            // sets agree at the cutoff.
                            if distance2 >= cutoff2 {
                                continue;
                            }
                            if center == neighbor && image == [0, 0, 0] {
                                continue;
                            }
                            if distance2 <= 1.0e-24 {
                                return Err(format!(
                                    "coincident atoms/images at center {center}, neighbor {neighbor}, image {image:?}"
                                ));
                            }
                            if neighbors.len() >= MAX_EDGES {
                                return Err(format!(
                                    "NEP neighbor graph exceeds the {MAX_EDGES}-edge safety limit"
                                ));
                            }
                            neighbors.push(NepNeighbor {
                                center: center as u32,
                                neighbor: neighbor as u32,
                                image,
                                displacement_a: displacement,
                                distance_a: distance2.sqrt(),
                            });
                        }
                    }
                }
            }
            center_offsets.push(neighbors.len());
        }
        Ok(Self {
            cutoff_a,
            neighbors,
            center_offsets,
        })
    }

    pub fn for_center(&self, center: usize) -> Option<&[NepNeighbor]> {
        let start = *self.center_offsets.get(center)?;
        let end = *self.center_offsets.get(center + 1)?;
        self.neighbors.get(start..end)
    }

    pub fn within_cutoff_for_center(
        &self,
        center: usize,
        cutoff_a: f64,
    ) -> Option<Vec<&NepNeighbor>> {
        if !cutoff_a.is_finite() || cutoff_a < 0.0 || cutoff_a > self.cutoff_a + BOUNDARY_EPS_A {
            return None;
        }
        self.for_center(center).map(|neighbors| {
            neighbors
                .iter()
                .filter(|edge| edge.distance_a < cutoff_a)
                .collect()
        })
    }
}

fn image_ranges(
    delta: [f64; 3],
    reciprocal: [[f64; 3]; 3],
    pbc: [bool; 3],
    cutoff_a: f64,
) -> Result<[(i32, i32); 3], String> {
    let mut ranges = [(0, 0); 3];
    for axis in 0..3 {
        if !pbc[axis] {
            continue;
        }
        let frac = dot(delta, reciprocal[axis]);
        let bound = cutoff_a * dot(reciprocal[axis], reciprocal[axis]).sqrt() + 1.0e-12;
        let low = (-frac - bound).ceil();
        let high = (-frac + bound).floor();
        if !low.is_finite() || !high.is_finite() || low < i32::MIN as f64 || high > i32::MAX as f64
        {
            return Err("periodic image range exceeds i32".into());
        }
        ranges[axis] = (low as i32, high as i32);
    }
    Ok(ranges)
}

fn ordered_image_values((low, high): (i32, i32)) -> Result<Vec<i32>, String> {
    if low > high {
        return Ok(Vec::new());
    }
    let count = i64::from(high) - i64::from(low) + 1;
    if count > MAX_EDGES as i64 {
        return Err("periodic image range exceeds the graph safety limit".into());
    }
    let mut values = Vec::with_capacity(count as usize);
    if low <= 0 && high >= 0 {
        values.push(0);
        let maximum = i64::from(high).max(-i64::from(low));
        for magnitude in 1..=maximum {
            if let Ok(positive) = i32::try_from(magnitude) {
                if positive <= high {
                    values.push(positive);
                }
            }
            if let Ok(negative) = i32::try_from(-magnitude) {
                if negative >= low {
                    values.push(negative);
                }
            }
        }
    } else if low > 0 {
        values.extend(low..=high);
    } else {
        values.extend((low..=high).rev());
    }
    Ok(values)
}

fn add_image(delta: [f64; 3], cell: [[f64; 3]; 3], image: [i32; 3]) -> [f64; 3] {
    std::array::from_fn(|axis| {
        delta[axis]
            + image[0] as f64 * cell[0][axis]
            + image[1] as f64 * cell[1][axis]
            + image[2] as f64 * cell[2][axis]
    })
}

fn cross(a: [f64; 3], b: [f64; 3]) -> [f64; 3] {
    [
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    ]
}

fn determinant(cell: [[f64; 3]; 3]) -> f64 {
    dot(cell[0], cross(cell[1], cell[2]))
}

fn scale(vector: [f64; 3], factor: f64) -> [f64; 3] {
    vector.map(|value| value * factor)
}

fn sub(a: [f64; 3], b: [f64; 3]) -> [f64; 3] {
    std::array::from_fn(|axis| a[axis] - b[axis])
}

fn dot(a: [f64; 3], b: [f64; 3]) -> f64 {
    a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
}

#[cfg(test)]
mod tests {
    use super::*;

    fn structure(positions_a: Vec<[f64; 3]>, cell_a: [[f64; 3]; 3], pbc: [bool; 3]) -> Structure {
        Structure {
            atomic_numbers: vec![14; positions_a.len()],
            positions_a,
            cell_a,
            pbc,
        }
    }

    #[test]
    fn small_periodic_cell_includes_multiple_images_and_self_images() {
        let structure = structure(
            vec![[0.0, 0.0, 0.0]],
            [[1.5, 0.0, 0.0], [0.0, 1.5, 0.0], [0.0, 0.0, 1.5]],
            [true; 3],
        );
        let graph = NepNeighborGraph::for_structure(&structure, 1.6).unwrap();
        assert_eq!(graph.center_offsets, [0, 6]);
        assert_eq!(graph.neighbors.len(), 6);
        assert!(graph
            .neighbors
            .iter()
            .all(|edge| edge.center == 0 && edge.neighbor == 0 && edge.distance_a == 1.5));
        assert_eq!(
            graph
                .neighbors
                .iter()
                .map(|edge| edge.image)
                .collect::<Vec<_>>(),
            vec![
                [0, 0, 1],
                [0, 0, -1],
                [0, 1, 0],
                [0, -1, 0],
                [1, 0, 0],
                [-1, 0, 0]
            ]
        );
    }

    #[test]
    fn skew_periodic_cell_keeps_image_and_cartesian_displacement() {
        let cell = [[2.0, 0.0, 0.0], [0.7, 1.8, 0.0], [0.2, 0.3, 2.1]];
        let structure = structure(vec![[0.0; 3], [1.9, 0.2, 0.1]], cell, [true; 3]);
        let graph = NepNeighborGraph::for_structure(&structure, 1.0).unwrap();
        let center_zero = graph.for_center(0).unwrap();
        assert!(center_zero.iter().any(|edge| {
            edge.neighbor == 1
                && edge.image == [-1, 0, 0]
                && edge
                    .displacement_a
                    .iter()
                    .zip([-0.1, 0.2, 0.1])
                    .all(|(actual, expected)| (actual - expected).abs() < 1.0e-12)
        }));
        assert!(center_zero
            .iter()
            .all(|edge| edge.distance_a <= 1.0 + 1.0e-10));
    }

    #[test]
    fn nonperiodic_graph_has_no_images_and_cutoff_filter_is_separate() {
        let structure = structure(
            vec![[0.0; 3], [0.5, 0.0, 0.0], [1.5, 0.0, 0.0]],
            [[0.0; 3]; 3],
            [false; 3],
        );
        let graph = NepNeighborGraph::for_structure(&structure, 1.2).unwrap();
        assert_eq!(graph.neighbors.len(), 4);
        assert!(graph.neighbors.iter().all(|edge| edge.image == [0; 3]));
        assert_eq!(graph.within_cutoff_for_center(0, 0.6).unwrap().len(), 1);
        assert!(graph.within_cutoff_for_center(0, 1.3).is_none());
    }

    #[test]
    fn rejects_collisions_and_invalid_cutoffs() {
        let collided = structure(vec![[0.0; 3], [0.0; 3]], [[0.0; 3]; 3], [false; 3]);
        assert!(NepNeighborGraph::for_structure(&collided, 2.0)
            .unwrap_err()
            .contains("coincident atoms"));
        let valid = structure(vec![[0.0; 3]], [[0.0; 3]; 3], [false; 3]);
        assert!(NepNeighborGraph::for_structure(&valid, f64::NAN).is_err());
    }

    #[test]
    fn matches_pinned_nep_cpu_si8_neighbor_order_when_reference_is_supplied() {
        let Some(path) = std::env::var_os("MACER_NEP89_STAGE_REFERENCE") else {
            eprintln!("skipping NEP_CPU stage comparison: MACER_NEP89_STAGE_REFERENCE is unset");
            return;
        };
        let reference: serde_json::Value =
            serde_json::from_slice(&std::fs::read(path).unwrap()).unwrap();
        let fixture = structure(
            vec![
                [0.0, 0.0, 0.0],
                [0.0, 2.715, 2.715],
                [2.715, 0.0, 2.715],
                [2.715, 2.715, 0.0],
                [1.3575, 1.3575, 1.3575],
                [1.3575, 4.0725, 4.0725],
                [4.0725, 1.3575, 4.0725],
                [4.0725, 4.0725, 1.3575],
            ],
            [[5.43, 0.0, 0.0], [0.0, 5.43, 0.0], [0.0, 0.0, 5.43]],
            [true; 3],
        );
        let graph = NepNeighborGraph::for_structure(&fixture, 6.0).unwrap();
        let reference_atoms = reference["neighbors_by_atom"].as_array().unwrap();
        assert_eq!(reference_atoms.len(), fixture.atomic_numbers.len());
        let mut max_displacement_delta = 0.0f64;
        for (atom, reference_atom) in reference_atoms.iter().enumerate() {
            for (cutoff, key) in [(6.0, "radial"), (5.0, "angular")] {
                let actual = graph.within_cutoff_for_center(atom, cutoff).unwrap();
                let expected = reference_atom[key].as_array().unwrap();
                assert_eq!(
                    actual.len(),
                    expected.len(),
                    "{key} neighbor count at atom {atom}"
                );
                for (edge_index, (actual, expected)) in actual.iter().zip(expected).enumerate() {
                    let expected_atom = expected[0].as_u64().unwrap() as u32;
                    assert_eq!(
                        actual.neighbor, expected_atom,
                        "{key} order at atom {atom}, edge {edge_index}"
                    );
                    for axis in 0..3 {
                        let expected_displacement = expected[axis + 1].as_f64().unwrap();
                        let delta = (actual.displacement_a[axis] - expected_displacement).abs();
                        max_displacement_delta = max_displacement_delta.max(delta);
                        assert!(
                            delta < 1.0e-10,
                            "{key} displacement at atom {atom}, edge {edge_index}, axis {axis}: {} vs {expected_displacement}",
                            actual.displacement_a[axis]
                        );
                    }
                }
            }
        }
        println!("NEP89 Si8 neighbor edge counts match; max_displacement_delta_a={max_displacement_delta:.17e}");
    }
}
