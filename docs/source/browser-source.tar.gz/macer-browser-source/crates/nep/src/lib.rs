//! Dependency-light NEP4-ZBL parser, descriptor, and evaluation implementation.
//! This package intentionally has no tensor runtime, model I/O, or network client.

pub mod nep89;
pub mod nep89_descriptors;
pub mod nep89_evaluator;
pub mod nep89_neighbors;
pub mod nep89_network;
pub mod nep89_zbl;
