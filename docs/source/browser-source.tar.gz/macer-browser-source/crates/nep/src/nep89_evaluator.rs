//! NEP89 E/F/virial/stress evaluation assembled from the parser, descriptors,
//! type-specific network, and universal ZBL pair term.

use crate::nep89::Nep4ZblModel;
use crate::nep89_descriptors::{
    angular_descriptors, descriptor_edge_gradients, radial_descriptors,
};
use crate::nep89_neighbors::{NepNeighbor, NepNeighborGraph};
use crate::nep89_network::{evaluate_network, NepNetworkOutput};
use crate::nep89_zbl::evaluate_zbl_pair;
use macer_rust_core::types::{Evaluation, Potential, Structure};

#[derive(Clone, Debug, PartialEq)]
pub struct NepEvaluationOutput {
    pub atomic_energies_ev: Vec<f64>,
    pub forces_ev_per_a: Vec<[f64; 3]>,
    /// Row-major xx,xy,xz,yx,yy,yz,zx,zy,zz per atom, in eV.
    pub per_atom_virial_ev: Vec<[f64; 9]>,
    pub total_virial_ev: [[f64; 3]; 3],
    /// `-virial / volume`; absent for nonperiodic structures.
    pub stress_ev_per_a3: Option<[[f64; 3]; 3]>,
}

impl NepEvaluationOutput {
    pub fn total_energy_ev(&self) -> f64 {
        self.atomic_energies_ev.iter().sum()
    }
}

pub fn evaluate(
    model: &Nep4ZblModel,
    structure: &Structure,
) -> Result<NepEvaluationOutput, String> {
    structure.validate()?;
    let graph_cutoff = model
        .config
        .cutoff_a
        .iter()
        .copied()
        .fold(model.config.zbl_transition_a[1], f64::max);
    let graph = NepNeighborGraph::for_structure(structure, graph_cutoff)?;
    let mut descriptors = radial_descriptors(model, structure, &graph)?;
    let angular = angular_descriptors(model, structure, &graph)?;
    for (row, angular_row) in descriptors.iter_mut().zip(angular) {
        row.extend(angular_row);
    }
    let descriptor_gradients = descriptor_edge_gradients(model, structure, &graph)?;
    let network = evaluate_network(model, &structure.atomic_numbers, &descriptors)?;
    assemble_evaluation(model, structure, &graph, network, descriptor_gradients)
}

/// Energy-only compatibility API retained for the early N04 parity checks.
pub fn evaluate_energy(
    model: &Nep4ZblModel,
    structure: &Structure,
) -> Result<NepEnergyOutput, String> {
    let output = evaluate(model, structure)?;
    Ok(NepEnergyOutput {
        atomic_energies_ev: output.atomic_energies_ev,
    })
}

#[derive(Clone, Debug, PartialEq)]
pub struct NepEnergyOutput {
    pub atomic_energies_ev: Vec<f64>,
}

impl NepEnergyOutput {
    pub fn total_energy_ev(&self) -> f64 {
        self.atomic_energies_ev.iter().sum()
    }
}

pub fn assemble_evaluation(
    model: &Nep4ZblModel,
    structure: &Structure,
    graph: &NepNeighborGraph,
    network: NepNetworkOutput,
    descriptor_gradients: Vec<Vec<Vec<[f64; 3]>>>,
) -> Result<NepEvaluationOutput, String> {
    structure.validate()?;
    let atom_count = structure.atomic_numbers.len();
    if network.atomic_energies_ev.len() != atom_count
        || network.d_energy_d_descriptor.len() != atom_count
        || graph.center_offsets.len() != atom_count + 1
        || descriptor_gradients.len() != atom_count
    {
        return Err("NEP evaluator input dimensions do not match the structure".into());
    }
    let descriptor_count = model.config.descriptor_count()?;
    let mut output = NepEvaluationOutput {
        atomic_energies_ev: network.atomic_energies_ev,
        forces_ev_per_a: vec![[0.0; 3]; atom_count],
        per_atom_virial_ev: vec![[0.0; 9]; atom_count],
        total_virial_ev: [[0.0; 3]; 3],
        stress_ev_per_a3: None,
    };

    // Network/descriptor force and virial. Each descriptor is centered on one
    // atom; its edge gradient is dE_center/d(r_neighbor(image)-r_center).
    for center in 0..atom_count {
        let descriptor_derivative = &network.d_energy_d_descriptor[center];
        let edges = graph
            .for_center(center)
            .ok_or_else(|| "NEP graph is missing a center row".to_owned())?;
        if descriptor_derivative.len() != descriptor_count
            || descriptor_gradients[center].len() != edges.len()
        {
            return Err(format!(
                "NEP descriptor-gradient dimensions are invalid at atom {center}"
            ));
        }
        for (edge_index, edge) in edges.iter().enumerate() {
            if descriptor_gradients[center][edge_index].len() != descriptor_count {
                return Err(format!(
                    "NEP descriptor-gradient row is invalid at atom {center}"
                ));
            }
            let mut d_energy_d_displacement = [0.0; 3];
            for (component, &derivative) in descriptor_derivative.iter().enumerate() {
                for axis in 0..3 {
                    d_energy_d_displacement[axis] +=
                        derivative * descriptor_gradients[center][edge_index][component][axis];
                }
            }
            accumulate_edge_derivative(
                &mut output,
                atom_count,
                center,
                edge,
                d_energy_d_displacement,
            );
        }
    }

    // The universal ZBL correction is a pair term. NEP_CPU visits directed
    // pairs and assigns half the pair energy/derivative to each direction.
    let zbl_cutoff = model.config.zbl_transition_a[1];
    if !zbl_cutoff.is_finite() || zbl_cutoff <= 0.0 || graph.cutoff_a + 1.0e-10 < zbl_cutoff {
        return Err("NEP graph cutoff does not cover the valid ZBL cutoff".into());
    }
    for center in 0..atom_count {
        for edge in graph
            .within_cutoff_for_center(center, zbl_cutoff)
            .ok_or_else(|| "invalid NEP ZBL cutoff".to_owned())?
        {
            let pair = evaluate_zbl_pair(
                model,
                structure.atomic_numbers[center],
                structure.atomic_numbers[edge.neighbor as usize],
                edge.distance_a,
            )?;
            output.atomic_energies_ev[center] += 0.5 * pair.energy_ev;
            let derivative = 0.5 * pair.d_energy_d_distance_ev_per_a;
            let d_energy_d_displacement = edge
                .displacement_a
                .map(|component| derivative * component / edge.distance_a);
            accumulate_edge_derivative(
                &mut output,
                atom_count,
                center,
                edge,
                d_energy_d_displacement,
            );
        }
    }

    if output
        .atomic_energies_ev
        .iter()
        .any(|value| !value.is_finite())
        || output
            .forces_ev_per_a
            .iter()
            .flatten()
            .any(|value| !value.is_finite())
        || output
            .per_atom_virial_ev
            .iter()
            .flatten()
            .any(|value| !value.is_finite())
    {
        return Err("NEP evaluation produced a non-finite result".into());
    }
    for atom_virial in &output.per_atom_virial_ev {
        for row in 0..3 {
            for column in 0..3 {
                output.total_virial_ev[row][column] += atom_virial[row * 3 + column];
            }
        }
    }
    if structure.pbc.iter().any(|&periodic| periodic) {
        let volume = determinant(structure.cell_a).abs();
        if !volume.is_finite() || volume.abs() < 1.0e-12 {
            return Err("periodic NEP stress requires a nonsingular cell".into());
        }
        output.stress_ev_per_a3 = Some(std::array::from_fn(|row| {
            std::array::from_fn(|column| -output.total_virial_ev[row][column] / volume)
        }));
    }
    Ok(output)
}

fn accumulate_edge_derivative(
    output: &mut NepEvaluationOutput,
    atom_count: usize,
    center: usize,
    edge: &NepNeighbor,
    d_energy_d_displacement: [f64; 3],
) {
    let neighbor = edge.neighbor as usize;
    for axis in 0..3 {
        output.forces_ev_per_a[center][axis] += d_energy_d_displacement[axis];
        output.forces_ev_per_a[neighbor][axis] -= d_energy_d_displacement[axis];
    }
    // NEP_CPU stores each directed edge virial on its neighbor atom. The
    // convention is W_ab = -R_a * dE/dR_b and stress = -W / volume.
    if neighbor < atom_count {
        for row in 0..3 {
            for column in 0..3 {
                output.per_atom_virial_ev[neighbor][row * 3 + column] -=
                    edge.displacement_a[row] * d_energy_d_displacement[column];
            }
        }
    }
}

fn determinant(cell: [[f64; 3]; 3]) -> f64 {
    cell[0][0] * (cell[1][1] * cell[2][2] - cell[1][2] * cell[2][1])
        - cell[0][1] * (cell[1][0] * cell[2][2] - cell[1][2] * cell[2][0])
        + cell[0][2] * (cell[1][0] * cell[2][1] - cell[1][1] * cell[2][0])
}

impl Potential for Nep4ZblModel {
    fn evaluate(&mut self, structure: &Structure) -> Result<Evaluation, String> {
        let output = crate::nep89_evaluator::evaluate(self, structure)?;
        let periodic = structure.pbc.iter().any(|&enabled| enabled);
        let stresses_ev_per_a3 = if periodic {
            let volume = structure.signed_volume_a3().abs();
            Some(
                output
                    .per_atom_virial_ev
                    .iter()
                    .map(|virial| {
                        std::array::from_fn(|row| {
                            std::array::from_fn(|column| -virial[row * 3 + column] / volume)
                        })
                    })
                    .collect(),
            )
        } else {
            None
        };
        Ok(Evaluation {
            energy_ev: output.total_energy_ev(),
            forces_ev_per_a: output.forces_ev_per_a,
            stress_ev_per_a3: output.stress_ev_per_a3.unwrap_or([[0.0; 3]; 3]),
            energies_ev: Some(output.atomic_energies_ev),
            stresses_ev_per_a3,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn si8() -> Structure {
        Structure {
            atomic_numbers: vec![14; 8],
            positions_a: vec![
                [0.0, 0.0, 0.0],
                [0.0, 2.715, 2.715],
                [2.715, 0.0, 2.715],
                [2.715, 2.715, 0.0],
                [1.3575, 1.3575, 1.3575],
                [1.3575, 4.0725, 4.0725],
                [4.0725, 1.3575, 4.0725],
                [4.0725, 4.0725, 1.3575],
            ],
            cell_a: [[5.43, 0.0, 0.0], [0.0, 5.43, 0.0], [0.0, 0.0, 5.43]],
            pbc: [true; 3],
        }
    }

    fn skew_mixed() -> Structure {
        Structure {
            atomic_numbers: vec![14, 6, 8, 1, 26],
            positions_a: vec![
                [1.04, 1.065, 1.35],
                [3.536, 2.135, 1.53],
                [2.264, 4.914, 2.7],
                [6.187, 6.591, 6.48],
                [7.568, 2.606, 3.78],
            ],
            cell_a: [[8.4, 0.0, 0.0], [1.1, 8.7, 0.0], [0.6, 1.3, 9.0]],
            pbc: [true; 3],
        }
    }

    fn nonperiodic_mixed() -> Structure {
        Structure {
            atomic_numbers: vec![14, 6, 8, 1, 26],
            positions_a: vec![
                [0.0, 0.0, 0.0],
                [1.34, 0.2, 0.0],
                [-1.0, 0.8, 0.3],
                [0.3, -1.7, 0.5],
                [12.0, 0.0, 0.0],
            ],
            cell_a: [[0.0; 3]; 3],
            pbc: [false; 3],
        }
    }

    #[test]
    fn official_nep89_si8_energy_force_virial_and_stress_match_pinned_cpu_reference_when_supplied()
    {
        let Some(model_path) = std::env::var_os("MACER_NEP89_MODEL") else {
            eprintln!("skipping NEP_CPU evaluator comparison: model env is unset");
            return;
        };
        let model = Nep4ZblModel::from_bytes(&std::fs::read(model_path).unwrap()).unwrap();
        let reference: serde_json::Value = serde_json::from_str(include_str!(
            "../../../evidence/nep89_reference_2026-10-25/oracle-results.json"
        ))
        .unwrap();
        let output = evaluate(&model, &si8()).unwrap();
        let expected_energy = reference["reference_output"]["energy_ev"].as_f64().unwrap();
        let energy_delta = (output.total_energy_ev() - expected_energy).abs();
        assert!(energy_delta <= 1.0e-9);
        let mut max_force_delta: f64 = 0.0;
        for (actual, expected) in output.forces_ev_per_a.iter().flatten().zip(
            reference["reference_output"]["forces_ev_per_a"]
                .as_array()
                .unwrap()
                .iter()
                .flat_map(|row| row.as_array().unwrap())
                .map(|value| value.as_f64().unwrap()),
        ) {
            max_force_delta = max_force_delta.max((actual - expected).abs());
        }
        let expected_virial = &reference["reference_output"]["total_virial_ev"];
        let mut max_virial_delta: f64 = 0.0;
        let mut max_stress_delta: f64 = 0.0;
        for row in 0..3 {
            for column in 0..3 {
                let expected = expected_virial[row][column].as_f64().unwrap();
                max_virial_delta =
                    max_virial_delta.max((output.total_virial_ev[row][column] - expected).abs());
                let expected_stress = reference["reference_output"]["stress_ev_per_a3"][row]
                    [column]
                    .as_f64()
                    .unwrap();
                max_stress_delta = max_stress_delta
                    .max((output.stress_ev_per_a3.unwrap()[row][column] - expected_stress).abs());
            }
        }
        println!(
            "NEP Si8 parity energy={energy_delta:.3e} eV force={max_force_delta:.3e} eV/A virial={max_virial_delta:.3e} eV stress={max_stress_delta:.3e} eV/A^3"
        );
        assert!(max_force_delta <= 1.0e-8);
        assert!(max_virial_delta <= 1.0e-8);
        assert!(max_stress_delta <= 1.0e-10);
    }

    #[test]
    fn analytic_force_matches_coordinate_finite_difference_when_model_is_supplied() {
        let Some(model_path) = std::env::var_os("MACER_NEP89_MODEL") else {
            eprintln!("skipping NEP force finite difference: model env is unset");
            return;
        };
        let model = Nep4ZblModel::from_bytes(&std::fs::read(model_path).unwrap()).unwrap();
        let mut structure = si8();
        structure.positions_a[0][0] += 0.03;
        let analytic = evaluate(&model, &structure).unwrap().forces_ev_per_a[0][0];
        let h = 1.0e-5;
        let mut plus = structure.clone();
        let mut minus = structure;
        plus.positions_a[0][0] += h;
        minus.positions_a[0][0] -= h;
        let derivative = (evaluate(&model, &plus).unwrap().total_energy_ev()
            - evaluate(&model, &minus).unwrap().total_energy_ev())
            / (2.0 * h);
        let error = (analytic + derivative).abs();
        println!("NEP force coordinate FD abs_delta={error:.17e} eV/A");
        assert!(error <= 2.0e-5, "force/finite-difference mismatch {error}");
    }

    #[test]
    fn mixed_element_skew_cell_e_f_virial_and_finite_differences_match_when_model_is_supplied() {
        let Some(model_path) = std::env::var_os("MACER_NEP89_MODEL") else {
            eprintln!("skipping NEP mixed-cell evaluator comparison: model env is unset");
            return;
        };
        let model = Nep4ZblModel::from_bytes(&std::fs::read(model_path).unwrap()).unwrap();
        let reference: serde_json::Value = serde_json::from_str(include_str!(
            "../../../evidence/nep89_evaluator_2026-10-25/skew_mixed-reference.json"
        ))
        .unwrap();
        let structure = skew_mixed();
        let output = evaluate(&model, &structure).unwrap();
        let energy_delta =
            (output.total_energy_ev() - reference["energy_ev"].as_f64().unwrap()).abs();
        let expected_forces = reference["forces_ev_per_a"].as_array().unwrap();
        let mut max_force_delta: f64 = 0.0;
        for (atom, expected) in expected_forces.iter().enumerate() {
            for axis in 0..3 {
                max_force_delta = max_force_delta.max(
                    (output.forces_ev_per_a[atom][axis] - expected[axis].as_f64().unwrap()).abs(),
                );
            }
        }
        let expected_atom_virials = reference["per_atom_virial_ev"].as_array().unwrap();
        let mut max_atom_virial_delta: f64 = 0.0;
        for (atom, expected) in expected_atom_virials.iter().enumerate() {
            for component in 0..9 {
                max_atom_virial_delta = max_atom_virial_delta.max(
                    (output.per_atom_virial_ev[atom][component]
                        - expected[component].as_f64().unwrap())
                    .abs(),
                );
            }
        }
        println!(
            "NEP mixed skew parity energy={energy_delta:.3e} eV force={max_force_delta:.3e} eV/A per_atom_virial={max_atom_virial_delta:.3e} eV"
        );
        assert!(energy_delta <= 1.0e-9);
        assert!(max_force_delta <= 1.0e-8);
        assert!(max_atom_virial_delta <= 1.0e-8);

        let coordinate_step = 1.0e-5;
        let mut plus = structure.clone();
        let mut minus = structure.clone();
        plus.positions_a[0][0] += coordinate_step;
        minus.positions_a[0][0] -= coordinate_step;
        let coordinate_derivative = (evaluate(&model, &plus).unwrap().total_energy_ev()
            - evaluate(&model, &minus).unwrap().total_energy_ev())
            / (2.0 * coordinate_step);
        let coordinate_error = (output.forces_ev_per_a[0][0] + coordinate_derivative).abs();
        assert!(
            coordinate_error <= 2.0e-5,
            "mixed force FD error {coordinate_error}"
        );

        let strain_step = 1.0e-5;
        let strained = |sign: f64| {
            let factor = 1.0 + sign * strain_step;
            let mut changed = structure.clone();
            for vector in &mut changed.cell_a {
                vector[0] *= factor;
            }
            for position in &mut changed.positions_a {
                position[0] *= factor;
            }
            changed
        };
        let strain_derivative = (evaluate(&model, &strained(1.0)).unwrap().total_energy_ev()
            - evaluate(&model, &strained(-1.0)).unwrap().total_energy_ev())
            / (2.0 * strain_step);
        let strain_error = (strain_derivative + output.total_virial_ev[0][0]).abs();
        println!(
            "NEP mixed finite differences coordinate={coordinate_error:.3e} eV/A strain={strain_error:.3e} eV"
        );
        assert!(
            strain_error <= 1.0e-4,
            "mixed strain FD error {strain_error}"
        );
    }

    #[test]
    fn nonperiodic_mixed_cluster_e_f_and_virial_match_no_image_cpu_reference_when_supplied() {
        let Some(model_path) = std::env::var_os("MACER_NEP89_MODEL") else {
            eprintln!("skipping NEP nonperiodic evaluator comparison: model env is unset");
            return;
        };
        let model = Nep4ZblModel::from_bytes(&std::fs::read(model_path).unwrap()).unwrap();
        let reference: serde_json::Value = serde_json::from_str(include_str!(
            "../../../evidence/nep89_evaluator_2026-10-25/nonperiodic_mixed-reference.json"
        ))
        .unwrap();
        let output = evaluate(&model, &nonperiodic_mixed()).unwrap();
        assert!(output.stress_ev_per_a3.is_none());
        let energy_delta =
            (output.total_energy_ev() - reference["energy_ev"].as_f64().unwrap()).abs();
        let mut max_force_delta: f64 = 0.0;
        let mut max_virial_delta: f64 = 0.0;
        for (atom, expected) in reference["forces_ev_per_a"]
            .as_array()
            .unwrap()
            .iter()
            .enumerate()
        {
            for axis in 0..3 {
                max_force_delta = max_force_delta.max(
                    (output.forces_ev_per_a[atom][axis] - expected[axis].as_f64().unwrap()).abs(),
                );
            }
        }
        for (atom, expected) in reference["per_atom_virial_ev"]
            .as_array()
            .unwrap()
            .iter()
            .enumerate()
        {
            for component in 0..9 {
                max_virial_delta = max_virial_delta.max(
                    (output.per_atom_virial_ev[atom][component]
                        - expected[component].as_f64().unwrap())
                    .abs(),
                );
            }
        }
        println!(
            "NEP nonperiodic parity energy={energy_delta:.3e} eV force={max_force_delta:.3e} eV/A virial={max_virial_delta:.3e} eV"
        );
        assert!(energy_delta <= 1.0e-9);
        assert!(max_force_delta <= 1.0e-8);
        assert!(max_virial_delta <= 1.0e-8);
    }

    #[test]
    fn short_silicon_pair_total_energy_force_and_virial_match_pinned_zbl_reference_when_supplied() {
        let Some(model_path) = std::env::var_os("MACER_NEP89_MODEL") else {
            eprintln!("skipping NEP_CPU ZBL comparison: model env is unset");
            return;
        };
        let model = Nep4ZblModel::from_bytes(&std::fs::read(model_path).unwrap()).unwrap();
        let reference: serde_json::Value = serde_json::from_str(include_str!(
            "../../../evidence/nep89_evaluator_2026-10-25/zbl_si2-reference.json"
        ))
        .unwrap();
        let structure = Structure {
            atomic_numbers: vec![14, 14],
            positions_a: vec![[0.0, 0.0, 0.0], [1.25, 0.0, 0.0]],
            cell_a: [[30.0, 0.0, 0.0], [0.0, 30.0, 0.0], [0.0, 0.0, 30.0]],
            pbc: [true; 3],
        };
        let output = evaluate(&model, &structure).unwrap();
        let expected = reference["energy_ev"].as_f64().unwrap();
        let energy_delta = (output.total_energy_ev() - expected).abs();
        assert!(energy_delta <= 1.0e-10);
        let mut max_force_delta: f64 = 0.0;
        for (actual, expected) in output.forces_ev_per_a.iter().flatten().zip(
            reference["forces_ev_per_a"]
                .as_array()
                .unwrap()
                .iter()
                .flat_map(|row| row.as_array().unwrap())
                .map(|value| value.as_f64().unwrap()),
        ) {
            max_force_delta = max_force_delta.max((actual - expected).abs());
        }
        let mut max_virial_delta: f64 = 0.0;
        for (actual, expected) in output.per_atom_virial_ev.iter().flatten().zip(
            reference["per_atom_virial_ev"]
                .as_array()
                .unwrap()
                .iter()
                .flat_map(|row| row.as_array().unwrap())
                .map(|value| value.as_f64().unwrap()),
        ) {
            max_virial_delta = max_virial_delta.max((actual - expected).abs());
        }
        println!(
            "NEP ZBL Si2 parity energy={energy_delta:.3e} eV force={max_force_delta:.3e} eV/A per_atom_virial={max_virial_delta:.3e} eV"
        );
        assert!(max_force_delta <= 1.0e-9);
        assert!(max_virial_delta <= 1.0e-9);
    }
}
