//! ASE-compatible Lennard-Jones calculator used by Macer's `lj` backend.
//!
//! The pair enumeration includes periodic self images and evaluates bothways,
//! matching ASE's NeighborList contract. Energies use ASE's default shifted
//! cutoff unless smooth mode is requested.

use crate::types::{Evaluation, Potential, Structure};

// Values are resolved from ASE's 2026 baseline constants and frozen here;
// the Macer source imports Hartree/Bohr at runtime and does not pin ASE.
const DEFAULT_EPSILON_EV: f64 = 0.000_379_28 * 27.211_386_024_367_243;
const DEFAULT_SIGMA_A: f64 = 6.434_516_99 * 0.529_177_210_563_841_1;

#[derive(Clone, Debug)]
pub struct LennardJones {
    pub epsilon_ev: f64,
    pub sigma_a: f64,
    pub cutoff_a: f64,
    pub onset_a: f64,
    pub smooth: bool,
}

impl Default for LennardJones {
    fn default() -> Self {
        let sigma_a = DEFAULT_SIGMA_A;
        let cutoff_a = 3.0 * sigma_a;
        Self {
            epsilon_ev: DEFAULT_EPSILON_EV,
            sigma_a,
            cutoff_a,
            onset_a: 0.66 * cutoff_a,
            smooth: false,
        }
    }
}

impl LennardJones {
    pub fn new(
        epsilon_ev: f64,
        sigma_a: f64,
        cutoff_a: Option<f64>,
        onset_a: Option<f64>,
        smooth: bool,
    ) -> Result<Self, String> {
        let cutoff_a = cutoff_a.unwrap_or(3.0 * sigma_a);
        let onset_a = onset_a.unwrap_or(0.66 * cutoff_a);
        if !epsilon_ev.is_finite() {
            return Err("Lennard-Jones epsilon must be finite".into());
        }
        if !sigma_a.is_finite() || sigma_a <= 0.0 {
            return Err("Lennard-Jones sigma must be positive and finite".into());
        }
        if !cutoff_a.is_finite() || cutoff_a <= 0.0 {
            return Err("Lennard-Jones cutoff must be positive and finite".into());
        }
        if !onset_a.is_finite() || onset_a < 0.0 || onset_a >= cutoff_a {
            return Err("Lennard-Jones onset must be finite and in [0, cutoff)".into());
        }
        Ok(Self {
            epsilon_ev,
            sigma_a,
            cutoff_a,
            onset_a,
            smooth,
        })
    }

    fn evaluate_validated(&self, structure: &Structure) -> Result<Evaluation, String> {
        let n = structure.atomic_numbers.len();
        let periodic = structure.pbc.iter().any(|&axis| axis);
        let volume = determinant(structure.cell_a);
        if periodic && volume.abs() < 1e-12 {
            return Err("periodic Lennard-Jones evaluation requires a nonsingular cell".into());
        }

        let reciprocal = if periodic {
            let [a, b, c] = structure.cell_a;
            [cross(b, c), cross(c, a), cross(a, b)].map(|row| row.map(|x| x / volume))
        } else {
            [[0.0; 3]; 3]
        };
        let cutoff2 = self.cutoff_a * self.cutoff_a;
        let onset2 = self.onset_a * self.onset_a;
        let sigma2 = self.sigma_a * self.sigma_a;
        let cutoff_c6 = (sigma2 / cutoff2).powi(3);
        let cutoff_energy = 4.0 * self.epsilon_ev * (cutoff_c6 * cutoff_c6 - cutoff_c6);
        let mut energy = 0.0;
        let mut per_atom_energy = vec![0.0; n];
        let mut forces = vec![[0.0; 3]; n];
        let mut virial = [[0.0; 3]; 3];
        let mut per_atom_virial = vec![[[0.0; 3]; 3]; n];

        for i in 0..n {
            for j in 0..n {
                let delta = std::array::from_fn(|axis| {
                    structure.positions_a[j][axis] - structure.positions_a[i][axis]
                });
                let mut ranges = [(0_i32, 0_i32); 3];
                if periodic {
                    for axis in 0..3 {
                        if structure.pbc[axis] {
                            let fractional = dot(delta, reciprocal[axis]);
                            let radius = self.cutoff_a
                                * dot(reciprocal[axis], reciprocal[axis]).sqrt()
                                + 1e-8;
                            let low = (-fractional - radius).ceil();
                            let high = (-fractional + radius).floor();
                            if low < i32::MIN as f64 || high > i32::MAX as f64 {
                                return Err("Lennard-Jones periodic image range exceeds i32".into());
                            }
                            ranges[axis] = (low as i32, high as i32);
                        }
                    }
                }

                for nx in ranges[0].0..=ranges[0].1 {
                    for ny in ranges[1].0..=ranges[1].1 {
                        for nz in ranges[2].0..=ranges[2].1 {
                            if i == j && nx == 0 && ny == 0 && nz == 0 {
                                continue;
                            }
                            let image = [nx, ny, nz];
                            let displacement = std::array::from_fn(|axis| {
                                delta[axis]
                                    + (0..3)
                                        .map(|k| image[k] as f64 * structure.cell_a[k][axis])
                                        .sum::<f64>()
                            });
                            let distance2 = dot(displacement, displacement);
                            if distance2 > cutoff2 {
                                continue;
                            }
                            if distance2 <= 1e-24 {
                                return Err(format!(
                                    "overlapping atoms in Lennard-Jones pair {i},{j}"
                                ));
                            }

                            let c6 = (sigma2 / distance2).powi(3);
                            let c12 = c6 * c6;
                            let raw_energy = 4.0 * self.epsilon_ev * (c12 - c6);
                            let mut pair_energy = raw_energy;
                            let mut pair_force_factor =
                                -24.0 * self.epsilon_ev * (2.0 * c12 - c6) / distance2;

                            if self.smooth {
                                let (cutoff, cutoff_derivative) =
                                    smooth_cutoff(distance2, cutoff2, onset2);
                                pair_force_factor = cutoff * pair_force_factor
                                    + 2.0 * cutoff_derivative * raw_energy;
                                pair_energy *= cutoff;
                            } else {
                                pair_energy -= cutoff_energy;
                            }

                            energy += 0.5 * pair_energy;
                            per_atom_energy[i] += 0.5 * pair_energy;
                            for a in 0..3 {
                                let pair_force = pair_force_factor * displacement[a];
                                forces[i][a] += pair_force;
                                for b in 0..3 {
                                    let atomic_virial = 0.5 * pair_force * displacement[b];
                                    virial[a][b] += atomic_virial;
                                    per_atom_virial[i][a][b] += atomic_virial;
                                }
                            }
                        }
                    }
                }
            }
        }

        let (stress_ev_per_a3, stresses_ev_per_a3) = if volume.abs() >= 1e-12 {
            let absolute_volume = volume.abs();
            let stress = virial.map(|row| row.map(|value| value / absolute_volume));
            let atomic_stresses = per_atom_virial
                .into_iter()
                .map(|tensor| tensor.map(|row| row.map(|value| value / absolute_volume)))
                .collect();
            (stress, Some(atomic_stresses))
        } else {
            ([[0.0; 3]; 3], None)
        };
        let result = Evaluation {
            energy_ev: energy,
            forces_ev_per_a: forces,
            stress_ev_per_a3,
            energies_ev: Some(per_atom_energy),
            stresses_ev_per_a3,
        };
        result.validate(n)?;
        Ok(result)
    }
}

impl Potential for LennardJones {
    fn evaluate(&mut self, structure: &Structure) -> Result<Evaluation, String> {
        structure.validate()?;
        self.evaluate_validated(structure)
    }
}

fn smooth_cutoff(distance2: f64, cutoff2: f64, onset2: f64) -> (f64, f64) {
    if distance2 < onset2 {
        (1.0, 0.0)
    } else if distance2 < cutoff2 {
        let denominator = (cutoff2 - onset2).powi(3);
        let cutoff = (cutoff2 - distance2).powi(2) * (cutoff2 + 2.0 * distance2 - 3.0 * onset2)
            / denominator;
        let derivative = 6.0 * (cutoff2 - distance2) * (onset2 - distance2) / denominator;
        (cutoff, derivative)
    } else {
        (0.0, 0.0)
    }
}

fn cross(a: [f64; 3], b: [f64; 3]) -> [f64; 3] {
    [
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    ]
}

fn dot(a: [f64; 3], b: [f64; 3]) -> f64 {
    a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
}

fn determinant(cell: [[f64; 3]; 3]) -> f64 {
    dot(cell[0], cross(cell[1], cell[2]))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn atoms(positions: Vec<[f64; 3]>, cell: [[f64; 3]; 3], pbc: [bool; 3]) -> Structure {
        Structure {
            atomic_numbers: vec![18; positions.len()],
            positions_a: positions,
            cell_a: cell,
            pbc,
        }
    }

    #[test]
    fn default_parameters_match_macer_argon_mapping() {
        let lj = LennardJones::default();
        assert!((lj.epsilon_ev - 0.010_320_734_491_322_009).abs() < 1e-15);
        assert!((lj.sigma_a - 3.404_999_752_093_843_3).abs() < 1e-14);
        assert!((lj.cutoff_a - 3.0 * lj.sigma_a).abs() < 1e-15);
    }

    #[test]
    fn open_boundary_pair_has_equal_opposite_forces() {
        let mut lj = LennardJones::default();
        let structure = atoms(
            vec![[0.0, 0.0, 0.0], [4.2, 0.0, 0.0]],
            [[20.0, 0.0, 0.0], [0.0, 20.0, 0.0], [0.0, 0.0, 20.0]],
            [false; 3],
        );
        let result = lj.evaluate(&structure).unwrap();
        assert!((result.energy_ev - -0.008_336_784_592_018_063).abs() < 1e-14);
        assert!((result.forces_ev_per_a[0][0] - 0.007_236_186_067_714_184).abs() < 1e-14);
        assert!((result.forces_ev_per_a[0][0] + result.forces_ev_per_a[1][0]).abs() < 1e-14);
        assert!((result.stress_ev_per_a3[0][0] - 3.798_997_685_549_946_2e-6).abs() < 1e-16);
        let per_atom_energies = result.energies_ev.as_ref().unwrap();
        assert!((per_atom_energies.iter().sum::<f64>() - result.energy_ev).abs() < 1e-14);
        let per_atom_stress = result.stresses_ev_per_a3.as_ref().unwrap();
        assert!(
            (per_atom_stress.iter().map(|s| s[0][0]).sum::<f64>() - result.stress_ev_per_a3[0][0])
                .abs()
                < 1e-16
        );
    }

    #[test]
    fn overlapping_atoms_and_invalid_parameters_are_rejected() {
        assert!(LennardJones::new(1.0, 1.0, Some(3.0), Some(3.0), false).is_err());
        let mut lj = LennardJones::default();
        let structure = atoms(
            vec![[0.0; 3], [0.0; 3]],
            [[10.0, 0.0, 0.0], [0.0, 10.0, 0.0], [0.0, 0.0, 10.0]],
            [false; 3],
        );
        assert!(lj
            .evaluate(&structure)
            .unwrap_err()
            .contains("overlapping atoms"));
    }

    #[test]
    fn smooth_cutoff_matches_ase_reference() {
        let mut lj = LennardJones::new(0.2, 2.0, Some(6.0), Some(4.0), true).unwrap();
        let structure = atoms(
            vec![[0.0, 0.0, 0.0], [4.5, 0.0, 0.0]],
            [[20.0, 0.0, 0.0], [0.0, 20.0, 0.0], [0.0, 0.0, 20.0]],
            [false; 3],
        );
        let result = lj.evaluate(&structure).unwrap();
        assert!((result.energy_ev - -0.005_406_928_711_334_451_5).abs() < 1e-14);
        assert!((result.forces_ev_per_a[0][0] - 0.009_917_687_359_987_704).abs() < 1e-14);
        assert!((result.stress_ev_per_a3[0][0] - 5.578_699_139_993_083_4e-6).abs() < 1e-16);
    }

    #[test]
    fn periodic_self_images_match_ase_reference() {
        let mut lj = LennardJones::new(0.2, 2.0, Some(6.0), Some(4.0), true).unwrap();
        let structure = atoms(
            vec![[0.0; 3]],
            [[5.0, 0.0, 0.0], [0.0, 5.0, 0.0], [0.0, 0.0, 5.0]],
            [true; 3],
        );
        let result = lj.evaluate(&structure).unwrap();
        result.validate(1).unwrap();
        assert!((result.energy_ev - -0.005_626_879_908_249_601).abs() < 1e-13);
        assert!((result.energies_ev.as_ref().unwrap()[0] - result.energy_ev).abs() < 1e-14);
        assert!(result.forces_ev_per_a[0]
            .iter()
            .all(|value| value.abs() < 1e-14));
        for axis in 0..3 {
            assert!(
                (result.stress_ev_per_a3[axis][axis] - 0.000_186_582_132_011_827_36).abs() < 1e-14
            );
        }
    }
}
