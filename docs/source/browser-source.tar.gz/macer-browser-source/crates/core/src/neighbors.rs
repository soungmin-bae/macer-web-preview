//! Deterministic periodic radius graph for MatterSim 5M.
//! Edge order follows pymatgen 2025.10.7's linked-cell enumeration: neighbor
//! cube offsets are lexicographic, and points within a cube are traversed in
//! reverse image-expansion order. This order is verified against frozen graphs.

use crate::types::Structure;

#[derive(Clone, Debug)]
pub struct RadiusGraph {
    pub source: Vec<u32>,
    pub destination: Vec<u32>,
    pub offsets: Vec<[f32; 3]>,
    pub triple_first: Vec<u32>,
    pub triple_second: Vec<u32>,
}

fn cross(a: [f64; 3], b: [f64; 3]) -> [f64; 3] {
    [
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    ]
}

fn dot(a: [f64; 3], b: [f64; 3]) -> f64 {
    a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
}

fn dot_fma(a: [f64; 3], b: [f64; 3]) -> f64 {
    let mut result = 0.;
    for k in 0..3 {
        result = a[k].mul_add(b[k], result);
    }
    result
}

// ASE uses a linear solve for scaled coordinates. Explicit LU/FMA keeps
// boundary rounding stable for the linked-cell neighbor enumeration.
pub fn scaled_positions(cell: [[f64; 3]; 3], position: [f64; 3]) -> Result<[f64; 3], String> {
    let mut lu: [[f64; 3]; 3] =
        std::array::from_fn(|row| std::array::from_fn(|column| cell[column][row]));
    let mut pivots = [0usize; 3];
    for k in 0..3 {
        let pivot = (k..3)
            .max_by(|&a, &b| lu[a][k].abs().total_cmp(&lu[b][k].abs()))
            .unwrap();
        if lu[pivot][k].abs() < 1e-14 {
            return Err("scaled positions require a nonsingular cell".into());
        }
        lu.swap(k, pivot);
        pivots[k] = pivot;
        for i in k + 1..3 {
            lu[i][k] /= lu[k][k];
            for j in k + 1..3 {
                lu[i][j] = (-lu[i][k]).mul_add(lu[k][j], lu[i][j]);
            }
        }
    }
    let mut value = position;
    for (k, &pivot) in pivots.iter().enumerate() {
        value.swap(k, pivot);
    }
    for k in 0..3 {
        for i in k + 1..3 {
            value[i] = (-lu[i][k]).mul_add(value[k], value[i]);
        }
    }
    for k in (0..3).rev() {
        value[k] /= lu[k][k];
        for i in 0..k {
            value[i] = (-lu[i][k]).mul_add(value[k], value[i]);
        }
    }
    Ok(value)
}

pub fn wrapped_structure(structure: &Structure) -> Result<Structure, String> {
    structure.validate()?;
    let mut wrapped = structure.clone();
    if !structure.pbc.iter().any(|&v| v) {
        return Ok(wrapped);
    }
    let cell = structure.cell_a;
    for (position, original) in wrapped.positions_a.iter_mut().zip(&structure.positions_a) {
        let raw_frac = scaled_positions(cell, *original)?;
        let frac: [f64; 3] = std::array::from_fn(|k| {
            let f = raw_frac[k];
            if structure.pbc[k] {
                f.rem_euclid(1.)
            } else {
                f
            }
        });
        *position = std::array::from_fn(|axis| {
            let mut value = 0.;
            for k in 0..3 {
                value = frac[k].mul_add(cell[k][axis], value);
            }
            value
        });
    }
    Ok(wrapped)
}

pub fn radius_graph(
    structure: &Structure,
    cutoff_a: f64,
    triple_cutoff_a: f64,
) -> Result<RadiusGraph, String> {
    structure.validate()?;
    if !cutoff_a.is_finite()
        || cutoff_a <= 0.0
        || !triple_cutoff_a.is_finite()
        || triple_cutoff_a <= 0.0
    {
        return Err("cutoffs must be finite and positive".into());
    }
    let cell = structure.cell_a;
    let volume = structure.signed_volume_a3();
    if volume.abs() < 1e-12 {
        return Err("radius graph requires a nonsingular cell".into());
    }
    let reciprocal = [
        cross(cell[1], cell[2]).map(|x| x / volume),
        cross(cell[2], cell[0]).map(|x| x / volume),
        cross(cell[0], cell[1]).map(|x| x / volume),
    ];
    let mut source = Vec::new();
    let mut destination = Vec::new();
    let mut offsets = Vec::new();
    let mut lengths = Vec::new();
    let n = structure.atomic_numbers.len();
    for i in 0..n {
        for j in 0..n {
            let delta =
                std::array::from_fn(|k| structure.positions_a[j][k] - structure.positions_a[i][k]);
            let mut ranges = [(0i32, 0i32); 3];
            for k in 0..3 {
                if structure.pbc[k] {
                    let frac = dot(delta, reciprocal[k]);
                    let radius = cutoff_a * dot(reciprocal[k], reciprocal[k]).sqrt() + 1e-8;
                    let low = (-frac - radius).ceil();
                    let high = (-frac + radius).floor();
                    if low < i32::MIN as f64 || high > i32::MAX as f64 {
                        return Err("periodic image range overflows i32".into());
                    }
                    ranges[k] = (low as i32, high as i32);
                }
            }
            for x in ranges[0].0..=ranges[0].1 {
                for y in ranges[1].0..=ranges[1].1 {
                    for z in ranges[2].0..=ranges[2].1 {
                        let image = [x, y, z];
                        let v: [f64; 3] = std::array::from_fn(|k| {
                            delta[k]
                                + image[0] as f64 * cell[0][k]
                                + image[1] as f64 * cell[1][k]
                                + image[2] as f64 * cell[2][k]
                        });
                        let distance2 = dot(v, v);
                        let length = distance2.sqrt();
                        if distance2 < cutoff_a * cutoff_a + 1e-8 && !(i == j && length <= 1e-8) {
                            source.push(i as u32);
                            destination.push(j as u32);
                            offsets.push(image.map(|v| v as f32));
                            lengths.push(length);
                        }
                    }
                }
            }
        }
    }
    // Pymatgen builds a linked list by prepending expanded images to each
    // Cartesian cube. Reconstruct that traversal order from the same image
    // and cube keys. Its cube index uses a positive 1e-8 shift.
    let valid_min: [f64; 3] = std::array::from_fn(|axis| {
        structure
            .positions_a
            .iter()
            .map(|p| p[axis])
            .fold(f64::INFINITY, f64::min)
            - cutoff_a
            - 1e-8
    });
    let cube = |p: [f64; 3]| -> [i64; 3] {
        std::array::from_fn(|axis| ((p[axis] - valid_min[axis] + 1e-8) / cutoff_a).floor() as i64)
    };
    let mut correction = vec![[0i32; 3]; n];
    let mut coords_in_cell = vec![[0f64; 3]; n];
    for j in 0..n {
        let frac: [f64; 3] =
            std::array::from_fn(|k| dot_fma(structure.positions_a[j], reciprocal[k]));
        let wrapped_frac: [f64; 3] = std::array::from_fn(|k| {
            if structure.pbc[k] {
                correction[j][k] = frac[k].floor() as i32;
                frac[k] - correction[j][k] as f64
            } else {
                frac[k]
            }
        });
        for axis in 0..3 {
            for k in 0..3 {
                coords_in_cell[j][axis] += wrapped_frac[k] * cell[k][axis];
            }
        }
    }
    let mut rank = Vec::with_capacity(source.len());
    for edge in 0..source.len() {
        let i = source[edge] as usize;
        let j = destination[edge] as usize;
        let shift = offsets[edge];
        let raw_shift: [i32; 3] = std::array::from_fn(|k| shift[k] as i32 + correction[j][k]);
        let expanded: [f64; 3] = std::array::from_fn(|axis| {
            raw_shift[0] as f64 * cell[0][axis]
                + raw_shift[1] as f64 * cell[1][axis]
                + raw_shift[2] as f64 * cell[2][axis]
                + coords_in_cell[j][axis]
        });
        let center_cube = cube(structure.positions_a[i]);
        let neighbor_cube = cube(expanded);
        let delta: [i64; 3] = std::array::from_fn(|axis| neighbor_cube[axis] - center_cube[axis]);
        rank.push((
            source[edge],
            delta[0],
            delta[1],
            delta[2],
            -raw_shift[0],
            -raw_shift[1],
            -raw_shift[2],
            -(j as i32),
            edge,
        ));
    }
    rank.sort_unstable();
    let reorder_u32 = |values: &Vec<u32>| rank.iter().map(|key| values[key.8]).collect::<Vec<_>>();
    let reorder_offset =
        |values: &Vec<[f32; 3]>| rank.iter().map(|key| values[key.8]).collect::<Vec<_>>();
    let reorder_length =
        |values: &Vec<f64>| rank.iter().map(|key| values[key.8]).collect::<Vec<_>>();
    source = reorder_u32(&source);
    destination = reorder_u32(&destination);
    offsets = reorder_offset(&offsets);
    lengths = reorder_length(&lengths);
    let mut triple_first = Vec::new();
    let mut triple_second = Vec::new();
    let mut groups = vec![Vec::new(); n];
    for (edge, &atom) in source.iter().enumerate() {
        if lengths[edge] <= triple_cutoff_a {
            groups[atom as usize].push(edge as u32);
        }
    }
    for group in groups {
        for &first in &group {
            for &second in &group {
                if first != second {
                    triple_first.push(first);
                    triple_second.push(second);
                }
            }
        }
    }
    Ok(RadiusGraph {
        source,
        destination,
        offsets,
        triple_first,
        triple_second,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn periodic_self_images_are_included_but_zero_image_is_excluded() {
        let structure = Structure {
            atomic_numbers: vec![1],
            positions_a: vec![[0., 0., 0.]],
            cell_a: [[2., 0., 0.], [0., 2., 0.], [0., 0., 2.]],
            pbc: [true; 3],
        };
        let graph = radius_graph(&structure, 2.01, 2.01).unwrap();
        assert_eq!(graph.source.len(), 6);
        assert_eq!(graph.triple_first.len(), 30);
        assert!(!graph.offsets.contains(&[0., 0., 0.]));
    }
}
