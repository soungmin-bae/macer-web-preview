//! Host-independent Macer kernels. No Python, Torch, or filesystem access.

pub use types::{
    CalculationProperty, Calculator, CalculatorCapabilities, CalculatorError, CalculatorEvaluation,
    Evaluation, Potential, PotentialCalculator, Structure,
};

pub mod dynamics;
pub mod emt;
pub mod ewald;
pub mod lennard_jones;
pub mod neighbors;
pub mod types;

pub struct Threebody {
    pairs: Vec<i32>,
    per_bond: Vec<i32>,
    per_atom: Vec<i32>,
    per_structure: Vec<i32>,
}

pub fn compute_threebody(
    bonds: &[[i32; 2]],
    atoms_per_structure: &[i32],
) -> Result<Threebody, &'static str> {
    let mut atom_count = 0usize;
    for &count in atoms_per_structure {
        if count < 0 {
            return Err("negative atom count");
        }
        atom_count = atom_count
            .checked_add(count as usize)
            .ok_or("atom count overflow")?;
    }
    if atom_count > i32::MAX as usize {
        return Err("atom count exceeds int32 graph contract");
    }
    let mut degrees = vec![0usize; atom_count];
    for bond in bonds {
        let source = bond[0];
        let destination = bond[1];
        if source < 0
            || source as usize >= atom_count
            || destination < 0
            || destination as usize >= atom_count
        {
            return Err("invalid bond index");
        }
        degrees[source as usize] = degrees[source as usize]
            .checked_add(1)
            .ok_or("bond degree overflow")?;
    }
    let mut pair_count = 0usize;
    for &degree in &degrees {
        pair_count = pair_count
            .checked_add(
                degree
                    .checked_mul(degree.saturating_sub(1))
                    .ok_or("pair count overflow")?,
            )
            .ok_or("pair count overflow")?;
    }
    if pair_count > i32::MAX as usize {
        return Err("pair count exceeds int32 graph contract");
    }
    let mut starts = vec![0usize; atom_count];
    let mut next = 0usize;
    for (atom, &degree) in degrees.iter().enumerate() {
        starts[atom] = next;
        next += degree;
    }
    let mut cursors = starts.clone();
    let mut order = vec![0usize; bonds.len()];
    for (index, bond) in bonds.iter().enumerate() {
        let source = bond[0] as usize;
        order[cursors[source]] = index;
        cursors[source] += 1;
    }
    let mut pairs = Vec::with_capacity(pair_count * 2);
    let mut per_bond = vec![0i32; bonds.len()];
    let mut per_atom = vec![0i32; atom_count];
    for (atom, &degree) in degrees.iter().enumerate() {
        let group = &order[starts[atom]..starts[atom] + degree];
        per_atom[atom] = (degree * degree.saturating_sub(1)) as i32;
        for &left in group {
            per_bond[left] = degree.saturating_sub(1) as i32;
            for &right in group {
                if left != right {
                    pairs.push(left as i32);
                    pairs.push(right as i32);
                }
            }
        }
    }
    let mut per_structure = Vec::with_capacity(atoms_per_structure.len());
    let mut begin = 0usize;
    for &count in atoms_per_structure {
        let end = begin + count as usize;
        let total: i64 = per_atom[begin..end].iter().map(|&v| i64::from(v)).sum();
        per_structure.push(total as i32);
        begin = end;
    }
    Ok(Threebody {
        pairs,
        per_bond,
        per_atom,
        per_structure,
    })
}

// The C ABI is a native adapter only; compute_threebody above is also built for WASM.
#[no_mangle]
pub unsafe extern "C" fn macer_threebody_create(
    bond_data: *const i32,
    n_bonds: usize,
    atom_counts: *const i32,
    n_structures: usize,
) -> *mut Threebody {
    if (n_bonds != 0 && bond_data.is_null()) || (n_structures != 0 && atom_counts.is_null()) {
        return std::ptr::null_mut();
    }
    let Some(raw_bond_len) = n_bonds.checked_mul(2) else {
        return std::ptr::null_mut();
    };
    if raw_bond_len > isize::MAX as usize / std::mem::size_of::<i32>() {
        return std::ptr::null_mut();
    }
    let raw_bonds = if n_bonds == 0 {
        &[][..]
    } else {
        std::slice::from_raw_parts(bond_data, raw_bond_len)
    };
    let counts = if n_structures == 0 {
        &[][..]
    } else {
        std::slice::from_raw_parts(atom_counts, n_structures)
    };
    let bonds: Vec<[i32; 2]> = raw_bonds
        .chunks_exact(2)
        .map(|chunk| [chunk[0], chunk[1]])
        .collect();
    match compute_threebody(&bonds, counts) {
        Ok(graph) => Box::into_raw(Box::new(graph)),
        Err(_) => std::ptr::null_mut(),
    }
}

#[no_mangle]
pub unsafe extern "C" fn macer_threebody_sizes(handle: *const Threebody, out: *mut usize) -> i32 {
    if handle.is_null() || out.is_null() {
        return 1;
    }
    let graph = &*handle;
    let sizes = [
        graph.pairs.len() / 2,
        graph.per_bond.len(),
        graph.per_atom.len(),
        graph.per_structure.len(),
    ];
    std::ptr::copy_nonoverlapping(sizes.as_ptr(), out, 4);
    0
}

#[no_mangle]
pub unsafe extern "C" fn macer_threebody_copy(
    handle: *const Threebody,
    pairs: *mut i32,
    per_bond: *mut i32,
    per_atom: *mut i32,
    per_structure: *mut i32,
) -> i32 {
    if handle.is_null() {
        return 1;
    }
    let graph = &*handle;
    if (!graph.pairs.is_empty() && pairs.is_null())
        || (!graph.per_bond.is_empty() && per_bond.is_null())
        || (!graph.per_atom.is_empty() && per_atom.is_null())
        || (!graph.per_structure.is_empty() && per_structure.is_null())
    {
        return 1;
    }
    if !graph.pairs.is_empty() {
        std::ptr::copy_nonoverlapping(graph.pairs.as_ptr(), pairs, graph.pairs.len());
    }
    if !graph.per_bond.is_empty() {
        std::ptr::copy_nonoverlapping(graph.per_bond.as_ptr(), per_bond, graph.per_bond.len());
    }
    if !graph.per_atom.is_empty() {
        std::ptr::copy_nonoverlapping(graph.per_atom.as_ptr(), per_atom, graph.per_atom.len());
    }
    if !graph.per_structure.is_empty() {
        std::ptr::copy_nonoverlapping(
            graph.per_structure.as_ptr(),
            per_structure,
            graph.per_structure.len(),
        );
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn macer_threebody_free(handle: *mut Threebody) {
    if !handle.is_null() {
        drop(Box::from_raw(handle));
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ordered_pairs_include_original_indices() {
        let graph = compute_threebody(&[[1, 3], [0, 1], [1, 2], [0, 2], [1, 0]], &[2, 2]).unwrap();
        assert_eq!(
            graph
                .pairs
                .chunks_exact(2)
                .map(|x| [x[0], x[1]])
                .collect::<Vec<_>>(),
            vec![
                [1, 3],
                [3, 1],
                [0, 2],
                [0, 4],
                [2, 0],
                [2, 4],
                [4, 0],
                [4, 2]
            ]
        );
        assert_eq!(graph.per_bond, [2, 1, 2, 1, 2]);
        assert_eq!(graph.per_atom, [2, 6, 0, 0]);
        assert_eq!(graph.per_structure, [8, 0]);
    }

    #[test]
    fn invalid_indices_are_rejected() {
        assert!(compute_threebody(&[[1, 0]], &[1]).is_err());
        assert!(compute_threebody(&[[0, -1]], &[1]).is_err());
    }
}
