//! ASE Effective Medium Theory calculator for Macer's built-in `emt` backend.
//!
//! This implements ASE EMT's default `asap_cutoff=False` parameterization for
//! Al, Cu, Ag, Au, Ni, Pd, Pt, H, C, N, and O. Energies use the same isolated
//! atom reference (`E0` subtraction), and forces/stress follow ASE's two-pass
//! EMT expressions.

use crate::types::{Evaluation, Potential, Structure};

const BETA: f64 = 1.809;
const BOHR_A: f64 = 0.529_177_210_563_841_1;

#[derive(Clone, Copy)]
struct RawParameters {
    z: u8,
    e0: f64,
    s0_bohr: f64,
    v0: f64,
    eta2_bohr_inv: f64,
    kappa_bohr_inv: f64,
    lambda_bohr_inv: f64,
    n0_bohr_inv3: f64,
}

// ASE ase.calculators.emt.parameters, version 3.27.0.
const RAW_PARAMETERS: [RawParameters; 11] = [
    RawParameters {
        z: 13,
        e0: -3.28,
        s0_bohr: 3.0,
        v0: 1.493,
        eta2_bohr_inv: 1.24,
        kappa_bohr_inv: 2.0,
        lambda_bohr_inv: 1.169,
        n0_bohr_inv3: 0.007,
    },
    RawParameters {
        z: 29,
        e0: -3.51,
        s0_bohr: 2.67,
        v0: 2.476,
        eta2_bohr_inv: 1.652,
        kappa_bohr_inv: 2.74,
        lambda_bohr_inv: 1.906,
        n0_bohr_inv3: 0.0091,
    },
    RawParameters {
        z: 47,
        e0: -2.96,
        s0_bohr: 3.01,
        v0: 2.132,
        eta2_bohr_inv: 1.652,
        kappa_bohr_inv: 2.79,
        lambda_bohr_inv: 1.892,
        n0_bohr_inv3: 0.00547,
    },
    RawParameters {
        z: 79,
        e0: -3.8,
        s0_bohr: 3.0,
        v0: 2.321,
        eta2_bohr_inv: 1.674,
        kappa_bohr_inv: 2.873,
        lambda_bohr_inv: 2.182,
        n0_bohr_inv3: 0.00703,
    },
    RawParameters {
        z: 28,
        e0: -4.44,
        s0_bohr: 2.6,
        v0: 3.673,
        eta2_bohr_inv: 1.669,
        kappa_bohr_inv: 2.757,
        lambda_bohr_inv: 1.948,
        n0_bohr_inv3: 0.0103,
    },
    RawParameters {
        z: 46,
        e0: -3.9,
        s0_bohr: 2.87,
        v0: 2.773,
        eta2_bohr_inv: 1.818,
        kappa_bohr_inv: 3.107,
        lambda_bohr_inv: 2.155,
        n0_bohr_inv3: 0.00688,
    },
    RawParameters {
        z: 78,
        e0: -5.85,
        s0_bohr: 2.9,
        v0: 4.067,
        eta2_bohr_inv: 1.812,
        kappa_bohr_inv: 3.145,
        lambda_bohr_inv: 2.192,
        n0_bohr_inv3: 0.00802,
    },
    RawParameters {
        z: 1,
        e0: -3.21,
        s0_bohr: 1.31,
        v0: 0.132,
        eta2_bohr_inv: 2.652,
        kappa_bohr_inv: 2.79,
        lambda_bohr_inv: 3.892,
        n0_bohr_inv3: 0.00547,
    },
    RawParameters {
        z: 6,
        e0: -3.5,
        s0_bohr: 1.81,
        v0: 0.332,
        eta2_bohr_inv: 1.652,
        kappa_bohr_inv: 2.79,
        lambda_bohr_inv: 1.892,
        n0_bohr_inv3: 0.01322,
    },
    RawParameters {
        z: 7,
        e0: -5.1,
        s0_bohr: 1.88,
        v0: 0.132,
        eta2_bohr_inv: 1.652,
        kappa_bohr_inv: 2.79,
        lambda_bohr_inv: 1.892,
        n0_bohr_inv3: 0.01222,
    },
    RawParameters {
        z: 8,
        e0: -4.6,
        s0_bohr: 1.95,
        v0: 0.332,
        eta2_bohr_inv: 1.652,
        kappa_bohr_inv: 2.79,
        lambda_bohr_inv: 1.892,
        n0_bohr_inv3: 0.0085,
    },
];

#[derive(Clone, Copy)]
struct ElementParameters {
    e0: f64,
    s0: f64,
    v0: f64,
    eta2: f64,
    kappa: f64,
    lambda: f64,
    n0: f64,
    inv12gamma1: f64,
    neghalfv0overgamma2: f64,
}

#[derive(Clone, Copy)]
struct NeighborTerm {
    atom: usize,
    displacement: [f64; 3],
    inv_distance: f64,
    dwdroverw: f64,
    dsigma1_self: f64,
    dsigma1_other: f64,
    dsigma2_self: f64,
    dsigma2_other: f64,
}

#[derive(Clone, Copy, Debug, Default)]
pub struct EffectiveMediumTheory;

impl EffectiveMediumTheory {
    fn parameters(z: u8, rc: f64, acut: f64) -> Result<ElementParameters, String> {
        let raw = RAW_PARAMETERS
            .iter()
            .find(|entry| entry.z == z)
            .ok_or_else(|| format!("EMT has no parameters for atomic number {z}"))?;
        let s0 = raw.s0_bohr * BOHR_A;
        let eta2 = raw.eta2_bohr_inv / BOHR_A;
        let kappa = raw.kappa_bohr_inv / BOHR_A;
        let lambda = raw.lambda_bohr_inv / BOHR_A;
        let n0 = raw.n0_bohr_inv3 / BOHR_A.powi(3);
        let shell_counts = [12.0, 6.0, 24.0];
        let distances = [1.0_f64, 2.0, 3.0].map(|shell| BETA * s0 * shell.sqrt());
        let mut gamma1 = 0.0;
        let mut gamma2 = 0.0;
        for (count, distance) in shell_counts.into_iter().zip(distances) {
            let weight = 1.0 / (1.0 + (acut * (distance - rc)).exp());
            let x = count * weight / 12.0;
            gamma1 += x * (-eta2 * (distance - BETA * s0)).exp();
            gamma2 += x * (-kappa / BETA * (distance - BETA * s0)).exp();
        }
        Ok(ElementParameters {
            e0: raw.e0,
            s0,
            v0: raw.v0,
            eta2,
            kappa,
            lambda,
            n0,
            inv12gamma1: 1.0 / (12.0 * gamma1),
            neghalfv0overgamma2: -0.5 * raw.v0 / gamma2,
        })
    }

    fn cutoff() -> (f64, f64, f64) {
        let max_s0 = RAW_PARAMETERS
            .iter()
            .map(|entry| entry.s0_bohr)
            .fold(0.0_f64, f64::max)
            * BOHR_A;
        let r1nn = BETA * max_s0;
        let rc = r1nn * 0.5 * (3.0_f64.sqrt() + 2.0);
        let r4nn = 2.0 * r1nn;
        let acut = (1.0_f64 / 1e-4 - 1.0).ln() / (r4nn - rc);
        (rc, rc + 0.5, acut)
    }

    fn neighbors_for(
        structure: &Structure,
        center: usize,
        cutoff: f64,
        rc: f64,
        params: &[ElementParameters],
        atom_param_indices: &[usize],
        chi: &[Vec<f64>],
        acut: f64,
    ) -> Result<Vec<NeighborTerm>, String> {
        let periodic = structure.pbc.iter().any(|&axis| axis);
        let volume = determinant(structure.cell_a);
        if periodic && volume.abs() < 1e-12 {
            return Err("periodic EMT evaluation requires a nonsingular cell".into());
        }
        let reciprocal = if periodic {
            let [a, b, c] = structure.cell_a;
            [cross(b, c), cross(c, a), cross(a, b)].map(|row| row.map(|x| x / volume))
        } else {
            [[0.0; 3]; 3]
        };
        let mut terms = Vec::new();
        for other in 0..structure.atomic_numbers.len() {
            let delta = std::array::from_fn(|axis| {
                structure.positions_a[other][axis] - structure.positions_a[center][axis]
            });
            let mut ranges = [(0_i32, 0_i32); 3];
            if periodic {
                for axis in 0..3 {
                    if structure.pbc[axis] {
                        let fractional = dot(delta, reciprocal[axis]);
                        let radius = cutoff * dot(reciprocal[axis], reciprocal[axis]).sqrt() + 1e-8;
                        let low = (-fractional - radius).ceil();
                        let high = (-fractional + radius).floor();
                        if low < i32::MIN as f64 || high > i32::MAX as f64 {
                            return Err("EMT periodic image range exceeds i32".into());
                        }
                        ranges[axis] = (low as i32, high as i32);
                    }
                }
            }
            for nx in ranges[0].0..=ranges[0].1 {
                for ny in ranges[1].0..=ranges[1].1 {
                    for nz in ranges[2].0..=ranges[2].1 {
                        if center == other && nx == 0 && ny == 0 && nz == 0 {
                            continue;
                        }
                        let image = [nx, ny, nz];
                        let displacement = std::array::from_fn(|axis| {
                            delta[axis]
                                + (0..3)
                                    .map(|k| image[k] as f64 * structure.cell_a[k][axis])
                                    .sum::<f64>()
                        });
                        let distance = dot(displacement, displacement).sqrt();
                        if distance >= cutoff {
                            continue;
                        }
                        if distance <= 1e-14 {
                            return Err(format!("overlapping atoms in EMT pair {center},{other}"));
                        }
                        let self_params = params[atom_param_indices[center]];
                        let other_params = params[atom_param_indices[other]];
                        let ratio = chi[atom_param_indices[center]][atom_param_indices[other]];
                        let w = 1.0 / (1.0 + (acut * (distance - rc)).exp());
                        let dwdroverw = acut * (w - 1.0);
                        let dsigma1_self =
                            (-other_params.eta2 * (distance - BETA * other_params.s0)).exp()
                                * ratio
                                * w;
                        let dsigma1_other =
                            (-self_params.eta2 * (distance - BETA * self_params.s0)).exp() / ratio
                                * w;
                        let dsigma2_self =
                            (-other_params.kappa * (distance / BETA - other_params.s0)).exp()
                                * ratio
                                * w;
                        let dsigma2_other =
                            (-self_params.kappa * (distance / BETA - self_params.s0)).exp() / ratio
                                * w;
                        terms.push(NeighborTerm {
                            atom: other,
                            displacement,
                            inv_distance: 1.0 / distance,
                            dwdroverw,
                            dsigma1_self,
                            dsigma1_other,
                            dsigma2_self,
                            dsigma2_other,
                        });
                    }
                }
            }
        }
        Ok(terms)
    }
}

impl Potential for EffectiveMediumTheory {
    fn evaluate(&mut self, structure: &Structure) -> Result<Evaluation, String> {
        structure.validate()?;
        let n = structure.atomic_numbers.len();
        let (rc, rc_list, acut) = Self::cutoff();
        let mut unique_z = structure.atomic_numbers.clone();
        unique_z.sort_unstable();
        unique_z.dedup();
        let params = unique_z
            .iter()
            .map(|&z| Self::parameters(z, rc, acut))
            .collect::<Result<Vec<_>, _>>()?;
        let atom_param_indices = structure
            .atomic_numbers
            .iter()
            .map(|z| unique_z.binary_search(z).unwrap())
            .collect::<Vec<_>>();
        let chi: Vec<Vec<f64>> = params
            .iter()
            .map(|self_params| {
                params
                    .iter()
                    .map(|other_params| other_params.n0 / self_params.n0)
                    .collect()
            })
            .collect();
        let neighbors = (0..n)
            .map(|center| {
                Self::neighbors_for(
                    structure,
                    center,
                    rc_list,
                    rc,
                    &params,
                    &atom_param_indices,
                    &chi,
                    acut,
                )
            })
            .collect::<Result<Vec<_>, _>>()?;

        let mut energies = vec![0.0; n];
        let mut deds = vec![0.0; n];
        for center in 0..n {
            let self_params = params[atom_param_indices[center]];
            let sigma1: f64 = neighbors[center].iter().map(|term| term.dsigma1_self).sum();
            if sigma1 == 0.0 {
                continue;
            }
            let ds = -(sigma1 * self_params.inv12gamma1).ln() / (BETA * self_params.eta2);
            let lambda_ds = self_params.lambda * ds;
            let exp_negative_lambda_ds = (-lambda_ds).exp();
            energies[center] += self_params.e0 * (1.0 + lambda_ds) * exp_negative_lambda_ds;
            deds[center] +=
                -self_params.e0 * self_params.lambda * lambda_ds * exp_negative_lambda_ds;
            let six_v0_exp_negative_kappa_ds =
                6.0 * self_params.v0 * (-self_params.kappa * ds).exp();
            energies[center] += six_v0_exp_negative_kappa_ds;
            deds[center] += -self_params.kappa * six_v0_exp_negative_kappa_ds;
            deds[center] /= -BETA * self_params.eta2 * sigma1;

            for term in &neighbors[center] {
                let self_neighbor_energy = self_params.neghalfv0overgamma2 * term.dsigma2_self;
                let other_params = params[atom_param_indices[term.atom]];
                let other_neighbor_energy = other_params.neghalfv0overgamma2 * term.dsigma2_other;
                energies[center] += 0.5 * (self_neighbor_energy + other_neighbor_energy);
            }
        }
        for (energy, &z) in energies.iter_mut().zip(&structure.atomic_numbers) {
            let params = params[unique_z.binary_search(&z).unwrap()];
            *energy -= params.e0;
        }

        let mut forces = vec![[0.0; 3]; n];
        let mut virial = [[0.0; 3]; 3];
        for center in 0..n {
            for term in &neighbors[center] {
                let self_params = params[atom_param_indices[center]];
                let other_params = params[atom_param_indices[term.atom]];
                let ddsigma1_self = term.dsigma1_self * (term.dwdroverw - other_params.eta2);
                let ddsigma1_other = term.dsigma1_other * (term.dwdroverw - self_params.eta2);
                let dedr_self = deds[center] * ddsigma1_self;
                let dedr_other = deds[term.atom] * ddsigma1_other;
                let mut force = [0.0; 3];
                for axis in 0..3 {
                    force[axis] =
                        (dedr_self + dedr_other) * term.inv_distance * term.displacement[axis];
                    forces[center][axis] += force[axis];
                }
                for a in 0..3 {
                    for b in 0..3 {
                        virial[a][b] += 0.5 * term.displacement[a] * force[b];
                    }
                }

                let es = self_params.neghalfv0overgamma2 * term.dsigma2_self;
                let eo = other_params.neghalfv0overgamma2 * term.dsigma2_other;
                let dedr_self = es * (term.dwdroverw - other_params.kappa / BETA);
                let dedr_other = eo * (term.dwdroverw - self_params.kappa / BETA);
                for axis in 0..3 {
                    force[axis] =
                        (dedr_self + dedr_other) * term.inv_distance * term.displacement[axis];
                    forces[center][axis] += force[axis];
                }
                for a in 0..3 {
                    for b in 0..3 {
                        virial[a][b] += 0.5 * term.displacement[a] * force[b];
                    }
                }
            }
        }

        let volume = structure.signed_volume_a3();
        let stress = if volume.abs() >= 1e-12 {
            let mut symmetric = [[0.0; 3]; 3];
            for a in 0..3 {
                for b in 0..3 {
                    symmetric[a][b] = 0.5 * (virial[a][b] + virial[b][a]) / volume.abs();
                }
            }
            symmetric
        } else {
            [[0.0; 3]; 3]
        };
        let result = Evaluation {
            energy_ev: energies.iter().sum(),
            forces_ev_per_a: forces,
            stress_ev_per_a3: stress,
            energies_ev: Some(energies),
            stresses_ev_per_a3: None,
        };
        result.validate(n)?;
        Ok(result)
    }
}

fn cross(a: [f64; 3], b: [f64; 3]) -> [f64; 3] {
    [
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    ]
}

fn dot(a: [f64; 3], b: [f64; 3]) -> f64 {
    a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
}

fn determinant(cell: [[f64; 3]; 3]) -> f64 {
    dot(cell[0], cross(cell[1], cell[2]))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn structure(z: Vec<u8>, positions: Vec<[f64; 3]>) -> Structure {
        Structure {
            atomic_numbers: z,
            positions_a: positions,
            cell_a: [[20.0, 0.0, 0.0], [0.0, 20.0, 0.0], [0.0, 0.0, 20.0]],
            pbc: [false; 3],
        }
    }

    #[test]
    fn cu_dimer_matches_ase_emt_energy_forces_and_stress() {
        let mut emt = EffectiveMediumTheory;
        let atoms = structure(vec![29, 29], vec![[0.0; 3], [2.3, 0.0, 0.0]]);
        let result = emt.evaluate(&atoms).unwrap();
        assert!((result.energy_ev - 3.300_760_833_836_831).abs() < 1e-11);
        assert!((result.forces_ev_per_a[0][0] - 1.651_718_744_096_880_8).abs() < 1e-10);
        assert!((result.forces_ev_per_a[1][0] + 1.651_718_744_096_880_8).abs() < 1e-10);
        assert!((result.stress_ev_per_a3[0][0] - 0.000_474_869_138_927_853_65).abs() < 1e-12);
        assert_eq!(result.energies_ev.as_ref().unwrap().len(), 2);
        assert!(
            (result.energies_ev.as_ref().unwrap().iter().sum::<f64>() - result.energy_ev).abs()
                < 1e-12
        );
    }

    #[test]
    fn aluminum_cluster_matches_ase_emt_multibody_reference() {
        let mut emt = EffectiveMediumTheory;
        let atoms = structure(
            vec![13; 4],
            vec![
                [0.0, 0.0, 0.0],
                [0.0, 2.86, 2.86],
                [2.86, 0.0, 2.86],
                [2.86, 2.86, 0.0],
            ],
        );
        let result = emt.evaluate(&atoms).unwrap();
        assert!((result.energy_ev - 8.535_029_329_203_624).abs() < 1e-10);
        assert!((result.forces_ev_per_a[0][0] - 0.863_476_965_362_836).abs() < 1e-10);
        assert!((result.forces_ev_per_a[1][1] + 0.863_476_965_362_836).abs() < 1e-10);
        assert!((result.stress_ev_per_a3[0][0] - 0.000_617_386_030_234_427_7).abs() < 1e-12);
    }

    #[test]
    fn unsupported_elements_report_emt_coverage() {
        let mut emt = EffectiveMediumTheory;
        let atoms = structure(vec![18], vec![[0.0; 3]]);
        assert!(emt.evaluate(&atoms).unwrap_err().contains("no parameters"));
    }

    #[test]
    fn periodic_copper_cell_matches_ase_self_image_reference() {
        let mut emt = EffectiveMediumTheory;
        let atoms = Structure {
            atomic_numbers: vec![29; 4],
            positions_a: vec![
                [0.0, 0.0, 0.0],
                [0.0, 1.8, 1.8],
                [1.8, 0.0, 1.8],
                [1.8, 1.8, 0.0],
            ],
            cell_a: [[3.6, 0.0, 0.0], [0.0, 3.6, 0.0], [0.0, 0.0, 3.6]],
            pbc: [true; 3],
        };
        let result = emt.evaluate(&atoms).unwrap();
        assert!((result.energy_ev - -0.026_755_074_743_153_53).abs() < 1e-10);
        assert!((result.stress_ev_per_a3[0][0] - 0.007_000_141_271_404_378).abs() < 1e-12);
        assert!(result
            .forces_ev_per_a
            .iter()
            .flatten()
            .all(|force| force.abs() < 1e-11));
    }
}
