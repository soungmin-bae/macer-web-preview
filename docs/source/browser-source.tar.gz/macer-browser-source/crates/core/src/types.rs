//! Platform-independent evaluation contract and units.

use serde::{Deserialize, Serialize};

/// Positions and cell are in Å; atom order is stable across every call.
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub struct Structure {
    pub atomic_numbers: Vec<u8>,
    pub positions_a: Vec<[f64; 3]>,
    pub cell_a: [[f64; 3]; 3],
    pub pbc: [bool; 3],
}

impl Structure {
    pub fn validate(&self) -> Result<(), String> {
        if self.atomic_numbers.is_empty() || self.atomic_numbers.len() != self.positions_a.len() {
            return Err(
                "atomic numbers and positions must be nonempty and have equal length".into(),
            );
        }
        if self.atomic_numbers.iter().any(|&z| z == 0 || z > 118) {
            return Err("atomic numbers must be between 1 and 118".into());
        }
        if self.positions_a.iter().flatten().any(|v| !v.is_finite())
            || self.cell_a.iter().flatten().any(|v| !v.is_finite())
        {
            return Err("positions and cell must be finite".into());
        }
        if self.pbc.iter().any(|&v| v) && self.signed_volume_a3().abs() < 1e-12 {
            return Err("periodic cell must have nonzero volume".into());
        }
        Ok(())
    }

    pub fn signed_volume_a3(&self) -> f64 {
        let [a, b, c] = self.cell_a;
        a[0] * (b[1] * c[2] - b[2] * c[1]) - a[1] * (b[0] * c[2] - b[2] * c[0])
            + a[2] * (b[0] * c[1] - b[1] * c[0])
    }
}

/// Energy is eV; forces are eV/Å; stress is eV/Å³.
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub struct Evaluation {
    pub energy_ev: f64,
    pub forces_ev_per_a: Vec<[f64; 3]>,
    pub stress_ev_per_a3: [[f64; 3]; 3],
    /// Optional ASE-style per-atom energies, when the calculator exposes them.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub energies_ev: Option<Vec<f64>>,
    /// Optional ASE-style per-atom stresses in eV/Å³.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub stresses_ev_per_a3: Option<Vec<[[f64; 3]; 3]>>,
}

impl Evaluation {
    /// ASE calculators expose free energy as the potential energy for the
    /// conservative calculators supported by this contract.
    pub fn free_energy_ev(&self) -> f64 {
        self.energy_ev
    }

    pub fn validate(&self, atoms: usize) -> Result<(), String> {
        if self.forces_ev_per_a.len() != atoms {
            return Err("force count does not match atom count".into());
        }
        if !self.energy_ev.is_finite()
            || self
                .forces_ev_per_a
                .iter()
                .flatten()
                .any(|v| !v.is_finite())
            || self
                .stress_ev_per_a3
                .iter()
                .flatten()
                .any(|v| !v.is_finite())
        {
            return Err("evaluation contains non-finite values".into());
        }
        if self
            .energies_ev
            .as_ref()
            .is_some_and(|values| values.len() != atoms || values.iter().any(|v| !v.is_finite()))
        {
            return Err("per-atom energies must be finite and match the atom count".into());
        }
        if self.stresses_ev_per_a3.as_ref().is_some_and(|values| {
            values.len() != atoms || values.iter().flatten().flatten().any(|v| !v.is_finite())
        }) {
            return Err("per-atom stresses must be finite and match the atom count".into());
        }
        Ok(())
    }
}

pub trait Potential {
    fn evaluate(&mut self, structure: &Structure) -> Result<Evaluation, String>;
}

/// A requested single-point property, mirroring Macer's calculator API.
#[derive(Clone, Copy, Debug, Deserialize, Eq, Hash, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum CalculationProperty {
    Energy,
    Forces,
    Stress,
}

/// Properties and execution modes that one exact model/backend supports.
#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct CalculatorCapabilities {
    pub energy: bool,
    pub forces: bool,
    pub stress: bool,
    pub native_batch: bool,
}

impl CalculatorCapabilities {
    pub const fn energy_forces_stress(native_batch: bool) -> Self {
        Self {
            energy: true,
            forces: true,
            stress: true,
            native_batch,
        }
    }

    pub const fn supports(self, property: CalculationProperty) -> bool {
        match property {
            CalculationProperty::Energy => self.energy,
            CalculationProperty::Forces => self.forces,
            CalculationProperty::Stress => self.stress,
        }
    }
}

/// Typed failures at the public Rust calculator boundary.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum CalculatorError {
    InvalidRequest(String),
    UnsupportedCapability(CalculationProperty),
    DeviceUnavailable(String),
    Evaluation(String),
}

impl std::fmt::Display for CalculatorError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::InvalidRequest(message)
            | Self::DeviceUnavailable(message)
            | Self::Evaluation(message) => formatter.write_str(message),
            Self::UnsupportedCapability(property) => {
                write!(formatter, "calculator does not support {property:?}")
            }
        }
    }
}

impl std::error::Error for CalculatorError {}

/// Only requested values are populated; units match [`Evaluation`].
#[derive(Clone, Debug, Default, Deserialize, PartialEq, Serialize)]
pub struct CalculatorEvaluation {
    pub energy_ev: Option<f64>,
    pub forces_ev_per_a: Option<Vec<[f64; 3]>>,
    pub stress_ev_per_a3: Option<[[f64; 3]; 3]>,
}

impl CalculatorEvaluation {
    pub fn validate(
        &self,
        atoms: usize,
        requested: &[CalculationProperty],
    ) -> Result<(), CalculatorError> {
        for property in requested {
            match property {
                CalculationProperty::Energy => {
                    if !self.energy_ev.is_some_and(f64::is_finite) {
                        return Err(CalculatorError::Evaluation(
                            "calculator omitted or returned a non-finite energy".into(),
                        ));
                    }
                }
                CalculationProperty::Forces => {
                    let Some(forces) = self.forces_ev_per_a.as_ref() else {
                        return Err(CalculatorError::Evaluation(
                            "calculator omitted requested forces".into(),
                        ));
                    };
                    if forces.len() != atoms || forces.iter().flatten().any(|v| !v.is_finite()) {
                        return Err(CalculatorError::Evaluation(
                            "forces must be finite and match the atom count".into(),
                        ));
                    }
                }
                CalculationProperty::Stress => {
                    let Some(stress) = self.stress_ev_per_a3 else {
                        return Err(CalculatorError::Evaluation(
                            "calculator omitted requested stress".into(),
                        ));
                    };
                    if stress.iter().flatten().any(|v| !v.is_finite()) {
                        return Err(CalculatorError::Evaluation(
                            "stress must contain only finite values".into(),
                        ));
                    }
                }
            }
        }
        Ok(())
    }
}

/// Public single-point and batch interface for Rust calculator adapters.
///
/// `evaluate_batch` defaults to ordered sequential evaluation. Backends with
/// a verified native batch path may override it and set `native_batch=true`.
pub trait Calculator {
    fn capabilities(&self) -> CalculatorCapabilities;

    fn evaluate_properties(
        &mut self,
        structure: &Structure,
        requested: &[CalculationProperty],
    ) -> Result<CalculatorEvaluation, CalculatorError>;

    fn evaluate_batch(
        &mut self,
        structures: &[Structure],
        requested: &[CalculationProperty],
        batch_size: Option<usize>,
    ) -> Result<Vec<CalculatorEvaluation>, CalculatorError> {
        if batch_size == Some(0) {
            return Err(CalculatorError::InvalidRequest(
                "batch size must be greater than zero".into(),
            ));
        }
        if requested.is_empty() {
            return Ok(vec![CalculatorEvaluation::default(); structures.len()]);
        }
        if let Some(unsupported) = requested
            .iter()
            .copied()
            .find(|property| !self.capabilities().supports(*property))
        {
            return Err(CalculatorError::UnsupportedCapability(unsupported));
        }
        let chunk_size = batch_size.unwrap_or_else(|| structures.len().max(1));
        let mut results = Vec::with_capacity(structures.len());
        for chunk in structures.chunks(chunk_size) {
            for structure in chunk {
                structure
                    .validate()
                    .map_err(CalculatorError::InvalidRequest)?;
                let result = self.evaluate_properties(structure, requested)?;
                result.validate(structure.atomic_numbers.len(), requested)?;
                results.push(result);
            }
        }
        Ok(results)
    }
}

/// Adapts any complete E/F/stress [`Potential`] to the public calculator API.
pub struct PotentialCalculator<P> {
    potential: P,
}

impl<P> PotentialCalculator<P> {
    pub fn new(potential: P) -> Self {
        Self { potential }
    }

    pub fn into_inner(self) -> P {
        self.potential
    }
}

impl<P: Potential> Calculator for PotentialCalculator<P> {
    fn capabilities(&self) -> CalculatorCapabilities {
        CalculatorCapabilities::energy_forces_stress(false)
    }

    fn evaluate_properties(
        &mut self,
        structure: &Structure,
        requested: &[CalculationProperty],
    ) -> Result<CalculatorEvaluation, CalculatorError> {
        if requested.is_empty() {
            return Ok(CalculatorEvaluation::default());
        }
        for property in requested {
            if !self.capabilities().supports(*property) {
                return Err(CalculatorError::UnsupportedCapability(*property));
            }
        }
        structure
            .validate()
            .map_err(CalculatorError::InvalidRequest)?;
        let evaluation = self
            .potential
            .evaluate(structure)
            .map_err(CalculatorError::Evaluation)?;
        let result = CalculatorEvaluation {
            energy_ev: requested
                .contains(&CalculationProperty::Energy)
                .then_some(evaluation.energy_ev),
            forces_ev_per_a: requested
                .contains(&CalculationProperty::Forces)
                .then_some(evaluation.forces_ev_per_a),
            stress_ev_per_a3: requested
                .contains(&CalculationProperty::Stress)
                .then_some(evaluation.stress_ev_per_a3),
        };
        result.validate(structure.atomic_numbers.len(), requested)?;
        Ok(result)
    }
}

#[cfg(test)]
mod tests {
    use super::{
        CalculationProperty, Calculator, CalculatorCapabilities, CalculatorError,
        CalculatorEvaluation, Evaluation, Potential, PotentialCalculator, Structure,
    };

    struct OrderedPotential;

    impl Potential for OrderedPotential {
        fn evaluate(&mut self, structure: &Structure) -> Result<Evaluation, String> {
            let energy = structure.atomic_numbers[0] as f64;
            Ok(Evaluation {
                energy_ev: energy,
                forces_ev_per_a: vec![[energy, 0.0, 0.0]; structure.atomic_numbers.len()],
                stress_ev_per_a3: [[energy; 3]; 3],
                energies_ev: None,
                stresses_ev_per_a3: None,
            })
        }
    }

    fn structure(z: u8) -> Structure {
        Structure {
            atomic_numbers: vec![z],
            positions_a: vec![[0.0; 3]],
            cell_a: [[4.0, 0.0, 0.0], [0.0, 4.0, 0.0], [0.0, 0.0, 4.0]],
            pbc: [true; 3],
        }
    }

    #[test]
    fn calculator_api_selects_only_requested_properties() {
        let mut calculator = PotentialCalculator::new(OrderedPotential);
        let result = calculator
            .evaluate_properties(&structure(8), &[CalculationProperty::Energy])
            .unwrap();
        assert_eq!(result.energy_ev, Some(8.0));
        assert_eq!(result.forces_ev_per_a, None);
        assert_eq!(result.stress_ev_per_a3, None);
        assert_eq!(
            calculator.capabilities(),
            CalculatorCapabilities::energy_forces_stress(false)
        );
    }

    #[test]
    fn default_batch_preserves_order_and_accepts_chunk_size() {
        let mut calculator = PotentialCalculator::new(OrderedPotential);
        let results = calculator
            .evaluate_batch(
                &[structure(8), structure(14), structure(26)],
                &[CalculationProperty::Energy],
                Some(2),
            )
            .unwrap();
        assert_eq!(
            results
                .iter()
                .map(|item| item.energy_ev)
                .collect::<Vec<_>>(),
            [Some(8.0), Some(14.0), Some(26.0)]
        );
    }

    #[test]
    fn calculator_api_rejects_unsupported_and_invalid_batch_requests() {
        struct EnergyOnly;
        impl Calculator for EnergyOnly {
            fn capabilities(&self) -> CalculatorCapabilities {
                CalculatorCapabilities {
                    energy: true,
                    forces: false,
                    stress: false,
                    native_batch: false,
                }
            }

            fn evaluate_properties(
                &mut self,
                _structure: &Structure,
                _requested: &[CalculationProperty],
            ) -> Result<CalculatorEvaluation, CalculatorError> {
                Ok(CalculatorEvaluation::default())
            }
        }
        let mut calculator = EnergyOnly;
        assert_eq!(
            calculator
                .evaluate_batch(&[structure(8)], &[CalculationProperty::Forces], None)
                .unwrap_err(),
            CalculatorError::UnsupportedCapability(CalculationProperty::Forces)
        );
        assert!(matches!(
            calculator.evaluate_batch(&[structure(8)], &[CalculationProperty::Energy], Some(0)),
            Err(CalculatorError::InvalidRequest(_))
        ));
    }

    #[test]
    fn empty_property_request_does_not_call_the_potential() {
        struct MustNotRun;
        impl Potential for MustNotRun {
            fn evaluate(&mut self, _structure: &Structure) -> Result<Evaluation, String> {
                Err("evaluation should not run".into())
            }
        }
        let mut calculator = PotentialCalculator::new(MustNotRun);
        assert_eq!(
            calculator.evaluate_properties(&structure(8), &[]).unwrap(),
            CalculatorEvaluation::default()
        );
        assert_eq!(
            calculator
                .evaluate_batch(&[structure(8), structure(14)], &[], None)
                .unwrap(),
            [
                CalculatorEvaluation::default(),
                CalculatorEvaluation::default()
            ]
        );
    }

    #[test]
    fn legacy_evaluation_restart_omits_optional_atomwise_properties() {
        let bytes = br#"{
            "energy_ev": -1.0,
            "forces_ev_per_a": [[0.0, 0.0, 0.0]],
            "stress_ev_per_a3": [[0.0, 0.0, 0.0], [0.0, 0.0, 0.0], [0.0, 0.0, 0.0]]
        }"#;
        let evaluation: Evaluation = serde_json::from_slice(bytes).unwrap();
        assert_eq!(evaluation.energies_ev, None);
        assert_eq!(evaluation.stresses_ev_per_a3, None);
        assert_eq!(evaluation.free_energy_ev(), -1.0);
        evaluation.validate(1).unwrap();
    }

    #[test]
    fn atomwise_properties_must_match_structure_size() {
        let evaluation = Evaluation {
            energy_ev: 0.0,
            forces_ev_per_a: vec![[0.0; 3]],
            stress_ev_per_a3: [[0.0; 3]; 3],
            energies_ev: Some(vec![0.0, 0.0]),
            stresses_ev_per_a3: None,
        };
        assert!(evaluation.validate(1).is_err());
    }
}
