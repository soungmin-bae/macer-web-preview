//! Deterministic NVE and BAOAB Langevin dynamics with restartable random state.

use crate::types::{Evaluation, Potential, Structure};
use serde::{Deserialize, Serialize};

/// eV/Å divided by amu, expressed as Å/fs².
const FORCE_TO_ACCELERATION: f64 = 0.009_648_533_215_665_326;
const BOLTZMANN_EV_PER_K: f64 = 8.617_333_262_145e-5;

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub struct RandomState {
    words: [u64; 4],
    cached_normal: Option<f64>,
}

impl RandomState {
    pub fn from_seed(seed: u64) -> Self {
        let mut splitmix = seed;
        let mut words = [0u64; 4];
        for word in &mut words {
            splitmix = splitmix.wrapping_add(0x9e37_79b9_7f4a_7c15);
            let mut z = splitmix;
            z = (z ^ (z >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
            z = (z ^ (z >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
            *word = z ^ (z >> 31);
        }
        Self {
            words,
            cached_normal: None,
        }
    }

    fn next_u64(&mut self) -> u64 {
        let result = self.words[1].wrapping_mul(5).rotate_left(7).wrapping_mul(9);
        let t = self.words[1] << 17;
        self.words[2] ^= self.words[0];
        self.words[3] ^= self.words[1];
        self.words[1] ^= self.words[2];
        self.words[0] ^= self.words[3];
        self.words[2] ^= t;
        self.words[3] = self.words[3].rotate_left(45);
        result
    }

    fn standard_normal(&mut self) -> f64 {
        if let Some(value) = self.cached_normal.take() {
            return value;
        }
        let mut u1 = (self.next_u64() >> 11) as f64 / ((1u64 << 53) as f64);
        while u1 == 0.0 {
            u1 = (self.next_u64() >> 11) as f64 / ((1u64 << 53) as f64);
        }
        let u2 = (self.next_u64() >> 11) as f64 / ((1u64 << 53) as f64);
        let radius = (-2.0 * u1.ln()).sqrt();
        let angle = 2.0 * std::f64::consts::PI * u2;
        self.cached_normal = Some(radius * angle.sin());
        radius * angle.cos()
    }
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub struct DynamicsState {
    pub structure: Structure,
    pub masses_amu: Vec<f64>,
    pub velocities_a_per_fs: Vec<[f64; 3]>,
    pub evaluation: Evaluation,
    pub step: u64,
    pub time_fs: f64,
    pub random: RandomState,
}

impl DynamicsState {
    pub fn initialize(
        structure: Structure,
        masses_amu: Vec<f64>,
        velocities_a_per_fs: Vec<[f64; 3]>,
        seed: u64,
        potential: &mut impl Potential,
    ) -> Result<Self, String> {
        structure.validate()?;
        let count = structure.atomic_numbers.len();
        if masses_amu.len() != count || velocities_a_per_fs.len() != count {
            return Err("masses and velocities must match the atom count".into());
        }
        if masses_amu.iter().any(|&m| !m.is_finite() || m <= 0.0)
            || velocities_a_per_fs.iter().flatten().any(|v| !v.is_finite())
        {
            return Err("masses must be positive and velocities finite".into());
        }
        let evaluation = potential.evaluate(&structure)?;
        evaluation.validate(count)?;
        Ok(Self {
            structure,
            masses_amu,
            velocities_a_per_fs,
            evaluation,
            step: 0,
            time_fs: 0.0,
            random: RandomState::from_seed(seed),
        })
    }

    pub fn kinetic_energy_ev(&self) -> f64 {
        self.masses_amu
            .iter()
            .zip(&self.velocities_a_per_fs)
            .map(|(&mass, velocity)| {
                0.5 * mass * velocity.iter().map(|v| v * v).sum::<f64>() / FORCE_TO_ACCELERATION
            })
            .sum()
    }

    pub fn step_nve(&mut self, dt_fs: f64, potential: &mut impl Potential) -> Result<(), String> {
        validate_step(dt_fs)?;
        let mut next = self.structure.clone();
        let mut half_velocities = self.velocities_a_per_fs.clone();
        for (index, velocity) in half_velocities.iter_mut().enumerate() {
            for axis in 0..3 {
                velocity[axis] += 0.5
                    * dt_fs
                    * FORCE_TO_ACCELERATION
                    * self.evaluation.forces_ev_per_a[index][axis]
                    / self.masses_amu[index];
                next.positions_a[index][axis] += dt_fs * velocity[axis];
            }
        }
        let evaluation = potential.evaluate(&next)?;
        evaluation.validate(next.atomic_numbers.len())?;
        for (index, velocity) in half_velocities.iter_mut().enumerate() {
            for axis in 0..3 {
                velocity[axis] +=
                    0.5 * dt_fs * FORCE_TO_ACCELERATION * evaluation.forces_ev_per_a[index][axis]
                        / self.masses_amu[index];
            }
        }
        self.commit(next, half_velocities, evaluation, dt_fs)
    }

    pub fn step_langevin(
        &mut self,
        dt_fs: f64,
        temperature_k: f64,
        gamma_per_fs: f64,
        potential: &mut impl Potential,
    ) -> Result<(), String> {
        validate_step(dt_fs)?;
        if !temperature_k.is_finite()
            || temperature_k < 0.0
            || !gamma_per_fs.is_finite()
            || gamma_per_fs < 0.0
        {
            return Err("temperature and Langevin friction must be nonnegative and finite".into());
        }
        let mut next = self.structure.clone();
        let mut velocities = self.velocities_a_per_fs.clone();
        let mut random = self.random.clone();
        let damping = (-gamma_per_fs * dt_fs).exp();
        let noise_factor = (1.0 - damping * damping).sqrt();
        for (index, velocity) in velocities.iter_mut().enumerate() {
            for axis in 0..3 {
                velocity[axis] += 0.5
                    * dt_fs
                    * FORCE_TO_ACCELERATION
                    * self.evaluation.forces_ev_per_a[index][axis]
                    / self.masses_amu[index];
                next.positions_a[index][axis] += 0.5 * dt_fs * velocity[axis];
                let thermal_sigma = (BOLTZMANN_EV_PER_K * temperature_k * FORCE_TO_ACCELERATION
                    / self.masses_amu[index])
                    .sqrt();
                velocity[axis] = damping * velocity[axis]
                    + noise_factor * thermal_sigma * random.standard_normal();
                next.positions_a[index][axis] += 0.5 * dt_fs * velocity[axis];
            }
        }
        let evaluation = potential.evaluate(&next)?;
        evaluation.validate(next.atomic_numbers.len())?;
        for (index, velocity) in velocities.iter_mut().enumerate() {
            for axis in 0..3 {
                velocity[axis] +=
                    0.5 * dt_fs * FORCE_TO_ACCELERATION * evaluation.forces_ev_per_a[index][axis]
                        / self.masses_amu[index];
            }
        }
        self.commit(next, velocities, evaluation, dt_fs)?;
        self.random = random;
        Ok(())
    }

    fn commit(
        &mut self,
        structure: Structure,
        velocities: Vec<[f64; 3]>,
        evaluation: Evaluation,
        dt_fs: f64,
    ) -> Result<(), String> {
        self.step = self.step.checked_add(1).ok_or("MD step counter overflow")?;
        self.time_fs += dt_fs;
        self.structure = structure;
        self.velocities_a_per_fs = velocities;
        self.evaluation = evaluation;
        Ok(())
    }
}

fn validate_step(dt_fs: f64) -> Result<(), String> {
    if !dt_fs.is_finite() || dt_fs <= 0.0 {
        return Err("MD timestep must be positive and finite".into());
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    struct Harmonic {
        k_ev_per_a2: f64,
    }

    impl Potential for Harmonic {
        fn evaluate(&mut self, structure: &Structure) -> Result<Evaluation, String> {
            let x = structure.positions_a[0][0];
            Ok(Evaluation {
                energy_ev: 0.5 * self.k_ev_per_a2 * x * x,
                forces_ev_per_a: vec![[-self.k_ev_per_a2 * x, 0.0, 0.0]],
                stress_ev_per_a3: [[0.0; 3]; 3],
                energies_ev: None,
                stresses_ev_per_a3: None,
            })
        }
    }

    fn initial_state() -> DynamicsState {
        let structure = Structure {
            atomic_numbers: vec![1],
            positions_a: vec![[1.0, 0.0, 0.0]],
            cell_a: [[0.0; 3]; 3],
            pbc: [false; 3],
        };
        DynamicsState::initialize(
            structure,
            vec![1.0],
            vec![[0.0; 3]],
            42,
            &mut Harmonic { k_ev_per_a2: 1.0 },
        )
        .unwrap()
    }

    #[test]
    fn velocity_verlet_keeps_harmonic_energy() {
        let mut state = initial_state();
        let first = state.evaluation.energy_ev + state.kinetic_energy_ev();
        let mut max_drift = 0.0f64;
        for _ in 0..1000 {
            state
                .step_nve(0.05, &mut Harmonic { k_ev_per_a2: 1.0 })
                .unwrap();
            let energy = state.evaluation.energy_ev + state.kinetic_energy_ev();
            max_drift = max_drift.max((energy - first).abs());
        }
        assert!(max_drift < 5e-6, "NVE maximum drift: {max_drift}");
    }

    #[test]
    fn langevin_restart_preserves_rng_and_trajectory() {
        let mut uninterrupted = initial_state();
        let mut restarted = initial_state();
        for _ in 0..7 {
            uninterrupted
                .step_langevin(0.5, 300.0, 0.02, &mut Harmonic { k_ev_per_a2: 1.0 })
                .unwrap();
            restarted
                .step_langevin(0.5, 300.0, 0.02, &mut Harmonic { k_ev_per_a2: 1.0 })
                .unwrap();
        }
        let bytes = serde_json::to_vec(&restarted).unwrap();
        let mut restarted: DynamicsState = serde_json::from_slice(&bytes).unwrap();
        for _ in 0..9 {
            uninterrupted
                .step_langevin(0.5, 300.0, 0.02, &mut Harmonic { k_ev_per_a2: 1.0 })
                .unwrap();
            restarted
                .step_langevin(0.5, 300.0, 0.02, &mut Harmonic { k_ev_per_a2: 1.0 })
                .unwrap();
        }
        assert_eq!(uninterrupted, restarted);
    }
}
