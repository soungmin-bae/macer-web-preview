//! Three-dimensional periodic Ewald summation for point-charge structures.
//!
//! The automatic cutoffs and screening parameter mirror Pymatgen's
//! `EwaldSummation` defaults so Macer can preserve its Madelung-energy
//! workflow without Python at runtime.

use crate::types::Structure;
use std::collections::BTreeMap;

#[path = "ewald/oxidation_data.rs"]
mod oxidation_data;

const COULOMB_EV_ANGSTROM: f64 = 14.399_645_468_667_815;
const EWALD_WEIGHT: f64 = std::f64::consts::FRAC_1_SQRT_2;
const DEFAULT_ACCURACY_FACTOR: f64 = 12.0;
const MAX_ENUMERATED_VECTORS: usize = 50_000_000;

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct EwaldEnergy {
    pub real_space_ev: f64,
    pub reciprocal_space_ev: f64,
    pub self_energy_ev: f64,
    pub charged_cell_ev: f64,
    pub total_ev: f64,
}

#[derive(Clone, Debug, PartialEq)]
pub struct OxidationAssignment {
    pub symbols: Vec<String>,
    pub site_symbols: Vec<String>,
    pub charges: Vec<f64>,
    pub source: OxidationSource,
}

#[derive(Clone, Debug, PartialEq)]
pub enum OxidationSource {
    Manual(String),
    PymatgenGuess,
    PymatgenZeroFallback,
}

#[derive(Clone, Debug)]
struct Choice {
    score: i64,
    counts: Vec<usize>,
}

fn determinant(cell: [[f64; 3]; 3]) -> f64 {
    let [[a, b, c], [d, e, f], [g, h, i]] = cell;
    a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)
}

fn inverse(cell: [[f64; 3]; 3]) -> Result<[[f64; 3]; 3], String> {
    let det = determinant(cell);
    if !det.is_finite() || det.abs() <= 1.0e-14 {
        return Err("Ewald summation requires a finite, nonsingular cell".into());
    }
    let [[a, b, c], [d, e, f], [g, h, i]] = cell;
    let inverse = [
        [e * i - f * h, c * h - b * i, b * f - c * e],
        [f * g - d * i, a * i - c * g, c * d - a * f],
        [d * h - e * g, b * g - a * h, a * e - b * d],
    ]
    .map(|row| row.map(|value| value / det));
    Ok(inverse)
}

fn norm(vector: [f64; 3]) -> f64 {
    vector.iter().map(|value| value * value).sum::<f64>().sqrt()
}

fn cart_to_fractional(vector: [f64; 3], inverse: [[f64; 3]; 3]) -> [f64; 3] {
    std::array::from_fn(|axis| (0..3).map(|cart| vector[cart] * inverse[cart][axis]).sum())
}

fn fractional_to_cartesian(vector: [f64; 3], cell: [[f64; 3]; 3]) -> [f64; 3] {
    std::array::from_fn(|cart| (0..3).map(|axis| vector[axis] * cell[axis][cart]).sum())
}

fn integer_bounds(center: f64, radius: f64) -> Result<(i64, i64), String> {
    let low = (-center - radius).ceil();
    let high = (-center + radius).floor();
    if !low.is_finite() || !high.is_finite() || low < i64::MIN as f64 || high > i64::MAX as f64 {
        return Err("Ewald image bound exceeds supported integer range".into());
    }
    Ok((low as i64, high as i64))
}

fn check_vector_budget(count: usize) -> Result<(), String> {
    if count > MAX_ENUMERATED_VECTORS {
        return Err(format!(
            "Ewald enumeration needs {count} vectors, above the safety limit {MAX_ENUMERATED_VECTORS}"
        ));
    }
    Ok(())
}

/// Compute the Ewald energy in eV with Pymatgen-compatible default settings.
pub fn ewald_energy(structure: &Structure, charges: &[f64]) -> Result<EwaldEnergy, String> {
    structure.validate()?;
    if structure.pbc != [true; 3] {
        return Err("Ewald summation requires periodicity in all three directions".into());
    }
    let atom_count = structure.atomic_numbers.len();
    if charges.len() != atom_count || charges.iter().any(|charge| !charge.is_finite()) {
        return Err("oxidation states must be finite and match the atom count".into());
    }
    let volume = determinant(structure.cell_a).abs();
    if !volume.is_finite() || volume <= 1.0e-14 {
        return Err("Ewald summation requires a positive cell volume".into());
    }
    let inverse = inverse(structure.cell_a)?;
    let sqrt_eta =
        ((atom_count as f64 * EWALD_WEIGHT / volume.powi(2)).cbrt() * std::f64::consts::PI).sqrt();
    if !sqrt_eta.is_finite() || sqrt_eta <= 0.0 {
        return Err("Ewald screening parameter is invalid".into());
    }
    let accuracy = (10_f64.powf(DEFAULT_ACCURACY_FACTOR).ln()).sqrt();
    let real_cutoff = accuracy / sqrt_eta;
    let reciprocal_cutoff = 2.0 * sqrt_eta * accuracy;
    let real_cutoff2 = real_cutoff * real_cutoff;
    let reciprocal_cutoff2 = reciprocal_cutoff * reciprocal_cutoff;

    let mut real_pair_sum = 0.0;
    let mut real_vector_count = 0usize;
    for (center, &qi) in charges.iter().enumerate() {
        for (neighbor, &qj) in charges.iter().enumerate() {
            let displacement = std::array::from_fn(|axis| {
                structure.positions_a[neighbor][axis] - structure.positions_a[center][axis]
            });
            let fractional = cart_to_fractional(displacement, inverse);
            let bounds: [f64; 3] = std::array::from_fn(|axis| {
                let reciprocal_column = [inverse[0][axis], inverse[1][axis], inverse[2][axis]];
                real_cutoff * norm(reciprocal_column)
            });
            let integer_ranges = [
                integer_bounds(fractional[0], bounds[0])?,
                integer_bounds(fractional[1], bounds[1])?,
                integer_bounds(fractional[2], bounds[2])?,
            ];
            let candidates = ((integer_ranges[0].1 - integer_ranges[0].0 + 1).max(0) as usize)
                .saturating_mul((integer_ranges[1].1 - integer_ranges[1].0 + 1).max(0) as usize)
                .saturating_mul((integer_ranges[2].1 - integer_ranges[2].0 + 1).max(0) as usize);
            check_vector_budget(real_vector_count.saturating_add(candidates))?;
            for nx in integer_ranges[0].0..=integer_ranges[0].1 {
                for ny in integer_ranges[1].0..=integer_ranges[1].1 {
                    for nz in integer_ranges[2].0..=integer_ranges[2].1 {
                        let vector = fractional_to_cartesian(
                            [
                                fractional[0] + nx as f64,
                                fractional[1] + ny as f64,
                                fractional[2] + nz as f64,
                            ],
                            structure.cell_a,
                        );
                        let distance2 = vector.iter().map(|value| value * value).sum::<f64>();
                        if distance2 > real_cutoff2 || distance2 <= 1.0e-16 {
                            continue;
                        }
                        let distance = distance2.sqrt();
                        real_pair_sum += qi * qj * libm::erfc(sqrt_eta * distance) / distance;
                        real_vector_count += 1;
                        check_vector_budget(real_vector_count)?;
                    }
                }
            }
        }
    }
    let real_space_ev = 0.5 * COULOMB_EV_ANGSTROM * real_pair_sum;

    let mut reciprocal_sum = 0.0;
    let reciprocal_bounds: [i64; 3] = std::array::from_fn(|axis| {
        let row_norm = norm(structure.cell_a[axis]);
        (reciprocal_cutoff * row_norm / (2.0 * std::f64::consts::PI)).ceil() as i64
    });
    let reciprocal_candidates = ((2 * reciprocal_bounds[0] + 1).max(0) as usize)
        .saturating_mul((2 * reciprocal_bounds[1] + 1).max(0) as usize)
        .saturating_mul((2 * reciprocal_bounds[2] + 1).max(0) as usize);
    check_vector_budget(reciprocal_candidates)?;
    let reciprocal_vectors = [
        -reciprocal_bounds[0]..=reciprocal_bounds[0],
        -reciprocal_bounds[1]..=reciprocal_bounds[1],
        -reciprocal_bounds[2]..=reciprocal_bounds[2],
    ];
    for h in reciprocal_vectors[0].clone() {
        for k in reciprocal_vectors[1].clone() {
            for l in reciprocal_vectors[2].clone() {
                if h == 0 && k == 0 && l == 0 {
                    continue;
                }
                let g: [f64; 3] = std::array::from_fn(|cart| {
                    2.0 * std::f64::consts::PI
                        * (0..3)
                            .map(|axis| [h, k, l][axis] as f64 * inverse[cart][axis])
                            .sum::<f64>()
                });
                let g2 = g.iter().map(|value| value * value).sum::<f64>();
                if g2 > reciprocal_cutoff2 {
                    continue;
                }
                let mut structure_real = 0.0;
                let mut structure_imag = 0.0;
                for (&charge, position) in charges.iter().zip(&structure.positions_a) {
                    let phase = (0..3).map(|axis| g[axis] * position[axis]).sum::<f64>();
                    structure_real += charge * phase.cos();
                    structure_imag += charge * phase.sin();
                }
                let factor = (-g2 / (4.0 * sqrt_eta * sqrt_eta)).exp() / g2;
                reciprocal_sum +=
                    factor * (structure_real * structure_real + structure_imag * structure_imag);
            }
        }
    }
    let reciprocal_space_ev =
        COULOMB_EV_ANGSTROM * (2.0 * std::f64::consts::PI / volume) * reciprocal_sum;
    let sum_charge = charges.iter().sum::<f64>();
    let self_energy_ev = -COULOMB_EV_ANGSTROM * sqrt_eta / std::f64::consts::PI.sqrt()
        * charges.iter().map(|charge| charge * charge).sum::<f64>();
    let charged_cell_ev = -COULOMB_EV_ANGSTROM * 0.5 * std::f64::consts::PI
        / (volume * sqrt_eta * sqrt_eta)
        * sum_charge
        * sum_charge;
    let total_ev = real_space_ev + reciprocal_space_ev + self_energy_ev + charged_cell_ev;
    if [
        real_space_ev,
        reciprocal_space_ev,
        self_energy_ev,
        charged_cell_ev,
        total_ev,
    ]
    .iter()
    .any(|value| !value.is_finite())
    {
        return Err("Ewald summation produced a non-finite energy".into());
    }
    Ok(EwaldEnergy {
        real_space_ev,
        reciprocal_space_ev,
        self_energy_ev,
        charged_cell_ev,
        total_ev,
    })
}

/// Parse manual per-element oxidation states, or reproduce Pymatgen's
/// common/ICSD-ranked composition guess used by Macer's Madelung command.
pub fn assign_oxidation_states(
    atomic_numbers: &[u8],
    manual: Option<&str>,
) -> Result<OxidationAssignment, String> {
    if atomic_numbers.is_empty() {
        return Err("cannot assign oxidation states to an empty structure".into());
    }
    let mut species: Vec<(String, u8, usize)> = Vec::new();
    for &atomic_number in atomic_numbers {
        if atomic_number == 0 || atomic_number > 118 {
            return Err(format!("unsupported atomic number {atomic_number}"));
        }
        let symbol = oxidation_data::ELEMENTS[atomic_number as usize - 1]
            .0
            .to_owned();
        if let Some((_, _, count)) = species
            .iter_mut()
            .find(|(existing, _, _)| existing == &symbol)
        {
            *count += 1;
        } else {
            species.push((symbol, atomic_number, 1));
        }
    }
    let (map, source) = if let Some(specification) = manual.filter(|value| !value.is_empty()) {
        (
            parse_manual_oxidation_states(specification)?,
            OxidationSource::Manual(specification.to_owned()),
        )
    } else {
        let map = guess_oxidation_map(&species)?;
        let source = if map.values().all(|charge| charge.abs() <= 1.0e-12) {
            OxidationSource::PymatgenZeroFallback
        } else {
            OxidationSource::PymatgenGuess
        };
        (map, source)
    };
    let mut charges = Vec::with_capacity(atomic_numbers.len());
    for &atomic_number in atomic_numbers {
        let symbol = oxidation_data::ELEMENTS[atomic_number as usize - 1].0;
        let charge = map
            .get(symbol)
            .copied()
            .ok_or_else(|| format!("oxidation state is missing for element {symbol}"))?;
        charges.push(charge);
    }
    let site_symbols = atomic_numbers
        .iter()
        .map(|&atomic_number| {
            oxidation_data::ELEMENTS[atomic_number as usize - 1]
                .0
                .to_owned()
        })
        .collect();
    Ok(OxidationAssignment {
        symbols: species.into_iter().map(|item| item.0).collect(),
        site_symbols,
        charges,
        source,
    })
}

fn parse_manual_oxidation_states(specification: &str) -> Result<BTreeMap<String, f64>, String> {
    let mut map = BTreeMap::new();
    for raw_token in specification.split(',') {
        let token = raw_token.trim();
        if token.is_empty() {
            continue;
        }
        let (symbol, value) = token.split_once(':').ok_or_else(|| {
            format!("invalid oxidation-state token '{token}'; expected Element:Value")
        })?;
        let symbol = symbol.trim();
        if symbol.is_empty() {
            return Err("element symbol is empty in oxidation-state string".into());
        }
        let charge = value
            .trim()
            .parse::<f64>()
            .map_err(|_| format!("invalid oxidation state for element {symbol}"))?;
        if !charge.is_finite() {
            return Err(format!(
                "oxidation state for element {symbol} must be finite"
            ));
        }
        map.insert(symbol.to_owned(), charge);
    }
    if map.is_empty() {
        return Err("no valid oxidation states parsed".into());
    }
    Ok(map)
}

fn guess_oxidation_map(species: &[(String, u8, usize)]) -> Result<BTreeMap<String, f64>, String> {
    if species.len() == 1 {
        return Ok([(species[0].0.clone(), 0.0)].into_iter().collect());
    }
    let mut element_choices = Vec::with_capacity(species.len());
    for (symbol, atomic_number, count) in species {
        let (_, ic_states, common_states) = oxidation_data::ELEMENTS[*atomic_number as usize - 1];
        let states = if !ic_states.is_empty() {
            ic_states
        } else {
            common_states
        };
        if states.is_empty() {
            return Ok(species
                .iter()
                .map(|(element, _, _)| (element.clone(), 0.0))
                .collect());
        }
        element_choices.push(element_oxidation_choices(symbol, states, *count)?);
    }
    let mut partial = vec![(0_i32, 0_i64, Vec::<usize>::new())];
    for choices in &element_choices {
        let mut next: BTreeMap<i32, (i64, Vec<usize>)> = BTreeMap::new();
        for (prior_charge, prior_score, prior_indices) in &partial {
            for (choice_index, choice) in choices.iter().enumerate() {
                let charge = prior_charge + choice.0;
                let score = prior_score + choice.1;
                let mut indices = prior_indices.clone();
                indices.push(choice_index);
                let replace = next.get(&charge).is_none_or(|(old_score, old_indices)| {
                    score > *old_score || (score == *old_score && indices < *old_indices)
                });
                if replace {
                    next.insert(charge, (score, indices));
                }
            }
        }
        partial = next
            .into_iter()
            .map(|(charge, (score, indices))| (charge, score, indices))
            .collect();
    }
    let Some((_, _, selected)) = partial.into_iter().find(|(charge, _, _)| *charge == 0) else {
        // Pymatgen's add_oxidation_state_by_guess() decorates every element
        // with oxidation state zero when oxi_state_guesses() has no result.
        // Macer then rejects that all-zero assignment with its own diagnostic.
        return Ok(species
            .iter()
            .map(|(symbol, _, _)| (symbol.clone(), 0.0))
            .collect());
    };
    let mut map = BTreeMap::new();
    for ((symbol, _, count), choices, selected_index) in species
        .iter()
        .zip(&element_choices)
        .zip(selected)
        .map(|((species, choices), index)| (species, choices, index))
    {
        map.insert(
            symbol.clone(),
            choices[selected_index].2 as f64 / *count as f64,
        );
    }
    Ok(map)
}

/// Hashes of the Pymatgen data files from which the built-in oxidation-state
/// and ICSD occurrence tables were generated.
pub fn oxidation_reference_data_info() -> (&'static str, &'static str, &'static str) {
    (
        oxidation_data::PYMATGEN_SOURCE_VERSION,
        oxidation_data::PYMATGEN_PERIODIC_DATA_SHA256,
        oxidation_data::PYMATGEN_ICSD_BV_SHA256,
    )
}

/// For one element, return `(integer charge sum, occurrence score, average
/// charge)` rows in Pymatgen's combinations-with-replacement order.
fn element_oxidation_choices(
    symbol: &str,
    states: &[i8],
    count: usize,
) -> Result<Vec<(i32, i64, i32)>, String> {
    let state_scores = states
        .iter()
        .map(|&state| {
            oxidation_data::OXI_OCCURRENCE
                .iter()
                .find(|(element, charge, _)| *element == symbol && *charge == state)
                .map(|(_, _, score)| *score)
                .unwrap_or(0)
        })
        .collect::<Vec<_>>();
    let mut best = vec![BTreeMap::<i32, Choice>::new(); count + 1];
    let mut first = vec![BTreeMap::<i32, Vec<usize>>::new(); count + 1];
    best[0].insert(
        0,
        Choice {
            score: 0,
            counts: vec![0; states.len()],
        },
    );
    first[0].insert(0, vec![0; states.len()]);
    for (state_index, &state) in states.iter().enumerate() {
        let mut next_best = best.clone();
        let mut next_first = first.clone();
        for used in 1..=count {
            let prior_best = next_best[used - 1].clone();
            let prior_first = next_first[used - 1].clone();
            for (prior_charge, choice) in prior_best {
                let charge = prior_charge + i32::from(state);
                let mut candidate = choice.clone();
                candidate.score += state_scores[state_index];
                candidate.counts[state_index] += 1;
                let replace = next_best[used].get(&charge).is_none_or(|old| {
                    candidate.score > old.score
                        || (candidate.score == old.score
                            && lex_counts_before(&candidate.counts, &old.counts))
                });
                if replace {
                    next_best[used].insert(charge, candidate);
                }
            }
            for (prior_charge, counts) in prior_first {
                let charge = prior_charge + i32::from(state);
                let mut candidate = counts;
                candidate[state_index] += 1;
                let replace = next_first[used]
                    .get(&charge)
                    .is_none_or(|old| lex_counts_before(&candidate, old));
                if replace {
                    next_first[used].insert(charge, candidate);
                }
            }
        }
        best = next_best;
        first = next_first;
    }
    let mut rows = best[count]
        .iter()
        .map(|(&charge, choice)| {
            let order = first[count]
                .get(&charge)
                .expect("reachable charge has first choice");
            (charge, choice.score, charge, order.clone())
        })
        .collect::<Vec<_>>();
    rows.sort_by(|left, right| {
        if lex_counts_before(&left.3, &right.3) {
            std::cmp::Ordering::Less
        } else if lex_counts_before(&right.3, &left.3) {
            std::cmp::Ordering::Greater
        } else {
            std::cmp::Ordering::Equal
        }
    });
    Ok(rows
        .into_iter()
        .map(|(sum, score, charge, _)| (sum, score, charge))
        .collect())
}

fn lex_counts_before(left: &[usize], right: &[usize]) -> bool {
    for (left_count, right_count) in left.iter().zip(right) {
        if left_count != right_count {
            return left_count > right_count;
        }
    }
    false
}

#[cfg(test)]
mod tests {
    use super::*;

    fn two_site_cell() -> Structure {
        Structure {
            atomic_numbers: vec![3, 9],
            positions_a: vec![[0.0, 0.0, 0.0], [2.0, 2.0, 2.0]],
            cell_a: [[4.0, 0.0, 0.0], [0.0, 4.0, 0.0], [0.0, 0.0, 4.0]],
            pbc: [true; 3],
        }
    }

    #[test]
    fn ewald_energy_is_invariant_to_global_translation() {
        let mut structure = two_site_cell();
        let original = ewald_energy(&structure, &[1.0, -1.0]).unwrap();
        for position in &mut structure.positions_a {
            for axis in 0..3 {
                position[axis] += 1.327;
            }
        }
        let translated = ewald_energy(&structure, &[1.0, -1.0]).unwrap();
        assert!((original.total_ev - translated.total_ev).abs() < 1.0e-11);
    }

    #[test]
    fn automatic_oxidation_guess_matches_common_alkali_halide_assignments() {
        let assigned = assign_oxidation_states(&[11, 17, 11, 17], None).unwrap();
        assert_eq!(assigned.symbols, ["Na", "Cl"]);
        assert_eq!(assigned.charges, [1.0, -1.0, 1.0, -1.0]);
    }

    #[test]
    fn manual_oxidation_assignment_preserves_species_order_and_values() {
        let assigned = assign_oxidation_states(&[26, 8, 26, 8], Some("Fe:2.5,O:-2")).unwrap();
        assert_eq!(assigned.symbols, ["Fe", "O"]);
        assert_eq!(assigned.charges, [2.5, -2.0, 2.5, -2.0]);
    }
}
