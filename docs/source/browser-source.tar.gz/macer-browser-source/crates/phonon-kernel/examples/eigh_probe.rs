use macer_rust_phonon_kernel::diagonalize_hermitian;

fn main() {
    let matrix = [[2.0, 0.0], [0.0, 1.0], [0.0, -1.0], [2.0, 0.0]];
    let result = diagonalize_hermitian(&matrix, 2).expect("Hermitian probe");
    for value in result.values {
        println!("E,{value:.17e}");
    }
    for value in result.vectors {
        println!("V,{:.17e},{:.17e}", value[0], value[1]);
    }
}
