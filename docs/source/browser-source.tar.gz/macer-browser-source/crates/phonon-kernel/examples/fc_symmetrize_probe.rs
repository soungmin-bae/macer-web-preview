use macer_rust_phonon_kernel::perm_trans_symmetrize_full_fc;

fn main() {
    let mut fc: Vec<f64> = (0..2 * 2 * 9).map(|i| (i as f64 - 8.0) / 7.0).collect();
    perm_trans_symmetrize_full_fc(&mut fc, 2, 1).expect("valid FC2");
    for value in fc {
        println!("{value:.17e}");
    }
}
