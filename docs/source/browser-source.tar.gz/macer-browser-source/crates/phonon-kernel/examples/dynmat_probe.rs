use macer_rust_phonon_kernel::{dynamical_matrix_at_q, DynamicalMatrixInput};

fn main() {
    let fc = [
        2.0, 0.0, 0.0, 0.0, 4.0, 0.0, 0.0, 0.0, 6.0, -1.0, 0.0, 0.0, 0.0, -2.0, 0.0, 0.0, 0.0, -3.0,
    ];
    let result = dynamical_matrix_at_q(DynamicalMatrixInput {
        force_constants: &fc,
        q: [0.0; 3],
        shortest_vectors: &[[0.0; 3], [1.0, 0.0, 0.0]],
        multiplicity_start: &[[1, 0], [1, 1]],
        masses: &[2.0],
        supercell_to_primitive: &[0, 0],
        primitive_to_force_constant_row: &[0],
        primitive_atoms: 1,
        supercell_atoms: 2,
    })
    .expect("valid fixed probe");
    for value in result {
        println!("{:.17e},{:.17e}", value[0], value[1]);
    }
}
