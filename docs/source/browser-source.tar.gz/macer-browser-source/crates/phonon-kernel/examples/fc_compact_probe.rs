use macer_rust_phonon_kernel::perm_trans_symmetrize_compact_fc;

fn main() {
    let n_satom = 2;
    let mut fc: Vec<f64> = (0..n_satom * 9).map(|i| (i as f64 - 5.0) / 9.0).collect();
    perm_trans_symmetrize_compact_fc(&mut fc, &[0, 1], &[0, 0], &[0], &[0, 0], n_satom, 1)
        .expect("valid compact FC2");
    for value in fc {
        println!("{value:.17e}");
    }
}
