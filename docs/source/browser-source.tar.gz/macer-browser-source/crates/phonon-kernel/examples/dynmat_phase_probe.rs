use macer_rust_phonon_kernel::{dynamical_matrix_at_q, DynamicalMatrixInput};

fn main() {
    let mut fc = vec![0.0; 2 * 2 * 9];
    fc[(0 * 2 + 1) * 9] = 1.0;
    fc[(1 * 2) * 9] = 1.0;
    let result = dynamical_matrix_at_q(DynamicalMatrixInput {
        force_constants: &fc,
        q: [0.25, 0.0, 0.0],
        shortest_vectors: &[[0.0; 3], [-1.0, 0.0, 0.0], [1.0, 0.0, 0.0], [0.0; 3]],
        multiplicity_start: &[[1, 0], [1, 1], [1, 2], [1, 3]],
        masses: &[1.0, 1.0],
        supercell_to_primitive: &[0, 1],
        primitive_to_force_constant_row: &[0, 1],
        primitive_atoms: 2,
        supercell_atoms: 2,
    })
    .expect("valid complex-phase probe");
    for value in result {
        println!("{:.17e},{:.17e}", value[0], value[1]);
    }
}
