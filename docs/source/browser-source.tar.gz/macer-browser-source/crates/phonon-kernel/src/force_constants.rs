//! Full second-order force-constant reconstruction and symmetrization.
//!
//! The permutation/translation procedure follows `phonors` 0.3.0
//! (`src/fc2.rs`, BSD-3-Clause), commit
//! `ca6eac4464cea519fef1d6d8018b4d13c20fa84d`.

use crate::KernelError;

/// One centered pair of force evaluations for displacement of atom `i` along
/// Cartesian axis `alpha` by `± displacement`.
#[derive(Clone, Copy)]
pub struct ForcePair<'a> {
    pub displaced_atom: usize,
    pub axis: usize,
    pub displacement: f64,
    /// Forces for the positive displacement, flattened `[atom, component]`.
    pub forces_plus: &'a [f64],
    /// Forces for the negative displacement, flattened `[atom, component]`.
    pub forces_minus: &'a [f64],
}

/// Force/displacement data for one symmetry-reduced displaced atom.
///
/// `site_rotations_cartesian` stores Cartesian rotation matrices row-major and
/// `atom_permutations` stores, for each operation and target atom, the source
/// atom whose force is rotated onto that target. This is the inverse-site
/// mapping convention used by phonopy's finite-difference solver.
pub struct SymmetryReducedDisplacementSet<'a> {
    pub displacements: &'a [[f64; 3]],
    /// Flattened `[displacement, atom, Cartesian component]` forces.
    pub forces: &'a [f64],
    /// Row-major `[operation, 3, 3]` Cartesian rotations.
    pub site_rotations_cartesian: &'a [f64],
    /// Row-major `[operation, target atom]` source-atom indices.
    pub atom_permutations: &'a [usize],
}

/// Reconstructs one displaced-atom FC2 row from symmetry-reduced forces.
///
/// For every target atom, site-symmetry operations expand each measured
/// displacement/force pair into an overdetermined Cartesian system. A 3x3
/// least-squares solve returns `-dF[target, beta] / du[alpha]` in eV/Å².
/// Output is flattened `[target atom, displacement axis, force component]`.
pub fn force_constants_row_from_symmetry_reduced_forces(
    n_atoms: usize,
    set: SymmetryReducedDisplacementSet<'_>,
) -> Result<Vec<f64>, KernelError> {
    let n_ops = set.site_rotations_cartesian.len() / 9;
    let expected_rotation_len = n_ops.checked_mul(9).ok_or(KernelError::InvalidDimensions)?;
    let expected_map_len = n_ops
        .checked_mul(n_atoms)
        .ok_or(KernelError::InvalidDimensions)?;
    let expected_force_len = set
        .displacements
        .len()
        .checked_mul(n_atoms)
        .and_then(|v| v.checked_mul(3))
        .ok_or(KernelError::InvalidDimensions)?;
    if n_atoms == 0
        || set.displacements.is_empty()
        || n_ops == 0
        || set.site_rotations_cartesian.len() != expected_rotation_len
        || set.atom_permutations.len() != expected_map_len
        || set.forces.len() != expected_force_len
    {
        return Err(KernelError::InvalidDimensions);
    }
    if !set.displacements.iter().flatten().all(|x| x.is_finite())
        || !set.forces.iter().all(|x| x.is_finite())
        || !set.site_rotations_cartesian.iter().all(|x| x.is_finite())
    {
        return Err(KernelError::NonFiniteInput);
    }
    if set.atom_permutations.iter().any(|&i| i >= n_atoms) {
        return Err(KernelError::InvalidMapping);
    }

    let n_samples = set.displacements.len() * n_ops;
    let mut design = Vec::with_capacity(n_samples);
    for displacement in set.displacements {
        for op in 0..n_ops {
            let r = &set.site_rotations_cartesian[op * 9..(op + 1) * 9];
            design.push([
                r[0] * displacement[0] + r[1] * displacement[1] + r[2] * displacement[2],
                r[3] * displacement[0] + r[4] * displacement[1] + r[5] * displacement[2],
                r[6] * displacement[0] + r[7] * displacement[1] + r[8] * displacement[2],
            ]);
        }
    }
    let mut gram = [[0.0; 3]; 3];
    for d in &design {
        for a in 0..3 {
            for b in 0..3 {
                gram[a][b] += d[a] * d[b];
            }
        }
    }
    let inverse = inverse_3x3(gram).ok_or(KernelError::InvalidMapping)?;
    let mut output = vec![0.0; n_atoms * 9];
    for target in 0..n_atoms {
        let mut rhs = [[0.0; 3]; 3];
        let mut sample = 0;
        for (disp_index, _) in set.displacements.iter().enumerate() {
            for op in 0..n_ops {
                let r = &set.site_rotations_cartesian[op * 9..(op + 1) * 9];
                let source = set.atom_permutations[op * n_atoms + target];
                let force_offset = (disp_index * n_atoms + source) * 3;
                let f = &set.forces[force_offset..force_offset + 3];
                let rotated_force = [
                    r[0] * f[0] + r[1] * f[1] + r[2] * f[2],
                    r[3] * f[0] + r[4] * f[1] + r[5] * f[2],
                    r[6] * f[0] + r[7] * f[1] + r[8] * f[2],
                ];
                for a in 0..3 {
                    for b in 0..3 {
                        rhs[a][b] -= design[sample][a] * rotated_force[b];
                    }
                }
                sample += 1;
            }
        }
        for a in 0..3 {
            for b in 0..3 {
                output[target * 9 + a * 3 + b] = (0..3).map(|k| inverse[a][k] * rhs[k][b]).sum();
            }
        }
    }
    Ok(output)
}

/// Expands representative displaced-atom FC2 rows to the full supercell by
/// space-group operations. Multiple valid mappings are averaged, which also
/// projects the row against the target atom's site symmetry.
pub fn force_constants_full_from_symmetry_reduced_rows(
    n_atoms: usize,
    representative_atoms: &[usize],
    representative_fc_rows: &[f64],
    rotations_cartesian: &[f64],
    atom_permutations: &[usize],
) -> Result<Vec<f64>, KernelError> {
    let n_ops = rotations_cartesian.len() / 9;
    let expected_rows = representative_atoms
        .len()
        .checked_mul(n_atoms)
        .and_then(|v| v.checked_mul(9))
        .ok_or(KernelError::InvalidDimensions)?;
    if n_atoms == 0
        || representative_atoms.is_empty()
        || n_ops == 0
        || representative_fc_rows.len() != expected_rows
        || rotations_cartesian.len() != n_ops * 9
        || atom_permutations.len()
            != n_ops
                .checked_mul(n_atoms)
                .ok_or(KernelError::InvalidDimensions)?
    {
        return Err(KernelError::InvalidDimensions);
    }
    if representative_atoms.iter().any(|&i| i >= n_atoms)
        || atom_permutations.iter().any(|&i| i >= n_atoms)
    {
        return Err(KernelError::InvalidMapping);
    }
    if !representative_fc_rows
        .iter()
        .chain(rotations_cartesian.iter())
        .all(|x| x.is_finite())
    {
        return Err(KernelError::NonFiniteInput);
    }
    let mut seen_rep = vec![false; n_atoms];
    for &atom in representative_atoms {
        if std::mem::replace(&mut seen_rep[atom], true) {
            return Err(KernelError::InvalidMapping);
        }
    }
    for op in 0..n_ops {
        let mut seen = vec![false; n_atoms];
        for &target in &atom_permutations[op * n_atoms..(op + 1) * n_atoms] {
            if std::mem::replace(&mut seen[target], true) {
                return Err(KernelError::InvalidMapping);
            }
        }
    }
    let mut output = vec![0.0; n_atoms * n_atoms * 9];
    for target_i in 0..n_atoms {
        let mut count = 0usize;
        for (row_id, &source_i) in representative_atoms.iter().enumerate() {
            for op in 0..n_ops {
                let permutation = &atom_permutations[op * n_atoms..(op + 1) * n_atoms];
                if permutation[source_i] != target_i {
                    continue;
                }
                let r = &rotations_cartesian[op * 9..(op + 1) * 9];
                for source_j in 0..n_atoms {
                    let target_j = permutation[source_j];
                    for alpha in 0..3 {
                        for beta in 0..3 {
                            let mut value = 0.0;
                            for gamma in 0..3 {
                                for delta in 0..3 {
                                    let source =
                                        ((row_id * n_atoms + source_j) * 3 + gamma) * 3 + delta;
                                    value += r[alpha * 3 + gamma]
                                        * representative_fc_rows[source]
                                        * r[beta * 3 + delta];
                                }
                            }
                            let target = ((target_i * n_atoms + target_j) * 3 + alpha) * 3 + beta;
                            output[target] += value;
                        }
                    }
                }
                count += 1;
            }
        }
        if count == 0 {
            return Err(KernelError::InvalidMapping);
        }
        let scale = 1.0 / count as f64;
        for value in &mut output[target_i * n_atoms * 9..(target_i + 1) * n_atoms * 9] {
            *value *= scale;
        }
    }
    Ok(output)
}

fn inverse_3x3(m: [[f64; 3]; 3]) -> Option<[[f64; 3]; 3]> {
    let det = m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
        - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
        + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
    let scale = m.iter().flatten().fold(0.0_f64, |a, &b| a.max(b.abs()));
    if !det.is_finite() || scale == 0.0 || det.abs() <= 1e-12 * scale.powi(3) {
        return None;
    }
    let inv_det = 1.0 / det;
    Some([
        [
            (m[1][1] * m[2][2] - m[1][2] * m[2][1]) * inv_det,
            (m[0][2] * m[2][1] - m[0][1] * m[2][2]) * inv_det,
            (m[0][1] * m[1][2] - m[0][2] * m[1][1]) * inv_det,
        ],
        [
            (m[1][2] * m[2][0] - m[1][0] * m[2][2]) * inv_det,
            (m[0][0] * m[2][2] - m[0][2] * m[2][0]) * inv_det,
            (m[0][2] * m[1][0] - m[0][0] * m[1][2]) * inv_det,
        ],
        [
            (m[1][0] * m[2][1] - m[1][1] * m[2][0]) * inv_det,
            (m[0][1] * m[2][0] - m[0][0] * m[2][1]) * inv_det,
            (m[0][0] * m[1][1] - m[0][1] * m[1][0]) * inv_det,
        ],
    ])
}

/// Reconstructs full FC2 as `-dF[j,beta] / du[i,alpha]` from centered
/// displacements. Output is flattened `[i, j, alpha, beta]` in eV/Å².
/// Every atom and Cartesian direction must appear exactly once.
pub fn force_constants_from_central_forces(
    n_atoms: usize,
    pairs: &[ForcePair<'_>],
) -> Result<Vec<f64>, KernelError> {
    if n_atoms == 0 || pairs.len() != n_atoms.saturating_mul(3) {
        return Err(KernelError::InvalidDimensions);
    }
    let force_len = n_atoms
        .checked_mul(3)
        .ok_or(KernelError::InvalidDimensions)?;
    let fc_len = n_atoms
        .checked_mul(n_atoms)
        .and_then(|v| v.checked_mul(9))
        .ok_or(KernelError::InvalidDimensions)?;
    let mut seen = vec![false; force_len];
    let mut fc = vec![0.0; fc_len];
    for pair in pairs {
        if pair.displaced_atom >= n_atoms
            || pair.axis >= 3
            || !pair.displacement.is_finite()
            || pair.displacement <= 0.0
            || pair.forces_plus.len() != force_len
            || pair.forces_minus.len() != force_len
        {
            return Err(KernelError::InvalidDimensions);
        }
        if !pair
            .forces_plus
            .iter()
            .chain(pair.forces_minus.iter())
            .all(|value| value.is_finite())
        {
            return Err(KernelError::NonFiniteInput);
        }
        let dof = pair.displaced_atom * 3 + pair.axis;
        if std::mem::replace(&mut seen[dof], true) {
            return Err(KernelError::InvalidMapping);
        }
        for target_atom in 0..n_atoms {
            for beta in 0..3 {
                let force_index = target_atom * 3 + beta;
                let fc_index =
                    ((pair.displaced_atom * n_atoms + target_atom) * 3 + pair.axis) * 3 + beta;
                fc[fc_index] = -(pair.forces_plus[force_index] - pair.forces_minus[force_index])
                    / (2.0 * pair.displacement);
            }
        }
    }
    if seen.iter().any(|was_seen| !was_seen) {
        return Err(KernelError::InvalidMapping);
    }
    Ok(fc)
}

fn set_index_permutation_symmetry(fc: &mut [f64], n: usize) {
    let stride = n * 9;
    for i in 0..n {
        for j in (i + 1)..n {
            for alpha in 0..3 {
                for beta in 0..3 {
                    let a = i * stride + j * 9 + alpha * 3 + beta;
                    let b = j * stride + i * 9 + beta * 3 + alpha;
                    let average = (fc[a] + fc[b]) * 0.5;
                    fc[a] = average;
                    fc[b] = average;
                }
            }
        }
        for alpha in 0..2 {
            for beta in (alpha + 1)..3 {
                let a = i * stride + i * 9 + alpha * 3 + beta;
                let b = i * stride + i * 9 + beta * 3 + alpha;
                let average = (fc[a] + fc[b]) * 0.5;
                fc[a] = average;
                fc[b] = average;
            }
        }
    }
}

fn set_translational_symmetry(fc: &mut [f64], n: usize) {
    let stride = n * 9;
    for i in 0..n {
        let mut sums = [[0.0; 3]; 3];
        for alpha in 0..3 {
            for beta in 0..3 {
                for j in 0..n {
                    if i != j {
                        sums[alpha][beta] += fc[i * stride + j * 9 + alpha * 3 + beta];
                    }
                }
            }
        }
        for alpha in 0..3 {
            for beta in 0..3 {
                fc[i * stride + i * 9 + alpha * 3 + beta] =
                    -(sums[alpha][beta] + sums[beta][alpha]) * 0.5;
            }
        }
    }
}

/// Applies phonors-style full-FC2 row/column drift removal, index permutation
/// averaging and final acoustic sum-rule on-site correction.
pub fn perm_trans_symmetrize_full_fc(
    fc: &mut [f64],
    n_atoms: usize,
    level: usize,
) -> Result<(), KernelError> {
    let expected = n_atoms
        .checked_mul(n_atoms)
        .and_then(|v| v.checked_mul(9))
        .ok_or(KernelError::InvalidDimensions)?;
    if n_atoms == 0 || fc.len() != expected {
        return Err(KernelError::InvalidDimensions);
    }
    if !fc.iter().all(|value| value.is_finite()) {
        return Err(KernelError::NonFiniteInput);
    }
    let inv_n = 1.0 / n_atoms as f64;
    let stride = n_atoms * 9;
    for _ in 0..level {
        for j in 0..n_atoms {
            for alpha in 0..3 {
                for beta in 0..3 {
                    let average = (0..n_atoms)
                        .map(|i| fc[i * stride + j * 9 + alpha * 3 + beta])
                        .sum::<f64>()
                        * inv_n;
                    for i in 0..n_atoms {
                        fc[i * stride + j * 9 + alpha * 3 + beta] -= average;
                    }
                }
            }
        }
        for i in 0..n_atoms {
            for alpha in 0..3 {
                for beta in 0..3 {
                    let average = (0..n_atoms)
                        .map(|j| fc[i * stride + j * 9 + alpha * 3 + beta])
                        .sum::<f64>()
                        * inv_n;
                    for j in 0..n_atoms {
                        fc[i * stride + j * 9 + alpha * 3 + beta] -= average;
                    }
                }
            }
        }
        set_index_permutation_symmetry(fc, n_atoms);
    }
    set_translational_symmetry(fc, n_atoms);
    Ok(())
}

fn set_index_permutation_symmetry_compact(
    fc: &mut [f64],
    p2s: &[usize],
    s2pp: &[usize],
    nsym_list: &[usize],
    perms: &[usize],
    n_satom: usize,
    n_patom: usize,
    transpose: bool,
) {
    let stride = n_satom * 9;
    let mut done = vec![false; n_patom * n_satom];
    for j in 0..n_satom {
        let j_p = s2pp[j];
        for i_p in 0..n_patom {
            let i = p2s[i_p];
            if i == j {
                for alpha in 0..3 {
                    for beta in (alpha + 1)..3 {
                        let m = i_p * stride + i * 9 + alpha * 3 + beta;
                        let n = i_p * stride + i * 9 + beta * 3 + alpha;
                        if transpose {
                            fc.swap(m, n);
                        } else {
                            let average = (fc[m] + fc[n]) * 0.5;
                            fc[m] = average;
                            fc[n] = average;
                        }
                    }
                }
            }
            if !done[i_p * n_satom + j] {
                let i_trans = perms[nsym_list[j] * n_satom + i];
                done[i_p * n_satom + j] = true;
                done[j_p * n_satom + i_trans] = true;
                for alpha in 0..3 {
                    for beta in 0..3 {
                        let m = i_p * stride + j * 9 + alpha * 3 + beta;
                        let n = j_p * stride + i_trans * 9 + beta * 3 + alpha;
                        if transpose {
                            fc.swap(m, n);
                        } else {
                            let average = (fc[m] + fc[n]) * 0.5;
                            fc[m] = average;
                            fc[n] = average;
                        }
                    }
                }
            }
        }
    }
}

fn set_translational_symmetry_compact(
    fc: &mut [f64],
    p2s: &[usize],
    n_satom: usize,
    n_patom: usize,
) {
    let stride = n_satom * 9;
    for i_p in 0..n_patom {
        let mut sums = [[0.0; 3]; 3];
        for alpha in 0..3 {
            for beta in 0..3 {
                for j in 0..n_satom {
                    if p2s[i_p] != j {
                        sums[alpha][beta] += fc[i_p * stride + j * 9 + alpha * 3 + beta];
                    }
                }
            }
        }
        let onsite = p2s[i_p];
        for alpha in 0..3 {
            for beta in 0..3 {
                fc[i_p * stride + onsite * 9 + alpha * 3 + beta] =
                    -(sums[alpha][beta] + sums[beta][alpha]) * 0.5;
            }
        }
    }
}

/// Applies phonors-style primitive/compact FC2 transpose averaging, row-drift
/// removal, pair-permutation averaging and on-site acoustic sum-rule closure.
/// `permutations` is row-major `[symmetry operation, supercell atom]`.
pub fn perm_trans_symmetrize_compact_fc(
    fc: &mut [f64],
    permutations: &[usize],
    s2pp: &[usize],
    p2s: &[usize],
    nsym_list: &[usize],
    n_satom: usize,
    level: usize,
) -> Result<(), KernelError> {
    let n_patom = p2s.len();
    let expected = n_patom
        .checked_mul(n_satom)
        .and_then(|v| v.checked_mul(9))
        .ok_or(KernelError::InvalidDimensions)?;
    if n_satom == 0
        || n_patom == 0
        || fc.len() != expected
        || s2pp.len() != n_satom
        || nsym_list.len() != n_satom
        || permutations.is_empty()
        || permutations.len() % n_satom != 0
    {
        return Err(KernelError::InvalidDimensions);
    }
    if !fc.iter().all(|value| value.is_finite()) {
        return Err(KernelError::NonFiniteInput);
    }
    let n_sym = permutations.len() / n_satom;
    if p2s.iter().any(|&atom| atom >= n_satom)
        || s2pp.iter().any(|&atom| atom >= n_patom)
        || nsym_list.iter().any(|&sym| sym >= n_sym)
        || permutations.iter().any(|&atom| atom >= n_satom)
    {
        return Err(KernelError::InvalidMapping);
    }
    let mut primitive_anchors = p2s.to_vec();
    primitive_anchors.sort_unstable();
    primitive_anchors.dedup();
    if primitive_anchors.len() != n_patom
        || permutations.chunks_exact(n_satom).any(|row| {
            let mut values = row.to_vec();
            values.sort_unstable();
            values.dedup();
            values.len() != n_satom
        })
    {
        return Err(KernelError::InvalidMapping);
    }
    let stride = n_satom * 9;
    let inv_n = 1.0 / n_satom as f64;
    for _ in 0..level {
        for _ in 0..2 {
            set_index_permutation_symmetry_compact(
                fc,
                p2s,
                s2pp,
                nsym_list,
                permutations,
                n_satom,
                n_patom,
                true,
            );
            for i_p in 0..n_patom {
                for alpha in 0..3 {
                    for beta in 0..3 {
                        let average = (0..n_satom)
                            .map(|j| fc[i_p * stride + j * 9 + alpha * 3 + beta])
                            .sum::<f64>()
                            * inv_n;
                        for j in 0..n_satom {
                            fc[i_p * stride + j * 9 + alpha * 3 + beta] -= average;
                        }
                    }
                }
            }
        }
        set_index_permutation_symmetry_compact(
            fc,
            p2s,
            s2pp,
            nsym_list,
            permutations,
            n_satom,
            n_patom,
            false,
        );
    }
    set_translational_symmetry_compact(fc, p2s, n_satom, n_patom);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn central_force_derivatives_reconstruct_force_constants() {
        let n = 2;
        let displacement = 0.01;
        let mut pairs = Vec::new();
        let mut storage = Vec::new();
        for i in 0..n {
            for alpha in 0..3 {
                let mut plus = vec![0.0; n * 3];
                let mut minus = vec![0.0; n * 3];
                for j in 0..n {
                    for beta in 0..3 {
                        let value = if i == j && alpha == beta { 2.0 } else { 0.0 };
                        plus[j * 3 + beta] = -value * displacement;
                        minus[j * 3 + beta] = value * displacement;
                    }
                }
                storage.push((plus, minus));
            }
        }
        for (dof, (plus, minus)) in storage.iter().enumerate() {
            pairs.push(ForcePair {
                displaced_atom: dof / 3,
                axis: dof % 3,
                displacement,
                forces_plus: plus,
                forces_minus: minus,
            });
        }
        let fc = force_constants_from_central_forces(n, &pairs).unwrap();
        assert_eq!(fc[0], 2.0);
        assert_eq!(fc[((1 * n + 1) * 3 + 2) * 3 + 2], 2.0);
        assert!(fc.iter().filter(|&&value| value != 0.0).count() == 6);
    }

    #[test]
    fn full_force_constant_symmetry_matches_invariants() {
        let n = 2;
        let mut fc: Vec<f64> = (0..n * n * 9).map(|i| (i as f64 - 8.0) / 7.0).collect();
        perm_trans_symmetrize_full_fc(&mut fc, n, 1).unwrap();
        for i in 0..n {
            for alpha in 0..3 {
                for beta in 0..3 {
                    let row_sum: f64 = (0..n)
                        .map(|j| fc[((i * n + j) * 3 + alpha) * 3 + beta])
                        .sum();
                    assert!(row_sum.abs() < 1e-12);
                    for j in 0..n {
                        let a = fc[((i * n + j) * 3 + alpha) * 3 + beta];
                        let b = fc[((j * n + i) * 3 + beta) * 3 + alpha];
                        assert!((a - b).abs() < 1e-12);
                    }
                }
            }
        }
    }

    #[test]
    fn compact_fc_symmetry_validates_primitive_mapping() {
        let n_satom = 2;
        let mut fc: Vec<f64> = (0..n_satom * 9).map(|i| (i as f64 - 5.0) / 9.0).collect();
        perm_trans_symmetrize_compact_fc(&mut fc, &[0, 1], &[0, 0], &[0], &[0, 0], n_satom, 1)
            .unwrap();
        for alpha in 0..3 {
            for beta in 0..3 {
                let sum: f64 = (0..n_satom).map(|j| fc[(j * 3 + alpha) * 3 + beta]).sum();
                assert!(sum.abs() < 1e-12);
            }
        }
        assert_eq!(
            perm_trans_symmetrize_compact_fc(&mut fc, &[0, 9], &[0, 0], &[0], &[0, 0], n_satom, 1),
            Err(KernelError::InvalidMapping)
        );
    }
}
