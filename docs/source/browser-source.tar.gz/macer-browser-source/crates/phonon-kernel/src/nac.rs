//! Sequential safe-slice Gonze reciprocal kernel extracted from phonors 0.3.0
//! ca6eac4464cea519fef1d6d8018b4d13c20fa84d (BSD-3-Clause).
use std::f64::consts::PI;
type Vec3D = [f64; 3];
type MatD = [[f64; 3]; 3];
type Cmplx = [f64; 2];
const Q2_ZERO_TOLERANCE: f64 = 1e-10;
/// q^T eps q.  Mirrors `get_dielectric_part` in `c/dynmat.c`.
fn dielectric_part(q_cart: Vec3D, dielectric: &MatD) -> f64 {
    let mut s = 0.0;
    for i in 0..3 {
        for j in 0..3 {
            s += q_cart[i] * dielectric[i][j] * q_cart[j];
        }
    }
    s
}

/// Per-G accumulation into the [i, alpha, j, beta] dipole-dipole
/// buffer.  Mirrors `get_dd_at_g` in `c/dynmat.c`.  The phase uses
/// G (not G+q) to give the C-type dynamical matrix.
fn dd_at_g(
    dd_part: &mut [Cmplx],
    i: usize,
    j: usize,
    g_vec: Vec3D,
    num_patom: usize,
    pos: &[Vec3D],
    kk: &MatD,
) {
    let mut phase = 0.0;
    for k in 0..3 {
        phase += (pos[i][k] - pos[j][k]) * g_vec[k];
    }
    phase *= 2.0 * PI;
    let cos_phase = phase.cos();
    let sin_phase = phase.sin();
    for k in 0..3 {
        for l in 0..3 {
            let adrs = i * num_patom * 9 + k * num_patom * 3 + j * 3 + l;
            dd_part[adrs][0] += kk[k][l] * cos_phase;
            dd_part[adrs][1] += kk[k][l] * sin_phase;
        }
    }
}

/// Build the dipole-dipole reciprocal sum into the
/// [i, alpha, j, beta] (real, imag) flat buffer.  Mirrors `get_dd`
/// in `c/dynmat.c`.  When `q_direction_cart` is `None` and
/// `q_cart` is at G=0, the K=0 term contributes zero (used for
/// the q0 path here); otherwise the q-direction limit is used.
#[allow(clippy::too_many_arguments)]
fn get_dd(
    dd_part: &mut [Cmplx],
    g_list: &[Vec3D],
    num_patom: usize,
    q_cart: Vec3D,
    q_direction_cart: Option<Vec3D>,
    dielectric: &MatD,
    pos: &[Vec3D],
    lambda: f64,
) {
    let l2 = 4.0 * lambda * lambda;
    let mut kk: Vec<MatD> = vec![[[0.0; 3]; 3]; g_list.len()];
    // PRECONDITION: `q_cart` is the cartesian image of a q-point inside
    // the first Brillouin zone.  Under that assumption the
    // `K = G + q_cart ≈ 0` special case can only fire when both
    // q_cart is at Gamma and G = 0 (any non-zero G has cartesian norm
    // well above the tolerance, and q_cart cannot sit on a non-zero
    // reciprocal lattice vector while being inside the first BZ).
    // We therefore hoist the q-at-Gamma check, skipping the per-G
    // norm computation and branch on the common (q != Gamma) path.
    //
    // If a caller ever feeds a q outside the first BZ that happens to
    // satisfy q + G = 0 for some G in `g_list`, the non-Gamma branch
    // below will divide by zero (`dpart = 0`).  Phonopy does not
    // strictly enforce the first-BZ precondition today; phono3py does.
    // Revisit this when the precondition is broken in practice.
    for (g, kk_g) in g_list.iter().zip(kk.iter_mut()) {
        let q_k = [g[0] + q_cart[0], g[1] + q_cart[1], g[2] + q_cart[2]];
        let norm = q_k[0] * q_k[0] + q_k[1] * q_k[1] + q_k[2] * q_k[2];
        if norm < Q2_ZERO_TOLERANCE {
            if let Some(qd) = q_direction_cart {
                let dpart = dielectric_part(qd, dielectric);
                for i in 0..3 {
                    for j in 0..3 {
                        kk_g[i][j] = qd[i] * qd[j] / dpart;
                    }
                }
            }
            // q_direction_cart == None leaves kk_g at zero.
            continue;
        }
        let dpart = dielectric_part(q_k, dielectric);
        let damp = (-dpart / l2).exp();
        for i in 0..3 {
            for j in 0..3 {
                kk_g[i][j] = q_k[i] * q_k[j] / dpart * damp;
            }
        }
    }

    // Sequential to avoid races on dd_part (matches the C comment).
    for (g, kk_g) in g_list.iter().zip(kk.iter()) {
        for i in 0..num_patom {
            for j in 0..num_patom {
                dd_at_g(dd_part, i, j, *g, num_patom, pos, kk_g);
            }
        }
    }
}

/// Per-(i, j) Born-charge multiplication for the reciprocal
/// dipole-dipole sum.  Mirrors `multiply_borns_at_ij`.
fn multiply_borns_at_ij(
    dd: &mut [Cmplx],
    i: usize,
    j: usize,
    dd_in: &[Cmplx],
    num_patom: usize,
    born: &[[[f64; 3]; 3]],
) {
    for k in 0..3 {
        for l in 0..3 {
            let adrs = i * num_patom * 9 + k * num_patom * 3 + j * 3 + l;
            let mut acc = [0.0f64; 2];
            for m in 0..3 {
                for n in 0..3 {
                    let adrs_in = i * num_patom * 9 + m * num_patom * 3 + j * 3 + n;
                    let zz = born[i][m][k] * born[j][n][l];
                    acc[0] += dd_in[adrs_in][0] * zz;
                    acc[1] += dd_in[adrs_in][1] * zz;
                }
            }
            dd[adrs][0] += acc[0];
            dd[adrs][1] += acc[1];
        }
    }
}

/// Apply Born charges to the [i, alpha, j, beta] buffer.  Mirrors
/// `multiply_borns` in `c/dynmat.c`.  Each (i, j) entry of `dd` is
/// independent so this is naturally parallel; we keep it
/// sequential here to match the existing scalar path.
fn multiply_borns(dd: &mut [Cmplx], dd_in: &[Cmplx], num_patom: usize, born: &[[[f64; 3]; 3]]) {
    for i in 0..num_patom {
        for j in 0..num_patom {
            multiply_borns_at_ij(dd, i, j, dd_in, num_patom, born);
        }
    }
}

/// Build the q=0 dipole-dipole correction `dd_q0` used by the
/// Gonze-Lee NAC.  Mirrors `dym_get_recip_dipole_dipole_q0`.
///
/// `dd_q0` has shape `[num_patom, 3, 3]` complex (flat
/// `num_patom * 9`).  `g_list` is the reciprocal lattice vectors
/// to sum over (already cartesian).  `pos` is the primitive-atom
/// positions (cartesian).  `lambda` is the Ewald parameter.
///
/// Output is symmetrized (real part) and antisymmetrized (imag
/// part) over (alpha, beta) per atom.
#[allow(clippy::too_many_arguments)]
pub fn get_recip_dipole_dipole_q0(
    dd_q0: &mut [Cmplx],
    g_list: &[Vec3D],
    num_patom: usize,
    born: &[[[f64; 3]; 3]],
    dielectric: &MatD,
    pos: &[Vec3D],
    lambda: f64,
) {
    debug_assert_eq!(dd_q0.len(), num_patom * 9);
    debug_assert_eq!(born.len(), num_patom);
    debug_assert_eq!(pos.len(), num_patom);

    let n2 = num_patom * num_patom * 9;
    let mut dd_tmp1: Vec<Cmplx> = vec![[0.0; 2]; n2];
    let mut dd_tmp2: Vec<Cmplx> = vec![[0.0; 2]; n2];

    let zero_vec = [0.0, 0.0, 0.0];
    get_dd(
        &mut dd_tmp1,
        g_list,
        num_patom,
        zero_vec,
        None,
        dielectric,
        pos,
        lambda,
    );

    multiply_borns(&mut dd_tmp2, &dd_tmp1, num_patom, born);

    for c in dd_q0.iter_mut() {
        *c = [0.0, 0.0];
    }

    for i in 0..num_patom {
        for k in 0..3 {
            for l in 0..3 {
                let adrs = i * 9 + k * 3 + l;
                for j in 0..num_patom {
                    let adrs_tmp = i * num_patom * 9 + k * num_patom * 3 + j * 3 + l;
                    dd_q0[adrs][0] += dd_tmp2[adrs_tmp][0];
                    dd_q0[adrs][1] += dd_tmp2[adrs_tmp][1];
                }
            }
        }
    }

    // Per-atom (alpha, beta) Hermitian symmetrization of the 3x3 block.
    for i in 0..num_patom {
        for k in 0..3 {
            for l in k..3 {
                let adrs = i * 9 + k * 3 + l;
                let adrs_t = i * 9 + l * 3 + k;
                let re = (dd_q0[adrs][0] + dd_q0[adrs_t][0]) * 0.5;
                let im = (dd_q0[adrs][1] - dd_q0[adrs_t][1]) * 0.5;
                dd_q0[adrs][0] = re;
                dd_q0[adrs][1] = im;
                dd_q0[adrs_t][0] = re;
                dd_q0[adrs_t][1] = -im;
            }
        }
    }
}

/// Build the Gonze-Lee reciprocal dipole-dipole correction at a
/// single q-point.  Mirrors `dym_get_recip_dipole_dipole`.
///
/// `dd` (output) has shape `[num_patom, 3, num_patom, 3]` complex
/// (flat `num_patom^2 * 9`).  `dd_q0` is the q=0 correction from
/// `get_recip_dipole_dipole_q0` and is subtracted on the diagonal
/// (i, i) blocks.  `factor` is `4*pi/V * unit_conversion` applied
/// to the entire output.  `q_direction_cart` is used only when the
/// K=0 term is reached at q=0.
#[allow(clippy::too_many_arguments)]
pub fn get_recip_dipole_dipole(
    dd: &mut [Cmplx],
    dd_q0: &[Cmplx],
    g_list: &[Vec3D],
    num_patom: usize,
    q_cart: Vec3D,
    q_direction_cart: Option<Vec3D>,
    born: &[[[f64; 3]; 3]],
    dielectric: &MatD,
    pos: &[Vec3D],
    factor: f64,
    lambda: f64,
) {
    let n2 = num_patom * num_patom * 9;
    debug_assert_eq!(dd.len(), n2);
    debug_assert_eq!(dd_q0.len(), num_patom * 9);
    debug_assert_eq!(born.len(), num_patom);
    debug_assert_eq!(pos.len(), num_patom);

    for c in dd.iter_mut() {
        *c = [0.0, 0.0];
    }
    let mut dd_tmp: Vec<Cmplx> = vec![[0.0; 2]; n2];

    get_dd(
        &mut dd_tmp,
        g_list,
        num_patom,
        q_cart,
        q_direction_cart,
        dielectric,
        pos,
        lambda,
    );

    multiply_borns(dd, &dd_tmp, num_patom, born);

    for i in 0..num_patom {
        for k in 0..3 {
            for l in 0..3 {
                let adrs = i * num_patom * 9 + k * num_patom * 3 + i * 3 + l;
                let adrs_sum = i * 9 + k * 3 + l;
                dd[adrs][0] -= dd_q0[adrs_sum][0];
                dd[adrs][1] -= dd_q0[adrs_sum][1];
            }
        }
    }

    for c in dd.iter_mut() {
        c[0] *= factor;
        c[1] *= factor;
    }
}

