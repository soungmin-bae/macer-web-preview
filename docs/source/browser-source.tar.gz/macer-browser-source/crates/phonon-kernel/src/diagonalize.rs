//! Single-matrix complex Hermitian eigensolver adapted from `phonors` 0.3.0
//! (`src/diagonalize.rs`, BSD-3-Clause), commit
//! `ca6eac4464cea519fef1d6d8018b4d13c20fa84d`. Rayon batching and the Python
//! binding are intentionally omitted; faer solves each matrix sequentially.

use faer::diag::Diag;
use faer::dyn_stack::{MemBuffer, MemStack};
use faer::linalg::evd::{self_adjoint_evd, self_adjoint_evd_scratch, ComputeEigenvectors};
use faer::mat::{Mat, MatRef};
use faer::{c64, Par};

use crate::{Complex64, KernelError};

#[derive(Debug, Clone, PartialEq)]
pub struct EigenResult {
    /// Eigenvalues in nondecreasing order.
    pub values: Vec<f64>,
    /// Eigenvectors as columns in row-major `[component, band]` order.
    pub vectors: Vec<Complex64>,
}

/// Diagonalizes a row-major complex Hermitian matrix and returns eigenvectors.
///
/// Eigenvectors are required for the phonon mode viewer. The matrix is checked
/// for finite values and Hermitian symmetry before it reaches faer; it is never
/// silently symmetrized here.
pub fn diagonalize_hermitian(
    matrix: &[Complex64],
    dimension: usize,
) -> Result<EigenResult, KernelError> {
    if dimension == 0 || matrix.len() != dimension.saturating_mul(dimension) {
        return Err(KernelError::InvalidDimensions);
    }
    if !matrix.iter().flatten().all(|value| value.is_finite()) {
        return Err(KernelError::NonFiniteInput);
    }
    let scale = matrix
        .iter()
        .map(|value| value[0].abs().max(value[1].abs()))
        .fold(1.0f64, f64::max);
    let tolerance = 1e-12 * scale;
    for row in 0..dimension {
        let diagonal = matrix[row * dimension + row];
        if diagonal[1].abs() > tolerance {
            return Err(KernelError::NonHermitian);
        }
        for col in 0..row {
            let lower = matrix[row * dimension + col];
            let upper = matrix[col * dimension + row];
            if (lower[0] - upper[0]).abs() > tolerance || (lower[1] + upper[1]).abs() > tolerance {
                return Err(KernelError::NonHermitian);
            }
        }
    }

    // Convert explicitly instead of relying on a repr(C) alias between
    // `[f64; 2]` and faer's complex type.
    let input: Vec<c64> = matrix.iter().map(|z| c64::new(z[0], z[1])).collect();
    let request = self_adjoint_evd_scratch::<c64>(
        dimension,
        ComputeEigenvectors::Yes,
        Par::Seq,
        Default::default(),
    );
    let mut memory = MemBuffer::new(request);
    let stack = MemStack::new(&mut memory);
    let mut diagonal = Diag::zeros(dimension);
    let mut vectors = Mat::zeros(dimension, dimension);
    self_adjoint_evd(
        MatRef::<c64>::from_row_major_slice(&input, dimension, dimension),
        diagonal.as_mut(),
        Some(vectors.as_mut()),
        Par::Seq,
        stack,
        Default::default(),
    )
    .map_err(|_| KernelError::EigenFailure)?;

    let mut values = Vec::with_capacity(dimension);
    let mut output_vectors = vec![[0.0; 2]; dimension * dimension];
    let eigenvalues = diagonal.column_vector();
    for band in 0..dimension {
        values.push(eigenvalues[band].re);
        for component in 0..dimension {
            let value = vectors[(component, band)];
            output_vectors[component * dimension + band] = [value.re, value.im];
        }
    }
    Ok(EigenResult {
        values,
        vectors: output_vectors,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn multiply(a: Complex64, b: Complex64) -> Complex64 {
        [a[0] * b[0] - a[1] * b[1], a[0] * b[1] + a[1] * b[0]]
    }

    #[test]
    fn complex_hermitian_eigenpairs_are_sorted_and_normalized() {
        // Eigenvalues are exactly 1 and 3; the off-diagonal phase is complex.
        let matrix = [[2.0, 0.0], [0.0, 1.0], [0.0, -1.0], [2.0, 0.0]];
        let result = diagonalize_hermitian(&matrix, 2).unwrap();
        assert!((result.values[0] - 1.0).abs() < 1e-12);
        assert!((result.values[1] - 3.0).abs() < 1e-12);

        for band in 0..2 {
            let mut norm = 0.0;
            for component in 0..2 {
                let z = result.vectors[component * 2 + band];
                norm += z[0] * z[0] + z[1] * z[1];
            }
            assert!((norm - 1.0).abs() < 1e-12);
            for row in 0..2 {
                let mut product = [0.0, 0.0];
                for col in 0..2 {
                    let a = matrix[row * 2 + col];
                    let v = result.vectors[col * 2 + band];
                    let term = multiply(a, v);
                    product[0] += term[0];
                    product[1] += term[1];
                }
                let v = result.vectors[row * 2 + band];
                assert!((product[0] - result.values[band] * v[0]).abs() < 1e-12);
                assert!((product[1] - result.values[band] * v[1]).abs() < 1e-12);
            }
        }
    }

    #[test]
    fn rejects_non_hermitian_input() {
        assert_eq!(
            diagonalize_hermitian(&[[1.0, 0.0], [0.0, 0.0], [1.0, 0.0], [2.0, 0.0]], 2),
            Err(KernelError::NonHermitian)
        );
    }
}
