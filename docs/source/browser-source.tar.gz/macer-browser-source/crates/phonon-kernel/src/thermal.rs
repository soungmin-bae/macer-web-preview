//! Harmonic thermodynamics from an explicitly weighted phonon mesh.

/// Planck constant times 1 THz, in eV.
pub const THZ_TO_EV: f64 = 6.626_070_15e-34 * 1e12 / 1.602_176_634e-19;
pub const BOLTZMANN_EV_PER_K: f64 = 1.380_649e-23 / 1.602_176_634e-19;

#[derive(Debug, Clone, Copy)]
pub struct GammaTranslations {
    /// The mesh row for Γ, identified by the caller.
    pub q_index: usize,
    /// The three distinct, exactly zero translational modes at Γ.
    pub mode_indices: [usize; 3],
}

#[derive(Debug, PartialEq, Eq)]
pub enum ThermalError {
    InvalidDimensions,
    InvalidWeights,
    InvalidTemperature,
    InvalidGammaTranslations,
    InvalidFrequency { q_index: usize, mode_index: usize },
    ImaginaryMode { q_index: usize, mode_index: usize },
    UnclassifiedZeroMode { q_index: usize, mode_index: usize },
    NoIntegratedModes,
    NonFiniteResult,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct ThermalPoint {
    pub temperature_k: f64,
    pub free_energy_ev_per_atom: f64,
    pub entropy_kb_per_atom: f64,
    pub heat_capacity_kb_per_atom: f64,
}

#[derive(Debug, Clone, PartialEq)]
pub struct HarmonicThermal {
    pub primitive_atoms: usize,
    pub q_weight_sum: u64,
    pub weighted_mode_count: u64,
    pub integrated_weighted_mode_count: u64,
    pub zero_point_energy_ev_per_atom: f64,
    pub points: Vec<ThermalPoint>,
}

/// Integrate the phonon frequencies, in cycles per second scaled to THz.
/// The flat input is q-major, with exactly three modes per primitive atom
/// in each row. Weights are positive mesh multiplicities. The denominator
/// includes the full mesh weight, including the row with any excluded Γ
/// translations. Other zero frequencies and all negative frequencies error.
pub fn harmonic_thermal(
    frequencies_thz: &[f64],
    q_weights: &[u32],
    primitive_atoms: usize,
    temperatures_k: &[f64],
    gamma_translations: Option<GammaTranslations>,
) -> Result<HarmonicThermal, ThermalError> {
    let modes = primitive_atoms
        .checked_mul(3)
        .filter(|&count| count > 0)
        .ok_or(ThermalError::InvalidDimensions)?;
    if q_weights.is_empty()
        || modes.checked_mul(q_weights.len()) != Some(frequencies_thz.len())
        || temperatures_k.is_empty()
    {
        return Err(ThermalError::InvalidDimensions);
    }
    if q_weights.contains(&0) {
        return Err(ThermalError::InvalidWeights);
    }
    let q_weight_sum = q_weights
        .iter()
        .try_fold(0_u64, |sum, &weight| sum.checked_add(u64::from(weight)))
        .ok_or(ThermalError::InvalidWeights)?;
    let weighted_mode_count = q_weight_sum
        .checked_mul(modes as u64)
        .ok_or(ThermalError::InvalidWeights)?;
    if temperatures_k.iter().any(|&t| !t.is_finite() || t < 0.0) {
        return Err(ThermalError::InvalidTemperature);
    }
    let omitted_weight = if let Some(GammaTranslations {
        q_index,
        mode_indices: [a, b, c],
    }) = gamma_translations
    {
        if q_index >= q_weights.len()
            || a == b
            || a == c
            || b == c
            || [a, b, c]
                .into_iter()
                .any(|m| m >= modes || frequencies_thz[q_index * modes + m] != 0.0)
        {
            return Err(ThermalError::InvalidGammaTranslations);
        }
        3 * u64::from(q_weights[q_index])
    } else {
        0
    };
    let integrated_weighted_mode_count = weighted_mode_count - omitted_weight;
    if integrated_weighted_mode_count == 0 {
        return Err(ThermalError::NoIntegratedModes);
    }

    let mut weighted_energies = Vec::with_capacity(frequencies_thz.len());
    let mut zpe = 0.0;
    for (q_index, (row, &weight)) in frequencies_thz
        .chunks_exact(modes)
        .zip(q_weights)
        .enumerate()
    {
        let normalized_weight = f64::from(weight) / q_weight_sum as f64 / primitive_atoms as f64;
        for (mode_index, &frequency) in row.iter().enumerate() {
            if gamma_translations.is_some_and(|gamma| {
                gamma.q_index == q_index && gamma.mode_indices.contains(&mode_index)
            }) {
                continue;
            }
            if !frequency.is_finite() {
                return Err(ThermalError::InvalidFrequency {
                    q_index,
                    mode_index,
                });
            }
            if frequency < 0.0 {
                return Err(ThermalError::ImaginaryMode {
                    q_index,
                    mode_index,
                });
            }
            if frequency == 0.0 {
                return Err(ThermalError::UnclassifiedZeroMode {
                    q_index,
                    mode_index,
                });
            }
            let energy = THZ_TO_EV * frequency;
            if energy == 0.0 {
                return Err(ThermalError::InvalidFrequency {
                    q_index,
                    mode_index,
                });
            }
            zpe += normalized_weight * (energy / 2.0);
            weighted_energies.push((energy, normalized_weight));
        }
    }

    let mut points = Vec::with_capacity(temperatures_k.len());
    for &temperature_k in temperatures_k {
        let thermal_energy = BOLTZMANN_EV_PER_K * temperature_k;
        let mut thermal_free_energy = 0.0;
        let mut entropy = 0.0;
        let mut heat_capacity = 0.0;
        if thermal_energy > 0.0 {
            for &(energy, weight) in &weighted_energies {
                let x = energy / thermal_energy;
                if x > 750.0 {
                    continue;
                }
                let (log_occupation, energy_over_kt, cv) = if x == 0.0 {
                    // Preserve the classical limit even when the ratio underflows.
                    (energy.ln() - thermal_energy.ln(), 1.0, 1.0)
                } else {
                    let exp_neg_x = (-x).exp();
                    let denominator = -(-x).exp_m1();
                    let log_occupation = if x < std::f64::consts::LN_2 {
                        denominator.ln()
                    } else {
                        (-exp_neg_x).ln_1p()
                    };
                    let cv_amplitude = (x / denominator) * (-x / 2.0).exp();
                    (
                        log_occupation,
                        (x / denominator) * exp_neg_x,
                        cv_amplitude * cv_amplitude,
                    )
                };
                thermal_free_energy += (weight * thermal_energy) * log_occupation;
                entropy += weight * (energy_over_kt - log_occupation);
                heat_capacity += weight * cv;
            }
        }
        let free_energy_ev_per_atom = zpe + thermal_free_energy;
        if !free_energy_ev_per_atom.is_finite()
            || !entropy.is_finite()
            || !heat_capacity.is_finite()
        {
            return Err(ThermalError::NonFiniteResult);
        }
        points.push(ThermalPoint {
            temperature_k,
            free_energy_ev_per_atom,
            entropy_kb_per_atom: entropy,
            heat_capacity_kb_per_atom: heat_capacity,
        });
    }

    Ok(HarmonicThermal {
        primitive_atoms,
        q_weight_sum,
        weighted_mode_count,
        integrated_weighted_mode_count,
        zero_point_energy_ev_per_atom: zpe,
        points,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rejects_invalid_thermal_inputs() {
        let run = |freq: &[f64], weights: &[u32], temperatures: &[f64], gamma| {
            harmonic_thermal(freq, weights, 1, temperatures, gamma)
        };
        assert_eq!(
            run(&[1., 2.], &[1], &[0.], None),
            Err(ThermalError::InvalidDimensions)
        );
        assert_eq!(
            run(&[1., 2., 3.], &[0], &[0.], None),
            Err(ThermalError::InvalidWeights)
        );
        assert_eq!(
            run(&[1., 2., 3.], &[1], &[-1.], None),
            Err(ThermalError::InvalidTemperature)
        );
        assert_eq!(
            run(&[1., f64::NAN, 3.], &[1], &[0.], None),
            Err(ThermalError::InvalidFrequency {
                q_index: 0,
                mode_index: 1
            })
        );
        assert_eq!(
            run(&[1., -1e-9, 3.], &[1], &[0.], None),
            Err(ThermalError::ImaginaryMode {
                q_index: 0,
                mode_index: 1
            })
        );
        assert_eq!(
            run(&[1., 0., 3.], &[1], &[0.], None),
            Err(ThermalError::UnclassifiedZeroMode {
                q_index: 0,
                mode_index: 1
            })
        );
        let gamma = Some(GammaTranslations {
            q_index: 0,
            mode_indices: [0, 1, 2],
        });
        assert_eq!(
            run(&[0., 0., 1e-9], &[1], &[0.], gamma),
            Err(ThermalError::InvalidGammaTranslations)
        );
        assert_eq!(
            run(&[0., 0., 0.], &[1], &[0.], gamma),
            Err(ThermalError::NoIntegratedModes)
        );
        assert_eq!(
            run(&[0., 0., 0., 1., 0., 3.], &[1, 1], &[0.], gamma),
            Err(ThermalError::UnclassifiedZeroMode {
                q_index: 1,
                mode_index: 1
            })
        );
    }

    #[test]
    fn exact_zero_and_extreme_temperature_limits() {
        let result = harmonic_thermal(&[1.; 3], &[7], 1, &[0., 1e-300, 1e9], None).unwrap();
        assert!((THZ_TO_EV - 0.004_135_667_696).abs() < 1e-12);
        assert!((result.zero_point_energy_ev_per_atom - 1.5 * THZ_TO_EV).abs() < 1e-16);
        for point in &result.points[..2] {
            assert_eq!(
                point.free_energy_ev_per_atom,
                result.zero_point_energy_ev_per_atom
            );
            assert_eq!(point.entropy_kb_per_atom, 0.0);
            assert_eq!(point.heat_capacity_kb_per_atom, 0.0);
        }
        assert!((result.points[2].heat_capacity_kb_per_atom - 3.0).abs() < 1e-12);
        let soft_mode = harmonic_thermal(&[1e-250, 1., 1.], &[1], 1, &[300.], None).unwrap();
        assert!(soft_mode.points[0].entropy_kb_per_atom > 500.0);
    }
}
