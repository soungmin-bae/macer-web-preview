//! Minimal ASE ULM trajectory writer for macer-compatible `md.traj` output.
//!
//! This writes ASE ULM v3 directly, so the native runtime does not need ASE or
//! Python. It supports the fixed atom order, cell, positions, momenta, energy,
//! forces, stress and optional per-atom properties emitted by native MD calculators.

use macer_rust_core::dynamics::DynamicsState;
use serde_json::{json, Map, Value};
use std::fs::File;
use std::io::{Seek, SeekFrom, Write};
use std::path::Path;

const ULM_MAGIC: &[u8; 8] = b"- of Ulm";
const ULM_TAG: &str = "ASE-Trajectory";
const ULM_VERSION: i64 = 3;
const ULM_OFFSET_TABLE: u64 = 48;
const ULM_OFFSET_CAPACITY: usize = 42;
const ASE_FS: f64 = 0.098_226_947_884_640_63;
const REFERENCE_ASE_VERSION: &str = "3.26.0";

pub struct UlmTrajectoryWriter {
    file: File,
    item_count: u64,
    offset_table: u64,
    offset_capacity: usize,
    offsets: Vec<i64>,
    first_frame: bool,
}

impl UlmTrajectoryWriter {
    pub fn create(
        path: &Path,
        state: &DynamicsState,
        calculator_name: &'static str,
    ) -> Result<Self, String> {
        let mut writer = Self::open(path)?;
        writer.write_frame(state, calculator_name)?;
        Ok(writer)
    }

    pub fn create_relax(
        path: &Path,
        structure: &macer_rust_core::types::Structure,
        evaluation: &macer_rust_core::types::Evaluation,
        calculator_name: &'static str,
    ) -> Result<Self, String> {
        let mut writer = Self::open(path)?;
        writer.write_relax_frame(structure, evaluation, calculator_name)?;
        Ok(writer)
    }

    fn open(path: &Path) -> Result<Self, String> {
        let mut file = File::create(path).map_err(|e| e.to_string())?;
        file.write_all(ULM_MAGIC).map_err(|e| e.to_string())?;
        let mut tag = [b' '; 16];
        let tag_bytes = ULM_TAG.as_bytes();
        tag[..tag_bytes.len()].copy_from_slice(tag_bytes);
        file.write_all(&tag).map_err(|e| e.to_string())?;
        write_i64(&mut file, ULM_VERSION)?;
        write_i64(&mut file, 0)?;
        write_i64(&mut file, ULM_OFFSET_TABLE as i64)?;
        write_i64(&mut file, -1)?;

        Ok(Self {
            file,
            item_count: 0,
            offset_table: ULM_OFFSET_TABLE,
            offset_capacity: 1,
            offsets: Vec::new(),
            first_frame: true,
        })
    }

    pub fn write_frame(
        &mut self,
        state: &DynamicsState,
        calculator_name: &'static str,
    ) -> Result<(), String> {
        let n = state.structure.atomic_numbers.len();
        let mut data = Map::new();
        if self.first_frame {
            data.insert("version".into(), json!(1));
            data.insert("ase_version".into(), json!(REFERENCE_ASE_VERSION));
            data.insert("pbc".into(), json!(state.structure.pbc));
            let numbers: Vec<i64> = state
                .structure
                .atomic_numbers
                .iter()
                .map(|&number| i64::from(number))
                .collect();
            data.insert("numbers.".into(), self.write_i64_array(&[n], &numbers)?);
            self.first_frame = false;
        }

        let positions: Vec<f64> = state
            .structure
            .positions_a
            .iter()
            .flatten()
            .copied()
            .collect();
        data.insert(
            "positions.".into(),
            self.write_f64_array(&[n, 3], &positions)?,
        );
        data.insert("cell".into(), json!(state.structure.cell_a));

        let momenta: Vec<f64> = state
            .masses_amu
            .iter()
            .zip(&state.velocities_a_per_fs)
            .flat_map(|(&mass, velocity)| velocity.map(|v| mass * v / ASE_FS))
            .collect();
        data.insert("momenta.".into(), self.write_f64_array(&[n, 3], &momenta)?);

        let stress = state.evaluation.stress_ev_per_a3;
        let stress_voigt = [
            stress[0][0],
            stress[1][1],
            stress[2][2],
            stress[1][2],
            stress[0][2],
            stress[0][1],
        ];
        let mut calculator = Map::new();
        calculator.insert("name".into(), json!(calculator_name));
        calculator.insert("energy".into(), json!(state.evaluation.energy_ev));
        calculator.insert(
            "free_energy".into(),
            json!(state.evaluation.free_energy_ev()),
        );
        calculator.insert(
            "forces.".into(),
            self.write_f64_array(
                &[n, 3],
                &state
                    .evaluation
                    .forces_ev_per_a
                    .iter()
                    .flatten()
                    .copied()
                    .collect::<Vec<_>>(),
            )?,
        );
        calculator.insert("stress".into(), json!(stress_voigt));
        if let Some(energies) = &state.evaluation.energies_ev {
            calculator.insert("energies.".into(), self.write_f64_array(&[n], energies)?);
        }
        if let Some(stresses) = &state.evaluation.stresses_ev_per_a3 {
            let stresses_voigt: Vec<f64> = stresses
                .iter()
                .flat_map(|tensor| {
                    [
                        tensor[0][0],
                        tensor[1][1],
                        tensor[2][2],
                        tensor[1][2],
                        tensor[0][2],
                        tensor[0][1],
                    ]
                })
                .collect();
            calculator.insert(
                "stresses.".into(),
                self.write_f64_array(&[n, 6], &stresses_voigt)?,
            );
        }
        data.insert("calculator.".into(), Value::Object(calculator));
        self.sync_item(data)
    }

    pub fn write_relax_frame(
        &mut self,
        structure: &macer_rust_core::types::Structure,
        evaluation: &macer_rust_core::types::Evaluation,
        calculator_name: &'static str,
    ) -> Result<(), String> {
        let n = structure.atomic_numbers.len();
        let mut data = Map::new();
        if self.first_frame {
            data.insert("version".into(), json!(1));
            data.insert("ase_version".into(), json!(REFERENCE_ASE_VERSION));
            data.insert("pbc".into(), json!(structure.pbc));
            let numbers = structure
                .atomic_numbers
                .iter()
                .map(|&number| i64::from(number))
                .collect::<Vec<_>>();
            data.insert("numbers.".into(), self.write_i64_array(&[n], &numbers)?);
            self.first_frame = false;
        }
        let positions = structure
            .positions_a
            .iter()
            .flatten()
            .copied()
            .collect::<Vec<_>>();
        data.insert(
            "positions.".into(),
            self.write_f64_array(&[n, 3], &positions)?,
        );
        data.insert("cell".into(), json!(structure.cell_a));

        let stress = evaluation.stress_ev_per_a3;
        let stress_voigt = [
            stress[0][0],
            stress[1][1],
            stress[2][2],
            stress[1][2],
            stress[0][2],
            stress[0][1],
        ];
        let mut calculator = Map::new();
        calculator.insert("name".into(), json!(calculator_name));
        calculator.insert("energy".into(), json!(evaluation.energy_ev));
        calculator.insert("free_energy".into(), json!(evaluation.free_energy_ev()));
        calculator.insert(
            "forces.".into(),
            self.write_f64_array(
                &[n, 3],
                &evaluation
                    .forces_ev_per_a
                    .iter()
                    .flatten()
                    .copied()
                    .collect::<Vec<_>>(),
            )?,
        );
        calculator.insert("stress".into(), json!(stress_voigt));
        if let Some(energies) = &evaluation.energies_ev {
            calculator.insert("energies.".into(), self.write_f64_array(&[n], energies)?);
        }
        if let Some(stresses) = &evaluation.stresses_ev_per_a3 {
            let stresses_voigt = stresses
                .iter()
                .flat_map(|tensor| {
                    [
                        tensor[0][0],
                        tensor[1][1],
                        tensor[2][2],
                        tensor[1][2],
                        tensor[0][2],
                        tensor[0][1],
                    ]
                })
                .collect::<Vec<_>>();
            calculator.insert(
                "stresses.".into(),
                self.write_f64_array(&[n, 6], &stresses_voigt)?,
            );
        }
        data.insert("calculator.".into(), Value::Object(calculator));
        self.sync_item(data)
    }

    pub fn close(mut self) -> Result<(), String> {
        self.file.flush().map_err(|e| e.to_string())
    }

    fn write_f64_array(&mut self, shape: &[usize], values: &[f64]) -> Result<Value, String> {
        if values.iter().any(|value| !value.is_finite()) {
            return Err("cannot write non-finite values to ASE trajectory".into());
        }
        let expected: usize = shape.iter().product();
        if expected != values.len() {
            return Err("ASE trajectory array shape does not match its data".into());
        }
        self.align_array()?;
        let offset = self.file.stream_position().map_err(|e| e.to_string())?;
        for value in values {
            self.file
                .write_all(&value.to_le_bytes())
                .map_err(|e| e.to_string())?;
        }
        Ok(json!({"ndarray": [shape, "float64", offset]}))
    }

    fn write_i64_array(&mut self, shape: &[usize], values: &[i64]) -> Result<Value, String> {
        let expected: usize = shape.iter().product();
        if expected != values.len() {
            return Err("ASE trajectory array shape does not match its data".into());
        }
        self.align_array()?;
        let offset = self.file.stream_position().map_err(|e| e.to_string())?;
        for value in values {
            write_i64(&mut self.file, *value)?;
        }
        Ok(json!({"ndarray": [shape, "int64", offset]}))
    }

    fn align_array(&mut self) -> Result<(), String> {
        let position = self.file.stream_position().map_err(|e| e.to_string())?;
        let padding = (8 - position % 8) % 8;
        if padding > 0 {
            self.file
                .write_all(&vec![b'#'; padding as usize])
                .map_err(|e| e.to_string())?;
        }
        Ok(())
    }

    fn sync_item(&mut self, data: Map<String, Value>) -> Result<(), String> {
        let json_bytes = serde_json::to_vec(&Value::Object(data)).map_err(|e| e.to_string())?;
        let item_offset = self.file.stream_position().map_err(|e| e.to_string())?;
        write_u64(&mut self.file, json_bytes.len() as u64)?;
        self.file
            .write_all(&json_bytes)
            .map_err(|e| e.to_string())?;

        if self.item_count >= self.offset_capacity as u64 {
            self.offset_capacity *= ULM_OFFSET_CAPACITY;
            self.align_array()?;
            self.offset_table = self.file.stream_position().map_err(|e| e.to_string())?;
            for &offset in &self.offsets {
                write_i64(&mut self.file, offset)?;
            }
            for _ in self.offsets.len()..self.offset_capacity {
                write_i64(&mut self.file, 0)?;
            }
            self.file
                .seek(SeekFrom::Start(40))
                .and_then(|_| {
                    self.file
                        .write_all(&(self.offset_table as i64).to_le_bytes())
                })
                .map_err(|e| e.to_string())?;
        }

        self.file
            .seek(SeekFrom::Start(self.offset_table + self.item_count * 8))
            .and_then(|_| self.file.write_all(&(item_offset as i64).to_le_bytes()))
            .map_err(|e| e.to_string())?;
        self.offsets.push(item_offset as i64);
        self.item_count += 1;
        self.file
            .seek(SeekFrom::Start(32))
            .and_then(|_| self.file.write_all(&(self.item_count as i64).to_le_bytes()))
            .map_err(|e| e.to_string())?;
        self.file
            .seek(SeekFrom::End(0))
            .map_err(|e| e.to_string())?;
        self.file.flush().map_err(|e| e.to_string())
    }
}

fn write_i64(file: &mut File, value: i64) -> Result<(), String> {
    file.write_all(&value.to_le_bytes())
        .map_err(|e| e.to_string())
}

fn write_u64(file: &mut File, value: u64) -> Result<(), String> {
    file.write_all(&value.to_le_bytes())
        .map_err(|e| e.to_string())
}
