use std::fs;
use std::path::PathBuf;

pub const HELP: &str = r#"macer-rust utility commands currently ported from macer.

USAGE:
    macer-rust util model list
    macer-rust util vasp-mlff inspect --model <ML_FF|ML_FFN> [--json]
    macer-rust util struct vasp4to5 --input <FILE> [--symbols <"Fe C">] [--output <FILE>]
    macer-rust util vasp4to5 --input <FILE> [--symbols <"Fe C">] [--output <FILE>]
    macer-rust util supercell --poscar <POSCAR> --dim <a b c | 9 integers> [OPTIONS]
    macer-rust util pydefect supercell --poscar <POSCAR> --dim <a b c | 9 integers> [OPTIONS]
    macer-rust util md summary [-i|--input <CSV>]
    macer-rust util md conductivity -i|--input <TRAJECTORY> -t|--temp <K> [OPTIONS]
    macer-rust util md plot [-i|--input <CSV>] [-o|--output <PDF_PREFIX>]
    macer-rust util calc_madelung [-p|--poscar <POSCAR>] [-o|--output-log <FILE>]
        [--oxidation-states <"Li:1,F:-1">] (aliases: madelung, cm)
    macer-rust util xdatcar-tool -i|--input <XDATCAR|md.traj> [OPTIONS]

If --symbols is omitted, the first line is used as the element-symbol list.
The default VASP4-to-VASP5 output path is <input>_v5.
The supercell utility writes a PyDefect-compatible supercell_info.json and SPOSCAR.
The xdatcar-tool writes cell statistics, strain, blocks, a PDF and report;
--rdf adds pair-resolved RDF output; --adp adds averaged POSCAR and ADP files;
--displacement-map adds per-atom displacement statistics. Symmetry sampling is
available with --symmetry-sample. Some less-used analysis options still need
Macer comparison fixtures.
"#;

pub fn run(arguments: impl Iterator<Item = String>) -> Result<(), String> {
    let mut arguments = arguments.collect::<Vec<_>>();
    if arguments.first().map(String::as_str) == Some("struct") {
        arguments.remove(0);
    }
    if arguments.first().map(String::as_str) == Some("pydefect") {
        arguments.remove(0);
    }
    if arguments
        .first()
        .is_some_and(|arg| arg == "supercell" || arg == "sc")
    {
        return crate::supercell::run(arguments.into_iter().skip(1));
    }
    if arguments.first().map(String::as_str) == Some("md") {
        return crate::md_util::run(arguments.into_iter());
    }
    if arguments
        .first()
        .is_some_and(|argument| crate::madelung::is_madelung_command(argument))
    {
        return crate::madelung::run(arguments.into_iter().skip(1));
    }
    if arguments.first().map(String::as_str) == Some("model") {
        return crate::model_list::run(arguments.into_iter().skip(1));
    }
    if arguments
        .first()
        .is_some_and(|arg| arg == "vasp-mlff" || arg == "vmlff")
    {
        return crate::vasp_mlff::run(arguments.into_iter().skip(1));
    }
    if arguments
        .first()
        .is_some_and(|arg| arg == "xdatcar-tool" || arg == "xt")
    {
        return crate::xdatcar_tool::run(arguments.into_iter().skip(1));
    }
    if arguments.first().map(String::as_str) != Some("vasp4to5") {
        return Err("usage: macer-rust util struct vasp4to5 --input <FILE> [--symbols <LIST>] [--output <FILE>]".into());
    }
    arguments.remove(0);
    run_vasp4to5(arguments.into_iter())
}

pub fn run_vasp4to5(arguments: impl Iterator<Item = String>) -> Result<(), String> {
    let mut input = None;
    let mut symbols = None;
    let mut output = None;
    let mut arguments = arguments.peekable();
    while let Some(argument) = arguments.next() {
        if argument == "-h" || argument == "--help" {
            print!("{HELP}");
            return Ok(());
        }
        let (option, inline_value) = argument
            .split_once('=')
            .map(|(option, value)| (option, Some(value.to_owned())))
            .unwrap_or((argument.as_str(), None));
        let value = match inline_value {
            Some(value) => value,
            None => arguments
                .next()
                .ok_or_else(|| format!("missing value for {option}"))?,
        };
        match option {
            "-i" | "--input" => input = Some(value),
            "-s" | "--symbols" => symbols = Some(value),
            "-o" | "--output" => output = Some(value),
            _ => return Err(format!("unexpected argument: {argument}")),
        }
    }
    let input = input.ok_or("missing required --input")?;
    convert_vasp4to5(&input, symbols.as_deref(), output.as_deref());
    Ok(())
}

fn convert_vasp4to5(input_path: &str, symbols: Option<&str>, output_path: Option<&str>) {
    let content = match fs::read_to_string(input_path) {
        Ok(content) => content,
        Err(_) => {
            println!("Error: File '{input_path}' not found.");
            return;
        }
    };
    let lines = content.split_inclusive('\n').collect::<Vec<_>>();
    if lines.len() < 6 {
        println!("Error: Invalid POSCAR file (too short).");
        return;
    }

    if !lines[5]
        .trim()
        .split_whitespace()
        .all(|token| token.chars().all(char::is_numeric))
    {
        println!("Info: '{input_path}' already appears to have element symbols (VASP5?).");
    }

    let guessed_symbols;
    let symbols = if let Some(symbols) = symbols {
        symbols
    } else {
        guessed_symbols = lines[0].split_whitespace().collect::<Vec<_>>().join(" ");
        println!("No symbols provided. Guessing from comment line: {guessed_symbols}");
        if guessed_symbols
            .split_whitespace()
            .any(|symbol| !symbol.is_empty() && symbol.chars().all(char::is_numeric))
        {
            println!("Error: Could not guess symbols safely. Please provide them with -s \"El1 El2 ...\"");
            return;
        }
        &guessed_symbols
    };

    let mut converted = String::with_capacity(content.len() + symbols.len() + 2);
    for line in lines.iter().take(5) {
        converted.push_str(line);
    }
    converted.push(' ');
    converted.push_str(symbols);
    converted.push('\n');
    for line in lines.iter().skip(5) {
        converted.push_str(line);
    }

    let output_path = output_path
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from(format!("{input_path}_v5")));
    match fs::write(&output_path, converted) {
        Ok(()) => {
            println!(
                "Successfully converted VASP4 -> VASP5: {}",
                output_path.display()
            );
            println!("Added element line: {symbols}");
        }
        Err(error) => println!("Error during conversion: {error}"),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn unique_test_path(suffix: &str) -> PathBuf {
        let nonce = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        std::env::temp_dir().join(format!(
            "macer-rust-vasp4to5-{}-{nonce}-{suffix}",
            std::process::id()
        ))
    }

    #[test]
    fn vasp4to5_inserts_symbols_and_preserves_remaining_input() {
        let input = unique_test_path("POSCAR");
        let output = unique_test_path("output");
        let source = "Fe C\n1.0\n2 0 0\n0 2 0\n0 0 2\n2 1\nDirect\n0 0 0\n0.5 0.5 0.5\n";
        fs::write(&input, source).unwrap();
        convert_vasp4to5(input.to_str().unwrap(), Some("Fe C"), output.to_str());
        assert_eq!(
            fs::read_to_string(&output).unwrap(),
            "Fe C\n1.0\n2 0 0\n0 2 0\n0 0 2\n Fe C\n2 1\nDirect\n0 0 0\n0.5 0.5 0.5\n"
        );
        let _ = fs::remove_file(input);
        let _ = fs::remove_file(output);
    }

    #[test]
    fn vasp4to5_defaults_output_name_to_input_suffix() {
        let input = unique_test_path("POSCAR");
        let default_output = PathBuf::from(format!("{}_v5", input.display()));
        fs::write(&input, "Fe C\n1\n1 0 0\n0 1 0\n0 0 1\n2 1\nDirect\n").unwrap();
        convert_vasp4to5(input.to_str().unwrap(), None, None);
        assert!(default_output.is_file());
        let _ = fs::remove_file(input);
        let _ = fs::remove_file(default_output);
    }
}
