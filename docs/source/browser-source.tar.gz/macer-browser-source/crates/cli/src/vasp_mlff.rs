//! Native metadata reader for `macer util vasp-mlff inspect`.
//!
//! VASP writes this format as an unformatted byte stream, not as Fortran
//! sequential records.  The reader intentionally loads only metadata and
//! skips matrix payloads while still calculating the same byte offsets as
//! Macer's Python reader.

use macer_rust_model::vasp_mlff::{
    angular_wion_from_payload, build_angular_basis_from_payload, build_gaussian_radial_splines,
    build_radial_basis_from_payload, radial_wion_from_payload, BesselRadialBasis, RadialSplineSet,
};
use macer_rust_model::vasp_mlff_evaluator::{
    VaspMLFFDescriptorChannel, VaspMLFFModel, VaspMLFFModelArrays, VaspMLFFModelConfig,
};
use serde::Serialize;
use serde_json::{json, Map, Value};
use std::collections::HashSet;
use std::fs::File;
use std::io::{Read, Seek, SeekFrom};
use std::path::Path;

pub const HELP: &str = "Usage: macer-rust util vasp-mlff inspect --model <ML_FF|ML_FFN> [--json]\n";
const HEADER_SIZE: usize = 4096;
const MAX_VERSION: (i32, i32, i32) = (0, 2, 5);
const MAX_ITEMS: usize = 20_000_000;

#[derive(Clone, Debug, PartialEq)]
pub struct VaspMLFFArrays {
    /// Per-species linear output weights, each with shape `[NB]`.
    pub wmat: Vec<Vec<f64>>,
    /// Per-species radial descriptor matrices, when `W1 > 0`.
    pub c00: Option<Vec<Vec<Vec<f64>>>>,
    /// Per-species angular descriptor matrices, when `W2 > 0`.
    pub ps: Option<Vec<Vec<Vec<f64>>>>,
}

#[derive(Clone, Debug, PartialEq)]
pub struct VaspMLFFEvaluationInput {
    /// Header, prefix and payload metadata with the same keys as `inspect` JSON.
    pub metadata: Value,
    /// Loaded row-major ML_FF matrices for the native evaluator.
    pub arrays: VaspMLFFArrays,
    /// Payload-derived radial basis and Gaussian interpolation table for W1.
    pub radial_basis: Option<BesselRadialBasis>,
    pub radial_splines: Option<RadialSplineSet>,
    /// DESC_TYPE=0 angular and LSIC active-index mappings.
    pub angular_layout: Vec<Vec<AngularDescriptorIndex>>,
    pub sic_layout: Vec<Vec<AngularSICDescriptorIndex>>,
    /// Payload-derived VASP Bohr radial basis, when W2 enables angular terms.
    pub angular_basis: Option<BesselRadialBasis>,
    /// Payload-derived Gaussian radial interpolation tables for angular terms.
    pub angular_splines: Option<RadialSplineSet>,
}

impl VaspMLFFEvaluationInput {
    /// Convert parsed VASP metadata and arrays into the host-independent Rust
    /// calculator contract. Unsupported model features fail before evaluation.
    pub fn to_model(&self) -> Result<VaspMLFFModel, String> {
        let payload = &self.metadata["payload"];
        if payload["desc_type"].as_i64() != Some(0)
            || payload["lsupervec"].as_bool() != Some(true)
            || payload["lwindow1"].as_bool() == Some(true)
            || payload["lwindow2"].as_bool() == Some(true)
            || payload["lmetric1"].as_bool() == Some(true)
            || payload["lmetric2"].as_bool() == Some(true)
            || payload["lvartran1"].as_bool() == Some(true)
            || payload["lvartran2"].as_bool() == Some(true)
        {
            return Err("VASP ML_FF uses an unsupported descriptor mode".into());
        }
        let symbols: Vec<String> = serde_json::from_value(payload["types"].clone())
            .map_err(|error| format!("invalid ML_FF type list: {error}"))?;
        let type_atomic_numbers = symbols
            .iter()
            .map(|symbol| {
                atomic_number_for_symbol(symbol)
                    .ok_or_else(|| format!("unknown ML_FF element symbol {symbol:?}"))
            })
            .collect::<Result<Vec<_>, _>>()?;
        let channel = |basis: Option<&BesselRadialBasis>,
                       splines: Option<&RadialSplineSet>,
                       cutoff_key: &str,
                       mrb_key: &str|
         -> Result<Option<VaspMLFFDescriptorChannel>, String> {
            match (basis, splines) {
                (None, None) => Ok(None),
                (Some(basis), Some(splines)) => Ok(Some(VaspMLFFDescriptorChannel {
                    cutoff_angstrom: payload[cutoff_key]
                        .as_f64()
                        .ok_or_else(|| format!("missing ML_FF {cutoff_key}"))?,
                    nrb: basis.nrb.clone(),
                    mrb: payload[mrb_key]
                        .as_u64()
                        .and_then(|value| usize::try_from(value).ok())
                        .ok_or_else(|| format!("invalid ML_FF {mrb_key}"))?,
                    splines: splines.clone(),
                })),
                _ => Err(format!("incomplete VASP ML_FF spline channel {cutoff_key}")),
            }
        };
        let angular_layout = self
            .angular_layout
            .iter()
            .map(|layout| {
                layout
                    .iter()
                    .map(
                        |item| macer_rust_model::vasp_mlff_descriptors::AngularDescriptorIndex {
                            active_index: item.active_index,
                            candidate_index_1based: item.candidate_index_1based,
                            center_type: item.center_type,
                            neighbor_type_a: item.neighbor_type_a,
                            neighbor_type_b: item.neighbor_type_b,
                            l: item.l,
                            radial_i_1based: item.radial_i_1based,
                            radial_j_1based: item.radial_j_1based,
                            pair_weight: item.pair_weight,
                        },
                    )
                    .collect()
            })
            .collect();
        let sic_layout = self
            .sic_layout
            .iter()
            .map(|layout| {
                layout
                    .iter()
                    .map(|item| {
                        macer_rust_model::vasp_mlff_descriptors::AngularSICDescriptorIndex {
                            active_index: item.active_index,
                            candidate_index_1based: item.candidate_index_1based,
                            center_type: item.center_type,
                            neighbor_type: item.neighbor_type,
                            l: item.l,
                            radial_i_1based: item.radial_i_1based,
                            radial_j_1based: item.radial_j_1based,
                        }
                    })
                    .collect()
            })
            .collect();
        let arrays = VaspMLFFModelArrays {
            wmat: self.arrays.wmat.clone(),
            c00: self.arrays.c00.clone(),
            ps: self.arrays.ps.clone(),
        };
        VaspMLFFModel::new(VaspMLFFModelConfig {
            type_atomic_numbers,
            w1: payload["w1"].as_f64().unwrap_or(0.0),
            w2: payload["w2"].as_f64().unwrap_or(0.0),
            lnorm1: payload["lnorm1"].as_bool().unwrap_or(false),
            lnorm2: payload["lnorm2"].as_bool().unwrap_or(false),
            lsic: payload["lsic"].as_bool().unwrap_or(false),
            nhyp2: payload["nhyp2"]
                .as_u64()
                .and_then(|value| usize::try_from(value).ok())
                .ok_or_else(|| "invalid ML_FF NHYP2".to_owned())?,
            iscale_toten: payload["iscale_toten"]
                .as_i64()
                .and_then(|value| i32::try_from(value).ok())
                .ok_or_else(|| "invalid ML_FF ISCALE_TOTEN".to_owned())?,
            eatom_ref_ev: serde_json::from_value(payload["eatom_ref_ev"].clone())
                .map_err(|error| format!("invalid ML_FF EATOM_REF: {error}"))?,
            totenav_ev_per_atom: payload["totenav_ev_per_atom"]
                .as_f64()
                .ok_or_else(|| "invalid ML_FF TOTENAV".to_owned())?,
            lafilt2: payload["lafilt2"].as_bool().unwrap_or(false),
            iafilt2: payload["iafilt2"]
                .as_u64()
                .and_then(|value| u8::try_from(value).ok()),
            afilt2: payload["afilt2"].as_f64(),
            arrays,
            radial: channel(
                self.radial_basis.as_ref(),
                self.radial_splines.as_ref(),
                "rcut1_angstrom",
                "mrb1",
            )?,
            angular: channel(
                self.angular_basis.as_ref(),
                self.angular_splines.as_ref(),
                "rcut2_angstrom",
                "mrb2",
            )?,
            angular_layout,
            sic_layout,
        })
    }
}

fn atomic_number_for_symbol(symbol: &str) -> Option<u8> {
    const SYMBOLS: [&str; 118] = [
        "H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne", "Na", "Mg", "Al", "Si", "P", "S",
        "Cl", "Ar", "K", "Ca", "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn", "Ga",
        "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr", "Nb", "Mo", "Tc", "Ru", "Rh", "Pd",
        "Ag", "Cd", "In", "Sn", "Sb", "Te", "I", "Xe", "Cs", "Ba", "La", "Ce", "Pr", "Nd", "Pm",
        "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb", "Lu", "Hf", "Ta", "W", "Re", "Os",
        "Ir", "Pt", "Au", "Hg", "Tl", "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th", "Pa",
        "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm", "Md", "No", "Lr", "Rf", "Db", "Sg",
        "Bh", "Hs", "Mt", "Ds", "Rg", "Cn", "Nh", "Fl", "Mc", "Lv", "Ts", "Og",
    ];
    SYMBOLS
        .iter()
        .position(|candidate| *candidate == symbol)
        .map(|index| (index + 1) as u8)
}

#[derive(Clone, Debug, PartialEq, Serialize)]
pub struct AngularDescriptorIndex {
    pub active_index: usize,
    pub candidate_index_1based: usize,
    pub center_type: usize,
    pub neighbor_type_a: usize,
    pub neighbor_type_b: usize,
    pub l: usize,
    pub radial_i_1based: usize,
    pub radial_j_1based: usize,
    pub pair_weight: f64,
}

#[derive(Clone, Debug, PartialEq, Serialize)]
pub struct AngularSICDescriptorIndex {
    pub active_index: usize,
    pub candidate_index_1based: usize,
    pub center_type: usize,
    pub neighbor_type: usize,
    pub l: usize,
    pub radial_i_1based: usize,
    pub radial_j_1based: usize,
}

/// Reconstruct the descriptor order written by VASP `READ_FFCAR` for
/// `DESC_TYPE=0`; indexes from the file are one-based candidate indexes.
pub fn build_desc_type0_angular_layout(
    payload: &Value,
) -> Result<Vec<Vec<AngularDescriptorIndex>>, String> {
    let desc_type = payload["desc_type"].as_i64().unwrap_or(-1);
    if desc_type != 0 {
        return Err(format!(
            "DESC_TYPE={desc_type} layout is not implemented; expected DESC_TYPE=0"
        ));
    }
    let types: Vec<String> = serde_json::from_value(payload["types"].clone())
        .map_err(|error| format!("invalid ML_FF type list: {error}"))?;
    let ntypes = types.len();
    let w2 = payload["w2"].as_f64().unwrap_or(0.0);
    if w2 <= 0.0 {
        return Ok(vec![Vec::new(); ntypes]);
    }
    let nrb2: Vec<usize> = serde_json::from_value(payload["nrb2"].clone())
        .map_err(|error| format!("invalid ML_FF NRB2: {error}"))?;
    let active: Vec<Vec<i32>> = serde_json::from_value(payload["active_descriptors"].clone())
        .map_err(|error| format!("invalid ML_FF active descriptors: {error}"))?;
    if active.len() != ntypes {
        return Err(format!(
            "active descriptor species count {} does not match type count {ntypes}",
            active.len()
        ));
    }
    let mut layouts = Vec::with_capacity(ntypes);
    for (center_type, active_candidates) in active.iter().enumerate() {
        let active_set = active_candidates.iter().copied().collect::<HashSet<_>>();
        let mut layout = Vec::with_capacity(active_candidates.len());
        let mut candidate = 0_usize;
        for neighbor_type_a in 0..ntypes {
            for neighbor_type_b in 0..ntypes {
                for (l, &radial_count) in nrb2.iter().enumerate() {
                    for radial_i in 1..=radial_count {
                        for radial_j in radial_i..=radial_count {
                            candidate = candidate.checked_add(1).ok_or_else(|| {
                                "ML_FF angular candidate index overflow".to_owned()
                            })?;
                            let candidate_i32 = i32::try_from(candidate).map_err(|_| {
                                "ML_FF angular candidate index exceeds int32".to_owned()
                            })?;
                            if !active_set.contains(&candidate_i32) {
                                continue;
                            }
                            layout.push(AngularDescriptorIndex {
                                active_index: layout.len(),
                                candidate_index_1based: candidate,
                                center_type,
                                neighbor_type_a,
                                neighbor_type_b,
                                l,
                                radial_i_1based: radial_i,
                                radial_j_1based: radial_j,
                                pair_weight: if radial_i == radial_j {
                                    1.0
                                } else {
                                    std::f64::consts::SQRT_2
                                },
                            });
                        }
                    }
                }
            }
        }
        if layout.len() != active_candidates.len() {
            return Err(format!(
                "active descriptor count mismatch for type {}: mapped {}, file has {}",
                types[center_type],
                layout.len(),
                active_candidates.len()
            ));
        }
        layouts.push(layout);
    }
    Ok(layouts)
}

/// Reconstruct the VASP `LSIC` angular descriptor subset for `DESC_TYPE=0`.
pub fn build_desc_type0_sic_layout(
    payload: &Value,
) -> Result<Vec<Vec<AngularSICDescriptorIndex>>, String> {
    let desc_type = payload["desc_type"].as_i64().unwrap_or(-1);
    if desc_type != 0 {
        return Err(format!(
            "DESC_TYPE={desc_type} LSIC layout is not implemented; expected DESC_TYPE=0"
        ));
    }
    let types: Vec<String> = serde_json::from_value(payload["types"].clone())
        .map_err(|error| format!("invalid ML_FF type list: {error}"))?;
    let ntypes = types.len();
    let w2 = payload["w2"].as_f64().unwrap_or(0.0);
    let lsic = payload["lsic"].as_bool().unwrap_or(false);
    if w2 <= 0.0 || !lsic {
        return Ok(vec![Vec::new(); ntypes]);
    }
    let nrb2: Vec<usize> = serde_json::from_value(payload["nrb2"].clone())
        .map_err(|error| format!("invalid ML_FF NRB2: {error}"))?;
    let active: Vec<Vec<i32>> =
        serde_json::from_value(payload["active_descriptors_sic"].clone())
            .map_err(|error| format!("invalid ML_FF SIC active descriptors: {error}"))?;
    if active.len() != ntypes {
        return Err(format!(
            "active SIC descriptor species count {} does not match type count {ntypes}",
            active.len()
        ));
    }
    let mut layouts = Vec::with_capacity(ntypes);
    for (center_type, active_candidates) in active.iter().enumerate() {
        let active_set = active_candidates.iter().copied().collect::<HashSet<_>>();
        let mut layout = Vec::with_capacity(active_candidates.len());
        let mut candidate = 0_usize;
        for neighbor_type in 0..ntypes {
            for (l, &radial_count) in nrb2.iter().enumerate() {
                for radial_i in 1..=radial_count {
                    for radial_j in radial_i..=radial_count {
                        candidate = candidate
                            .checked_add(1)
                            .ok_or_else(|| "ML_FF SIC candidate index overflow".to_owned())?;
                        let candidate_i32 = i32::try_from(candidate)
                            .map_err(|_| "ML_FF SIC candidate index exceeds int32".to_owned())?;
                        if !active_set.contains(&candidate_i32) {
                            continue;
                        }
                        layout.push(AngularSICDescriptorIndex {
                            active_index: layout.len(),
                            candidate_index_1based: candidate,
                            center_type,
                            neighbor_type,
                            l,
                            radial_i_1based: radial_i,
                            radial_j_1based: radial_j,
                        });
                    }
                }
            }
        }
        if layout.len() != active_candidates.len() {
            return Err(format!(
                "active LSIC descriptor count mismatch for type {}: mapped {}, file has {}",
                types[center_type],
                layout.len(),
                active_candidates.len()
            ));
        }
        layouts.push(layout);
    }
    Ok(layouts)
}

struct Reader<'a> {
    file: &'a mut (dyn ReadSeek + 'a),
    position: usize,
    little_endian: bool,
}

trait ReadSeek: Read + Seek {}
impl<T: Read + Seek> ReadSeek for T {}

impl<'a> Reader<'a> {
    fn new(
        file: &'a mut (dyn ReadSeek + 'a),
        position: usize,
        little_endian: bool,
    ) -> Result<Self, String> {
        file.seek(SeekFrom::Start(position as u64))
            .map_err(|error| error.to_string())?;
        Ok(Self {
            file,
            position,
            little_endian,
        })
    }

    fn tell(&self) -> usize {
        self.position
    }

    fn take(&mut self, count: usize) -> Result<Vec<u8>, String> {
        let end = self
            .position
            .checked_add(count)
            .ok_or_else(|| "VASP ML_FF offset overflow".to_owned())?;
        let mut slice = vec![0_u8; count];
        self.file.read_exact(&mut slice).map_err(|error| {
            if error.kind() == std::io::ErrorKind::UnexpectedEof {
                format!(
                    "unexpected EOF while reading {count} bytes at offset {}",
                    self.position
                )
            } else {
                error.to_string()
            }
        })?;
        self.position = end;
        Ok(slice)
    }

    fn i32(&mut self) -> Result<i32, String> {
        let end = self
            .position
            .checked_add(4)
            .ok_or_else(|| "VASP ML_FF offset overflow".to_owned())?;
        let mut raw = [0_u8; 4];
        self.file.read_exact(&mut raw).map_err(|error| {
            if error.kind() == std::io::ErrorKind::UnexpectedEof {
                format!(
                    "unexpected EOF while reading 4 bytes at offset {}",
                    self.position
                )
            } else {
                error.to_string()
            }
        })?;
        self.position = end;
        Ok(if self.little_endian {
            i32::from_le_bytes(raw)
        } else {
            i32::from_be_bytes(raw)
        })
    }

    fn i32s(&mut self, count: usize) -> Result<Vec<i32>, String> {
        checked_count(count)?;
        (0..count).map(|_| self.i32()).collect()
    }

    fn f64(&mut self) -> Result<f64, String> {
        let end = self
            .position
            .checked_add(8)
            .ok_or_else(|| "VASP ML_FF offset overflow".to_owned())?;
        let mut raw = [0_u8; 8];
        self.file.read_exact(&mut raw).map_err(|error| {
            if error.kind() == std::io::ErrorKind::UnexpectedEof {
                format!(
                    "unexpected EOF while reading 8 bytes at offset {}",
                    self.position
                )
            } else {
                error.to_string()
            }
        })?;
        self.position = end;
        Ok(if self.little_endian {
            f64::from_le_bytes(raw)
        } else {
            f64::from_be_bytes(raw)
        })
    }

    fn f64s(&mut self, count: usize) -> Result<Vec<f64>, String> {
        checked_count(count)?;
        (0..count).map(|_| self.f64()).collect()
    }

    fn matrix(
        &mut self,
        rows: usize,
        columns: usize,
        load: bool,
    ) -> Result<Option<Vec<Vec<f64>>>, String> {
        let count = rows
            .checked_mul(columns)
            .ok_or_else(|| "VASP ML_FF matrix dimensions overflow".to_owned())?;
        if !load {
            self.skip_f64s(count)?;
            return Ok(None);
        }
        checked_count(count)?;
        let mut row_major = vec![vec![0.0; columns]; rows];
        for column in 0..columns {
            for row in 0..rows {
                row_major[row][column] = self.f64()?;
            }
        }
        Ok(Some(row_major))
    }

    fn logical(&mut self) -> Result<bool, String> {
        Ok(self.i32()? != 0)
    }

    fn chars2(&mut self, count: usize) -> Result<Vec<String>, String> {
        checked_count(count)?;
        (0..count)
            .map(|_| {
                let bytes = self.take(2)?;
                Ok(String::from_utf8_lossy(&bytes).trim().to_owned())
            })
            .collect()
    }

    fn skip_f64s(&mut self, count: usize) -> Result<(), String> {
        let bytes = count
            .checked_mul(8)
            .ok_or_else(|| "VASP ML_FF matrix byte-size overflow".to_owned())?;
        // Match the reference stream reader, which seeks over matrix blocks
        // without checking whether the final skipped bytes exist. A later
        // read still detects EOF.
        let next_position = self
            .position
            .checked_add(bytes)
            .ok_or_else(|| "VASP ML_FF offset overflow".to_owned())?;
        let delta = i64::try_from(bytes)
            .map_err(|_| "VASP ML_FF matrix seek exceeds platform limits".to_owned())?;
        self.file
            .seek(SeekFrom::Current(delta))
            .map_err(|error| error.to_string())?;
        self.position = next_position;
        Ok(())
    }

    fn skip_matrix(&mut self, rows: usize, columns: usize) -> Result<(), String> {
        let count = rows
            .checked_mul(columns)
            .ok_or_else(|| "VASP ML_FF matrix dimensions overflow".to_owned())?;
        self.skip_f64s(count)
    }
}

fn checked_count(count: usize) -> Result<(), String> {
    if count > MAX_ITEMS {
        return Err(format!(
            "VASP ML_FF metadata requests {count} items (limit {MAX_ITEMS})"
        ));
    }
    Ok(())
}

fn version_leq(version: (i32, i32, i32), other: (i32, i32, i32)) -> bool {
    version <= other
}

fn version_geq(version: (i32, i32, i32), other: (i32, i32, i32)) -> bool {
    version >= other
}

fn version_value(version: (i32, i32, i32)) -> Value {
    json!([version.0, version.1, version.2])
}

fn read_version(
    file: &mut (dyn ReadSeek + '_),
    offset: usize,
    little_endian: bool,
) -> Result<(i32, i32, i32), String> {
    file.seek(SeekFrom::Start(offset as u64))
        .map_err(|error| error.to_string())?;
    let mut data = [0_u8; 12];
    file.read_exact(&mut data)
        .map_err(|_| "cannot read VASP ML_FF version triplet".to_owned())?;
    let value = |index: usize| {
        let raw: [u8; 4] = data[index..index + 4].try_into().expect("four-byte chunk");
        if little_endian {
            i32::from_le_bytes(raw)
        } else {
            i32::from_be_bytes(raw)
        }
    };
    Ok((value(0), value(4), value(8)))
}

fn detect_endian(
    file: &mut (dyn ReadSeek + '_),
    offset: usize,
    expected: Option<(i32, i32, i32)>,
) -> Result<bool, String> {
    let little = read_version(file, offset, true)?;
    let big = read_version(file, offset, false)?;
    if let Some(expected) = expected {
        if little == expected {
            return Ok(true);
        }
        if big == expected {
            return Ok(false);
        }
    }
    let plausible = |version: (i32, i32, i32)| {
        (0..=10).contains(&version.0)
            && (0..=100).contains(&version.1)
            && (0..=100).contains(&version.2)
    };
    if plausible(little) {
        return Ok(true);
    }
    if plausible(big) {
        return Ok(false);
    }
    Err("could not infer endian from VASP ML_FF version triplet".to_owned())
}

struct Header {
    has_header: bool,
    text: Option<String>,
    version: Option<(i32, i32, i32)>,
    mode: Option<String>,
    metadata: Value,
}

fn parse_header(bytes: &[u8]) -> Result<Header, String> {
    let raw = &bytes[..bytes.len().min(HEADER_SIZE)];
    let decoded = String::from_utf8_lossy(raw);
    if !decoded.starts_with("ML_FF ") {
        return Ok(Header {
            has_header: false,
            text: None,
            version: None,
            mode: None,
            metadata: json!({}),
        });
    }
    let text = decoded
        .trim_end_matches(|ch| matches!(ch, ' ' | '\n' | '\r' | '\0'))
        .to_owned();
    let mut fields = text.split_whitespace();
    let _magic = fields.next();
    let version_text = fields.next().ok_or_else(|| {
        "ML_FF header starts with ML_FF but version/mode could not be parsed".to_owned()
    })?;
    let mode = fields
        .next()
        .ok_or_else(|| {
            "ML_FF header starts with ML_FF but version/mode could not be parsed".to_owned()
        })?
        .to_owned();
    let parts = version_text
        .split('.')
        .map(|part| {
            if part.is_empty() || !part.bytes().all(|byte| byte.is_ascii_digit()) {
                return Err(());
            }
            part.parse::<i32>().map_err(|_| ())
        })
        .collect::<Result<Vec<_>, _>>()
        .map_err(|_| "ML_FF header starts with ML_FF but version/mode could not be parsed")?;
    if parts.len() != 3 || fields.next().is_none() {
        return Err("ML_FF header starts with ML_FF but version/mode could not be parsed".into());
    }
    drop(fields);
    let version = (parts[0], parts[1], parts[2]);
    if !version_leq(version, MAX_VERSION) {
        return Err(format!(
            "ML_FF version ({}, {}, {}) is newer than supported (0, 2, 5)",
            version.0, version.1, version.2
        ));
    }
    if mode != "binary" {
        return Err(format!(
            "native reader currently supports binary ML_FF only, got {mode:?}"
        ));
    }
    let metadata = if let (Some(start), Some(end)) = (text.find('{'), text.rfind('}')) {
        if end > start {
            let raw_json = &text[start..=end];
            serde_json::from_str(raw_json).unwrap_or_else(|_| json!({ "_raw_json": raw_json }))
        } else {
            json!({})
        }
    } else {
        json!({})
    };
    Ok(Header {
        has_header: true,
        text: Some(text),
        version: Some(version),
        mode: Some(mode),
        metadata,
    })
}

fn parse_payload(
    file: &mut (dyn ReadSeek + '_),
    offset: usize,
    header_version: Option<(i32, i32, i32)>,
    read_arrays: bool,
) -> Result<(bool, Value, Value, Option<VaspMLFFArrays>), String> {
    let little_endian = detect_endian(file, offset, header_version)?;
    let mut reader = Reader::new(file, offset, little_endian)?;
    let version_vec = reader.i32s(3)?;
    let version = (version_vec[0], version_vec[1], version_vec[2]);
    if !version_leq(version, MAX_VERSION) {
        return Err(format!(
            "ML_FF payload version ({}, {}, {}) is newer than supported (0, 2, 5)",
            version.0, version.1, version.2
        ));
    }
    let desc_type = if version_geq(version, (0, 2, 1)) {
        reader.i32()?
    } else {
        0
    };
    let type_count = reader.i32()?;
    if !(1..=256).contains(&type_count) {
        return Err(format!("invalid ML_FF type count: {type_count}"));
    }
    let type_count = type_count as usize;
    let types = reader.chars2(type_count)?;
    let eatom = reader.f64s(type_count)?;
    let masses = reader.f64s(type_count)?;
    let iweight = reader.i32()?;
    let weights = reader.f64s(3)?;
    let rmse_energy = reader.f64()?;
    let rmse_force = reader.f64()?;
    let rmse_stress = reader.f64()?;
    let lmlmb = reader.logical()?;
    if !lmlmb {
        return Err("native reader currently supports VASP many-body ML_FF only".into());
    }
    let lsic = reader.logical()?;
    let lsupervec = reader.logical()?;
    let w = reader.f64s(2)?;
    let cut = reader.i32s(2)?;
    let rcut = reader.f64s(2)?;
    let broad = reader.i32s(2)?;
    let sion = reader.f64s(2)?;
    let mrb = reader.i32s(2)?;
    let w1 = w[0];
    let w2 = w[1];
    let mrb1 = mrb[0];
    let mrb2 = mrb[1];

    let basis_type2 = if version_geq(version, (0, 2, 2)) {
        reader.i32()?
    } else {
        0
    };
    let mrb2_max = if matches!(basis_type2, 4 | 5) {
        Some(reader.i32()?)
    } else {
        None
    };
    if matches!(desc_type, 2 | 4 | 7 | 9) {
        return Err(format!(
            "reduced descriptor ML_DESC_TYPE={desc_type} is not implemented yet"
        ));
    }

    let nr = reader.i32s(2)?;
    let mspl = reader.i32s(2)?;
    let lmax = reader.i32s(2)?;
    let nhyp = reader.i32s(2)?;
    let lnorm = [reader.logical()?, reader.logical()?];
    let lwindow = [reader.logical()?, reader.logical()?];
    let iwindow1 = if lwindow[0] {
        Some(reader.i32()?)
    } else {
        None
    };
    let iwindow2 = if lwindow[1] {
        Some(reader.i32()?)
    } else {
        None
    };
    let lafilt2 = reader.logical()?;
    let iafilt2 = if lafilt2 { Some(reader.i32()?) } else { None };
    let afilt2 = if iafilt2 == Some(2) {
        Some(reader.f64()?)
    } else {
        None
    };
    let lmetric = [reader.logical()?, reader.logical()?];
    let nmetric1 = if lmetric[0] {
        Some(reader.i32()?)
    } else {
        None
    };
    let rmetric1 = if lmetric[0] {
        Some(reader.f64()?)
    } else {
        None
    };
    let nmetric2 = if lmetric[1] {
        Some(reader.i32()?)
    } else {
        None
    };
    let rmetric2 = if lmetric[1] {
        Some(reader.f64()?)
    } else {
        None
    };
    let lvartran = [reader.logical()?, reader.logical()?];
    let nvartran1 = if lvartran[0] {
        Some(reader.i32()?)
    } else {
        None
    };
    let nvartran2 = if lvartran[1] {
        Some(reader.i32()?)
    } else {
        None
    };

    let mut nrb2 = Vec::new();
    let mut nnvar2 = vec![0; type_count];
    let mut active_descriptors = vec![Vec::<i32>::new(); type_count];
    let mut nnvar2_sic = vec![0; type_count];
    let mut active_descriptors_sic = vec![Vec::<i32>::new(); type_count];
    if w2 > 0.0 {
        if lmax[1] < 0 {
            return Err(format!("invalid ML_FF LMAX2: {}", lmax[1]));
        }
        nrb2 = reader.i32s((lmax[1] as usize).saturating_add(1))?;
        for i in 0..type_count {
            let count = reader.i32()?;
            if count < 0 {
                return Err(format!("invalid ML_FF active descriptor count: {count}"));
            }
            nnvar2[i] = count;
            active_descriptors[i] = reader.i32s(count as usize)?;
        }
        if lsic {
            for i in 0..type_count {
                let count = reader.i32()?;
                if count < 0 {
                    return Err(format!("invalid ML_FF SIC descriptor count: {count}"));
                }
                nnvar2_sic[i] = count;
                active_descriptors_sic[i] = reader.i32s(count as usize)?;
            }
        }
    }
    let nb = reader.i32s(type_count)?;
    if nb.iter().any(|count| *count < 0) {
        return Err("invalid negative ML_FF NB count".to_owned());
    }
    let iscale_toten = reader.i32()?;
    let totenav = reader.f64()?;

    let wmat_offset = reader.tell();
    let mut wmat_arrays = read_arrays.then(|| Vec::with_capacity(type_count));
    for count in &nb {
        let matrix = reader.matrix(*count as usize, 1, read_arrays)?;
        if let (Some(arrays), Some(matrix)) = (&mut wmat_arrays, matrix) {
            arrays.push(matrix.into_iter().map(|row| row[0]).collect());
        }
    }
    let c00_offset = if w1 > 0.0 { Some(reader.tell()) } else { None };
    let mut c00_arrays = (read_arrays && w1 > 0.0).then(|| Vec::with_capacity(type_count));
    if w1 > 0.0 {
        if mrb1 < 0 {
            return Err(format!("invalid negative ML_FF MRB1: {mrb1}"));
        }
        let rows = (mrb1 as usize)
            .checked_mul(type_count)
            .ok_or_else(|| "ML_FF C00 matrix dimensions overflow".to_owned())?;
        for count in &nb {
            let matrix = reader.matrix(rows, *count as usize, read_arrays)?;
            if let (Some(arrays), Some(matrix)) = (&mut c00_arrays, matrix) {
                arrays.push(matrix);
            }
        }
    }
    let ps_offset = if w2 > 0.0 { Some(reader.tell()) } else { None };
    let mut ps_arrays = (read_arrays && w2 > 0.0).then(|| Vec::with_capacity(type_count));
    if w2 > 0.0 {
        for (active, count) in nnvar2.iter().zip(nb.iter()) {
            let matrix = reader.matrix(*active as usize, *count as usize, read_arrays)?;
            if let (Some(arrays), Some(matrix)) = (&mut ps_arrays, matrix) {
                arrays.push(matrix);
            }
        }
    }

    let sigv = reader.f64()?;
    let sigw = reader.f64()?;
    let sig_energy = reader.f64()?;
    let sig_force = reader.f64s(3)?;
    let mut sig_stress = reader.f64s(3)?;
    sig_stress.extend(reader.f64s(3)?);

    let lfast_from_file = version_geq(version, (0, 2, 4));
    let lfast_read = if lfast_from_file {
        Some(reader.logical()?)
    } else {
        None
    };
    let mut lfast_effective = lfast_read.unwrap_or(true);
    if lsic {
        lfast_effective = false;
    }
    let writecmat = if version_geq(version, (0, 2, 5)) {
        reader.logical()?
    } else {
        !(matches!(version, (0, 2, 3) | (0, 2, 4)) && lfast_read == Some(true))
    };
    let tail_offset = reader.tell();
    if !writecmat {
        for count in &nb {
            reader.skip_matrix(*count as usize, *count as usize)?;
        }
    } else if !lfast_effective {
        let total = nb.iter().try_fold(0_usize, |sum, value| {
            sum.checked_add(*value as usize)
                .ok_or_else(|| "ML_FF NB total overflow".to_owned())
        })?;
        reader.skip_matrix(total, total)?;
    }
    let end_offset = reader.tell();
    let loaded_arrays = read_arrays.then(|| VaspMLFFArrays {
        wmat: wmat_arrays.unwrap_or_default(),
        c00: c00_arrays,
        ps: ps_arrays,
    });
    let wmat_shapes = if read_arrays {
        json!(nb.iter().map(|count| vec![*count]).collect::<Vec<_>>())
    } else {
        Value::Null
    };
    let c00_shapes = if read_arrays && w1 > 0.0 {
        let rows = mrb1 * type_count as i32;
        json!(nb
            .iter()
            .map(|count| vec![rows, *count])
            .collect::<Vec<_>>())
    } else {
        Value::Null
    };
    let ps_shapes = if read_arrays && w2 > 0.0 {
        json!(nnvar2
            .iter()
            .zip(nb.iter())
            .map(|(rows, columns)| vec![*rows, *columns])
            .collect::<Vec<_>>())
    } else {
        Value::Null
    };
    let prefix = json!({
        "version": version_value(version),
        "desc_type": desc_type,
        "types": types,
        "eatom_ref_ev": eatom,
        "pomass_amu": masses,
        "iweight": iweight,
        "weights": weights,
        "rmse_energy_ev_per_atom": rmse_energy,
        "rmse_force_ev_per_angstrom": rmse_force,
        "rmse_stress_kbar": rmse_stress,
        "lmlmb": lmlmb,
        "lsic": lsic,
        "lsupervec": lsupervec,
        "w1": w1,
        "w2": w2,
        "icut1": cut[0],
        "icut2": cut[1],
        "rcut1_angstrom": rcut[0],
        "rcut2_angstrom": rcut[1],
        "ibroad1": broad[0],
        "ibroad2": broad[1],
        "sion1_angstrom": sion[0],
        "sion2_angstrom": sion[1],
        "mrb1": mrb1,
        "mrb2": mrb2,
    });
    let nbtot: i64 = nb.iter().map(|value| i64::from(*value)).sum();
    let mmvar1 = if w1 > 0.0 {
        mrb1 * type_count as i32
    } else {
        0
    };
    let mmvar2 = nnvar2.iter().copied().max().unwrap_or(0);
    let payload = json!({
        "version": version_value(version),
        "desc_type": desc_type,
        "types": types,
        "eatom_ref_ev": eatom,
        "pomass_amu": masses,
        "iweight": iweight,
        "weights": weights,
        "rmse_energy_ev_per_atom": rmse_energy,
        "rmse_force_ev_per_angstrom": rmse_force,
        "rmse_stress_kbar": rmse_stress,
        "lmlmb": lmlmb,
        "lsic": lsic,
        "lsupervec": lsupervec,
        "w1": w1,
        "w2": w2,
        "icut1": cut[0],
        "icut2": cut[1],
        "rcut1_angstrom": rcut[0],
        "rcut2_angstrom": rcut[1],
        "ibroad1": broad[0],
        "ibroad2": broad[1],
        "sion1_angstrom": sion[0],
        "sion2_angstrom": sion[1],
        "mrb1": mrb1,
        "mrb2": mrb2,
        "basis_type2": basis_type2,
        "mrb2_max": mrb2_max,
        "nr1": nr[0], "nr2": nr[1],
        "mspl1": mspl[0], "mspl2": mspl[1],
        "lmax1": lmax[0], "lmax2": lmax[1],
        "nhyp1": nhyp[0], "nhyp2": nhyp[1],
        "lnorm1": lnorm[0], "lnorm2": lnorm[1],
        "lwindow1": lwindow[0], "lwindow2": lwindow[1],
        "iwindow1": iwindow1, "iwindow2": iwindow2,
        "lafilt2": lafilt2, "iafilt2": iafilt2, "afilt2": afilt2,
        "lmetric1": lmetric[0], "lmetric2": lmetric[1],
        "nmetric1": nmetric1, "rmetric1": rmetric1,
        "nmetric2": nmetric2, "rmetric2": rmetric2,
        "lvartran1": lvartran[0], "lvartran2": lvartran[1],
        "nvartran1": nvartran1, "nvartran2": nvartran2,
        "nrb2": nrb2,
        "nnvar2": nnvar2,
        "active_descriptors": active_descriptors,
        "nnvar2_sic": nnvar2_sic,
        "active_descriptors_sic": active_descriptors_sic,
        "nb": nb,
        "iscale_toten": iscale_toten,
        "totenav_ev_per_atom": totenav,
        "sigv": sigv, "sigw": sigw,
        "sig_energy_ev_per_atom": sig_energy,
        "sig_force_ev_per_angstrom": sig_force,
        "sig_stress_kbar": sig_stress,
        "lfast_from_file": lfast_from_file,
        "lfast_read": lfast_read,
        "lfast_effective": lfast_effective,
        "writecmat": writecmat,
        "wmat_offset": wmat_offset,
        "c00_offset": c00_offset,
        "ps_offset": ps_offset,
        "tail_offset": tail_offset,
        "end_offset": end_offset,
        "wmat": wmat_shapes, "c00": c00_shapes, "ps": ps_shapes,
        "nbtot": nbtot,
        "mmvar1": mmvar1,
        "mmvar2": mmvar2,
    });
    Ok((little_endian, prefix, payload, loaded_arrays))
}

fn sort_json(value: Value) -> Value {
    match value {
        Value::Array(items) => Value::Array(items.into_iter().map(sort_json).collect()),
        Value::Object(object) => {
            let mut entries = object.into_iter().collect::<Vec<_>>();
            entries.sort_by(|a, b| a.0.cmp(&b.0));
            let mut sorted = Map::new();
            for (key, value) in entries {
                sorted.insert(key, sort_json(value));
            }
            Value::Object(sorted)
        }
        other => other,
    }
}

fn read_model(
    path: &str,
    read_arrays: bool,
) -> Result<(Value, Value, Option<VaspMLFFArrays>), String> {
    let mut file = File::open(path).map_err(|error| format!("could not read {path}: {error}"))?;
    let file_size = file.metadata().map_err(|error| error.to_string())?.len();
    let header_len = file_size.min(HEADER_SIZE as u64) as usize;
    let mut header_bytes = vec![0_u8; header_len];
    file.read_exact(&mut header_bytes)
        .map_err(|error| format!("could not read {path}: {error}"))?;
    let header = parse_header(&header_bytes)?;
    let binary_offset = if header.has_header { HEADER_SIZE } else { 0 };
    let (little_endian, prefix, payload, arrays) =
        parse_payload(&mut file, binary_offset, header.version, read_arrays)?;
    let output = json!({
        "path": path,
        "file_size": file_size,
        "has_header": header.has_header,
        "header_text": header.text,
        "header": header.metadata,
        "header_version": header.version.map(version_value),
        "header_mode": header.mode,
        "binary_offset": binary_offset,
        "endian": if little_endian { "<" } else { ">" },
        "prefix": prefix,
        "payload": payload,
    });
    Ok((output, header.metadata, arrays))
}

fn inspect(path: &str) -> Result<(Value, Value), String> {
    let (data, header, _arrays) = read_model(path, false)?;
    Ok((data, header))
}

#[allow(dead_code)]
pub fn load_for_native_evaluation(
    path: impl AsRef<Path>,
) -> Result<VaspMLFFEvaluationInput, String> {
    let path = path.as_ref().to_string_lossy().into_owned();
    let (metadata, _header, arrays) = read_model(&path, true)?;
    let arrays =
        arrays.ok_or_else(|| "internal error: array loading was not enabled".to_owned())?;
    let payload = &metadata["payload"];
    let angular_layout = build_desc_type0_angular_layout(payload)?;
    let sic_layout = build_desc_type0_sic_layout(payload)?;
    let positive_usize = |key: &str| -> Result<usize, String> {
        let value = payload[key]
            .as_u64()
            .ok_or_else(|| format!("invalid ML_FF {key}"))?;
        usize::try_from(value).map_err(|_| format!("ML_FF {key} exceeds usize"))
    };
    let radial_basis = if payload["w1"].as_f64().unwrap_or(0.0) > 0.0 {
        Some(build_radial_basis_from_payload(
            payload["rcut1_angstrom"]
                .as_f64()
                .ok_or_else(|| "missing ML_FF RCUT1".to_owned())?,
            positive_usize("nr1")?,
            positive_usize("mrb1")?,
            positive_usize("lmax1")?,
            payload["lvartran1"].as_bool().unwrap_or(false),
            payload["lwindow1"].as_bool().unwrap_or(false),
        )?)
    } else {
        None
    };
    let radial_splines = radial_basis
        .as_ref()
        .map(|basis| {
            let sion = payload["sion1_angstrom"]
                .as_f64()
                .ok_or_else(|| "missing ML_FF SION1".to_owned())?;
            let ibroad = payload["ibroad1"].as_i64().unwrap_or(-1) as i32;
            let wion = radial_wion_from_payload(sion, ibroad)?;
            build_gaussian_radial_splines(basis, positive_usize("mspl1")?, wion)
        })
        .transpose()?;
    let angular_basis = if payload["w2"].as_f64().unwrap_or(0.0) > 0.0 {
        let cutoff = payload["rcut2_angstrom"]
            .as_f64()
            .ok_or_else(|| "missing ML_FF RCUT2".to_owned())?;
        let basis = build_angular_basis_from_payload(
            cutoff,
            positive_usize("nr2")?,
            positive_usize("mrb2")?,
            positive_usize("lmax2")?,
            payload["basis_type2"].as_i64().unwrap_or(-1) as i32,
            payload["lvartran2"].as_bool().unwrap_or(false),
            payload["lwindow2"].as_bool().unwrap_or(false),
        )?;
        let serialized_nrb: Vec<usize> = serde_json::from_value(payload["nrb2"].clone())
            .map_err(|error| format!("invalid ML_FF NRB2: {error}"))?;
        if basis.nrb != serialized_nrb {
            return Err(format!(
                "ML_FF NRB2 {:?} does not match generated Bessel basis {:?}",
                serialized_nrb, basis.nrb
            ));
        }
        Some(basis)
    } else {
        None
    };
    let angular_splines = angular_basis
        .as_ref()
        .map(|basis| {
            let sion = payload["sion2_angstrom"]
                .as_f64()
                .ok_or_else(|| "missing ML_FF SION2".to_owned())?;
            let ibroad = payload["ibroad2"].as_i64().unwrap_or(-1) as i32;
            let wion = angular_wion_from_payload(sion, ibroad)?;
            build_gaussian_radial_splines(basis, positive_usize("mspl2")?, wion)
        })
        .transpose()?;
    Ok(VaspMLFFEvaluationInput {
        metadata,
        arrays,
        radial_basis,
        radial_splines,
        angular_layout,
        sic_layout,
        angular_basis,
        angular_splines,
    })
}

fn optional_header_value(header: &Value, key: &str) -> String {
    header
        .get(key)
        .map(|value| match value {
            Value::String(value) => value.clone(),
            Value::Null => "null".into(),
            other => other.to_string(),
        })
        .unwrap_or_else(|| "unknown".into())
}

fn render_plain(path: &str, data: &Value, header: &Value) {
    println!("macer: ML-accelerated Atomic Computational Environment for Research");
    println!("  Version: {}", env!("CARGO_PKG_VERSION"));
    println!("  Command: util vasp-mlff inspect");
    println!("  Model  : VASP ({path})");
    println!("--------------------------------------------------\n");
    println!("Path        : {}", data["path"].as_str().unwrap_or(path));
    println!("File size   : {} bytes", data["file_size"]);
    println!(
        "Header      : {}",
        if data["has_header"] == true {
            "yes"
        } else {
            "no"
        }
    );
    let version = data["header_version"]
        .as_array()
        .cloned()
        .unwrap_or_else(|| {
            data["prefix"]["version"]
                .as_array()
                .cloned()
                .unwrap_or_default()
        });
    println!(
        "Version     : {}",
        serde_json::to_string(&version).unwrap_or_else(|_| "unknown".into())
    );
    println!(
        "Mode        : {}",
        data["header_mode"].as_str().unwrap_or("binary/no-header")
    );
    println!("Endian      : {}", data["endian"].as_str().unwrap_or("?"));
    if header.is_object() && !header.as_object().is_some_and(Map::is_empty) {
        println!(
            "ML_LFAST    : {}",
            optional_header_value(header, "ML_LFAST")
        );
        println!("Header types: {}", optional_header_value(header, "types"));
        println!(
            "Train cfgs  : {}",
            optional_header_value(header, "training_structures")
        );
    }
    let prefix = &data["prefix"];
    let types = prefix["types"].as_array().cloned().unwrap_or_default();
    println!(
        "Payload type: {}",
        serde_json::to_string(&types).unwrap_or_default()
    );
    println!("DESC_TYPE   : {}", prefix["desc_type"]);
    println!("LMLMB/LSIC  : {} / {}", prefix["lmlmb"], prefix["lsic"]);
    println!("W1/W2       : {} / {}", prefix["w1"], prefix["w2"]);
    println!(
        "RCUT1/2 A   : {} / {}",
        prefix["rcut1_angstrom"], prefix["rcut2_angstrom"]
    );
    println!(
        "SION1/2 A   : {} / {}",
        prefix["sion1_angstrom"], prefix["sion2_angstrom"]
    );
    let payload = &data["payload"];
    let nb = payload["nb"].as_array().cloned().unwrap_or_default();
    println!(
        "NB per type : {}",
        serde_json::to_string(&nb).unwrap_or_default()
    );
    println!("NB total    : {}", payload["nbtot"]);
    println!(
        "NNVAR1/2    : {} / {}",
        payload["mmvar1"], payload["mmvar2"]
    );
    println!("NRB2        : {}", payload["nrb2"]);
    println!("MRB1/2      : {} / {}", payload["mrb1"], payload["mrb2"]);
    println!("LMAX1/2     : {} / {}", payload["lmax1"], payload["lmax2"]);
    println!("BASIS_TYPE2 : {}", payload["basis_type2"]);
    println!(
        "LFAST       : {} (file={})",
        payload["lfast_effective"], payload["lfast_read"]
    );
    println!("WRITECMAT   : {}", payload["writecmat"]);
    println!(
        "Offsets     : wmat={}, c00={}, ps={}, tail={}, end={}",
        payload["wmat_offset"],
        payload["c00_offset"],
        payload["ps_offset"],
        payload["tail_offset"],
        payload["end_offset"]
    );
}

pub fn run(arguments: impl Iterator<Item = String>) -> Result<(), String> {
    let arguments = arguments.collect::<Vec<_>>();
    if arguments.iter().any(|arg| arg == "--help" || arg == "-h") {
        print!("{HELP}");
        return Ok(());
    }
    if arguments.first().map(String::as_str) != Some("inspect") {
        return Err(HELP.trim_end().to_owned());
    }
    let mut model = None;
    let mut as_json = false;
    let mut args = arguments.into_iter().skip(1).peekable();
    while let Some(argument) = args.next() {
        if argument == "--json" {
            as_json = true;
            continue;
        }
        let (option, inline_value) = argument
            .split_once('=')
            .map(|(option, value)| (option, Some(value.to_owned())))
            .unwrap_or((argument.as_str(), None));
        if option != "--model" {
            return Err(format!("unexpected argument: {argument}"));
        }
        let value = match inline_value {
            Some(value) => value,
            None => args.next().ok_or("missing value for --model")?,
        };
        model = Some(value);
    }
    let model = model.ok_or("missing required --model")?;
    let (data, header) = inspect(&model)?;
    if as_json {
        println!(
            "{}",
            serde_json::to_string_pretty(&sort_json(data)).map_err(|error| error.to_string())?
        );
    } else {
        render_plain(&model, &data, &header);
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Cursor;

    const SYNTHETIC_MODEL: &[u8] =
        include_bytes!("../../../evidence/vasp_mlff_inspect_parity_2026-10-24/header-le-025-fast");
    const BIG_ENDIAN_MODEL: &[u8] = include_bytes!(
        "../../../evidence/vasp_mlff_inspect_parity_2026-10-24/no-header-be-025-fast"
    );
    const DESCRIPTOR_LAYOUT_MODEL: &[u8] = include_bytes!(
        "../../../evidence/vasp_mlff_inspect_parity_2026-10-24/descriptor-layout-lsic"
    );
    const EXPECTED_DESCRIPTOR_LAYOUT: &str = include_str!(
        "../../../evidence/vasp_mlff_inspect_parity_2026-10-24/descriptor_layout_expected.json"
    );
    const EVALUATION_GOLDEN: &str =
        include_str!("../../../evidence/vasp_mlff_eval_2026-10-24/macer_reference.json");

    #[test]
    fn reads_weight_arrays_from_fortran_column_major_stream() {
        let header = parse_header(&SYNTHETIC_MODEL[..HEADER_SIZE]).unwrap();
        let mut source = Cursor::new(SYNTHETIC_MODEL);
        let (_, _, metadata, arrays) =
            parse_payload(&mut source, HEADER_SIZE, header.version, true).unwrap();
        let arrays = arrays.expect("array-loading mode returns weights");

        assert_eq!(arrays.wmat[0], [0.01, 0.02]);
        assert_eq!(arrays.wmat[1], [0.01]);
        assert_eq!(arrays.c00.as_ref().unwrap()[0].len(), 48);
        assert_eq!(arrays.c00.as_ref().unwrap()[0][0], [1.0, 49.0]);
        assert_eq!(arrays.c00.as_ref().unwrap()[0][47], [48.0, 96.0]);
        assert_eq!(arrays.ps.as_ref().unwrap()[0].len(), 3);
        assert_eq!(arrays.ps.as_ref().unwrap()[0][0], [1.0, 4.0]);
        assert_eq!(arrays.ps.as_ref().unwrap()[0][2], [3.0, 6.0]);
        assert_eq!(metadata["wmat"], json!([[2], [1], [1], [1]]));
        assert_eq!(metadata["c00"], json!([[48, 2], [48, 1], [48, 1], [48, 1]]));
        assert_eq!(metadata["ps"], json!([[3, 2], [2, 1], [2, 1], [2, 1]]));
    }

    #[test]
    fn reads_weight_arrays_from_big_endian_headerless_stream() {
        let mut source = Cursor::new(BIG_ENDIAN_MODEL);
        let (_, _, _, arrays) = parse_payload(&mut source, 0, None, true).unwrap();
        let arrays = arrays.expect("array-loading mode returns weights");
        assert_eq!(arrays.wmat[0], [0.01, 0.02]);
        assert_eq!(arrays.c00.as_ref().unwrap()[0][0], [1.0, 49.0]);
        assert_eq!(arrays.ps.as_ref().unwrap()[0][0], [1.0, 4.0]);
    }

    #[test]
    fn evaluation_loader_returns_metadata_and_transposed_arrays() {
        let path = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../evidence/vasp_mlff_inspect_parity_2026-10-24/header-le-025-fast");
        let loaded = load_for_native_evaluation(path).unwrap();
        assert_eq!(loaded.metadata["payload"]["nb"], json!([2, 1, 1, 1]));
        assert_eq!(loaded.arrays.wmat[0], [0.01, 0.02]);
        assert_eq!(loaded.arrays.c00.as_ref().unwrap()[0][0], [1.0, 49.0]);
        assert_eq!(loaded.arrays.ps.as_ref().unwrap()[0][0], [1.0, 4.0]);
        assert_eq!(loaded.radial_basis.as_ref().unwrap().nrb, [12]);
        assert_eq!(loaded.radial_splines.as_ref().unwrap().fnl.len(), 32);
        assert_eq!(loaded.angular_layout[0].len(), 3);
        assert!(loaded.sic_layout.iter().all(Vec::is_empty));
        assert_eq!(loaded.angular_basis.as_ref().unwrap().nrb, [8, 7, 7]);
        assert_eq!(loaded.angular_splines.as_ref().unwrap().fnl.len(), 32);
    }

    #[test]
    fn descriptor_layouts_match_frozen_macer_order() {
        let header = parse_header(&DESCRIPTOR_LAYOUT_MODEL[..HEADER_SIZE]).unwrap();
        let mut source = Cursor::new(DESCRIPTOR_LAYOUT_MODEL);
        let (_, _, payload, _) =
            parse_payload(&mut source, HEADER_SIZE, header.version, false).unwrap();
        let actual = json!({
            "angular": build_desc_type0_angular_layout(&payload).unwrap(),
            "sic": build_desc_type0_sic_layout(&payload).unwrap(),
        });
        let expected: Value = serde_json::from_str(EXPECTED_DESCRIPTOR_LAYOUT).unwrap();
        assert_eq!(actual, expected);
    }

    #[test]
    fn native_vasp_evaluator_matches_macer_energy_forces_and_stress() {
        let golden: Value = serde_json::from_str(EVALUATION_GOLDEN).unwrap();
        let structure = macer_rust_core::Structure {
            atomic_numbers: serde_json::from_value(golden["structure"]["atomic_numbers"].clone())
                .unwrap(),
            positions_a: serde_json::from_value(golden["structure"]["positions_a"].clone())
                .unwrap(),
            cell_a: serde_json::from_value(golden["structure"]["cell_a"].clone()).unwrap(),
            pbc: [true; 3],
        };
        let model_path = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../evidence/vasp_mlff_inspect_parity_2026-10-24/descriptor-layout-lsic");
        let input = load_for_native_evaluation(model_path).unwrap();
        let model = input.to_model().unwrap();
        let prediction = model.evaluate(&structure, true).unwrap();

        let expected_energy = golden["reference"]["energy_free_ev"].as_f64().unwrap();
        let per_atom_energy_error = (prediction.energy_free_ev - expected_energy).abs()
            / structure.atomic_numbers.len() as f64;
        assert!(
            per_atom_energy_error <= 1.0e-5,
            "energy error per atom {per_atom_energy_error:.6e} eV"
        );
        let expected_forces: Vec<[f64; 3]> =
            serde_json::from_value(golden["reference"]["forces_ev_per_angstrom"].clone()).unwrap();
        let force_error = prediction
            .forces_ev_per_angstrom
            .iter()
            .flatten()
            .zip(expected_forces.iter().flatten())
            .map(|(actual, expected)| (actual - expected).abs())
            .fold(0.0_f64, f64::max);
        assert!(
            force_error <= 1.0e-4,
            "maximum force error {force_error:.6e} eV/A"
        );
        let expected_stress: [[f64; 3]; 3] =
            serde_json::from_value(golden["reference"]["stress_kbar"].clone()).unwrap();
        let stress_error = prediction
            .stress_kbar
            .unwrap()
            .iter()
            .flatten()
            .zip(expected_stress.iter().flatten())
            .map(|(actual, expected)| (actual - expected).abs())
            .fold(0.0_f64, f64::max);
        println!(
            "VASP ML_FF parity: energy_per_atom={per_atom_energy_error:.6e} eV, force_max={force_error:.6e} eV/A, stress_max={stress_error:.6e} kbar"
        );
        assert!(
            stress_error <= 0.1,
            "maximum stress error {stress_error:.6e} kbar"
        );
    }
}
