//! Pair-resolved radial distribution functions matching Macer's `plot_rdf`.

use crate::trajectory::{determinant, Trajectory};
use std::collections::BTreeMap;
use std::f64::consts::PI;
use std::path::Path;

#[derive(Debug, Clone)]
pub(crate) struct Curve {
    pub label: String,
    pub values: Vec<f64>,
}

#[derive(Debug, Clone)]
pub(crate) struct ResultData {
    pub safe_rmax: f64,
    pub n_frames: usize,
    pub radii: Vec<f64>,
    pub curves: Vec<Curve>,
}

pub(crate) fn compute(
    trajectory: &Trajectory,
    requested_rmax: f64,
    bins: usize,
) -> Result<ResultData, String> {
    if !requested_rmax.is_finite() || requested_rmax <= 0.0 {
        return Err("--rmax must be finite and greater than zero".into());
    }
    if bins == 0 {
        return Err("--bins must be at least 1".into());
    }
    let n_total = trajectory.fractional_positions.len();
    if n_total == 0 || trajectory.cells_a.len() != n_total {
        return Err("RDF requires a nonempty trajectory with one cell per frame".into());
    }
    let start = ((n_total as f64) * 0.8) as usize;
    let frames = start.min(n_total - 1)..n_total;
    let n_frames = frames.len();

    let min_height = frames
        .clone()
        .flat_map(|index| cell_heights(trajectory.cells_a[index]))
        .filter(|height| height.is_finite() && *height > 0.0)
        .min_by(f64::total_cmp);
    let safe_rmax = min_height
        .map(|height| requested_rmax.min(0.49 * height))
        .unwrap_or(requested_rmax);
    if !safe_rmax.is_finite() || safe_rmax <= 0.0 {
        return Err("RDF cutoff is not positive after periodic-cell safety adjustment".into());
    }

    let symbols = trajectory.symbols()?;
    let mut species_indices: BTreeMap<&str, Vec<usize>> = BTreeMap::new();
    for (index, symbol) in symbols.iter().enumerate() {
        species_indices.entry(symbol).or_default().push(index);
    }

    let avg_volume = frames
        .clone()
        .map(|index| determinant(trajectory.cells_a[index]).abs())
        .sum::<f64>()
        / n_frames as f64;
    if !avg_volume.is_finite() || avg_volume <= 0.0 {
        return Err("RDF requires positive finite cell volumes".into());
    }

    let dr = safe_rmax / bins as f64;
    let radii = (0..bins)
        .map(|index| (index as f64 + 0.5) * dr)
        .collect::<Vec<_>>();
    let shell = radii
        .iter()
        .map(|radius| 4.0 * PI * radius * radius * dr)
        .collect::<Vec<_>>();
    let mut curves = Vec::new();
    let species = species_indices.keys().copied().collect::<Vec<_>>();
    for first_index in 0..species.len() {
        for second_index in first_index..species.len() {
            let first = species[first_index];
            let second = species[second_index];
            let first_atoms = &species_indices[first];
            let second_atoms = &species_indices[second];
            let mut histogram = vec![0.0; bins];
            for frame_index in frames.clone() {
                let positions = &trajectory.fractional_positions[frame_index];
                let cell = trajectory.cells_a[frame_index];
                for &i in first_atoms {
                    for &j in second_atoms {
                        if first == second && i >= j {
                            continue;
                        }
                        let delta: [f64; 3] = std::array::from_fn(|axis| {
                            let raw = positions[j][axis] - positions[i][axis];
                            raw - round_ties_even(raw)
                        });
                        let cartesian: [f64; 3] = std::array::from_fn(|axis| {
                            (0..3).map(|row| delta[row] * cell[row][axis]).sum()
                        });
                        let distance = cartesian.iter().map(|x| x * x).sum::<f64>().sqrt();
                        if distance > 1.0e-12 && distance < safe_rmax {
                            let bin = (distance / dr) as usize;
                            if bin < bins {
                                histogram[bin] += 1.0;
                            }
                        }
                    }
                }
            }
            let n_first = first_atoms.len() as f64;
            let n_second = second_atoms.len() as f64;
            let values = (0..bins)
                .map(|bin| {
                    let denominator = if first == second {
                        n_frames as f64 * n_first * shell[bin] * (n_first / avg_volume)
                    } else {
                        n_frames as f64 * n_first * shell[bin] * (n_second / avg_volume)
                    };
                    if denominator <= 0.0 {
                        0.0
                    } else if first == second {
                        2.0 * histogram[bin] / denominator
                    } else {
                        histogram[bin] / denominator
                    }
                })
                .collect();
            curves.push(Curve {
                label: format!("{first}-{second}"),
                values,
            });
        }
    }
    Ok(ResultData {
        safe_rmax,
        n_frames,
        radii,
        curves,
    })
}

fn cell_heights(cell: [[f64; 3]; 3]) -> [f64; 3] {
    let cross = |a: [f64; 3], b: [f64; 3]| {
        [
            a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0],
        ]
    };
    let norm = |v: [f64; 3]| v.iter().map(|x| x * x).sum::<f64>().sqrt();
    let volume = determinant(cell).abs();
    [
        volume / norm(cross(cell[1], cell[2])),
        volume / norm(cross(cell[2], cell[0])),
        volume / norm(cross(cell[0], cell[1])),
    ]
}

fn round_ties_even(value: f64) -> f64 {
    let floor = value.floor();
    match (value - floor).total_cmp(&0.5) {
        std::cmp::Ordering::Less => floor,
        std::cmp::Ordering::Greater => floor + 1.0,
        std::cmp::Ordering::Equal if floor % 2.0 == 0.0 => floor,
        std::cmp::Ordering::Equal => floor + 1.0,
    }
}

pub(crate) fn write_data(path: &Path, result: &ResultData) -> Result<(), String> {
    let mut output = format!(
        "# r_A{}\n",
        result.curves.iter().fold(String::new(), |mut line, curve| {
            line.push_str(&format!(" {}", curve.label));
            line
        })
    );
    for (index, radius) in result.radii.iter().enumerate() {
        output.push_str(&format!("{radius:.12}"));
        for curve in &result.curves {
            output.push_str(&format!(" {:.12e}", curve.values[index]));
        }
        output.push('\n');
    }
    std::fs::write(path, output).map_err(|error| error.to_string())
}

#[cfg(test)]
mod tests {
    use super::compute;
    use crate::trajectory::Trajectory;

    #[test]
    fn pair_rdf_matches_analytic_two_atom_shell_normalization() {
        let cell = [[12.0, 0.0, 0.0], [0.0, 12.0, 0.0], [0.0, 0.0, 12.0]];
        let trajectory = Trajectory {
            atomic_numbers: vec![29, 29],
            cell_a: cell,
            cells_a: vec![cell],
            pbc: [true; 3],
            fractional_positions: vec![vec![[0.0, 0.0, 0.0], [0.45, 0.0, 0.0]]],
        };
        let result = compute(&trajectory, 6.0, 12).unwrap();
        assert!((result.safe_rmax - 5.88).abs() < 1.0e-14);
        assert_eq!(result.n_frames, 1);
        assert_eq!(result.curves.len(), 1);
        let dr: f64 = 5.88 / 12.0;
        let shell = 4.0 * std::f64::consts::PI * (11.5 * dr).powi(2) * dr;
        let expected = 2.0 / (2.0 * shell * (2.0 / 1728.0));
        assert!((result.curves[0].values[11] - expected).abs() < 1.0e-14);
        assert_eq!(
            result.curves[0]
                .values
                .iter()
                .filter(|&&value| value != 0.0)
                .count(),
            1
        );
    }
}
