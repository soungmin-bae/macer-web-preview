//! VASP POSCAR reader for standalone native commands.

use macer_rust_core::types::Structure;
use std::path::Path;

use crate::elements::SYMBOLS;

fn vec3(line: &str) -> Result<[f64; 3], String> {
    let values: Vec<f64> = line
        .split_whitespace()
        .take(3)
        .map(|s| s.parse::<f64>().map_err(|e| e.to_string()))
        .collect::<Result<_, _>>()?;
    if values.len() != 3 || values.iter().any(|x| !x.is_finite()) {
        return Err("expected three finite coordinates".into());
    }
    Ok([values[0], values[1], values[2]])
}

fn determinant(cell: [[f64; 3]; 3]) -> f64 {
    let [[a, b, c], [d, e, f], [g, h, i]] = cell;
    a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)
}

pub fn read_poscar(path: &Path) -> Result<Structure, String> {
    let text = std::fs::read_to_string(path).map_err(|e| e.to_string())?;
    parse_poscar(&text)
}

pub fn parse_poscar(text: &str) -> Result<Structure, String> {
    let mut lines = text.lines().map(str::trim).filter(|s| !s.is_empty());
    let _comment = lines.next().ok_or("POSCAR has no comment line")?;
    let scale_tokens = lines
        .next()
        .ok_or("POSCAR has no scaling line")?
        .split_whitespace()
        .collect::<Vec<_>>();
    if scale_tokens.len() != 1 {
        return Err("invalid POSCAR scaling factor".into());
    }
    let scale = scale_tokens[0]
        .parse::<f64>()
        .map_err(|_| "invalid POSCAR scaling factor")?;
    if !scale.is_finite() || scale == 0. {
        return Err("POSCAR scaling must be finite and nonzero".into());
    }
    let mut raw_cell = [[0.; 3]; 3];
    for row in &mut raw_cell {
        *row = vec3(
            lines
                .next()
                .ok_or("POSCAR has fewer than three cell vectors")?,
        )?;
    }
    let scale = if scale > 0. {
        scale
    } else {
        let raw_volume = determinant(raw_cell).abs();
        if raw_volume <= 1.0e-14 {
            return Err("POSCAR cell volume must be positive".into());
        }
        (-scale / raw_volume).cbrt()
    };
    let cell = raw_cell.map(|row| row.map(|value| value * scale));

    let symbols_or_counts: Vec<&str> = lines
        .next()
        .ok_or("POSCAR has no element symbols or atom counts")?
        .split_whitespace()
        .collect();
    let (symbols, counts, vasp4): (Vec<&str>, Vec<usize>, bool) = if symbols_or_counts
        .iter()
        .all(|value| value.parse::<usize>().is_ok())
    {
        let counts = symbols_or_counts
            .iter()
            .map(|value| {
                value
                    .parse()
                    .map_err(|_| "invalid POSCAR element count".to_string())
            })
            .collect::<Result<Vec<_>, _>>()?;
        (Vec::new(), counts, true)
    } else {
        let symbols = symbols_or_counts;
        let counts = lines
            .next()
            .ok_or("POSCAR has no element counts")?
            .split_whitespace()
            .map(|s| {
                s.parse()
                    .map_err(|_| "invalid POSCAR element count".to_string())
            })
            .collect::<Result<Vec<_>, _>>()?;
        (symbols, counts, false)
    };
    if !vasp4 && symbols.iter().any(|s| s.parse::<usize>().is_ok()) {
        return Err("VASP 5 POSCAR element symbols are required".into());
    }
    if !vasp4 && counts.len() != symbols.len() {
        return Err("POSCAR element symbols and counts differ".into());
    }
    let mut mode = lines.next().ok_or("POSCAR has no coordinate mode")?;
    let selective = mode.to_ascii_lowercase().starts_with('s');
    if selective {
        mode = lines
            .next()
            .ok_or("POSCAR has no coordinate mode after Selective Dynamics")?;
    }
    let direct = mode.to_ascii_lowercase().starts_with('d');
    if !direct
        && !mode.to_ascii_lowercase().starts_with('c')
        && !mode.to_ascii_lowercase().starts_with('k')
    {
        return Err("POSCAR coordinate mode must be Direct or Cartesian".into());
    }
    let site_count = counts.iter().sum::<usize>();
    let mut positions = Vec::with_capacity(site_count);
    let mut coordinate_lines = Vec::with_capacity(site_count);
    for _ in 0..site_count {
        let line = lines
            .next()
            .ok_or("POSCAR has fewer positions than atoms")?;
        coordinate_lines.push(line.to_owned());
        let p = vec3(line)?;
        positions.push(if direct {
            std::array::from_fn(|k| (0..3).map(|j| p[j] * cell[j][k]).sum())
        } else {
            p.map(|value| value * scale)
        });
    }
    let mut numbers = Vec::with_capacity(site_count);
    if vasp4 {
        let symbol_index = if selective { 6 } else { 3 };
        let coordinate_symbols = coordinate_lines
            .iter()
            .map(|line| line.split_whitespace().nth(symbol_index))
            .collect::<Option<Vec<_>>>();
        let coordinate_symbols = coordinate_symbols.filter(|symbols| {
            symbols
                .iter()
                .all(|symbol| SYMBOLS.iter().any(|&candidate| candidate == *symbol))
        });
        if let Some(coordinate_symbols) = coordinate_symbols {
            for symbol in coordinate_symbols {
                let z = SYMBOLS.iter().position(|&name| name == symbol).unwrap();
                numbers.push(z as u8);
            }
        } else {
            // Pymatgen's no-POTCAR VASP4 fallback assigns H, He, Li, ... by
            // species group; it does not interpret the comment as symbols.
            for (&count, z) in counts.iter().zip(1_u8..) {
                numbers.extend(std::iter::repeat_n(z, count));
            }
        }
    } else {
        for (&symbol, &count) in symbols.iter().zip(&counts) {
            let symbol = symbol
                .split('/')
                .next()
                .unwrap_or(symbol)
                .split('_')
                .next()
                .unwrap_or(symbol);
            let z = SYMBOLS
                .iter()
                .position(|&name| name == symbol)
                .ok_or_else(|| format!("unsupported element symbol: {symbol}"))?;
            if z == 0 {
                return Err("unknown element symbol".into());
            }
            numbers.extend(std::iter::repeat_n(z as u8, count));
        }
    }
    let structure = Structure {
        atomic_numbers: numbers,
        positions_a: positions,
        cell_a: cell,
        pbc: [true; 3],
    };
    structure.validate()?;
    Ok(structure)
}

pub fn has_selective_dynamics(path: &Path) -> Result<bool, String> {
    let text = std::fs::read_to_string(path).map_err(|e| e.to_string())?;
    let lines = text
        .lines()
        .map(str::trim)
        .filter(|line| !line.is_empty())
        .collect::<Vec<_>>();
    let line = lines
        .get(7)
        .ok_or("POSCAR is missing its coordinate-mode line")?;
    Ok(line.to_ascii_lowercase().starts_with('s'))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn cus12_fixture_has_expected_elements() {
        let path = Path::new(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../reference/fixtures/CuS-P63mmc-POSCAR"
        ));
        let s = read_poscar(path).unwrap();
        assert_eq!(s.atomic_numbers.len(), 12);
        assert_eq!(&s.atomic_numbers[..6], &[29; 6]);
        assert_eq!(&s.atomic_numbers[6..], &[16; 6]);
    }

    #[test]
    fn supports_vasp4_pymatgen_element_fallback_and_negative_volume_scale() {
        let path = std::env::temp_dir().join(format!(
            "macer-rust-poscar-v4-{}-{}.vasp",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let source = "Fe C\n-64\n2 0 0\n0 2 0\n0 0 2\n1 1\nDirect\n0 0 0\n0.5 0.5 0.5\n";
        std::fs::write(&path, source).unwrap();
        let structure = read_poscar(&path).unwrap();
        assert_eq!(structure.atomic_numbers, [1, 2]);
        assert!((determinant(structure.cell_a).abs() - 64.).abs() < 1.0e-12);
        assert_eq!(structure.positions_a, [[0., 0., 0.], [2., 2., 2.]]);
        let _ = std::fs::remove_file(path);
    }

    #[test]
    fn selective_cartesian_positions_use_scale_and_ignore_flags() {
        let path = std::env::temp_dir().join(format!(
            "macer-rust-poscar-selective-{}-{}.vasp",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let source = "Fe\n2\n2 0 0\n0 2 0\n0 0 2\nFe\n1\nSelective dynamics\nCartesian\n0.25 0.5 0.75 T F T\n";
        std::fs::write(&path, source).unwrap();
        let structure = read_poscar(&path).unwrap();
        assert_eq!(structure.positions_a, [[0.5, 1.0, 1.5]]);
        let _ = std::fs::remove_file(path);
    }
}
