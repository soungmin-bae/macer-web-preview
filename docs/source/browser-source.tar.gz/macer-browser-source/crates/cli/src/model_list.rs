//! Native counterpart of `macer util model list`.
//!
//! The model directory beside the executable is the Rust distribution's
//! package model directory. An optional `mlff_directory` in `~/.macer.yaml`
//! is listed first, matching Macer's user-configured-before-package order.

use std::env;
use std::fs;
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};

pub const HELP: &str = "Usage: macer-rust util model list\n";
const DEFAULT_CONFIG: &str = include_str!("../data/default.yaml");

#[derive(Debug)]
enum ConfigError {
    Malformed(String),
    InvalidModelDirectory(String),
}

pub fn run(arguments: impl Iterator<Item = String>) -> Result<(), String> {
    let arguments = arguments.collect::<Vec<_>>();
    if arguments.iter().any(|arg| arg == "--help" || arg == "-h") {
        print!("{HELP}");
        return Ok(());
    }
    if arguments.as_slice() != ["list"] {
        return Err(HELP.trim_end().to_owned());
    }
    list_models()
}

fn home_directory() -> Result<PathBuf, String> {
    env::var_os("HOME")
        .or_else(|| env::var_os("USERPROFILE"))
        .map(PathBuf::from)
        .ok_or_else(|| "could not determine the user's home directory".to_owned())
}

fn configured_model_directory(config_path: &Path) -> Result<Option<PathBuf>, ConfigError> {
    let contents = match fs::read_to_string(config_path) {
        Ok(contents) => contents,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Err(error) => return Err(ConfigError::Malformed(error.to_string())),
    };
    let value: serde_yaml_ng::Value = serde_yaml_ng::from_str(&contents)
        .map_err(|error| ConfigError::Malformed(error.to_string()))?;
    let Some(mapping) = value.as_mapping() else {
        // Macer's defaults loader ignores falsey non-mapping YAML documents.
        return Ok(None);
    };
    let key = serde_yaml_ng::Value::String("mlff_directory".into());
    let Some(value) = mapping.get(&key) else {
        return Ok(None);
    };
    match value {
        serde_yaml_ng::Value::Null => Ok(None),
        serde_yaml_ng::Value::String(path) if !path.is_empty() => Ok(Some(PathBuf::from(path))),
        serde_yaml_ng::Value::String(_) => Ok(None),
        serde_yaml_ng::Value::Bool(false) => Ok(None),
        serde_yaml_ng::Value::Number(number)
            if number.as_i64() == Some(0)
                || number.as_u64() == Some(0)
                || number.as_f64() == Some(0.0) =>
        {
            Ok(None)
        }
        serde_yaml_ng::Value::Sequence(items) if items.is_empty() => Ok(None),
        serde_yaml_ng::Value::Mapping(items) if items.is_empty() => Ok(None),
        _ => Err(ConfigError::InvalidModelDirectory(format!(
            "mlff_directory must be a path string, got {value:?}"
        ))),
    }
}

fn ensure_user_config(home: &Path) {
    let config_path = home.join(".macer.yaml");
    if !config_path.exists() {
        // Macer copies its bundled defaults on first import. Match that
        // user-visible initialization while keeping listing usable if HOME is
        // read-only, as Macer's best-effort copy does.
        let _ = fs::write(config_path, DEFAULT_CONFIG);
    }
}

#[cfg(unix)]
fn local_backup_timestamp() -> String {
    let seconds = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs() as libc::time_t;
    let mut local = std::mem::MaybeUninit::<libc::tm>::uninit();
    // SAFETY: `seconds` is a valid time_t and `local` points to writable storage;
    // localtime_r writes to that storage without shared static state.
    let result = unsafe { libc::localtime_r(&seconds, local.as_mut_ptr()) };
    if result.is_null() {
        return seconds.to_string();
    }
    // SAFETY: localtime_r returned the same initialized pointer on success.
    let local = unsafe { local.assume_init() };
    format!(
        "{:04}{:02}{:02}_{:02}{:02}{:02}",
        local.tm_year + 1900,
        local.tm_mon + 1,
        local.tm_mday,
        local.tm_hour,
        local.tm_min,
        local.tm_sec
    )
}

#[cfg(not(unix))]
fn local_backup_timestamp() -> String {
    // Windows fallback uses UTC; the backup still preserves the original file.
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
        .to_string()
}

fn recover_user_config(config_path: &Path, error: &str) {
    println!(
        "Warning: Failed to load config from {}: {error}",
        config_path.display()
    );
    println!("  [Auto-Recovery] Corrupted user config detected.");
    let backup_path = config_path.with_extension(format!("yaml.bak.{}", local_backup_timestamp()));
    println!(
        "  [Auto-Recovery] Backing up corrupted file to: {}",
        backup_path.display()
    );

    let result = if backup_path.exists() {
        fs::remove_file(&backup_path).and_then(|()| fs::rename(config_path, &backup_path))
    } else {
        fs::rename(config_path, &backup_path)
    };
    if let Err(error) = result {
        println!("  [Auto-Recovery] Critical Error: Failed to recover config: {error}");
        return;
    }

    println!("  [Auto-Recovery] Regenerating default configuration...");
    if let Some(home) = config_path.parent() {
        ensure_user_config(home);
    }
}

fn package_model_directory() -> Result<PathBuf, String> {
    let executable = env::current_exe().map_err(|error| error.to_string())?;
    let directory = executable
        .parent()
        .ok_or_else(|| "the executable has no parent directory".to_owned())?;
    Ok(directory.join("mlff-model"))
}

fn list_models() -> Result<(), String> {
    let home = home_directory()?;
    ensure_user_config(&home);
    let config_path = home.join(".macer.yaml");
    let configured = match configured_model_directory(&config_path) {
        Ok(configured) => configured,
        Err(ConfigError::Malformed(error)) => {
            recover_user_config(&config_path, &error);
            None
        }
        Err(ConfigError::InvalidModelDirectory(error)) => return Err(error),
    };
    let package = package_model_directory()?;
    let directories = configured
        .into_iter()
        .chain(std::iter::once(package))
        .collect::<Vec<_>>();

    for model_directory in directories {
        if !model_directory.exists() {
            println!(
                "Warning: Model directory '{}' not found.",
                model_directory.display()
            );
            continue;
        }

        println!("\nAvailable models in {}:", model_directory.display());
        println!("{}", "-".repeat(50));
        let mut models = match fs::read_dir(&model_directory) {
            Ok(entries) => entries
                .filter_map(Result::ok)
                .filter_map(|entry| {
                    let path = entry.path();
                    let extension = path.extension()?.to_str()?;
                    matches!(extension, "pth" | "model").then_some(path)
                })
                .collect::<Vec<_>>(),
            Err(error)
                if matches!(
                    error.kind(),
                    std::io::ErrorKind::NotFound
                        | std::io::ErrorKind::NotADirectory
                        | std::io::ErrorKind::PermissionDenied
                ) =>
            {
                Vec::new()
            }
            Err(error) => return Err(format!("{}: {error}", model_directory.display())),
        };
        models.sort();

        if models.is_empty() {
            println!("  (No models found)");
        } else {
            for model in models {
                let metadata = fs::metadata(&model)
                    .map_err(|error| format!("{}: {error}", model.display()))?;
                let name = model
                    .file_name()
                    .and_then(|name| name.to_str())
                    .unwrap_or_default();
                let size_mb = metadata.len() as f64 / (1024.0 * 1024.0);
                println!("  - {name:<40} ({size_mb:>6.1} MB)");
            }
        }
        println!("{}", "-".repeat(50));
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::configured_model_directory;
    use std::fs;
    use std::path::PathBuf;
    use std::time::{SystemTime, UNIX_EPOCH};

    fn unique_path() -> PathBuf {
        let nonce = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        std::env::temp_dir().join(format!(
            "macer-rust-model-list-{}-{nonce}",
            std::process::id()
        ))
    }

    #[test]
    fn parses_yaml_aliases_comments_and_nested_model_settings() {
        let root = unique_path();
        fs::create_dir_all(&root).unwrap();
        let config = root.join(".macer.yaml");
        fs::write(
            &config,
            "models:\n  mlff_directory: ignored\nmodel_cache: &cache './custom models'\nmlff_directory: *cache # cache\n",
        )
        .unwrap();
        assert_eq!(
            configured_model_directory(&config).unwrap(),
            Some(PathBuf::from("./custom models"))
        );
        let _ = fs::remove_dir_all(root);
    }

    #[test]
    fn parses_yaml_block_scalar_and_empty_null_values() {
        let root = unique_path();
        fs::create_dir_all(&root).unwrap();
        let config = root.join(".macer.yaml");
        fs::write(&config, "mlff_directory: |\n  ./custom models\n").unwrap();
        assert_eq!(
            configured_model_directory(&config).unwrap(),
            Some(PathBuf::from("./custom models\n"))
        );
        fs::write(&config, "mlff_directory: null\n").unwrap();
        assert_eq!(configured_model_directory(&config).unwrap(), None);
        let _ = fs::remove_dir_all(root);
    }
}
