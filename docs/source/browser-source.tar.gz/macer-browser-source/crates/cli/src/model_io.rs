//! Filesystem adapter for the path-free model API.
//!
//! This module belongs to the native CLI. Browser hosts can fetch or cache the
//! same manifest and safetensors bytes and pass them to `Evaluator::from_bytes`
//! without compiling file access into the model crate.

use candle_core::Device;
use macer_rust_model::evaluation::Evaluator;
use macer_rust_model::{validate_weights_bytes, ModelManifest};
use std::fs;
use std::path::Path;

fn read_package(manifest_path: &Path, weights_path: &Path) -> Result<(Vec<u8>, Vec<u8>), String> {
    let manifest_bytes =
        fs::read(manifest_path).map_err(|error| format!("manifest read failed: {error}"))?;
    let weights_bytes =
        fs::read(weights_path).map_err(|error| format!("weights read failed: {error}"))?;
    Ok((manifest_bytes, weights_bytes))
}

pub fn load_evaluator(
    manifest_path: &Path,
    weights_path: &Path,
    device: Device,
) -> Result<Evaluator, String> {
    let (manifest_bytes, weights_bytes) = read_package(manifest_path, weights_path)?;
    Evaluator::from_bytes(&manifest_bytes, &weights_bytes, device)
}

pub fn validate_model_files(
    manifest_path: &Path,
    weights_path: &Path,
) -> Result<ModelManifest, String> {
    let (manifest_bytes, weights_bytes) = read_package(manifest_path, weights_path)?;
    let manifest = ModelManifest::from_json_bytes(&manifest_bytes)?;
    validate_weights_bytes(&manifest, &weights_bytes)?;
    Ok(manifest)
}
