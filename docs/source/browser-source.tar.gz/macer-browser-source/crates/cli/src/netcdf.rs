//! Minimal, dependency-free NetCDF classic reader for Pymatgen's ETSF
//! structure variables. Only geometry and species variables are read; large
//! density arrays in the same file are skipped by seeking to their offsets.

use macer_rust_core::types::Structure;
use std::collections::HashMap;
use std::fs::File;
use std::io::{Read, Seek, SeekFrom};
use std::path::Path;

const NC_DIMENSION: u32 = 10;
const NC_VARIABLE: u32 = 11;
const NC_ATTRIBUTE: u32 = 12;
const MAX_HEADER_ITEMS: usize = 1 << 20;
const MAX_NAME_BYTES: usize = 1 << 20;
// Matches Pymatgen 2026.9.24's atomic-unit conversion table.
const BOHR_TO_ANGSTROM: f64 = 0.529_177_210_544;

#[derive(Debug)]
struct Variable {
    dimension_ids: Vec<usize>,
    value_type: u32,
    begin: u64,
}

#[derive(Debug)]
struct NetcdfClassic {
    file: File,
    dimensions: Vec<(String, usize)>,
    variables: HashMap<String, Variable>,
}

impl NetcdfClassic {
    fn open(path: &Path) -> Result<Self, String> {
        let mut file = File::open(path).map_err(|error| error.to_string())?;
        let mut magic = [0_u8; 4];
        file.read_exact(&mut magic)
            .map_err(|error| format!("invalid NetCDF header: {error}"))?;
        let offset_width = match magic {
            [b'C', b'D', b'F', 1] => 4,
            [b'C', b'D', b'F', 2] => 8,
            [b'C', b'D', b'F', 5] => return Err("NetCDF CDF-5 files are not supported yet".into()),
            [0x89, b'H', b'D', b'F'] => {
                return Err("NetCDF-4 HDF5 containers are not supported yet".into())
            }
            _ => {
                return Err("unsupported NetCDF encoding (expected classic CDF-1 or CDF-2)".into())
            }
        };
        let records = read_u32(&mut file)?;
        if records != 0 {
            return Err("NetCDF record variables are not supported in structure files".into());
        }

        let dimension_count = read_list_count(&mut file, NC_DIMENSION, "dimensions")?;
        let mut dimensions = Vec::with_capacity(dimension_count);
        for _ in 0..dimension_count {
            let name = read_name(&mut file)?;
            let length = read_u32(&mut file)? as usize;
            if length == 0 {
                return Err(format!("NetCDF dimension {name} is unlimited or empty"));
            }
            dimensions.push((name, length));
        }

        read_attribute_list(&mut file, "global attributes")?;

        let variable_count = read_list_count(&mut file, NC_VARIABLE, "variables")?;
        let mut variables = HashMap::with_capacity(variable_count);
        for _ in 0..variable_count {
            let name = read_name(&mut file)?;
            let rank = bounded_count(read_u32(&mut file)?, "variable rank")?;
            let mut dimension_ids = Vec::with_capacity(rank);
            for _ in 0..rank {
                dimension_ids.push(read_u32(&mut file)? as usize);
            }
            if dimension_ids.iter().any(|&id| id >= dimensions.len()) {
                return Err(format!(
                    "NetCDF variable {name} has an invalid dimension id"
                ));
            }
            read_attribute_list(&mut file, &format!("attributes for {name}"))?;
            let value_type = read_u32(&mut file)?;
            value_size(value_type)?;
            let _padded_byte_size = read_u32(&mut file)?;
            let begin = if offset_width == 4 {
                u64::from(read_u32(&mut file)?)
            } else {
                read_u64(&mut file)?
            };
            if variables
                .insert(
                    name.clone(),
                    Variable {
                        dimension_ids,
                        value_type,
                        begin,
                    },
                )
                .is_some()
            {
                return Err(format!("duplicate NetCDF variable {name}"));
            }
        }

        Ok(Self {
            file,
            dimensions,
            variables,
        })
    }

    fn read_numeric(&mut self, name: &str) -> Result<Vec<f64>, String> {
        let variable = self
            .variables
            .get(name)
            .ok_or_else(|| format!("NetCDF file is missing variable {name}"))?;
        let value_count = variable
            .dimension_ids
            .iter()
            .try_fold(1_usize, |count, &id| {
                count.checked_mul(self.dimensions[id].1)
            });
        let value_count = value_count
            .ok_or_else(|| format!("NetCDF variable {name} has an overflowing element count"))?;
        let value_type = variable.value_type;
        let begin = variable.begin;
        self.file
            .seek(SeekFrom::Start(begin))
            .map_err(|error| format!("cannot seek to NetCDF variable {name}: {error}"))?;
        let mut values = Vec::with_capacity(value_count);
        let mut bytes = [0_u8; 8];
        for _ in 0..value_count {
            let size = value_size(value_type)?;
            self.file
                .read_exact(&mut bytes[..size])
                .map_err(|error| format!("truncated NetCDF variable {name}: {error}"))?;
            let value = match value_type {
                1 => f64::from(i8::from_be_bytes([bytes[0]])),
                3 => f64::from(i16::from_be_bytes([bytes[0], bytes[1]])),
                4 => f64::from(i32::from_be_bytes(bytes[..4].try_into().unwrap())),
                5 => f64::from(f32::from_be_bytes(bytes[..4].try_into().unwrap())),
                6 => f64::from_be_bytes(bytes),
                2 => {
                    return Err(format!(
                        "NetCDF variable {name} is character data, not numeric"
                    ))
                }
                _ => unreachable!("value_size rejects unknown NetCDF types"),
            };
            values.push(value);
        }
        Ok(values)
    }

    fn variable_shape(&self, name: &str) -> Result<Vec<usize>, String> {
        let variable = self
            .variables
            .get(name)
            .ok_or_else(|| format!("NetCDF file is missing variable {name}"))?;
        Ok(variable
            .dimension_ids
            .iter()
            .map(|&id| self.dimensions[id].1)
            .collect())
    }
}

fn bounded_count(value: u32, field: &str) -> Result<usize, String> {
    let value = value as usize;
    if value > MAX_HEADER_ITEMS {
        return Err(format!("NetCDF {field} exceeds the supported header limit"));
    }
    Ok(value)
}

fn read_u32(reader: &mut impl Read) -> Result<u32, String> {
    let mut bytes = [0_u8; 4];
    reader
        .read_exact(&mut bytes)
        .map_err(|error| format!("invalid NetCDF header: {error}"))?;
    Ok(u32::from_be_bytes(bytes))
}

fn read_u64(reader: &mut impl Read) -> Result<u64, String> {
    let mut bytes = [0_u8; 8];
    reader
        .read_exact(&mut bytes)
        .map_err(|error| format!("invalid NetCDF header: {error}"))?;
    Ok(u64::from_be_bytes(bytes))
}

fn read_name(reader: &mut impl Read) -> Result<String, String> {
    let length = bounded_count(read_u32(reader)?, "name length")?;
    if length > MAX_NAME_BYTES {
        return Err("NetCDF name exceeds the supported length".into());
    }
    let mut bytes = vec![0_u8; length];
    reader
        .read_exact(&mut bytes)
        .map_err(|error| format!("invalid NetCDF name: {error}"))?;
    skip_padding(reader, length)?;
    String::from_utf8(bytes).map_err(|_| "NetCDF name is not UTF-8".into())
}

fn read_list_count(
    reader: &mut impl Read,
    expected_tag: u32,
    field: &str,
) -> Result<usize, String> {
    let tag = read_u32(reader)?;
    let count = bounded_count(read_u32(reader)?, field)?;
    if tag == 0 && count == 0 {
        return Ok(0);
    }
    if tag != expected_tag {
        return Err(format!("invalid NetCDF {field} list tag {tag}"));
    }
    Ok(count)
}

fn read_attribute_list(reader: &mut impl Read, field: &str) -> Result<(), String> {
    let count = read_list_count(reader, NC_ATTRIBUTE, field)?;
    for _ in 0..count {
        let _name = read_name(reader)?;
        let value_type = read_u32(reader)?;
        let size = value_size(value_type)?;
        let count = bounded_count(read_u32(reader)?, "attribute value count")?;
        let byte_count = size
            .checked_mul(count)
            .ok_or_else(|| format!("NetCDF {field} byte count overflows"))?;
        skip_bytes(reader, byte_count)?;
        skip_padding(reader, byte_count)?;
    }
    Ok(())
}

fn value_size(value_type: u32) -> Result<usize, String> {
    match value_type {
        1 | 2 => Ok(1),
        3 => Ok(2),
        4 | 5 => Ok(4),
        6 => Ok(8),
        _ => Err(format!("unsupported NetCDF data type {value_type}")),
    }
}

fn skip_padding(reader: &mut impl Read, byte_count: usize) -> Result<(), String> {
    skip_bytes(reader, (4 - byte_count % 4) % 4)
}

fn skip_bytes(reader: &mut impl Read, mut byte_count: usize) -> Result<(), String> {
    let mut buffer = [0_u8; 4096];
    while byte_count > 0 {
        let chunk = byte_count.min(buffer.len());
        reader
            .read_exact(&mut buffer[..chunk])
            .map_err(|error| format!("invalid NetCDF header or attribute: {error}"))?;
        byte_count -= chunk;
    }
    Ok(())
}

pub fn read_structure(path: &Path) -> Result<Structure, String> {
    let mut nc = NetcdfClassic::open(path)?;
    let cell_shape = nc.variable_shape("primitive_vectors")?;
    if cell_shape != [3, 3] {
        return Err(format!(
            "NetCDF primitive_vectors must have shape [3, 3], got {cell_shape:?}"
        ));
    }
    let position_shape = nc.variable_shape("reduced_atom_positions")?;
    if position_shape.len() != 2 || position_shape[1] != 3 {
        return Err(format!(
            "NetCDF reduced_atom_positions must have shape [natom, 3], got {position_shape:?}"
        ));
    }
    let atom_count = position_shape[0];
    let atomic_numbers = nc.read_numeric("atomic_numbers")?;
    let atom_species = nc.read_numeric("atom_species")?;
    let fractional = nc.read_numeric("reduced_atom_positions")?;
    let primitive_vectors = nc.read_numeric("primitive_vectors")?;
    if atom_species.len() != atom_count || fractional.len() != atom_count * 3 {
        return Err(
            "NetCDF atom_species or reduced_atom_positions has an inconsistent size".into(),
        );
    }

    let mut numbers = Vec::with_capacity(atom_count);
    let mut positions_a = Vec::with_capacity(atom_count);
    for atom in 0..atom_count {
        let type_index = integer_index(atom_species[atom], "atom_species")?;
        let atomic_number = *atomic_numbers
            .get(
                type_index
                    .checked_sub(1)
                    .ok_or("NetCDF atom_species indices are 1-based")?,
            )
            .ok_or("NetCDF atom_species references an unknown atomic number")?;
        if !atomic_number.is_finite()
            || atomic_number.fract() != 0.
            || !(1.0..=118.0).contains(&atomic_number)
        {
            return Err(format!("invalid NetCDF atomic number {atomic_number}"));
        }
        numbers.push(atomic_number as u8);
        let frac = [
            fractional[atom * 3],
            fractional[atom * 3 + 1],
            fractional[atom * 3 + 2],
        ];
        positions_a.push(std::array::from_fn(|cartesian| {
            (0..3)
                .map(|axis| frac[axis] * primitive_vectors[axis * 3 + cartesian] * BOHR_TO_ANGSTROM)
                .sum()
        }));
    }
    let cell_a = std::array::from_fn(|row| {
        std::array::from_fn(|column| primitive_vectors[row * 3 + column] * BOHR_TO_ANGSTROM)
    });
    let structure = Structure {
        atomic_numbers: numbers,
        positions_a,
        cell_a,
        pbc: [true; 3],
    };
    structure.validate()?;
    Ok(structure)
}

fn integer_index(value: f64, field: &str) -> Result<usize, String> {
    if !value.is_finite() || value.fract() != 0. || value < 1. || value > usize::MAX as f64 {
        return Err(format!("invalid NetCDF 1-based index in {field}: {value}"));
    }
    Ok(value as usize)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reads_etsf_netcdf_cdf1_and_cdf2_structure_geometry() {
        for version in [1, 2] {
            let path = Path::new(env!("CARGO_MANIFEST_DIR"))
                .join("../../reference/fixtures")
                .join(format!("nacl_etsf_cdf{version}.nc"));
            let structure = read_structure(&path).unwrap();
            assert_eq!(structure.atomic_numbers, [11, 17]);
            assert!((structure.cell_a[0][0] - 5.64).abs() < 1e-12);
            assert_eq!(structure.positions_a[0], [0.0; 3]);
            for coordinate in structure.positions_a[1] {
                assert!((coordinate - 2.82).abs() < 1e-12);
            }
        }
    }

    #[test]
    fn reports_unsupported_netcdf_container_variants() {
        let path = std::env::temp_dir().join(format!(
            "macer-rust-netcdf-unsupported-{}-{}.nc",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        for (signature, expected_error) in [
            (&b"CDF\x05"[..], "NetCDF CDF-5 files are not supported yet"),
            (
                &b"\x89HDF"[..],
                "NetCDF-4 HDF5 containers are not supported yet",
            ),
        ] {
            std::fs::write(&path, signature).unwrap();
            assert_eq!(NetcdfClassic::open(&path).unwrap_err(), expected_error);
        }
        let _ = std::fs::remove_file(path);
    }
}
