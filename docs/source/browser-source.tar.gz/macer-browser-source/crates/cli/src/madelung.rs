use macer_rust_core::ewald::{
    assign_oxidation_states, ewald_energy, OxidationAssignment, OxidationSource,
};
use std::collections::HashMap;
use std::fs;
use std::path::PathBuf;
use std::time::{SystemTime, UNIX_EPOCH};

pub const HELP: &str = r#"Compute the periodic point-charge Madelung energy from a structure file.

USAGE:
    macer-rust util calc_madelung [-p|--poscar <STRUCTURE>] [-o|--output-log <FILE>]
        [--oxidation-states <"Li:1,F:-1">]

ALIASES:
    madelung, cm

If oxidation states are omitted, Pymatgen-compatible common/ICSD states are
ranked by the captured ICSD occurrence counts. Energies are reported in eV.
"#;

fn python_float(value: f64) -> String {
    let formatted = format!("{value}");
    if value.fract() == 0.0 {
        format!("{formatted}.0")
    } else {
        formatted
    }
}

fn oxidation_map_text(assignment: &OxidationAssignment) -> String {
    let seen = assignment
        .symbols
        .iter()
        .filter_map(|symbol| {
            assignment
                .site_symbols
                .iter()
                .zip(&assignment.charges)
                .find(|(site_symbol, _)| *site_symbol == symbol)
                .map(|(_, charge)| (symbol.as_str(), *charge))
        })
        .collect::<Vec<_>>();
    format!(
        "{{{}}}",
        seen.iter()
            .map(|(symbol, charge)| format!("'{}': {}", symbol, python_float(*charge)))
            .collect::<Vec<_>>()
            .join(", ")
    )
}

fn site_species(charge: f64, symbol: &str) -> String {
    if charge.fract().abs() <= 1.0e-12 {
        let integer = charge as i64;
        if integer == 0 {
            format!("{symbol}0+")
        } else if integer == 1 {
            format!("{symbol}+")
        } else if integer == -1 {
            format!("{symbol}-")
        } else if integer > 0 {
            format!("{symbol}{integer}+")
        } else {
            format!("{symbol}{}-", integer.abs())
        }
    } else {
        format!(
            "{symbol}{:.2}{}",
            charge.abs(),
            if charge > 0.0 { "+" } else { "-" }
        )
    }
}

fn format_assignment(assignment: &OxidationAssignment) -> String {
    match &assignment.source {
        OxidationSource::Manual(source) => format!("manual ({source})"),
        OxidationSource::PymatgenGuess => {
            format!(
                "guessed by composition ({})",
                oxidation_map_text(assignment)
            )
        }
        OxidationSource::PymatgenZeroFallback => "guessed by pymatgen".to_owned(),
    }
}

fn utc_timestamp() -> String {
    let duration = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default();
    let days = (duration.as_secs() / 86_400) as i64;
    let seconds = duration.as_secs() % 86_400;
    let z = days + 719_468;
    let era = if z >= 0 { z } else { z - 146_096 } / 146_097;
    let doe = z - era * 146_097;
    let yoe = (doe - doe / 1_460 + doe / 36_524 - doe / 146_096) / 365;
    let mut year = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let day = doy - (153 * mp + 2) / 5 + 1;
    let month = mp + if mp < 10 { 3 } else { -9 };
    year += i64::from(month <= 2);
    format!(
        "{year:04}-{month:02}-{day:02}T{:02}:{:02}:{:02}.{:06}+00:00",
        seconds / 3_600,
        (seconds % 3_600) / 60,
        seconds % 60,
        duration.subsec_micros()
    )
}

pub fn run(arguments: impl Iterator<Item = String>) -> Result<(), String> {
    let mut values = HashMap::new();
    let mut arguments = arguments.peekable();
    while let Some(argument) = arguments.next() {
        if argument == "-h" || argument == "--help" {
            print!("{HELP}");
            return Ok(());
        }
        let (option, inline) = argument
            .split_once('=')
            .map(|(option, value)| (option, Some(value.to_owned())))
            .unwrap_or((argument.as_str(), None));
        let value = match inline {
            Some(value) => value,
            None => arguments
                .next()
                .ok_or_else(|| format!("missing value for {option}"))?,
        };
        let key = match option {
            "-p" | "--poscar" => "poscar",
            "-o" | "--output-log" => "output-log",
            "--oxidation-states" => "oxidation-states",
            _ => return Err(format!("unexpected argument: {argument}")),
        };
        // argparse accepts repeated options and keeps the last value.
        values.insert(key.to_owned(), value);
    }
    let poscar_path = PathBuf::from(values.get("poscar").map(String::as_str).unwrap_or("POSCAR"));
    let structure = crate::structure_io::read_structure(&poscar_path)?;
    let manual = values.get("oxidation-states").map(String::as_str);
    let assignment = assign_oxidation_states(&structure.atomic_numbers, manual)?;
    if assignment
        .charges
        .iter()
        .all(|charge| charge.abs() <= 1.0e-12)
    {
        return Err("Failed to assign non-zero oxidation states automatically. Please pass --oxidation-states (e.g., \"Mn:2,Cr:3,O:-2\").".into());
    }
    let energy = ewald_energy(&structure, &assignment.charges)?;
    let energy_per_atom = energy.total_ev / structure.atomic_numbers.len() as f64;
    let assignment_text = format_assignment(&assignment);

    let mut species_summary = Vec::<(String, usize)>::new();
    for (symbol, &charge) in assignment.site_symbols.iter().zip(&assignment.charges) {
        let label = site_species(charge, symbol);
        if let Some((_, count)) = species_summary
            .iter_mut()
            .find(|(existing, _)| *existing == label)
        {
            *count += 1;
        } else {
            species_summary.push((label, 1));
        }
    }
    let oxidation_summary = species_summary
        .iter()
        .map(|(symbol, count)| format!("{symbol} x{count}"))
        .collect::<Vec<_>>()
        .join(", ");
    let output_path = values
        .get("output-log")
        .map(PathBuf::from)
        .unwrap_or_else(|| {
            PathBuf::from(format!(
                "madelung-{}.log",
                poscar_path
                    .file_name()
                    .and_then(|name| name.to_str())
                    .unwrap_or("POSCAR")
            ))
        });
    let input_path = poscar_path
        .canonicalize()
        .unwrap_or_else(|_| poscar_path.clone());
    let lines = [
        format!("Timestamp: {}", utc_timestamp()),
        format!("Input POSCAR: {}", input_path.display()),
        format!("Oxidation assignment: {assignment_text}"),
        format!("Oxidation states summary: {oxidation_summary}"),
        format!("Number of atoms: {}", structure.atomic_numbers.len()),
        format!("Madelung energy (total): {:.12} eV", energy.total_ev),
        format!(
            "Madelung energy (per atom): {:.12} eV/atom",
            energy_per_atom
        ),
    ];
    fs::write(&output_path, lines.join("\n") + "\n").map_err(|error| error.to_string())?;
    for line in &lines[1..] {
        println!("{line}");
    }
    println!("Log saved: {}", output_path.display());
    Ok(())
}

pub fn is_madelung_command(value: &str) -> bool {
    matches!(value, "calc_madelung" | "madelung" | "cm")
}
