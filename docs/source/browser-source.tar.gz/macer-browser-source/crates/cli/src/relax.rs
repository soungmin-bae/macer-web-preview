use crate::cell_filter::FrechetCellFilter;
use crate::elements::SYMBOLS;
use crate::model_io::load_evaluator;
use crate::plots::{write_relax_history_plot, write_relax_single_point_plot};
use crate::poscar::{has_selective_dynamics, read_poscar};
use crate::relax_outputs::{
    write_contcar, write_outcar, write_vasprun_xml, write_vasprun_xml_frames,
};
use crate::ulm::UlmTrajectoryWriter;
use candle_core::Device;
use macer_rust_core::emt::EffectiveMediumTheory;
use macer_rust_core::lennard_jones::LennardJones;
use macer_rust_core::types::{Evaluation, Potential, Structure};
use macer_rust_model::evaluation::Evaluator;
use macer_rust_relax::FireOptimizer;
use std::collections::HashMap;
use std::fs;
use std::path::{Path, PathBuf};
use std::time::Instant;

enum Engine {
    MatterSim(Evaluator),
    LennardJones(LennardJones),
    EffectiveMediumTheory(EffectiveMediumTheory),
}

impl Potential for Engine {
    fn evaluate(&mut self, structure: &Structure) -> Result<Evaluation, String> {
        match self {
            Self::MatterSim(evaluator) => evaluator.evaluate(structure),
            Self::LennardJones(evaluator) => evaluator.evaluate(structure),
            Self::EffectiveMediumTheory(evaluator) => evaluator.evaluate(structure),
        }
    }
}

impl Engine {
    fn ase_calculator_name(&self) -> &'static str {
        match self {
            Self::MatterSim(_) => "macermattersimcalculator",
            Self::LennardJones(_) => "lennardjones",
            Self::EffectiveMediumTheory(_) => "emt",
        }
    }
}

pub const HELP: &str = r#"Run native single-point, fixed-cell, and variable-cell relaxation workflows.

USAGE:
    macer-rust relax --structure <POSCAR> [OPTIONS]

INPUT:
    --structure, --poscar <PATH>   VASP 5 structure file
    --force-field, --ff <NAME>     mattersim (default), lj, or emt
    --model <PATH>                 MatterSim weights; adjacent .json manifest required
    --device <cpu|cuda>            Calculation device (default: cpu)
    --isif <N>                     VASP mode; Rust supports 0-8 (FIRE; ISIF=5/6/7 fix atoms, 7/8 are hydrostatic)
    --symmetry-off                 Disable Macer's default symmetry constraint (required in current optimizer slice)
    --fmax <EV/A>                  Force convergence threshold (default: 0.01)
    --smax <GPA>                   Stress convergence threshold for variable-cell modes (default: 0.001)
    --max-step <N>                 Maximum callback count, including the initial structure
    --pressure <GPA>               Target pressure (only valid for volume-changing modes)

OUTPUT:
    --output-dir <PATH>            Output directory (default: current directory)
    --contcar <NAME>                Override final POSCAR name
    --outcar <NAME>                 Override OUTCAR name
    --vasprun <NAME>                Override vasprun XML name
    --no-pdf                        Disable the relaxation PDF
    --quiet                         Suppress progress text

Numerical parity evidence covers CPU LJ ISIF=0, fixed-cell ISIF=1/2, and
variable-cell ISIF=3-8 hydrostatic, triclinic-shear, pressure, fixed-axis,
constant-volume, and fixed-position fixtures. All optimizer parity fixtures disable symmetry.
"#;

fn required(args: &HashMap<String, String>, key: &str) -> Result<String, String> {
    args.get(key)
        .cloned()
        .ok_or_else(|| format!("missing --{key}"))
}

fn parse<T: std::str::FromStr>(
    args: &HashMap<String, String>,
    key: &str,
) -> Result<Option<T>, String> {
    args.get(key)
        .map(|value| value.parse().map_err(|_| format!("invalid --{key}")))
        .transpose()
}

fn pick_path(value: Option<&String>, output: &Path, fallback: String) -> PathBuf {
    let name = value.map(String::as_str).unwrap_or(&fallback);
    let path = Path::new(name);
    if path.is_absolute() {
        path.to_path_buf()
    } else {
        output.join(path)
    }
}

fn resolve_output_dir(path: Option<&String>) -> Result<PathBuf, String> {
    let Some(path) = path else {
        return Ok(PathBuf::from("."));
    };
    let base = PathBuf::from(path);
    let mut candidate = base.clone();
    let mut suffix = 1usize;
    while candidate.exists() {
        candidate = PathBuf::from(format!("{}-NEW{suffix:02}", base.display()));
        suffix += 1;
    }
    fs::create_dir_all(&candidate).map_err(|error| error.to_string())?;
    Ok(candidate)
}

fn validate_emt_elements(structure: &Structure) -> Result<(), String> {
    // Keep the supported list identical to ASE's EMT implementation.
    const SUPPORTED: &[&str] = &["Al", "Cu", "Ag", "Au", "Ni", "Pd", "Pt", "H", "C", "N", "O"];
    for &number in &structure.atomic_numbers {
        let name = SYMBOLS.get(number as usize).copied().unwrap_or("?");
        if !SUPPORTED.contains(&name) {
            return Err(format!("EMT does not support element {name}"));
        }
    }
    Ok(())
}

fn maximum_force(forces: &[[f64; 3]]) -> f64 {
    forces
        .iter()
        .map(|force| force.iter().map(|value| value * value).sum::<f64>().sqrt())
        .fold(0.0, f64::max)
}

fn evaluation_with_position_constraint(
    evaluation: &Evaluation,
    fixed_positions: bool,
) -> Evaluation {
    let mut output = evaluation.clone();
    if fixed_positions {
        output.forces_ev_per_a.fill([0.0; 3]);
    }
    output
}

fn optimize_fixed_cell_fire(
    structure: Structure,
    evaluation: Evaluation,
    engine: &mut Engine,
    fmax_threshold: f64,
    max_steps: Option<usize>,
    trajectory_interval: usize,
    save_interval_s: f64,
    trajectory_path: &Path,
    output_dir: &Path,
    prefix: &str,
    calculator_name: &'static str,
    quiet: bool,
) -> Result<(Vec<(Structure, Evaluation)>, String), String> {
    let mut trajectory = UlmTrajectoryWriter::create_relax(
        trajectory_path,
        &structure,
        &evaluation,
        calculator_name,
    )?;
    let mut fire = FireOptimizer::new(structure.atomic_numbers.len());
    let mut history = vec![(structure, evaluation)];
    let mut last_save = Instant::now();
    let mut log = String::new();
    let mut termination = "maximum optimizer steps reached";
    let mut optimizer_steps = 0usize;

    loop {
        let (current_structure, current_evaluation) = history.last().expect("initial frame exists");
        let fmax = maximum_force(&current_evaluation.forces_ev_per_a);
        let row = format!(
            " Step {:4} | E = {:.6} eV | Fmax={:.5} | σres_max=0.00000 | P_current={:.4} GPa\n",
            history.len(),
            current_evaluation.energy_ev,
            fmax,
            0.0
        );
        log.push_str(&row);
        if !quiet {
            print!("{row}");
        }

        // Macer attaches its callback before FIRE.run, so the initial structure
        // is counted toward max-step and convergence is checked at step zero.
        if fmax < fmax_threshold {
            termination = "converged force threshold";
            break;
        }
        if max_steps.is_some_and(|limit| history.len() >= limit) {
            termination = "maximum callback count reached";
            break;
        }
        if optimizer_steps >= 100_000 {
            break;
        }

        let mut next_structure = current_structure.clone();
        fire.step(&mut next_structure, &current_evaluation.forces_ev_per_a)?;
        let next_evaluation = engine.evaluate(&next_structure)?;
        next_evaluation.validate(next_structure.atomic_numbers.len())?;
        history.push((next_structure, next_evaluation));
        optimizer_steps += 1;

        if optimizer_steps % trajectory_interval == 0 {
            let (frame_structure, frame_evaluation) = history.last().unwrap();
            trajectory.write_relax_frame(frame_structure, frame_evaluation, calculator_name)?;
        }
        if last_save.elapsed().as_secs_f64() >= save_interval_s {
            let (frame_structure, _) = history.last().unwrap();
            write_contcar(
                &output_dir.join(format!("CONTCAR-{prefix}-step={}", history.len())),
                frame_structure,
            )?;
            last_save = Instant::now();
        }
    }
    trajectory.close()?;
    log.push_str(&format!(
        " termination={termination}\noptimizer_steps={optimizer_steps}\n"
    ));
    Ok((history, log))
}

#[allow(clippy::too_many_arguments)]
fn optimize_variable_cell_fire(
    structure: Structure,
    evaluation: Evaluation,
    engine: &mut Engine,
    fmax_threshold: f64,
    smax_threshold: f64,
    max_steps: Option<usize>,
    trajectory_interval: usize,
    save_interval_s: f64,
    trajectory_path: &Path,
    output_dir: &Path,
    prefix: &str,
    calculator_name: &'static str,
    pressure_ev_per_a3: f64,
    fix_axis: &[String],
    constant_volume: bool,
    hydrostatic_strain: bool,
    fixed_positions: bool,
    quiet: bool,
) -> Result<
    (
        Vec<(Structure, Evaluation)>,
        String,
        Structure,
        Evaluation,
        bool,
    ),
    String,
> {
    let filter = FrechetCellFilter::new(
        &structure,
        pressure_ev_per_a3,
        fix_axis,
        constant_volume,
        hydrostatic_strain,
        fixed_positions,
    );
    let initial_output_evaluation =
        evaluation_with_position_constraint(&evaluation, fixed_positions);
    let mut coordinates = filter.initial_coordinates();
    let mut trajectory = UlmTrajectoryWriter::create_relax(
        trajectory_path,
        &structure,
        &initial_output_evaluation,
        calculator_name,
    )?;
    let mut fire = FireOptimizer::new(coordinates.len());
    let mut history = vec![(structure.clone(), evaluation.clone())];
    let mut stable_structure = structure.clone();
    let mut stable_evaluation = evaluation.clone();
    let initial_energy = evaluation.energy_ev;
    let mut last_save = Instant::now();
    let mut log = String::new();
    let mut termination = "maximum optimizer steps reached";
    let mut optimizer_steps = 0usize;
    let mut diverged = false;

    loop {
        let (current_structure, current_evaluation) = history.last().expect("initial frame exists");
        let fmax = if fixed_positions {
            0.0
        } else {
            maximum_force(&current_evaluation.forces_ev_per_a)
        };
        let (stress_residual_ev_per_a3, current_pressure_gpa) =
            filter.physical_stress_residual_max(current_evaluation);
        let stress_residual_gpa = stress_residual_ev_per_a3 * 160.217_662_08;
        let row = format!(
            " Step {:4} | E = {:.6} eV | Fmax={:.5} eV/Å | σres_max={:.5} GPa | P_current={:.4} GPa\n",
            history.len(),
            current_evaluation.energy_ev,
            fmax,
            stress_residual_gpa,
            current_pressure_gpa,
        );
        log.push_str(&row);
        if !quiet {
            print!("{row}");
        }

        if last_save.elapsed().as_secs_f64() >= save_interval_s {
            write_contcar(
                &output_dir.join(format!("CONTCAR-{prefix}-step={}", history.len())),
                current_structure,
            )?;
            last_save = Instant::now();
        }

        let energy_rise_per_atom = (current_evaluation.energy_ev - initial_energy)
            / current_structure.atomic_numbers.len() as f64;
        // A transient 5% cell-volume excursion is not sufficient evidence of
        // divergence: stable full-cell FIRE paths can briefly overshoot this
        // while energy, forces, and stress continue to improve. Keep the
        // energy-rise guard; convergence and the step limit remain authoritative.
        if energy_rise_per_atom > 0.05 {
            diverged = true;
            termination = "divergence guard restored the last stable structure";
            if !quiet {
                println!(
                    "  [DIVERGED] cell relaxation energy rose by {energy_rise_per_atom:+.4} eV/atom at step {}; reverting to the last stable step.",
                    history.len()
                );
            }
            break;
        }
        stable_structure = current_structure.clone();
        stable_evaluation = current_evaluation.clone();

        // Macer checks its physical force/stress callback first. ASE's FIRE
        // then independently stops when the filter's combined gradient falls
        // below fmax, even if the callback stress criterion is still higher.
        if fmax < fmax_threshold && stress_residual_gpa < smax_threshold {
            termination = "converged force and stress thresholds";
            break;
        }
        if max_steps.is_some_and(|limit| history.len() >= limit) {
            termination = "maximum callback count reached";
            break;
        }
        if optimizer_steps >= 100_000 {
            break;
        }

        let forces = filter.forces(current_structure, current_evaluation, &coordinates)?;
        fire.step_coordinates(&mut coordinates, &forces)?;
        let (next_structure, next_coordinates) = filter.apply_coordinates(&coordinates)?;
        coordinates = next_coordinates;
        let next_evaluation = engine.evaluate(&next_structure)?;
        next_evaluation.validate(next_structure.atomic_numbers.len())?;
        history.push((next_structure, next_evaluation));
        optimizer_steps += 1;

        if optimizer_steps % trajectory_interval == 0 {
            let (frame_structure, frame_evaluation) = history.last().unwrap();
            let output_evaluation =
                evaluation_with_position_constraint(frame_evaluation, fixed_positions);
            trajectory.write_relax_frame(frame_structure, &output_evaluation, calculator_name)?;
        }
    }
    trajectory.close()?;
    if diverged {
        fs::write(
            output_dir.join("FAILED_DIVERGED"),
            "cell relaxation diverged; geometry reverted to the last stable step\n",
        )
        .map_err(|error| error.to_string())?;
    }
    log.push_str(&format!(
        " termination={termination}\noptimizer_steps={optimizer_steps}\n"
    ));
    Ok((history, log, stable_structure, stable_evaluation, diverged))
}

pub fn run(arguments: impl Iterator<Item = String>) -> Result<(), String> {
    let mut args = HashMap::new();
    let mut iter = arguments;
    while let Some(key) = iter.next() {
        let Some(key) = key.strip_prefix("--") else {
            return Err(format!("unexpected argument: {key}"));
        };
        if ["quiet", "no-pdf", "symmetry-off"].contains(&key) {
            if args.insert(key.to_string(), "true".into()).is_some() {
                return Err(format!("duplicate --{key}"));
            }
            continue;
        }
        let value = iter
            .next()
            .ok_or_else(|| format!("missing value for --{key}"))?;
        let canonical = match key {
            "poscar" => "structure",
            "ff" => "force-field",
            "press" => "pressure",
            other => other,
        };
        if args.insert(canonical.to_string(), value).is_some() {
            return Err(format!("duplicate --{canonical}"));
        }
    }
    for key in args.keys() {
        if ![
            "structure",
            "force-field",
            "model",
            "device",
            "isif",
            "pressure",
            "output-dir",
            "contcar",
            "outcar",
            "vasprun",
            "fmax",
            "smax",
            "max-step",
            "optimizer",
            "fix-axis",
            "symprec",
            "save-interval",
            "traj-interval",
            "modal",
            "delta-model",
            "symmetry-off",
            "quiet",
            "no-pdf",
        ]
        .contains(&key.as_str())
        {
            return Err(format!("unknown option --{key}"));
        }
    }
    let input = PathBuf::from(required(&args, "structure")?);
    let structure = read_poscar(&input)?;
    let force_field = args
        .get("force-field")
        .map(String::as_str)
        .unwrap_or("mattersim");
    let device_name = args.get("device").map(String::as_str).unwrap_or("cpu");
    let isif = parse::<u8>(&args, "isif")?.unwrap_or(3);
    let pressure_gpa = parse::<f64>(&args, "pressure")?.unwrap_or(0.0);
    if !pressure_gpa.is_finite() {
        return Err("--pressure must be finite".into());
    }
    if pressure_gpa.abs() > 1.0e-15 && ![3, 6, 7, 8].contains(&isif) {
        return Err(format!(
            "--pressure requires a volume-changing ISIF (3, 6, 7, 8); received ISIF={isif}"
        ));
    }
    if isif > 8 {
        return Err(format!(
            "ISIF={isif} is not implemented; choose a VASP-like mode from 0 through 8"
        ));
    }
    let fmax_threshold = parse::<f64>(&args, "fmax")?.unwrap_or(0.01);
    let smax_threshold = parse::<f64>(&args, "smax")?.unwrap_or(0.001);
    let max_steps = parse::<usize>(&args, "max-step")?;
    let symprec = parse::<f64>(&args, "symprec")?.unwrap_or(1e-5);
    let save_interval = parse::<f64>(&args, "save-interval")?.unwrap_or(30.0);
    let trajectory_interval = parse::<usize>(&args, "traj-interval")?.unwrap_or(1);
    if !fmax_threshold.is_finite()
        || !smax_threshold.is_finite()
        || !symprec.is_finite()
        || !save_interval.is_finite()
    {
        return Err("relaxation thresholds and intervals must be finite".into());
    }
    if trajectory_interval == 0 {
        return Err("--traj-interval must be at least 1".into());
    }
    if isif != 0 {
        if args.get("optimizer").map(String::as_str).unwrap_or("FIRE") != "FIRE" {
            return Err("the current Rust relaxation slice supports only --optimizer FIRE".into());
        }
        if !args.contains_key("symmetry-off") {
            return Err("ISIF=1-8 currently requires --symmetry-off; Macer's default FixSymmetry constraint is not ported yet".into());
        }
        if has_selective_dynamics(&input)? {
            return Err("POSCAR selective-dynamics constraints are not supported by the current Rust FIRE slice".into());
        }
    }
    if isif >= 3 && structure.pbc != [true; 3] {
        return Err(
            "ISIF=3-8 variable-cell relaxation currently requires periodicity on all three axes"
                .into(),
        );
    }
    if args.contains_key("delta-model") {
        return Err("--delta-model is not implemented in the current Rust relax slice".into());
    }
    if args.contains_key("modal") {
        return Err("--modal is not implemented in the current Rust relax slice".into());
    }
    let started = Instant::now();
    let mut engine = match force_field {
        "mattersim" => {
            let model_path = PathBuf::from(required(&args, "model")?);
            let manifest_path = model_path.with_extension("json");
            let device = match device_name {
                "cpu" => Device::Cpu,
                #[cfg(feature = "cuda")]
                "cuda" => Device::new_cuda(0).map_err(|error| error.to_string())?,
                _ => return Err(format!("unsupported device: {device_name}")),
            };
            Engine::MatterSim(load_evaluator(&manifest_path, &model_path, device)?)
        }
        "lj" => {
            if device_name != "cpu" {
                return Err("Lennard-Jones currently supports only --device cpu".into());
            }
            if args.contains_key("model") {
                return Err("--model is not used with --force-field lj".into());
            }
            Engine::LennardJones(LennardJones::default())
        }
        "emt" => {
            if device_name != "cpu" {
                return Err("native EMT currently supports only --device cpu".into());
            }
            if args.contains_key("model") {
                return Err("--model is not used with --force-field emt".into());
            }
            validate_emt_elements(&structure)?;
            Engine::EffectiveMediumTheory(EffectiveMediumTheory)
        }
        _ => {
            return Err(format!(
                "unsupported Rust force field `{force_field}`; choose mattersim, lj, or emt"
            ))
        }
    };
    let evaluation = engine.evaluate(&structure)?;
    evaluation.validate(structure.atomic_numbers.len())?;
    let fmax = maximum_force(&evaluation.forces_ev_per_a);

    let output = resolve_output_dir(args.get("output-dir"))?;
    let prefix = input
        .file_name()
        .and_then(|name| name.to_str())
        .unwrap_or("POSCAR");
    let contcar = pick_path(
        args.get("contcar"),
        &output,
        format!("CONTCAR-{prefix}-final"),
    );
    let outcar = pick_path(args.get("outcar"), &output, format!("OUTCAR-{prefix}"));
    let vasprun = pick_path(
        args.get("vasprun"),
        &output,
        format!("vasprun-{prefix}.xml"),
    );
    let mut variable_cell_diverged = false;
    let (mut workflow_log, final_structure, final_evaluation) = if isif == 0 {
        write_contcar(&contcar, &structure)?;
        write_outcar(&outcar, &structure, &evaluation, isif, pressure_gpa)?;
        write_vasprun_xml(&vasprun, &structure, &evaluation)?;
        if !args.contains_key("no-pdf") {
            write_relax_single_point_plot(
                &output.join(format!("relax-{prefix}_log.pdf")),
                evaluation.energy_ev,
                fmax,
            )?;
        }
        (
            "ISIF=0 single-point calculation\n".to_string(),
            structure.clone(),
            evaluation.clone(),
        )
    } else if isif >= 3 {
        let trajectory_path = output.join(format!("relax-{prefix}.traj"));
        let calculator_name = engine.ase_calculator_name();
        let pressure_ev_per_a3 = pressure_gpa / 160.217_662_08;
        let requested_fix_axis = args
            .get("fix-axis")
            .map(|value| {
                value
                    .split(',')
                    .map(str::trim)
                    .filter(|axis| !axis.is_empty())
                    .map(str::to_string)
                    .collect::<Vec<_>>()
            })
            .unwrap_or_default();
        let fix_axis = if matches!(isif, 7 | 8) {
            if !requested_fix_axis.is_empty() {
                println!("WARNING: --fix-axis is not compatible with ISIF={isif} which only changes volume hydrostatically. Ignoring --fix-axis.");
            }
            Vec::new()
        } else {
            requested_fix_axis
        };
        let constant_volume = matches!(isif, 4 | 5);
        let hydrostatic_strain = matches!(isif, 7 | 8);
        let fixed_positions = matches!(isif, 5 | 6 | 7);
        let (history, log, final_structure, final_evaluation, diverged) =
            optimize_variable_cell_fire(
                structure.clone(),
                evaluation.clone(),
                &mut engine,
                fmax_threshold,
                smax_threshold,
                max_steps,
                trajectory_interval,
                save_interval,
                &trajectory_path,
                &output,
                prefix,
                calculator_name,
                pressure_ev_per_a3,
                &fix_axis,
                constant_volume,
                hydrostatic_strain,
                fixed_positions,
                args.contains_key("quiet"),
            )?;
        variable_cell_diverged = diverged;
        write_contcar(&contcar, &final_structure)?;
        let output_final_evaluation =
            evaluation_with_position_constraint(&final_evaluation, fixed_positions);
        write_outcar(
            &outcar,
            &final_structure,
            &output_final_evaluation,
            isif,
            pressure_gpa,
        )?;
        let output_evaluations = history
            .iter()
            .map(|(_, frame_evaluation)| {
                evaluation_with_position_constraint(frame_evaluation, fixed_positions)
            })
            .collect::<Vec<_>>();
        let frame_refs = history
            .iter()
            .zip(&output_evaluations)
            .map(|((frame_structure, _), frame_evaluation)| (frame_structure, frame_evaluation))
            .collect::<Vec<_>>();
        write_vasprun_xml_frames(&vasprun, &structure, &frame_refs)?;
        if !args.contains_key("no-pdf") {
            let energies = history
                .iter()
                .map(|(_, item)| item.energy_ev)
                .collect::<Vec<_>>();
            let forces = history
                .iter()
                .map(|(_, item)| {
                    if fixed_positions {
                        0.0
                    } else {
                        maximum_force(&item.forces_ev_per_a)
                    }
                })
                .collect::<Vec<_>>();
            write_relax_history_plot(
                &output.join(format!("relax-{prefix}_log.pdf")),
                &energies,
                &forces,
            )?;
        }
        (log, final_structure, output_final_evaluation)
    } else {
        let trajectory_path = output.join(format!("relax-{prefix}.traj"));
        let calculator_name = engine.ase_calculator_name();
        let (history, log) = optimize_fixed_cell_fire(
            structure.clone(),
            evaluation.clone(),
            &mut engine,
            fmax_threshold,
            max_steps,
            trajectory_interval,
            save_interval,
            &trajectory_path,
            &output,
            prefix,
            calculator_name,
            args.contains_key("quiet"),
        )?;
        let (final_structure, final_evaluation) = history.last().expect("initial frame exists");
        write_contcar(&contcar, final_structure)?;
        write_outcar(
            &outcar,
            final_structure,
            final_evaluation,
            isif,
            pressure_gpa,
        )?;
        let frame_refs = history
            .iter()
            .map(|(frame_structure, frame_evaluation)| (frame_structure, frame_evaluation))
            .collect::<Vec<_>>();
        write_vasprun_xml_frames(&vasprun, &structure, &frame_refs)?;
        if !args.contains_key("no-pdf") {
            let energies = history
                .iter()
                .map(|(_, item)| item.energy_ev)
                .collect::<Vec<_>>();
            let forces = history
                .iter()
                .map(|(_, item)| maximum_force(&item.forces_ev_per_a))
                .collect::<Vec<_>>();
            write_relax_history_plot(
                &output.join(format!("relax-{prefix}_log.pdf")),
                &energies,
                &forces,
            )?;
        }
        let (final_structure, final_evaluation) = history.last().expect("initial frame exists");
        let final_structure = final_structure.clone();
        let final_evaluation = final_evaluation.clone();
        (log, final_structure, final_evaluation)
    };
    if isif >= 3 || pressure_gpa.abs() > 1.0e-15 {
        let stress = final_evaluation.stress_ev_per_a3;
        let final_pressure_gpa =
            -((stress[0][0] + stress[1][1] + stress[2][2]) / 3.0) * 160.217_662_08;
        let delta_pressure_gpa = final_pressure_gpa - pressure_gpa;
        let pressure_summary = format!(
            " Final pressure summary | Ptarget={pressure_gpa:.6} GPa | Pfinal={final_pressure_gpa:.6} GPa | ΔP={delta_pressure_gpa:+.6} GPa\n"
        );
        workflow_log.push_str(&pressure_summary);
        if !args.contains_key("quiet") {
            print!("{pressure_summary}");
        }
    }
    let elapsed_s = started.elapsed().as_secs_f64();
    let log = format!(
        "{workflow_log}force_field={force_field}\ndevice={device_name}\natoms={}\nisif={isif}\nenergy_ev={:.16}\nfmax_ev_per_a={:.16}\nelapsed_s={elapsed_s:.6}\n",
        final_structure.atomic_numbers.len(),
        final_evaluation.energy_ev,
        maximum_force(&final_evaluation.forces_ev_per_a),
    );
    fs::write(output.join(format!("relax-{prefix}_log.txt")), &log)
        .map_err(|error| error.to_string())?;
    if !args.contains_key("quiet") {
        println!(
            " Finished {prefix} -> Results saved in {}",
            output.display()
        );
        if isif == 0 {
            print!("{log}");
        }
    }
    if variable_cell_diverged {
        return Err(format!(
            "variable-cell relaxation diverged; last stable structure and diagnostics were saved in {}",
            output.display()
        ));
    }
    let _ = (smax_threshold, symprec);
    Ok(())
}
