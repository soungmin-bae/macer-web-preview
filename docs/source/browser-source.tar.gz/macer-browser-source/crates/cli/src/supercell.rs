//! Python-free port of Macer's manual PyDefect supercell-info utility.

use moyo::base::{Cell, Lattice, Position};
use moyo::MoyoDataset;
use serde_json::{json, Value};
use std::collections::BTreeMap;
use std::fs;
use std::path::{Path, PathBuf};

const SYMPREC_ANGSTROM: f64 = 1.0e-2;
pub(crate) const HELP: &str = r#"Create a PyDefect-compatible manual supercell.

USAGE:
    macer-rust util supercell --poscar <POSCAR> --dim <a b c | 9 integers> [OPTIONS]
    macer-rust util pydefect supercell --poscar <POSCAR> --dim <a b c | 9 integers> [OPTIONS]

OPTIONS:
    -p, --poscar <FILE>       Input POSCAR
        --dim <INT...>         Three diagonal values or nine row-major matrix values
        --no-symmetry           Keep one defect site per input atom
    -o, --output-dir <DIR>    Output directory (default: current directory)
    -h, --help                Show this help

Writes POSCAR-unitcell, SPOSCAR and supercell_info.json.
"#;

#[derive(Debug, Clone)]
struct Options {
    input: Option<PathBuf>,
    dimensions: Vec<i64>,
    analyze_symmetry: bool,
    output_dir: PathBuf,
}

#[derive(Debug)]
struct BuiltSupercell {
    matrix: [[i64; 3]; 3],
    cell: [[f64; 3]; 3],
    fractional: Vec<[f64; 3]>,
    numbers: Vec<u8>,
    space_group: String,
    sites: Value,
}

pub(crate) fn run(arguments: impl Iterator<Item = String>) -> Result<(), String> {
    let options = parse(arguments)?;
    let Some(input) = options.input else {
        print!("{HELP}");
        return Ok(());
    };
    if options.dimensions.is_empty() {
        print!("{HELP}");
        return Ok(());
    }
    let input = expand_user_path(input);
    let input = match input.canonicalize() {
        Ok(path) => path,
        Err(_) => {
            println!("Error: {} not found.", input.display());
            return Ok(());
        }
    };
    let matrix = parse_matrix(&options.dimensions)?;
    let output_dir = expand_user_path(options.output_dir);
    fs::create_dir_all(&output_dir).map_err(|error| error.to_string())?;
    let output_dir = output_dir
        .canonicalize()
        .map_err(|error| error.to_string())?;
    // Macer creates the destination and preserves the input before loading or
    // validating the structure. It also ignores copy failures (for example,
    // when source and destination are the same file).
    let _ = fs::copy(&input, output_dir.join("POSCAR-unitcell"));
    let structure = crate::poscar::read_poscar(&input)?;
    let built = build_supercell(&structure, matrix, options.analyze_symmetry)?;
    // pymatgen's POSCAR writer flips a left-handed cell as a whole while
    // retaining fractional coordinates. Its serialized SupercellInfo keeps
    // the original transformed lattice, so apply the adjustment only here.
    let poscar_cell = if determinant(built.matrix) < 0 {
        built.cell.map(|row| row.map(|value| -value))
    } else {
        built.cell
    };
    write_poscar(
        &output_dir.join("SPOSCAR"),
        &built.numbers,
        poscar_cell,
        &built.fractional,
    )?;
    let unitcell = structure_as_dict(
        &structure.atomic_numbers,
        structure.cell_a,
        &fractional_coordinates(&structure.positions_a, structure.cell_a)?,
    )?;
    let supercell = structure_as_dict(&built.numbers, built.cell, &built.fractional)?;
    let supercell_info = json!({
        "@module": "pydefect.input_maker.supercell_info",
        "@class": "SupercellInfo",
        "structure": supercell,
        "space_group": built.space_group,
        "transformation_matrix": built.matrix,
        "sites": built.sites,
        "interstitials": [],
        "unitcell_structure": unitcell,
    });
    fs::write(
        output_dir.join("supercell_info.json"),
        serde_json::to_string_pretty(&supercell_info).map_err(|error| error.to_string())? + "\n",
    )
    .map_err(|error| error.to_string())?;
    println!("Created supercell_info.json in {}", output_dir.display());
    Ok(())
}

fn parse(arguments: impl Iterator<Item = String>) -> Result<Options, String> {
    let mut options = Options {
        input: None,
        dimensions: Vec::new(),
        analyze_symmetry: true,
        output_dir: PathBuf::from("."),
    };
    let mut args = arguments.peekable();
    while let Some(argument) = args.next() {
        let (flag, inline) = argument
            .split_once('=')
            .map(|(flag, value)| (flag, Some(value.to_owned())))
            .unwrap_or((argument.as_str(), None));
        match flag {
            "-h" | "--help" => {
                print!("{HELP}");
                return Ok(options);
            }
            "-p" | "--poscar" => {
                let value = value(inline, &mut args, flag)?;
                options.input = Some(PathBuf::from(value));
            }
            "--dim" => {
                if let Some(value) = inline {
                    options.dimensions.extend(parse_dimensions(&value)?);
                } else {
                    while let Some(next) = args.peek() {
                        if next.starts_with('-') && next.parse::<i64>().is_err() {
                            break;
                        }
                        let next = args.next().expect("peeked value");
                        options.dimensions.extend(parse_dimensions(&next)?);
                    }
                }
            }
            "--no-symmetry" => options.analyze_symmetry = false,
            "-o" | "--output-dir" => {
                let value = value(inline, &mut args, flag)?;
                options.output_dir = PathBuf::from(value);
            }
            _ => return Err(format!("unexpected argument: {argument}")),
        }
    }
    Ok(options)
}

fn value(
    inline: Option<String>,
    args: &mut std::iter::Peekable<impl Iterator<Item = String>>,
    flag: &str,
) -> Result<String, String> {
    inline
        .or_else(|| args.next())
        .ok_or_else(|| format!("missing value for {flag}"))
}

fn expand_user_path(path: PathBuf) -> PathBuf {
    let Some(text) = path.to_str() else {
        return path;
    };
    if text == "~" || text.starts_with("~/") {
        if let Some(home) = std::env::var_os("HOME") {
            let suffix = text.strip_prefix('~').expect("checked tilde prefix");
            return PathBuf::from(home).join(suffix.strip_prefix('/').unwrap_or(suffix));
        }
    }
    path
}

fn parse_dimensions(value: &str) -> Result<Vec<i64>, String> {
    value
        .split(',')
        .map(|part| {
            part.parse::<i64>()
                .map_err(|_| format!("invalid --dim integer: {part}"))
        })
        .collect()
}

fn parse_matrix(dimensions: &[i64]) -> Result<[[i64; 3]; 3], String> {
    match dimensions.len() {
        3 => Ok([
            [dimensions[0], 0, 0],
            [0, dimensions[1], 0],
            [0, 0, dimensions[2]],
        ]),
        9 => Ok([
            [dimensions[0], dimensions[1], dimensions[2]],
            [dimensions[3], dimensions[4], dimensions[5]],
            [dimensions[6], dimensions[7], dimensions[8]],
        ]),
        _ => Err("--dim must be 3 (diagonal) or 9 (full matrix) integers.".into()),
    }
}

fn build_supercell(
    structure: &macer_rust_core::types::Structure,
    matrix: [[i64; 3]; 3],
    analyze_symmetry: bool,
) -> Result<BuiltSupercell, String> {
    let signed_determinant = determinant(matrix);
    if signed_determinant == 0 {
        return Err("supercell matrix must be nonsingular".into());
    }
    let determinant_magnitude = signed_determinant
        .checked_abs()
        .ok_or("supercell determinant is too large")?;
    let multiplicity =
        usize::try_from(determinant_magnitude).map_err(|_| "supercell determinant is too large")?;
    let inverse_matrix = inverse_i64(matrix, signed_determinant);
    let unit_fractional = fractional_coordinates(&structure.positions_a, structure.cell_a)?;
    let translation_points = lattice_points_in_supercell(matrix, inverse_matrix, multiplicity)?;
    let new_cell = multiply_i64_f64(matrix, structure.cell_a);

    let mut fractional = Vec::with_capacity(structure.atomic_numbers.len() * multiplicity);
    let mut numbers = Vec::with_capacity(structure.atomic_numbers.len() * multiplicity);
    for (&number, &position) in structure.atomic_numbers.iter().zip(&unit_fractional) {
        let old_in_new = row_multiply(position, inverse_matrix);
        for &translation in &translation_points {
            fractional.push(std::array::from_fn(|axis| {
                wrap_fractional(old_in_new[axis] + translation[axis])
            }));
            numbers.push(number);
        }
    }

    let cell = Cell::new(
        Lattice::from_basis(structure.cell_a),
        unit_fractional
            .iter()
            .map(|position| Position::new(position[0], position[1], position[2]))
            .collect(),
        structure
            .atomic_numbers
            .iter()
            .map(|&number| i32::from(number))
            .collect(),
    );
    let dataset = MoyoDataset::with_default(&cell, SYMPREC_ANGSTROM)
        .map_err(|error| format!("space-group analysis failed: {error}"))?;
    let symbol = dataset.hm_symbol.split_whitespace().collect::<String>();
    let space_group = format!("{symbol}");
    let sites = build_sites(
        &structure.atomic_numbers,
        &dataset,
        signed_determinant,
        analyze_symmetry,
    )?;

    Ok(BuiltSupercell {
        matrix,
        cell: new_cell,
        fractional,
        numbers,
        space_group,
        sites,
    })
}

fn build_sites(
    atomic_numbers: &[u8],
    dataset: &MoyoDataset,
    signed_determinant: i64,
    analyze_symmetry: bool,
) -> Result<Value, String> {
    if dataset.orbits.len() != atomic_numbers.len()
        || dataset.wyckoffs.len() != atomic_numbers.len()
        || dataset.site_symmetry_symbols.len() != atomic_numbers.len()
    {
        return Err("space-group analyzer returned inconsistent site metadata".into());
    }
    let mut sites = serde_json::Map::new();
    let mut element_counts: BTreeMap<&'static str, usize> = BTreeMap::new();
    let mut groups: Vec<(u8, usize, Vec<usize>)> = Vec::new();
    for (index, (&number, &orbit)) in atomic_numbers.iter().zip(&dataset.orbits).enumerate() {
        if analyze_symmetry {
            if let Some((_, _, atoms)) = groups.iter_mut().find(|(group_number, group_orbit, _)| {
                *group_number == number && *group_orbit == orbit
            }) {
                atoms.push(index);
            } else {
                groups.push((number, orbit, vec![index]));
            }
        } else {
            groups.push((number, index, vec![index]));
        }
    }
    for (number, orbit, atoms) in groups {
        let element = element(number)?;
        let serial = element_counts.entry(element).or_insert(0);
        *serial += 1;
        let name = format!("{element}{serial}");
        let first = atoms[0];
        if analyze_symmetry {
            let equivalents = if signed_determinant < 0 {
                // Match PyDefect's current signed `range(i*m, (i+1)*m)` behavior.
                Vec::new()
            } else {
                let multiplicity = signed_determinant as usize;
                atoms
                    .iter()
                    .flat_map(|&index| (index * multiplicity)..((index + 1) * multiplicity))
                    .map(Value::from)
                    .collect::<Vec<_>>()
            };
            sites.insert(
                name,
                json!({
                    "@module": "vise.util.structure_symmetrizer",
                    "@class": "Site",
                    "element": element,
                    "wyckoff_letter": dataset.wyckoffs[first].to_string(),
                    "site_symmetry": dataset.site_symmetry_symbols[first],
                    "equivalent_atoms": equivalents,
                }),
            );
        } else {
            sites.insert(
                name,
                json!({
                    "@module": "pydefect.input_maker.supercell_info",
                    "@class": "SimpleSite",
                    "element": element,
                    "site_index": first as i64 * signed_determinant,
                    "site_symmetry": null,
                    "wyckoff_letter": null,
                }),
            );
        }
        let _ = orbit;
    }
    Ok(Value::Object(sites))
}

fn structure_as_dict(
    numbers: &[u8],
    cell: [[f64; 3]; 3],
    fractional: &[[f64; 3]],
) -> Result<Value, String> {
    if numbers.len() != fractional.len() {
        return Err("structure atomic-number and coordinate counts differ".into());
    }
    let lengths = cell.map(norm);
    let angles = [
        angle(cell[1], cell[2])?,
        angle(cell[0], cell[2])?,
        angle(cell[0], cell[1])?,
    ];
    let lattice = json!({
        "matrix": cell,
        "pbc": [true, true, true],
        "a": lengths[0], "b": lengths[1], "c": lengths[2],
        "alpha": angles[0], "beta": angles[1], "gamma": angles[2],
        "volume": determinant_f64(cell).abs(),
    });
    let sites = numbers
        .iter()
        .zip(fractional)
        .map(|(&number, &abc)| {
            let symbol = element(number)?;
            let xyz = row_multiply(abc, cell);
            Ok(json!({
                "species": [{"element": symbol, "occu": 1}],
                "abc": abc,
                "properties": {},
                "label": symbol,
                "xyz": xyz,
            }))
        })
        .collect::<Result<Vec<_>, String>>()?;
    Ok(json!({
        "@module": "pymatgen.core.structure",
        "@class": "Structure",
        "charge": 0.0,
        "lattice": lattice,
        "properties": {},
        "sites": sites,
    }))
}

fn write_poscar(
    path: &Path,
    numbers: &[u8],
    cell: [[f64; 3]; 3],
    fractional: &[[f64; 3]],
) -> Result<(), String> {
    let symbols = numbers
        .iter()
        .map(|&number| element(number))
        .collect::<Result<Vec<_>, _>>()?;
    let mut groups: Vec<(&str, usize)> = Vec::new();
    for &symbol in &symbols {
        if let Some((last, count)) = groups.last_mut() {
            if *last == symbol {
                *count += 1;
                continue;
            }
        }
        groups.push((symbol, 1));
    }
    let formula = groups
        .iter()
        .map(|(symbol, count)| format!("{symbol}{count}"))
        .collect::<Vec<_>>()
        .join(" ");
    let mut output = format!("{formula}\n1.0\n");
    for row in cell {
        output.push_str(&format!(
            "{:20.16} {:20.16} {:20.16}\n",
            row[0], row[1], row[2]
        ));
    }
    output.push_str(
        &groups
            .iter()
            .map(|(symbol, _)| *symbol)
            .collect::<Vec<_>>()
            .join(" "),
    );
    output.push('\n');
    output.push_str(
        &groups
            .iter()
            .map(|(_, count)| count.to_string())
            .collect::<Vec<_>>()
            .join(" "),
    );
    output.push_str("\ndirect\n");
    for (symbol, position) in symbols.iter().zip(fractional) {
        output.push_str(&format!(
            "{:20.16} {:20.16} {:20.16} {}\n",
            position[0], position[1], position[2], symbol
        ));
    }
    fs::write(path, output).map_err(|error| error.to_string())
}

fn lattice_points_in_supercell(
    matrix: [[i64; 3]; 3],
    inverse: [[f64; 3]; 3],
    expected: usize,
) -> Result<Vec<[f64; 3]>, String> {
    let mut minimum = [i64::MAX; 3];
    let mut maximum = [i64::MIN; 3];
    for a in 0..=1 {
        for b in 0..=1 {
            for c in 0..=1 {
                let corner = [a as i64, b as i64, c as i64];
                let point = std::array::from_fn::<_, 3, _>(|axis| {
                    (0..3)
                        .map(|row| corner[row] * matrix[row][axis])
                        .sum::<i64>()
                });
                for axis in 0..3 {
                    minimum[axis] = minimum[axis].min(point[axis]);
                    maximum[axis] = maximum[axis].max(point[axis]);
                }
            }
        }
    }
    let ranges =
        std::array::from_fn::<_, 3, _>(|axis| (minimum[axis]..=maximum[axis]).collect::<Vec<_>>());
    let candidate_count = ranges
        .iter()
        .try_fold(1usize, |count, range| count.checked_mul(range.len()))
        .ok_or("supercell translation range overflow")?;
    if candidate_count > expected.saturating_mul(100_000).max(1_000_000) {
        return Err("supercell matrix produces an impractically large translation search".into());
    }
    let mut points = Vec::with_capacity(expected);
    for &a in &ranges[0] {
        for &b in &ranges[1] {
            for &c in &ranges[2] {
                let original_translation = [a as f64, b as f64, c as f64];
                let fractional = row_multiply(original_translation, inverse);
                if fractional
                    .iter()
                    .all(|&x| x >= -1.0e-10 && x < 1.0 - 1.0e-10)
                {
                    points.push(fractional.map(wrap_fractional));
                }
            }
        }
    }
    if points.len() != expected {
        return Err(format!(
            "supercell translation count mismatch: expected {expected}, found {}",
            points.len()
        ));
    }
    Ok(points)
}

fn fractional_coordinates(
    positions: &[[f64; 3]],
    cell: [[f64; 3]; 3],
) -> Result<Vec<[f64; 3]>, String> {
    let inverse = inverse_f64(cell)?;
    Ok(positions
        .iter()
        .map(|&position| row_multiply(position, inverse))
        .collect())
}

fn multiply_i64_f64(left: [[i64; 3]; 3], right: [[f64; 3]; 3]) -> [[f64; 3]; 3] {
    std::array::from_fn(|i| {
        std::array::from_fn(|j| (0..3).map(|k| left[i][k] as f64 * right[k][j]).sum())
    })
}

fn row_multiply(row: [f64; 3], matrix: [[f64; 3]; 3]) -> [f64; 3] {
    std::array::from_fn(|j| (0..3).map(|i| row[i] * matrix[i][j]).sum())
}

fn inverse_i64(matrix: [[i64; 3]; 3], determinant: i64) -> [[f64; 3]; 3] {
    let m = matrix;
    let inv_det = 1.0 / determinant as f64;
    [
        [
            (m[1][1] * m[2][2] - m[1][2] * m[2][1]) as f64,
            (m[0][2] * m[2][1] - m[0][1] * m[2][2]) as f64,
            (m[0][1] * m[1][2] - m[0][2] * m[1][1]) as f64,
        ],
        [
            (m[1][2] * m[2][0] - m[1][0] * m[2][2]) as f64,
            (m[0][0] * m[2][2] - m[0][2] * m[2][0]) as f64,
            (m[0][2] * m[1][0] - m[0][0] * m[1][2]) as f64,
        ],
        [
            (m[1][0] * m[2][1] - m[1][1] * m[2][0]) as f64,
            (m[0][1] * m[2][0] - m[0][0] * m[2][1]) as f64,
            (m[0][0] * m[1][1] - m[0][1] * m[1][0]) as f64,
        ],
    ]
    .map(|row| row.map(|value| value * inv_det))
}

fn inverse_f64(matrix: [[f64; 3]; 3]) -> Result<[[f64; 3]; 3], String> {
    let determinant = determinant_f64(matrix);
    if !determinant.is_finite() || determinant.abs() < 1.0e-14 {
        return Err("cell or supercell matrix is singular".into());
    }
    let inverse = [
        [
            matrix[1][1] * matrix[2][2] - matrix[1][2] * matrix[2][1],
            matrix[0][2] * matrix[2][1] - matrix[0][1] * matrix[2][2],
            matrix[0][1] * matrix[1][2] - matrix[0][2] * matrix[1][1],
        ],
        [
            matrix[1][2] * matrix[2][0] - matrix[1][0] * matrix[2][2],
            matrix[0][0] * matrix[2][2] - matrix[0][2] * matrix[2][0],
            matrix[0][2] * matrix[1][0] - matrix[0][0] * matrix[1][2],
        ],
        [
            matrix[1][0] * matrix[2][1] - matrix[1][1] * matrix[2][0],
            matrix[0][1] * matrix[2][0] - matrix[0][0] * matrix[2][1],
            matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0],
        ],
    ];
    Ok(inverse.map(|row| row.map(|value| value / determinant)))
}

fn determinant(matrix: [[i64; 3]; 3]) -> i64 {
    matrix[0][0] * (matrix[1][1] * matrix[2][2] - matrix[1][2] * matrix[2][1])
        - matrix[0][1] * (matrix[1][0] * matrix[2][2] - matrix[1][2] * matrix[2][0])
        + matrix[0][2] * (matrix[1][0] * matrix[2][1] - matrix[1][1] * matrix[2][0])
}

fn determinant_f64(matrix: [[f64; 3]; 3]) -> f64 {
    matrix[0][0] * (matrix[1][1] * matrix[2][2] - matrix[1][2] * matrix[2][1])
        - matrix[0][1] * (matrix[1][0] * matrix[2][2] - matrix[1][2] * matrix[2][0])
        + matrix[0][2] * (matrix[1][0] * matrix[2][1] - matrix[1][1] * matrix[2][0])
}

fn norm(vector: [f64; 3]) -> f64 {
    vector.iter().map(|x| x * x).sum::<f64>().sqrt()
}

fn angle(first: [f64; 3], second: [f64; 3]) -> Result<f64, String> {
    let denominator = norm(first) * norm(second);
    if denominator <= 0.0 {
        return Err("cell has a zero-length lattice vector".into());
    }
    Ok(
        (first.iter().zip(second).map(|(a, b)| a * b).sum::<f64>() / denominator)
            .clamp(-1.0, 1.0)
            .acos()
            .to_degrees(),
    )
}

fn wrap_fractional(value: f64) -> f64 {
    let wrapped = value - value.floor();
    if wrapped >= 1.0 - 1.0e-14 {
        0.0
    } else if wrapped.abs() < 1.0e-14 {
        0.0
    } else {
        wrapped
    }
}

fn element(number: u8) -> Result<&'static str, String> {
    crate::elements::SYMBOLS
        .get(number as usize)
        .copied()
        .filter(|symbol| *symbol != "X")
        .ok_or_else(|| format!("unsupported atomic number {number}"))
}

#[cfg(test)]
mod tests {
    use super::{lattice_points_in_supercell, parse, parse_matrix, wrap_fractional};

    #[test]
    fn parses_diagonal_and_full_matrices() {
        assert_eq!(
            parse_matrix(&[2, 1, 3]).unwrap(),
            [[2, 0, 0], [0, 1, 0], [0, 0, 3]]
        );
        assert_eq!(
            parse_matrix(&[1, 1, 0, 0, 1, 0, 0, 0, 1]).unwrap(),
            [[1, 1, 0], [0, 1, 0], [0, 0, 1]]
        );
        assert!(parse_matrix(&[1, 2]).is_err());
    }

    #[test]
    fn parses_negative_matrix_entries_before_following_options() {
        let options = parse(
            ["--dim", "-1", "1", "1", "--no-symmetry"]
                .into_iter()
                .map(str::to_owned),
        )
        .unwrap();
        assert_eq!(options.dimensions, [-1, 1, 1]);
        assert!(!options.analyze_symmetry);
    }

    #[test]
    fn diagonal_and_sheared_cells_have_expected_coset_count() {
        let diagonal = [[2, 0, 0], [0, 1, 0], [0, 0, 1]];
        let diagonal_points = lattice_points_in_supercell(
            diagonal,
            [[0.5, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]],
            2,
        )
        .unwrap();
        assert_eq!(diagonal_points, [[0.0, 0.0, 0.0], [0.5, 0.0, 0.0]]);

        let shear = [[2, 1, 0], [0, 1, 0], [0, 0, 1]];
        let inverse = [[0.5, -0.5, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]];
        assert_eq!(
            lattice_points_in_supercell(shear, inverse, 2)
                .unwrap()
                .len(),
            2
        );
    }

    #[test]
    fn wraps_negative_fractional_coordinates_into_unit_cell() {
        assert!((wrap_fractional(-0.25) - 0.75).abs() < 1.0e-12);
        assert_eq!(wrap_fractional(1.0), 0.0);
    }
}
