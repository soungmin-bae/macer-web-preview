use crate::plots::{csv_columns, write_md_log_plot};
use std::path::{Path, PathBuf};

pub const HELP: &str = r#"Molecular-dynamics post-processing utilities.

USAGE:
    macer-rust util md summary [-i|--input <CSV>]
    macer-rust util md conductivity -i|--input <TRAJECTORY> -t|--temp <K> [OPTIONS]
    macer-rust util md plot [-i|--input <CSV>] [-o|--output <PDF_PREFIX>]

Commands:
    summary    Print mean, standard deviation, minimum, and maximum from md.csv
    conductivity Calculate Nernst-Einstein ionic conductivity from md.traj or XDATCAR
    plot       Plot temperature, potential energy, and pressure from md.csv
"#;

pub fn run(arguments: impl Iterator<Item = String>) -> Result<(), String> {
    let mut arguments = arguments.collect::<Vec<_>>();
    if arguments.first().map(String::as_str) != Some("md") {
        return Err("usage: macer-rust util md <summary|plot> [OPTIONS]".into());
    }
    arguments.remove(0);
    let Some(action) = arguments.first().cloned() else {
        return Err(HELP.into());
    };
    arguments.remove(0);
    match action.as_str() {
        "summary" => run_summary(arguments.into_iter()),
        "conductivity" => crate::md_conductivity::run(arguments.into_iter()),
        "plot" => run_plot(arguments.into_iter()),
        "-h" | "--help" => {
            print!("{HELP}");
            Ok(())
        }
        _ => Err(format!("unknown macer util md command: {action}\n{HELP}")),
    }
}

fn run_summary(arguments: impl Iterator<Item = String>) -> Result<(), String> {
    let input = parse_input(arguments, "md.csv")?;
    let columns = match csv_columns(Path::new(&input)) {
        Ok(columns) => columns,
        Err(error) => {
            if !Path::new(&input).exists() {
                println!("Error: CSV file '{input}' not found.");
            } else {
                println!("Error reading CSV for summary: {error}");
            }
            return Ok(());
        }
    };
    let selected = ["T_K", "P_GPa", "Epot_eV", "Etot_eV", "Vol_A3"]
        .into_iter()
        .filter_map(|name| columns.get(name).map(|values| (name, values.as_slice())))
        .collect::<Vec<_>>();
    if selected.is_empty() {
        println!("\nMD Statistical Summary for: {input}");
        println!("{}", "-".repeat(50));
        println!("No supported numeric columns found.");
        println!("{}", "-".repeat(50));
        return Ok(());
    }

    let summaries = selected
        .iter()
        .map(|(_, values)| statistics(values))
        .collect::<Vec<_>>();
    print_summary(&input, &selected, &summaries);
    Ok(())
}

fn run_plot(arguments: impl Iterator<Item = String>) -> Result<(), String> {
    let mut input = "md.csv".to_owned();
    let mut output = "md_plot".to_owned();
    parse_options(arguments, |option, value| match option {
        "-i" | "--input" => {
            input = value;
            Ok(())
        }
        "-o" | "--output" => {
            output = value;
            Ok(())
        }
        _ => return Err(format!("unexpected argument: {option}")),
    })?;
    let output_path = PathBuf::from(format!("{output}.pdf"));
    write_md_log_plot(Path::new(&input), &output_path)?;
    println!("MD plots saved to {}", output_path.display());
    Ok(())
}

fn parse_input(arguments: impl Iterator<Item = String>, default: &str) -> Result<String, String> {
    let mut input = default.to_owned();
    parse_options(arguments, |option, value| match option {
        "-i" | "--input" => {
            input = value;
            Ok(())
        }
        _ => return Err(format!("unexpected argument: {option}")),
    })?;
    Ok(input)
}

fn parse_options(
    arguments: impl Iterator<Item = String>,
    mut set_option: impl FnMut(&str, String) -> Result<(), String>,
) -> Result<(), String> {
    let mut arguments = arguments.peekable();
    while let Some(argument) = arguments.next() {
        if argument == "--help" || argument == "-h" {
            print!("{HELP}");
            return Ok(());
        }
        let (option, value) = match argument.split_once('=') {
            Some((option, value)) => (option.to_owned(), value.to_owned()),
            None => (
                argument.clone(),
                arguments
                    .next()
                    .ok_or_else(|| format!("missing value for {argument}"))?,
            ),
        };
        set_option(&option, value)?;
    }
    Ok(())
}

fn statistics(values: &[f64]) -> [f64; 4] {
    let values = values
        .iter()
        .copied()
        .filter(|value| !value.is_nan())
        .collect::<Vec<_>>();
    if values.is_empty() {
        return [f64::NAN; 4];
    }
    let count = values.len() as f64;
    let mean = values.iter().sum::<f64>() / count;
    let std = if values.len() > 1 {
        (values
            .iter()
            .map(|value| (value - mean).powi(2))
            .sum::<f64>()
            / (count - 1.0))
            .sqrt()
    } else {
        f64::NAN
    };
    let min = values.iter().copied().fold(f64::INFINITY, f64::min);
    let max = values.iter().copied().fold(f64::NEG_INFINITY, f64::max);
    [mean, std, min, max]
}

fn print_summary(input: &str, columns: &[(&str, &[f64])], summaries: &[[f64; 4]]) {
    let index_width = 4;
    let rendered = summaries
        .iter()
        .map(|stats| format_column(stats))
        .collect::<Vec<_>>();
    let widths = columns
        .iter()
        .enumerate()
        .map(|(column_index, (name, _))| {
            let values_width = rendered
                .get(column_index)
                .into_iter()
                .flat_map(|stats| stats.iter())
                .map(String::len)
                .max()
                .unwrap_or(0);
            let width = name.len().max(values_width);
            // Pandas' table formatter leaves one extra column-space cell when
            // a short dataset's header, rather than its values, sets the width.
            width + usize::from(name.len() > values_width)
        })
        .collect::<Vec<_>>();
    let mut output = format!(
        "\nMD Statistical Summary for: {input}\n{}\n",
        "-".repeat(50)
    );
    output.push_str(&format!("{:>index_width$}", ""));
    for ((name, _), width) in columns.iter().zip(&widths) {
        output.push_str(&format!(" {name:>width$}"));
    }
    output.push('\n');
    for (row, label) in ["mean", "std", "min", "max"].iter().enumerate() {
        output.push_str(&format!("{label:<index_width$}"));
        for (column_values, width) in rendered.iter().zip(&widths) {
            output.push_str(&format!(" {:>width$}", column_values[row]));
        }
        output.push('\n');
    }
    output.push_str(&"-".repeat(50));
    println!("{output}");
}

fn format_column(values: &[f64; 4]) -> [String; 4] {
    let scientific = values.iter().any(|value| {
        value.is_finite() && *value != 0.0 && format!("{value:.6}").parse::<f64>() == Ok(0.0)
    });
    if scientific {
        return values.map(format_scientific);
    }
    let decimals = values
        .iter()
        .filter(|value| value.is_finite())
        .map(|value| {
            let mut rendered = format!("{value:.6}");
            while rendered.ends_with('0') {
                rendered.pop();
            }
            rendered
                .split_once('.')
                .map(|(_, digits)| digits.len())
                .unwrap_or(0)
        })
        .max()
        .unwrap_or(1)
        .max(1);
    values.map(|value| {
        if value.is_nan() {
            "NaN".into()
        } else if value.is_infinite() {
            if value.is_sign_positive() {
                "inf".into()
            } else {
                "-inf".into()
            }
        } else {
            let rendered = format!("{value:.decimals$}");
            if value >= 0.0 {
                format!(" {rendered}")
            } else {
                rendered
            }
        }
    })
}

fn format_scientific(value: f64) -> String {
    if value.is_nan() {
        return "NaN".into();
    }
    if value.is_infinite() {
        return if value.is_sign_positive() {
            "inf"
        } else {
            "-inf"
        }
        .into();
    }
    let rendered = format!("{value:.6e}");
    let (mantissa, exponent) = rendered
        .split_once('e')
        .expect("scientific formatter has exponent");
    let exponent = exponent
        .parse::<i32>()
        .expect("scientific formatter has numeric exponent");
    let rendered = format!(
        "{mantissa}e{}{abs_exponent:02}",
        if exponent >= 0 { "+" } else { "-" },
        abs_exponent = exponent.abs()
    );
    if value >= 0.0 {
        format!(" {rendered}")
    } else {
        rendered
    }
}

#[cfg(test)]
mod tests {
    use super::{statistics, *};

    #[test]
    fn statistics_match_pandas_describe_sample_standard_deviation() {
        let stats = statistics(&[100.0, 200.0, 300.0]);
        assert_eq!(stats[0], 200.0);
        assert_eq!(stats[1], 100.0);
        assert_eq!(stats[2], 100.0);
        assert_eq!(stats[3], 300.0);
    }

    #[test]
    fn float_format_matches_the_legacy_summary_precision() {
        assert_eq!(
            format_column(&[200.0, 100.0, 100.0, 300.0]),
            [" 200.0", " 100.0", " 100.0", " 300.0"]
        );
        assert_eq!(
            format_column(&[1.23456789, 1.0, -1.0, 0.0]),
            [" 1.234568", " 1.000000", "-1.000000", " 0.000000"]
        );
        assert_eq!(format_scientific(205.4078652466493), " 2.054079e+02");
        assert_eq!(format_scientific(6.139791e-14), " 6.139791e-14");
    }

    #[test]
    fn summary_selects_only_the_legacy_columns_in_legacy_order() {
        let path =
            std::env::temp_dir().join(format!("macer-rust-md-summary-{}.csv", std::process::id()));
        std::fs::write(
            &path,
            "step,T_K,other,Etot_eV,P_GPa,Epot_eV,Vol_A3\n0,100,99,-9.5,1,-10,20\n1,200,99,-8.5,2,-9,21\n2,300,99,-7.5,3,-8,22\n",
        )
        .unwrap();
        let columns = csv_columns(&path).unwrap();
        let selected = ["T_K", "P_GPa", "Epot_eV", "Etot_eV", "Vol_A3"]
            .into_iter()
            .filter_map(|name| columns.get(name).map(|values| (name, values.as_slice())))
            .collect::<Vec<_>>();
        assert_eq!(
            selected.iter().map(|(name, _)| *name).collect::<Vec<_>>(),
            ["T_K", "P_GPa", "Epot_eV", "Etot_eV", "Vol_A3"]
        );
        assert_eq!(statistics(selected[0].1), [200.0, 100.0, 100.0, 300.0]);
        std::fs::remove_file(path).unwrap();
    }
}
