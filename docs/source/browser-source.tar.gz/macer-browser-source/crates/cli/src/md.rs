use crate::elements::MASSES_AMU;
use crate::md_outputs::LegacyMdOutputs;
use crate::model_io::load_evaluator;
use crate::npz::{read_macer_restart_npz, write_macer_restart_npz};
use crate::plots::write_md_plots;
use crate::poscar::read_poscar;
use crate::ulm::UlmTrajectoryWriter;
use crate::vasp_mlff::load_for_native_evaluation;
use candle_core::Device;
use macer_rust_core::dynamics::DynamicsState;
use macer_rust_core::emt::EffectiveMediumTheory;
use macer_rust_core::lennard_jones::LennardJones;
use macer_rust_core::types::{Evaluation, Potential, Structure};
use macer_rust_model::evaluation::Evaluator;
use macer_rust_model::vasp_mlff_evaluator::VaspMLFFModel;
use serde::Serialize;
use std::collections::HashMap;
use std::fs::{self, File};
use std::io::{BufWriter, Write};
use std::path::{Path, PathBuf};
use std::time::Instant;

enum Engine {
    MatterSim(Evaluator),
    LennardJones(LennardJones),
    EffectiveMediumTheory(EffectiveMediumTheory),
    VaspMLFF(VaspMLFFModel),
}

impl Potential for Engine {
    fn evaluate(&mut self, structure: &Structure) -> Result<Evaluation, String> {
        match self {
            Self::MatterSim(evaluator) => evaluator.evaluate(structure),
            Self::LennardJones(evaluator) => evaluator.evaluate(structure),
            Self::EffectiveMediumTheory(evaluator) => evaluator.evaluate(structure),
            Self::VaspMLFF(evaluator) => evaluator.evaluate(structure),
        }
    }
}

impl Engine {
    fn ase_calculator_name(&self) -> &'static str {
        match self {
            Self::MatterSim(_) => "macermattersimcalculator",
            Self::LennardJones(_) => "lennardjones",
            Self::EffectiveMediumTheory(_) => "emt",
            Self::VaspMLFF(_) => "vaspmlff",
        }
    }
}

pub const HELP: &str = r#"Run molecular dynamics with a native Macer calculator.

USAGE:
    macer-rust md --force-field <mattersim|lj|emt|vasp-mlff> --device <cpu|cuda> \
        --ensemble <nve|langevin> --steps <N> --dt-fs <FS> --seed <N> \
        --output <DIR> [OPTIONS]

INPUT:
    --structure <POSCAR>       Initial structure; required unless --resume is used
    --force-field <NAME>        mattersim (default), lj, emt, or vasp-mlff
    --model <PATH>              Required for mattersim or vasp-mlff; MatterSim needs an adjacent .json manifest
    --device <cpu|cuda>         Execution device; LJ, EMT, and VASP ML_FF currently support cpu
    --ensemble <nve|langevin>   MD ensemble
    --steps <N>                 Number of steps to advance
    --dt-fs <FS>                Time step in femtoseconds
    --seed <N>                  Random seed for initialization/integration

LENNARD-JONES (ASE-compatible; parameters in eV and Å):
    --epsilon-ev <VALUE>        Pair well depth (Macer's Argon default)
    --sigma-a <VALUE>           Pair length scale (Macer's Argon default)
    --cutoff-a <VALUE>          Cutoff (default: 3*sigma)
    --onset-a <VALUE>            Smooth cutoff onset (default: 0.66*cutoff)
    --smooth <true|false>        Smooth energy/force cutoff (default: false)

LANGEVIN:
    --temperature-k <K>         Target temperature in kelvin
    --gamma-per-fs <VALUE>      Friction coefficient in 1/fs

OUTPUT AND RESTART:
    --output <DIR>              Output directory
    --output-stride <N>         Frame/output interval (default: 100)
    --warmup-steps <N>          Unrecorded model warmup steps (default: 2)
    --velocity-file <JSON>      Initial velocities in Å/fs
    --resume <restart.json|restart.npz>
                                Continue from a Rust or Macer-compatible restart
    -h, --help                  Print this help text

Energy is reported in eV, force in eV/Å, stress in eV/Å³, and time in fs.
"#;

#[derive(Serialize)]
struct Frame<'a> {
    schema_version: &'static str,
    step: u64,
    time_fs: f64,
    potential_energy_ev: f64,
    kinetic_energy_ev: f64,
    atomic_numbers: &'a [u8],
    cell_a: [[f64; 3]; 3],
    pbc: [bool; 3],
    positions_a: &'a [[f64; 3]],
    velocities_a_per_fs: &'a [[f64; 3]],
    forces_ev_per_a: &'a [[f64; 3]],
    stress_ev_per_a3: [[f64; 3]; 3],
}

#[derive(Serialize)]
struct Report {
    schema_version: &'static str,
    device: String,
    ensemble: String,
    model_weights: String,
    atoms: usize,
    steps: usize,
    dt_fs: f64,
    seed: u64,
    output_stride: usize,
    model_load_s: f64,
    initial_evaluation_s: f64,
    warmup_s: f64,
    md_s: f64,
    steps_per_s: f64,
    final_energy_ev: f64,
    final_kinetic_energy_ev: f64,
}

fn required<'a>(args: &'a HashMap<String, String>, key: &str) -> Result<&'a str, String> {
    args.get(key)
        .map(String::as_str)
        .ok_or_else(|| format!("missing --{key}"))
}

fn parse<T: std::str::FromStr>(args: &HashMap<String, String>, key: &str) -> Result<T, String> {
    required(args, key)?
        .parse()
        .map_err(|_| format!("invalid --{key}"))
}

fn optional_parse<T: std::str::FromStr>(
    args: &HashMap<String, String>,
    key: &str,
) -> Result<Option<T>, String> {
    args.get(key)
        .map(|value| value.parse().map_err(|_| format!("invalid --{key}")))
        .transpose()
}

fn write_restart(path: &Path, state: &DynamicsState) -> Result<(), String> {
    let temporary = path.with_extension("json.tmp");
    let data = serde_json::to_vec(state).map_err(|e| e.to_string())?;
    fs::write(&temporary, data).map_err(|e| e.to_string())?;
    fs::rename(temporary, path).map_err(|e| e.to_string())
}

fn write_frame(writer: &mut BufWriter<File>, state: &DynamicsState) -> Result<(), String> {
    let frame = Frame {
        schema_version: "macer-rust-frame-v2",
        step: state.step,
        time_fs: state.time_fs,
        potential_energy_ev: state.evaluation.energy_ev,
        kinetic_energy_ev: state.kinetic_energy_ev(),
        atomic_numbers: &state.structure.atomic_numbers,
        cell_a: state.structure.cell_a,
        pbc: state.structure.pbc,
        positions_a: &state.structure.positions_a,
        velocities_a_per_fs: &state.velocities_a_per_fs,
        forces_ev_per_a: &state.evaluation.forces_ev_per_a,
        stress_ev_per_a3: state.evaluation.stress_ev_per_a3,
    };
    serde_json::to_writer(&mut *writer, &frame).map_err(|e| e.to_string())?;
    writer.write_all(b"\n").map_err(|e| e.to_string())
}

pub fn run(arguments: impl Iterator<Item = String>) -> Result<(), String> {
    let mut args = HashMap::new();
    let mut iter = arguments;
    while let Some(key) = iter.next() {
        let Some(key) = key.strip_prefix("--") else {
            return Err(format!("unexpected argument: {key}"));
        };
        let value = iter
            .next()
            .ok_or_else(|| format!("missing value for --{key}"))?;
        if args.insert(key.to_string(), value).is_some() {
            return Err(format!("duplicate --{key}"));
        }
    }
    for key in args.keys() {
        if ![
            "structure",
            "force-field",
            "model",
            "device",
            "ensemble",
            "steps",
            "dt-fs",
            "seed",
            "output",
            "output-stride",
            "temperature-k",
            "gamma-per-fs",
            "velocity-file",
            "warmup-steps",
            "resume",
            "epsilon-ev",
            "sigma-a",
            "cutoff-a",
            "onset-a",
            "smooth",
        ]
        .contains(&key.as_str())
        {
            return Err(format!("unknown option --{key}"));
        }
    }
    let force_field = args
        .get("force-field")
        .map(String::as_str)
        .unwrap_or("mattersim");
    if !["mattersim", "lj", "emt", "vasp-mlff"].contains(&force_field) {
        return Err(format!(
            "unsupported force field `{force_field}`; choose mattersim, lj, emt, or vasp-mlff"
        ));
    }
    let device_name = args.get("device").map(String::as_str).unwrap_or("cpu");
    let model_load_start = Instant::now();
    let (mut engine, model_identity) = match force_field {
        "mattersim" => {
            let model_path = PathBuf::from(required(&args, "model")?);
            let manifest_path = model_path.with_extension("json");
            let device = match device_name {
                "cpu" => Device::Cpu,
                #[cfg(feature = "cuda")]
                "cuda" => Device::new_cuda(0).map_err(|e| e.to_string())?,
                _ => return Err(format!("unsupported device: {device_name}")),
            };
            (
                Engine::MatterSim(load_evaluator(&manifest_path, &model_path, device)?),
                model_path.display().to_string(),
            )
        }
        "vasp-mlff" => {
            if device_name != "cpu" {
                return Err("native VASP ML_FF currently supports only --device cpu".into());
            }
            if ["epsilon-ev", "sigma-a", "cutoff-a", "onset-a", "smooth"]
                .iter()
                .any(|key| args.contains_key(*key))
            {
                return Err(
                    "Lennard-Jones parameters cannot be used with --force-field vasp-mlff".into(),
                );
            }
            let model_path = PathBuf::from(required(&args, "model")?);
            let model = load_for_native_evaluation(&model_path)?.to_model()?;
            (
                Engine::VaspMLFF(model),
                format!("vasp-mlff:{}", model_path.display()),
            )
        }
        "lj" => {
            if device_name != "cpu" {
                return Err("Lennard-Jones currently supports only --device cpu".into());
            }
            if args.contains_key("model") {
                return Err("--model is not used with --force-field lj".into());
            }
            let defaults = LennardJones::default();
            let epsilon =
                optional_parse::<f64>(&args, "epsilon-ev")?.unwrap_or(defaults.epsilon_ev);
            let sigma = optional_parse::<f64>(&args, "sigma-a")?.unwrap_or(defaults.sigma_a);
            let cutoff = optional_parse::<f64>(&args, "cutoff-a")?;
            let onset = optional_parse::<f64>(&args, "onset-a")?;
            let smooth = match args.get("smooth").map(String::as_str).unwrap_or("false") {
                "true" => true,
                "false" => false,
                value => return Err(format!("--smooth must be true or false, got `{value}`")),
            };
            let evaluator = LennardJones::new(epsilon, sigma, cutoff, onset, smooth)?;
            let identity = format!(
                "builtin:lj:epsilon_ev={:.17}:sigma_a={:.17}:cutoff_a={:.17}:onset_a={:.17}:smooth={}",
                evaluator.epsilon_ev,
                evaluator.sigma_a,
                evaluator.cutoff_a,
                evaluator.onset_a,
                evaluator.smooth
            );
            (Engine::LennardJones(evaluator), identity)
        }
        "emt" => {
            if device_name != "cpu" {
                return Err("native EMT currently supports only --device cpu".into());
            }
            if args.contains_key("model") {
                return Err("--model is not used with --force-field emt".into());
            }
            if ["epsilon-ev", "sigma-a", "cutoff-a", "onset-a", "smooth"]
                .iter()
                .any(|key| args.contains_key(*key))
            {
                return Err(
                    "Lennard-Jones parameters cannot be used with --force-field emt".into(),
                );
            }
            (
                Engine::EffectiveMediumTheory(EffectiveMediumTheory),
                "builtin:emt:ase-default".into(),
            )
        }
        _ => unreachable!("force field was validated above"),
    };
    let model_load_s = model_load_start.elapsed().as_secs_f64();
    let ensemble = required(&args, "ensemble")?;
    if ensemble != "nve" && ensemble != "langevin" {
        return Err("ensemble must be nve or langevin".into());
    }
    let steps: usize = parse(&args, "steps")?;
    let dt_fs: f64 = parse(&args, "dt-fs")?;
    let seed: u64 = parse(&args, "seed")?;
    let output_stride: usize = args
        .get("output-stride")
        .map(|s| s.parse().map_err(|_| "invalid --output-stride".to_string()))
        .transpose()?
        .unwrap_or(100);
    let warmup_steps: usize = args
        .get("warmup-steps")
        .map(|s| s.parse().map_err(|_| "invalid --warmup-steps".to_string()))
        .transpose()?
        .unwrap_or(2);
    if steps == 0 || output_stride == 0 || !dt_fs.is_finite() || dt_fs <= 0. {
        return Err("steps, stride and timestep must be positive".into());
    }
    let temperature_k: f64 = if ensemble == "langevin" {
        parse(&args, "temperature-k")?
    } else {
        0.
    };
    let gamma_per_fs: f64 = if ensemble == "langevin" {
        parse(&args, "gamma-per-fs")?
    } else {
        0.
    };
    let output = PathBuf::from(required(&args, "output")?);
    fs::create_dir_all(&output).map_err(|e| e.to_string())?;
    let initial_start = Instant::now();
    let mut state = if let Some(path) = args.get("resume") {
        if Path::new(path).extension().and_then(|value| value.to_str()) == Some("npz") {
            read_macer_restart_npz(Path::new(path), ensemble, dt_fs, seed, &mut engine)?
        } else {
            let bytes = fs::read(path).map_err(|e| e.to_string())?;
            let state: DynamicsState = serde_json::from_slice(&bytes).map_err(|e| e.to_string())?;
            state.structure.validate()?;
            state
                .evaluation
                .validate(state.structure.atomic_numbers.len())?;
            state
        }
    } else {
        let structure = read_poscar(Path::new(required(&args, "structure")?))?;
        let masses = structure
            .atomic_numbers
            .iter()
            .map(|&z| MASSES_AMU[z as usize])
            .collect();
        let velocities = if let Some(path) = args.get("velocity-file") {
            let bytes = fs::read(path).map_err(|e| e.to_string())?;
            serde_json::from_slice(&bytes).map_err(|e| format!("velocity file: {e}"))?
        } else {
            vec![[0.; 3]; structure.atomic_numbers.len()]
        };
        DynamicsState::initialize(structure, masses, velocities, seed, &mut engine)?
    };
    let initial_evaluation_s = initial_start.elapsed().as_secs_f64();
    let warm_start = Instant::now();
    if warmup_steps > 0 {
        let mut warm = state.clone();
        for _ in 0..warmup_steps {
            if ensemble == "nve" {
                warm.step_nve(dt_fs, &mut engine)?;
            } else {
                warm.step_langevin(dt_fs, temperature_k, gamma_per_fs, &mut engine)?;
            }
        }
    }
    let warmup_s = warm_start.elapsed().as_secs_f64();
    let trajectory = File::create(output.join("trajectory.jsonl")).map_err(|e| e.to_string())?;
    let mut writer = BufWriter::new(trajectory);
    let mut ase_trajectory = UlmTrajectoryWriter::create(
        &output.join("md.traj"),
        &state,
        engine.ase_calculator_name(),
    )?;
    let mut legacy_outputs =
        LegacyMdOutputs::create(&output, &state, ensemble, steps, dt_fs, output_stride)?;
    legacy_outputs.write_contcar(&output, &state, 0)?;
    if output_stride == 1 {
        legacy_outputs.write_contcar(&output, &state, 1)?;
    }
    write_frame(&mut writer, &state)?;
    let start = Instant::now();
    for index in 1..=steps {
        if ensemble == "nve" {
            state.step_nve(dt_fs, &mut engine)?;
        } else {
            state.step_langevin(dt_fs, temperature_k, gamma_per_fs, &mut engine)?;
        }
        let legacy_step = state.step + 1;
        legacy_outputs.write_step(&state, legacy_step, index, output_stride)?;
        if legacy_step % output_stride as u64 == 0 {
            legacy_outputs.write_contcar(&output, &state, legacy_step)?;
        }
        if index % output_stride == 0 || index == steps {
            write_frame(&mut writer, &state)?;
            ase_trajectory.write_frame(&state, engine.ase_calculator_name())?;
            write_restart(&output.join("restart.json"), &state)?;
        }
    }
    writer.flush().map_err(|e| e.to_string())?;
    ase_trajectory.close()?;
    legacy_outputs.close()?;
    let md_s = start.elapsed().as_secs_f64();
    write_macer_restart_npz(
        &output.join("restart.npz"),
        &state,
        ensemble,
        dt_fs,
        &output,
    )?;
    write_md_plots(&output)?;
    let report = Report {
        schema_version: "macer-rust-md-v2",
        device: device_name.to_string(),
        ensemble: ensemble.to_string(),
        model_weights: model_identity,
        atoms: state.structure.atomic_numbers.len(),
        steps,
        dt_fs,
        seed,
        output_stride,
        model_load_s,
        initial_evaluation_s,
        warmup_s,
        md_s,
        steps_per_s: steps as f64 / md_s,
        final_energy_ev: state.evaluation.energy_ev,
        final_kinetic_energy_ev: state.kinetic_energy_ev(),
    };
    fs::write(
        output.join("report.json"),
        serde_json::to_vec_pretty(&report).map_err(|e| e.to_string())?,
    )
    .map_err(|e| e.to_string())?;
    println!(
        "{}",
        serde_json::to_string(&report).map_err(|e| e.to_string())?
    );
    Ok(())
}
