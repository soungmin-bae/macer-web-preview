//! Structure input adapters shared by native commands.

use macer_rust_core::types::Structure;
use mmcif_cif::{Block, Document, Entry, Loop};
use moyo::base::Operation;
use moyo::data::{hall_symbol_entry, operations_from_number, Setting};
use quick_xml::events::{BytesStart, Event};
use quick_xml::reader::Reader;
use std::fs::File;
use std::io::{BufRead, BufReader};
use std::path::Path;

#[derive(Clone, Copy)]
struct SymmetryOperation {
    rotation: [[i32; 3]; 3],
    translation: [f64; 3],
}

impl From<Operation> for SymmetryOperation {
    fn from(operation: Operation) -> Self {
        Self {
            rotation: operation.rotation_as_array(),
            translation: operation.translation_as_array(),
        }
    }
}

fn tag_parts(tag: &str) -> Option<(String, String)> {
    let body = tag.strip_prefix('_')?;
    if let Some((category, item)) = body.split_once('.') {
        return Some((category.to_ascii_lowercase(), item.to_ascii_lowercase()));
    }
    // CIF 1.1 uses flat tags such as `_atom_site_fract_x`; CIF 2.0 writes
    // the same data as `_atom_site.fract_x`.
    for category in [
        "space_group_symop",
        "symmetry_equiv_pos",
        "atom_site",
        "space_group",
        "symmetry",
        "cell",
    ] {
        if let Some(item) = body
            .strip_prefix(category)
            .and_then(|rest| rest.strip_prefix('_'))
        {
            return Some((category.to_owned(), item.to_ascii_lowercase()));
        }
    }
    None
}

fn tag_matches(tag: &str, category: &str, item: &str) -> bool {
    tag_parts(tag).is_some_and(|(tag_category, tag_item)| {
        tag_category.eq_ignore_ascii_case(category) && tag_item.eq_ignore_ascii_case(item)
    })
}

fn pair_value<'a>(block: &Block<'a>, category: &str, item: &str) -> Option<String> {
    block.entries().find_map(|entry| match entry {
        Entry::Pair(pair) if tag_matches(pair.tag(), category, item) => {
            pair.value().as_str().map(str::to_owned)
        }
        _ => None,
    })
}

fn loop_column<'a>(block: &Block<'a>, category: &str, item: &str) -> Option<(Loop<'a>, usize)> {
    block.entries().find_map(|entry| {
        let Entry::Loop(table) = entry else {
            return None;
        };
        let column = table
            .tags()
            .position(|tag| tag_matches(tag, category, item))?;
        Some((table, column))
    })
}

fn loop_value<'a>(table: &Loop<'a>, column: usize, row: usize) -> Option<&'a str> {
    table.value(row, column)?.as_str()
}

fn field_values(block: &Block<'_>, category: &str, item: &str) -> Vec<String> {
    let mut values = Vec::new();
    for entry in block.entries() {
        match entry {
            Entry::Pair(pair) if tag_matches(pair.tag(), category, item) => {
                if let Some(value) = pair.value().as_str() {
                    values.push(value.to_owned());
                }
            }
            Entry::Loop(table) => {
                if let Some(column) = table
                    .tags()
                    .position(|tag| tag_matches(tag, category, item))
                {
                    values.extend(
                        (0..table.row_count())
                            .filter_map(|row| loop_value(&table, column, row).map(str::to_owned)),
                    );
                }
            }
            _ => {}
        }
    }
    values
}

fn parse_number(value: &str, field: &str) -> Result<f64, String> {
    let value = value.trim();
    let without_uncertainty = if let Some(open) = value.find('(') {
        let close = value[open..]
            .find(')')
            .map(|offset| open + offset)
            .ok_or_else(|| format!("invalid CIF number for {field}: {value}"))?;
        format!("{}{}", &value[..open], &value[close + 1..])
    } else {
        value.to_owned()
    };
    let parsed = if let Some((numerator, denominator)) = without_uncertainty.split_once('/') {
        numerator
            .trim()
            .parse::<f64>()
            .and_then(|n| denominator.trim().parse::<f64>().map(|d| n / d))
    } else {
        without_uncertainty.parse::<f64>()
    }
    .map_err(|_| format!("invalid CIF number for {field}: {value}"))?;
    if !parsed.is_finite() {
        return Err(format!("non-finite CIF number for {field}: {value}"));
    }
    Ok(parsed)
}

fn lattice_from_cif(block: &Block<'_>) -> Result<[[f64; 3]; 3], String> {
    let a = parse_number(
        &pair_value(block, "cell", "length_a").ok_or("CIF is missing _cell_length_a")?,
        "_cell_length_a",
    )?;
    let b = parse_number(
        &pair_value(block, "cell", "length_b").ok_or("CIF is missing _cell_length_b")?,
        "_cell_length_b",
    )?;
    let c = parse_number(
        &pair_value(block, "cell", "length_c").ok_or("CIF is missing _cell_length_c")?,
        "_cell_length_c",
    )?;
    let alpha = parse_number(
        &pair_value(block, "cell", "angle_alpha").ok_or("CIF is missing _cell_angle_alpha")?,
        "_cell_angle_alpha",
    )?
    .to_radians();
    let beta = parse_number(
        &pair_value(block, "cell", "angle_beta").ok_or("CIF is missing _cell_angle_beta")?,
        "_cell_angle_beta",
    )?
    .to_radians();
    let gamma = parse_number(
        &pair_value(block, "cell", "angle_gamma").ok_or("CIF is missing _cell_angle_gamma")?,
        "_cell_angle_gamma",
    )?
    .to_radians();
    if a <= 0. || b <= 0. || c <= 0. || gamma.sin().abs() < 1e-12 {
        return Err("CIF lattice parameters must define a non-degenerate cell".into());
    }
    let ca = alpha.cos();
    let cb = beta.cos();
    let cg = gamma.cos();
    let sg = gamma.sin();
    let cx = c * cb;
    let cy = c * (ca - cb * cg) / sg;
    let cz_squared = c * c - cx * cx - cy * cy;
    if cz_squared <= 0. {
        return Err("CIF lattice parameters produce a non-positive cell volume".into());
    }
    Ok([
        [a, 0., 0.],
        [b * cg, b * sg, 0.],
        [cx, cy, cz_squared.sqrt()],
    ])
}

fn parse_symmetry_component(expression: &str) -> Result<([i32; 3], f64), String> {
    let compact = expression
        .chars()
        .filter(|character| !character.is_ascii_whitespace())
        .collect::<String>()
        .to_ascii_lowercase();
    if compact.is_empty() {
        return Err("empty CIF symmetry coordinate".into());
    }
    let bytes = compact.as_bytes();
    let mut terms = Vec::<(i32, String)>::new();
    let mut start = 0;
    let mut sign = 1;
    if bytes[0] == b'+' || bytes[0] == b'-' {
        sign = if bytes[0] == b'-' { -1 } else { 1 };
        start = 1;
    }
    for index in 1..bytes.len() {
        if bytes[index] == b'+' || bytes[index] == b'-' {
            terms.push((sign, compact[start..index].to_owned()));
            sign = if bytes[index] == b'-' { -1 } else { 1 };
            start = index + 1;
        }
    }
    terms.push((sign, compact[start..].to_owned()));

    let mut rotation = [0; 3];
    let mut translation = 0.;
    for (sign, term) in terms {
        if term.is_empty() {
            return Err(format!("invalid CIF symmetry coordinate: {expression}"));
        }
        if let Some(axis) = term
            .bytes()
            .position(|byte| matches!(byte, b'x' | b'y' | b'z'))
        {
            let variable = term.as_bytes()[axis];
            let coefficient = &term[..axis];
            let coefficient = if coefficient.is_empty() {
                1.
            } else {
                let coefficient = coefficient.trim_end_matches('*');
                parse_number(coefficient, "symmetry rotation coefficient")?
            };
            let coefficient = coefficient * f64::from(sign);
            if (coefficient - coefficient.round()).abs() > 1e-12 {
                return Err(format!("non-integer CIF symmetry rotation in {expression}"));
            }
            if term[axis + 1..].contains(['x', 'y', 'z']) {
                return Err(format!("invalid CIF symmetry coordinate: {expression}"));
            }
            let column = match variable {
                b'x' => 0,
                b'y' => 1,
                _ => 2,
            };
            rotation[column] += coefficient as i32;
        } else {
            translation += f64::from(sign) * parse_number(&term, "symmetry translation")?;
        }
    }
    Ok((rotation, translation.rem_euclid(1.)))
}

fn parse_xyz_operation(value: &str) -> Result<SymmetryOperation, String> {
    let coordinates = value.split(',').collect::<Vec<_>>();
    if coordinates.len() != 3 {
        return Err(format!(
            "CIF symmetry operation must have three coordinates: {value}"
        ));
    }
    let parsed = coordinates
        .iter()
        .map(|coordinate| parse_symmetry_component(coordinate))
        .collect::<Result<Vec<_>, _>>()?;
    let mut rotation = [[0; 3]; 3];
    let mut translation = [0.; 3];
    for row in 0..3 {
        rotation[row] = parsed[row].0;
        translation[row] = parsed[row].1;
    }
    Ok(SymmetryOperation {
        rotation,
        translation,
    })
}

fn normalized_space_group(symbol: &str) -> String {
    symbol
        .chars()
        .filter(|character| !character.is_ascii_whitespace() && *character != '_')
        .flat_map(char::to_lowercase)
        .collect()
}

fn operations_for_block(block: &Block<'_>) -> Result<Vec<SymmetryOperation>, String> {
    for (category, item) in [
        ("symmetry_equiv_pos", "as_xyz"),
        ("space_group_symop", "operation_xyz"),
    ] {
        let values = field_values(block, category, item);
        if !values.is_empty() {
            return values
                .iter()
                .map(|value| parse_xyz_operation(value))
                .collect();
        }
    }

    let number = [
        ("space_group", "it_number"),
        ("symmetry", "int_tables_number"),
    ]
    .iter()
    .find_map(|(category, item)| pair_value(block, category, item))
    .and_then(|value| parse_number(&value, "space group number").ok())
    .map(|number| number.round() as i32);

    if let Some(number) = number {
        if (1..=230).contains(&number) {
            let operations = operations_from_number(number, Setting::Standard, false)
                .map_err(|error| format!("cannot expand CIF space group {number}: {error}"))?;
            return Ok(operations.into_iter().map(Into::into).collect());
        }
    }

    for (category, item) in [
        ("space_group", "name_h-m_alt"),
        ("symmetry", "space_group_name_h-m"),
        ("space_group", "name_h-m_full"),
        ("symmetry", "space_group_name_h-m_"),
    ] {
        if let Some(symbol) = pair_value(block, category, item) {
            let normalized = normalized_space_group(&symbol);
            for hall_number in 1..=530 {
                let Some(entry) = hall_symbol_entry(hall_number) else {
                    continue;
                };
                if normalized == normalized_space_group(entry.hm_short)
                    || normalized == normalized_space_group(entry.hm_full)
                {
                    let operations = operations_from_number(
                        entry.number,
                        Setting::HallNumber(hall_number),
                        false,
                    )
                    .map_err(|error| format!("cannot expand CIF space group {symbol}: {error}"))?;
                    return Ok(operations.into_iter().map(Into::into).collect());
                }
            }
        }
    }
    Ok(vec![parse_xyz_operation("x,y,z")?])
}

fn element_number(symbol: &str) -> Result<u8, String> {
    let symbol = symbol.trim();
    if symbol.eq_ignore_ascii_case("d") || symbol.eq_ignore_ascii_case("t") {
        return Ok(1);
    }
    let mut characters = symbol.chars();
    let Some(first) = characters.next() else {
        return Err("CIF atom has an empty element symbol".into());
    };
    let mut normalized = first.to_ascii_uppercase().to_string();
    if let Some(second) = characters
        .next()
        .filter(|character| character.is_ascii_lowercase())
    {
        normalized.push(second);
    }
    let index = crate::elements::SYMBOLS
        .iter()
        .position(|candidate| *candidate == normalized)
        .ok_or_else(|| format!("unsupported CIF element symbol: {symbol}"))?;
    if index == 0 {
        return Err(format!("unsupported CIF element symbol: {symbol}"));
    }
    Ok(index as u8)
}

fn wrap_fractional(value: f64) -> f64 {
    let wrapped = value.rem_euclid(1.);
    if wrapped < 1e-12 || (1. - wrapped) < 1e-12 {
        0.
    } else {
        wrapped
    }
}

fn same_periodic_coordinate(left: [f64; 3], right: [f64; 3]) -> bool {
    (0..3).all(|axis| {
        let delta = (left[axis] - right[axis]).abs();
        delta.min(1. - delta) <= 1e-4
    })
}

fn parse_cif_block(block: &Block<'_>) -> Result<Structure, String> {
    let cell = lattice_from_cif(block)?;
    let (atom_sites, labels_column) =
        loop_column(block, "atom_site", "label").ok_or("CIF has no atom_site label loop")?;
    let type_symbols = loop_column(block, "atom_site", "type_symbol");
    let occupancy = loop_column(block, "atom_site", "occupancy");
    let fractional_columns = [
        loop_column(block, "atom_site", "fract_x").ok_or("CIF atom_site is missing fract_x")?,
        loop_column(block, "atom_site", "fract_y").ok_or("CIF atom_site is missing fract_y")?,
        loop_column(block, "atom_site", "fract_z").ok_or("CIF atom_site is missing fract_z")?,
    ];
    let operations = operations_for_block(block)?;
    let mut sites = Vec::<(u8, [f64; 3])>::new();
    for row in 0..atom_sites.row_count() {
        let label = loop_value(&atom_sites, labels_column, row)
            .ok_or("CIF atom_site has a missing label")?;
        let symbol = type_symbols
            .as_ref()
            .and_then(|(table, column)| loop_value(table, *column, row))
            .unwrap_or(label);
        let number = element_number(symbol)?;
        let amount = occupancy
            .as_ref()
            .and_then(|(table, column)| loop_value(table, *column, row))
            .map(|value| parse_number(value, "_atom_site_occupancy"))
            .transpose()?
            .unwrap_or(1.);
        if amount <= 0. {
            continue;
        }
        if (amount - 1.).abs() > 1e-8 {
            return Err(format!(
                "partially occupied CIF sites are not yet supported by the native structure contract ({label}: {amount})"
            ));
        }
        let mut fractional = [0.; 3];
        for axis in 0..3 {
            let (table, column) = fractional_columns[axis];
            let value = loop_value(&table, column, row)
                .ok_or("CIF atom_site has a missing fractional coordinate")?;
            let mut coordinate = parse_number(value, "_atom_site_fract_* ")?;
            for ideal in [1. / 3., 2. / 3.] {
                if ((coordinate / ideal) - 1.).abs() <= 1e-4 {
                    coordinate = ideal;
                }
            }
            fractional[axis] = coordinate;
        }
        for operation in &operations {
            let coordinate = std::array::from_fn(|axis| {
                wrap_fractional(
                    (0..3)
                        .map(|column| {
                            f64::from(operation.rotation[axis][column]) * fractional[column]
                        })
                        .sum::<f64>()
                        + operation.translation[axis],
                )
            });
            if let Some((existing_number, _)) = sites
                .iter()
                .find(|(_, existing)| same_periodic_coordinate(*existing, coordinate))
            {
                if *existing_number != number {
                    return Err(format!(
                        "disordered CIF sites overlap at fractional coordinate {coordinate:?}"
                    ));
                }
                continue;
            }
            sites.push((number, coordinate));
        }
    }
    if sites.is_empty() {
        return Err("CIF contains no occupied atom sites".into());
    }
    // Pymatgen sorts CIF-derived structures before returning them. Its default
    // species ordering follows atomic number; preserve generated order within
    // each element while matching that grouping.
    sites.sort_by_key(|(number, _)| *number);
    let atomic_numbers = sites.iter().map(|(number, _)| *number).collect();
    let positions_a = sites
        .iter()
        .map(|(_, fractional)| {
            std::array::from_fn(|cartesian| {
                (0..3)
                    .map(|axis| fractional[axis] * cell[axis][cartesian])
                    .sum()
            })
        })
        .collect();
    let structure = Structure {
        atomic_numbers,
        positions_a,
        cell_a: cell,
        pbc: [true; 3],
    };
    structure.validate()?;
    Ok(structure)
}

fn json_array3(value: &serde_json::Value, field: &str) -> Result<[f64; 3], String> {
    let values = value
        .as_array()
        .filter(|values| values.len() == 3)
        .ok_or_else(|| format!("Pymatgen JSON field `{field}` must contain three values"))?;
    let mut result = [0.; 3];
    for axis in 0..3 {
        result[axis] = values[axis]
            .as_f64()
            .filter(|value| value.is_finite())
            .ok_or_else(|| format!("Pymatgen JSON field `{field}` has an invalid number"))?;
    }
    Ok(result)
}

fn parse_mson_structure(value: &serde_json::Value) -> Result<Structure, String> {
    let lattice = value
        .get("lattice")
        .and_then(|lattice| lattice.get("matrix"))
        .and_then(serde_json::Value::as_array)
        .filter(|rows| rows.len() == 3)
        .ok_or("Pymatgen JSON Structure is missing a 3x3 lattice.matrix")?;
    let mut cell = [[0.; 3]; 3];
    for row in 0..3 {
        cell[row] = json_array3(&lattice[row], "lattice.matrix")?;
    }
    let pbc = value
        .get("lattice")
        .and_then(|lattice| lattice.get("pbc"))
        .and_then(serde_json::Value::as_array)
        .filter(|axes| axes.len() == 3)
        .map(|axes| {
            axes.iter()
                .map(|axis| axis.as_bool().ok_or("invalid lattice.pbc value".to_owned()))
                .collect::<Result<Vec<_>, _>>()
        })
        .transpose()?
        .map(|axes| [axes[0], axes[1], axes[2]])
        .unwrap_or([true; 3]);
    let sites = value
        .get("sites")
        .and_then(serde_json::Value::as_array)
        .ok_or("Pymatgen JSON Structure is missing its sites array")?;
    let mut atomic_numbers = Vec::with_capacity(sites.len());
    let mut positions_a = Vec::with_capacity(sites.len());
    for (index, site) in sites.iter().enumerate() {
        let species = site
            .get("species")
            .and_then(serde_json::Value::as_array)
            .filter(|species| species.len() == 1)
            .ok_or_else(|| format!("Pymatgen JSON site {index} is disordered"))?;
        let species = &species[0];
        let symbol = species
            .as_str()
            .or_else(|| species.get("element").and_then(serde_json::Value::as_str))
            .or_else(|| species.get("name").and_then(serde_json::Value::as_str))
            .ok_or_else(|| format!("Pymatgen JSON site {index} has no element symbol"))?;
        let occupancy = species
            .get("occu")
            .and_then(serde_json::Value::as_f64)
            .unwrap_or(1.);
        if (occupancy - 1.).abs() > 1e-8 {
            return Err(format!(
                "partially occupied Pymatgen JSON sites are not yet supported by the native structure contract (site {index}: {occupancy})"
            ));
        }
        atomic_numbers.push(element_number(symbol)?);
        let fractional = site
            .get("abc")
            .map(|value| json_array3(value, "sites[].abc"))
            .transpose()?;
        let cartesian = site
            .get("xyz")
            .map(|value| json_array3(value, "sites[].xyz"))
            .transpose()?;
        let position = if let Some(fractional) = fractional {
            std::array::from_fn(|cartesian| {
                (0..3)
                    .map(|axis| fractional[axis] * cell[axis][cartesian])
                    .sum()
            })
        } else {
            cartesian.ok_or_else(|| {
                format!("Pymatgen JSON site {index} has neither abc nor xyz coordinates")
            })?
        };
        positions_a.push(position);
    }
    let structure = Structure {
        atomic_numbers,
        positions_a,
        cell_a: cell,
        pbc,
    };
    structure.validate()?;
    Ok(structure)
}

fn lattice_from_lengths_angles(
    lengths: [f64; 3],
    angles_degrees: [f64; 3],
    format: &str,
) -> Result<[[f64; 3]; 3], String> {
    let [a, b, c] = lengths;
    let [alpha, beta, gamma] = angles_degrees.map(f64::to_radians);
    if lengths
        .iter()
        .any(|length| !length.is_finite() || *length <= 0.)
        || angles_degrees
            .iter()
            .any(|angle| !angle.is_finite() || *angle <= 0. || *angle >= 180.)
        || gamma.sin().abs() < 1e-12
    {
        return Err(format!("{format} lattice parameters are invalid"));
    }
    let ca = alpha.cos();
    let cb = beta.cos();
    let cg = gamma.cos();
    let sg = gamma.sin();
    let cx = c * cb;
    let cy = c * (ca - cb * cg) / sg;
    let cz_squared = c * c - cx * cx - cy * cy;
    if cz_squared <= 0. {
        return Err(format!(
            "{format} lattice parameters produce a non-positive cell volume"
        ));
    }
    Ok([
        [a, 0., 0.],
        [b * cg, b * sg, 0.],
        [cx, cy, cz_squared.sqrt()],
    ])
}

fn parse_cssr_structure(contents: &str) -> Result<Structure, String> {
    let lines = contents.lines().collect::<Vec<_>>();
    if lines.len() < 5 {
        return Err("CSSR structure is missing its lattice or atom section".into());
    }
    let parse_triplet = |line: &str, field: &str| -> Result<[f64; 3], String> {
        let values = line
            .split_whitespace()
            .take(3)
            .map(str::parse::<f64>)
            .collect::<Result<Vec<_>, _>>()
            .map_err(|_| format!("invalid CSSR {field}"))?;
        if values.len() != 3 || values.iter().any(|value| !value.is_finite()) {
            return Err(format!("invalid CSSR {field}"));
        }
        Ok([values[0], values[1], values[2]])
    };
    let cell = lattice_from_lengths_angles(
        parse_triplet(lines[0], "lattice lengths")?,
        parse_triplet(lines[1], "lattice angles")?,
        "CSSR",
    )?;
    let mut atomic_numbers = Vec::new();
    let mut positions_a = Vec::new();
    for line in &lines[4..] {
        let fields = line.split_whitespace().collect::<Vec<_>>();
        if fields.len() < 5 || fields[0].parse::<usize>().is_err() {
            continue;
        }
        // Pymatgen's CSSR reader ignores non-site lines and uses the first
        // word element and following three fractional-coordinate fields.
        let Ok(position) = [2, 3, 4]
            .map(|index| fields[index].parse::<f64>())
            .into_iter()
            .collect::<Result<Vec<_>, _>>()
            .map(|values| [values[0], values[1], values[2]])
        else {
            continue;
        };
        let number = element_number(fields[1])?;
        let cartesian = std::array::from_fn(|axis| {
            (0..3)
                .map(|vector| position[vector] * cell[vector][axis])
                .sum()
        });
        atomic_numbers.push(number);
        positions_a.push(cartesian);
    }
    if atomic_numbers.is_empty() {
        return Err("CSSR contains no atom sites".into());
    }
    let structure = Structure {
        atomic_numbers,
        positions_a,
        cell_a: cell,
        pbc: [true; 3],
    };
    structure.validate()?;
    Ok(structure)
}

fn parse_xsf_structure(contents: &str) -> Result<Structure, String> {
    let lines = contents.lines().collect::<Vec<_>>();
    let primitive_vectors = lines
        .iter()
        .position(|line| line.contains("PRIMVEC"))
        .ok_or("XSF structure is missing PRIMVEC")?;
    let coordinate_header = lines
        .iter()
        .position(|line| line.contains("PRIMCOORD"))
        .ok_or("XSF structure is missing PRIMCOORD")?;
    if primitive_vectors + 3 >= lines.len() || coordinate_header + 1 >= lines.len() {
        return Err("XSF structure has a truncated cell or atom section".into());
    }
    let parse_vector = |line: &str| -> Result<[f64; 3], String> {
        let values = line
            .split_whitespace()
            .take(3)
            .map(str::parse::<f64>)
            .collect::<Result<Vec<_>, _>>()
            .map_err(|_| "invalid XSF lattice vector".to_owned())?;
        if values.len() != 3 || values.iter().any(|value| !value.is_finite()) {
            return Err("invalid XSF lattice vector".into());
        }
        Ok([values[0], values[1], values[2]])
    };
    let cell = [
        parse_vector(lines[primitive_vectors + 1])?,
        parse_vector(lines[primitive_vectors + 2])?,
        parse_vector(lines[primitive_vectors + 3])?,
    ];
    let site_count = lines[coordinate_header + 1]
        .split_whitespace()
        .next()
        .ok_or("XSF PRIMCOORD is missing the site count")?
        .parse::<usize>()
        .map_err(|_| "invalid XSF PRIMCOORD site count")?;
    if coordinate_header + 2 + site_count > lines.len() {
        return Err("XSF PRIMCOORD atom section is truncated".into());
    }
    let mut atomic_numbers = Vec::with_capacity(site_count);
    let mut positions_a = Vec::with_capacity(site_count);
    for line in &lines[coordinate_header + 2..coordinate_header + 2 + site_count] {
        let fields = line.split_whitespace().collect::<Vec<_>>();
        if fields.len() < 4 {
            return Err("invalid XSF atom coordinate".into());
        }
        let number = if let Ok(number) = fields[0].parse::<u8>() {
            if number == 0 || usize::from(number) >= crate::elements::SYMBOLS.len() {
                return Err(format!("unsupported XSF atomic number: {number}"));
            }
            number
        } else {
            element_number(fields[0])?
        };
        let position = [1, 2, 3]
            .map(|index| fields[index].parse::<f64>())
            .into_iter()
            .collect::<Result<Vec<_>, _>>()
            .map_err(|_| "invalid XSF atom coordinate".to_owned())?;
        if position.iter().any(|coordinate| !coordinate.is_finite()) {
            return Err("invalid XSF atom coordinate".into());
        }
        atomic_numbers.push(number);
        positions_a.push([position[0], position[1], position[2]]);
    }
    if site_count == 0 {
        return Err("XSF contains no atom sites".into());
    }
    let structure = Structure {
        atomic_numbers,
        positions_a,
        cell_a: cell,
        pbc: [true; 3],
    };
    structure.validate()?;
    Ok(structure)
}

fn parse_yaml_structure(contents: &str) -> Result<Structure, String> {
    let value: serde_yaml_ng::Value = serde_yaml_ng::from_str(contents)
        .map_err(|error| format!("invalid Pymatgen YAML Structure: {error}"))?;
    let value = serde_json::to_value(value)
        .map_err(|error| format!("invalid Pymatgen YAML Structure: {error}"))?;
    parse_mson_structure(&value)
}

fn read_text(path: &Path) -> Result<String, String> {
    let bytes = mmcif_cif::read_file(path).map_err(|error| error.to_string())?;
    String::from_utf8(bytes).map_err(|error| format!("structure file is not UTF-8: {error}"))
}

fn read_mson(path: &Path) -> Result<Structure, String> {
    let bytes = mmcif_cif::read_file(path).map_err(|error| error.to_string())?;
    let value: serde_json::Value = serde_json::from_slice(&bytes)
        .map_err(|error| format!("invalid Pymatgen JSON Structure: {error}"))?;
    parse_mson_structure(&value)
}

fn read_cif(path: &Path) -> Result<Structure, String> {
    let document = Document::open(path).map_err(|error| error.to_string())?;
    let mut errors = Vec::new();
    for block in document.blocks() {
        if loop_column(&block, "atom_site", "label").is_none() {
            continue;
        }
        match parse_cif_block(&block) {
            Ok(structure) => return Ok(structure),
            Err(error) => errors.push(error),
        }
    }
    if errors.is_empty() {
        Err("CIF has no atom_site data block".into())
    } else {
        Err(errors.join("; "))
    }
}

fn read_cssr(path: &Path) -> Result<Structure, String> {
    parse_cssr_structure(&read_text(path)?)
}

fn read_xsf(path: &Path) -> Result<Structure, String> {
    parse_xsf_structure(&read_text(path)?)
}

fn read_yaml(path: &Path) -> Result<Structure, String> {
    parse_yaml_structure(&read_text(path)?)
}

#[derive(Clone, Copy)]
enum VasprunVectorKind {
    Cell,
    Fractional,
}

struct VasprunStructureBuilder {
    name: String,
    cell: Vec<[f64; 3]>,
    fractional: Vec<[f64; 3]>,
    vector_kind: Option<VasprunVectorKind>,
}

enum VasprunTextCapture {
    Vector(VasprunVectorKind),
    AtomSymbol,
}

fn xml_attribute(start: &BytesStart<'_>, name: &str) -> Result<Option<String>, String> {
    for attribute in start.attributes() {
        let attribute =
            attribute.map_err(|error| format!("invalid vasprun.xml attribute: {error}"))?;
        if attribute.key.as_ref() == name {
            return attribute
                .normalized_value(quick_xml::XmlVersion::Implicit1_0)
                .map(|value| Some(value.into_owned()))
                .map_err(|error| format!("invalid vasprun.xml attribute value: {error}"));
        }
    }
    Ok(None)
}

fn parse_xml_triplet(text: &str, field: &str) -> Result<[f64; 3], String> {
    let values = text
        .split_whitespace()
        .map(str::parse::<f64>)
        .collect::<Result<Vec<_>, _>>()
        .map_err(|_| format!("invalid vasprun.xml {field} vector"))?;
    if values.len() != 3 || values.iter().any(|value| !value.is_finite()) {
        return Err(format!("invalid vasprun.xml {field} vector"));
    }
    Ok([values[0], values[1], values[2]])
}

fn structure_from_vasprun_builder(
    builder: VasprunStructureBuilder,
    symbols: &[String],
) -> Result<Structure, String> {
    if builder.cell.len() != 3 || builder.fractional.len() != symbols.len() {
        return Err(format!(
            "vasprun.xml {} structure has {} cell vectors and {} positions for {} atoms",
            builder.name,
            builder.cell.len(),
            builder.fractional.len(),
            symbols.len()
        ));
    }
    let cell = [builder.cell[0], builder.cell[1], builder.cell[2]];
    let mut atomic_numbers = Vec::with_capacity(symbols.len());
    let mut positions_a = Vec::with_capacity(symbols.len());
    for (symbol, fractional) in symbols.iter().zip(builder.fractional) {
        // Pymatgen's Vasprun atominfo parser accepts these VASP aliases.
        let symbol = match symbol.as_str() {
            "X" => "Xe",
            "r" => "Zr",
            _ => symbol.as_str(),
        };
        atomic_numbers.push(element_number(symbol)?);
        positions_a.push(std::array::from_fn(|cartesian| {
            (0..3)
                .map(|axis| fractional[axis] * cell[axis][cartesian])
                .sum()
        }));
    }
    let structure = Structure {
        atomic_numbers,
        positions_a,
        cell_a: cell,
        pbc: [true; 3],
    };
    structure.validate()?;
    Ok(structure)
}

fn open_maybe_gzip_reader(path: &Path) -> Result<Box<dyn BufRead>, String> {
    use flate2::read::MultiGzDecoder;
    use std::io::BufRead as _;

    let file = File::open(path).map_err(|error| error.to_string())?;
    let mut input = BufReader::new(file);
    let compressed = input
        .fill_buf()
        .map_err(|error| error.to_string())?
        .starts_with(&[0x1f, 0x8b]);
    if compressed {
        Ok(Box::new(BufReader::new(MultiGzDecoder::new(input))))
    } else {
        Ok(Box::new(input))
    }
}

fn open_vasprun_reader(path: &Path) -> Result<Reader<Box<dyn BufRead>>, String> {
    let input = open_maybe_gzip_reader(path)?;
    let mut reader = Reader::from_reader(input);
    reader.config_mut().trim_text(true);
    Ok(reader)
}

fn read_volumetric_structure(path: &Path) -> Result<Structure, String> {
    use std::io::BufRead as _;

    let mut input = open_maybe_gzip_reader(path)?;
    let mut header = String::new();
    let mut line = String::new();
    let mut has_header = false;
    loop {
        line.clear();
        let bytes = input
            .read_line(&mut line)
            .map_err(|error| error.to_string())?;
        if bytes == 0 {
            return Err(
                "volumetric VASP file has no blank separator after its POSCAR header".into(),
            );
        }
        if line.trim().is_empty() {
            if has_header {
                break;
            }
            continue;
        }
        has_header = true;
        header.push_str(&line);
    }
    let structure = crate::poscar::parse_poscar(&header)?;

    // Validate and stream past volumetric values without allocating the often
    // enormous CHGCAR/LOCPOT grids. Structure.from_file needs the geometry;
    // retaining the charge/potential array would only inflate peak memory.
    let mut dataset_count = 0_usize;
    let mut remaining_values = 0_usize;
    loop {
        line.clear();
        let bytes = input
            .read_line(&mut line)
            .map_err(|error| error.to_string())?;
        if bytes == 0 {
            break;
        }
        let content = line.trim();
        if content.is_empty() {
            continue;
        }
        if content
            .to_ascii_lowercase()
            .starts_with("augmentation occupancies")
        {
            let count = content
                .split_whitespace()
                .last()
                .ok_or("invalid VASP augmentation occupancy header")?
                .parse::<usize>()
                .map_err(|_| "invalid VASP augmentation occupancy count")?;
            skip_volumetric_values(&mut *input, &mut line, count)?;
            continue;
        }
        if remaining_values == 0 {
            let dimensions = content
                .split_whitespace()
                .map(str::parse::<usize>)
                .collect::<Result<Vec<_>, _>>();
            let Ok(dimensions) = dimensions else {
                return Err(format!(
                    "invalid VASP volumetric grid dimensions: {content}"
                ));
            };
            if dimensions.len() != 3 || dimensions.contains(&0) {
                return Err(format!(
                    "invalid VASP volumetric grid dimensions: {content}"
                ));
            }
            remaining_values = dimensions[0]
                .checked_mul(dimensions[1])
                .and_then(|value| value.checked_mul(dimensions[2]))
                .ok_or("VASP volumetric grid size overflows usize")?;
            dataset_count += 1;
        } else {
            let values = content
                .split_whitespace()
                .map(str::parse::<f64>)
                .collect::<Result<Vec<_>, _>>()
                .map_err(|_| format!("invalid VASP volumetric data row: {content}"))?;
            if values.is_empty() || values.len() > remaining_values {
                return Err("VASP volumetric data count does not match its grid dimensions".into());
            }
            remaining_values -= values.len();
        }
    }
    if dataset_count == 0 {
        return Err("VASP volumetric file contains no grid data".into());
    }
    if remaining_values != 0 {
        return Err(format!(
            "VASP volumetric grid is missing {remaining_values} values"
        ));
    }
    Ok(structure)
}

fn skip_volumetric_values(
    input: &mut dyn BufRead,
    line: &mut String,
    mut remaining: usize,
) -> Result<(), String> {
    while remaining > 0 {
        line.clear();
        let bytes = input.read_line(line).map_err(|error| error.to_string())?;
        if bytes == 0 {
            return Err("VASP augmentation occupancy data ended unexpectedly".into());
        }
        let content = line.trim();
        if content.is_empty() {
            continue;
        }
        let values = content
            .split_whitespace()
            .map(str::parse::<f64>)
            .collect::<Result<Vec<_>, _>>()
            .map_err(|_| format!("invalid VASP augmentation occupancy data: {content}"))?;
        if values.is_empty() || values.len() > remaining {
            return Err("VASP augmentation occupancy count does not match its header".into());
        }
        remaining -= values.len();
    }
    Ok(())
}

fn read_vasprun(path: &Path) -> Result<Structure, String> {
    let mut reader = open_vasprun_reader(path)?;
    let mut buffer = Vec::new();
    let mut stack = Vec::<String>::new();
    let mut builder: Option<VasprunStructureBuilder> = None;
    let mut initial_structure = None;
    let mut final_structure = None;
    let mut atom_symbols = Vec::<String>::new();
    let mut atoms_array_depth = None;
    let mut atom_row: Option<Vec<String>> = None;
    let mut capture: Option<VasprunTextCapture> = None;
    let mut text = String::new();

    loop {
        let event = reader.read_event_into(&mut buffer).map_err(|error| {
            format!(
                "invalid vasprun.xml at byte {}: {error}",
                reader.error_position()
            )
        })?;
        match event {
            Event::Start(start) => {
                let tag = start.name().as_ref().to_owned();
                let attribute_name = xml_attribute(&start, "name")?;
                match tag.as_str() {
                    "structure" => {
                        if matches!(attribute_name.as_deref(), Some("initialpos" | "finalpos")) {
                            builder = Some(VasprunStructureBuilder {
                                name: attribute_name.unwrap(),
                                cell: Vec::new(),
                                fractional: Vec::new(),
                                vector_kind: None,
                            });
                        }
                    }
                    "varray" if builder.is_some() => {
                        if let Some(current) = builder.as_mut() {
                            current.vector_kind = match attribute_name.as_deref() {
                                Some("basis") => Some(VasprunVectorKind::Cell),
                                Some("positions") => Some(VasprunVectorKind::Fractional),
                                _ => None,
                            };
                        }
                    }
                    "array"
                        if attribute_name.as_deref() == Some("atoms")
                            && stack.iter().any(|ancestor| ancestor == "atominfo") =>
                    {
                        atoms_array_depth = Some(stack.len());
                    }
                    "rc" if atoms_array_depth.is_some() => atom_row = Some(Vec::new()),
                    "v" if builder
                        .as_ref()
                        .is_some_and(|current| current.vector_kind.is_some()) =>
                    {
                        capture = builder
                            .as_ref()
                            .and_then(|current| current.vector_kind)
                            .map(VasprunTextCapture::Vector);
                        text.clear();
                    }
                    "c" if atom_row.is_some() => {
                        capture = Some(VasprunTextCapture::AtomSymbol);
                        text.clear();
                    }
                    _ => {}
                }
                stack.push(tag);
            }
            Event::Text(value) => {
                if capture.is_some() {
                    let decoded = value.xml_content(quick_xml::XmlVersion::Implicit1_0);
                    text.push_str(&decoded);
                }
            }
            Event::CData(value) => {
                if capture.is_some() {
                    let decoded = value.xml_content(quick_xml::XmlVersion::Implicit1_0);
                    text.push_str(&decoded);
                }
            }
            Event::End(end) => {
                let tag = end.name();
                match tag.as_ref() {
                    "v" => {
                        if let Some(VasprunTextCapture::Vector(kind)) = capture.take() {
                            let vector = parse_xml_triplet(&text, "structure")?;
                            let current = builder
                                .as_mut()
                                .ok_or("vasprun.xml vector is outside a named structure")?;
                            match kind {
                                VasprunVectorKind::Cell => current.cell.push(vector),
                                VasprunVectorKind::Fractional => current.fractional.push(vector),
                            }
                        }
                    }
                    "c" => {
                        if matches!(capture.take(), Some(VasprunTextCapture::AtomSymbol)) {
                            if let Some(row) = atom_row.as_mut() {
                                row.push(text.trim().to_owned());
                            }
                        }
                    }
                    "rc" => {
                        if let Some(row) = atom_row.take() {
                            if let Some(symbol) = row.first().filter(|symbol| !symbol.is_empty()) {
                                atom_symbols.push(symbol.clone());
                            }
                        }
                    }
                    "array" => {
                        if atoms_array_depth == stack.len().checked_sub(1) {
                            atoms_array_depth = None;
                        }
                    }
                    "varray" => {
                        if let Some(current) = builder.as_mut() {
                            current.vector_kind = None;
                        }
                    }
                    "structure" => {
                        if let Some(current) = builder.take() {
                            match current.name.as_str() {
                                "initialpos" => initial_structure = Some(current),
                                "finalpos" => final_structure = Some(current),
                                _ => {}
                            }
                        }
                    }
                    _ => {}
                }
                stack.pop();
                text.clear();
            }
            Event::Eof => break,
            _ => {}
        }
        buffer.clear();
    }

    let builder = final_structure
        .or(initial_structure)
        .ok_or("vasprun.xml has neither an initialpos nor finalpos structure")?;
    structure_from_vasprun_builder(builder, &atom_symbols)
}

pub fn read_structure(path: &Path) -> Result<Structure, String> {
    let name = path
        .file_name()
        .and_then(|name| name.to_str())
        .unwrap_or_default()
        .to_ascii_lowercase();
    if name.starts_with("chgcar") || name.starts_with("locpot") {
        read_volumetric_structure(path)
    } else if name.ends_with(".nc") {
        crate::netcdf::read_structure(path)
    } else if name.ends_with(".cif")
        || name.ends_with(".mcif")
        || name.ends_with(".cif.gz")
        || name.ends_with(".mcif.gz")
    {
        read_cif(path)
    } else if name.starts_with("vasprun") && (name.ends_with(".xml") || name.ends_with(".xml.gz")) {
        read_vasprun(path)
    } else if name.ends_with(".cssr") || name.ends_with(".cssr.gz") {
        read_cssr(path)
    } else if name.ends_with(".xsf") || name.ends_with(".xsf.gz") {
        read_xsf(path)
    } else if name.ends_with(".yaml")
        || name.ends_with(".yml")
        || name.ends_with(".yaml.gz")
        || name.ends_with(".yml.gz")
    {
        read_yaml(path)
    } else if name.ends_with(".json")
        || name.ends_with(".mson")
        || name.ends_with(".json.gz")
        || name.ends_with(".mson.gz")
    {
        read_mson(path)
    } else {
        crate::poscar::read_poscar(path)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const NACL_FM3M: &str = "data_NaCl\n_space_group_name_H-M_alt 'F m -3 m'\n_space_group_IT_number 225\n_cell_length_a 5.64\n_cell_length_b 5.64\n_cell_length_c 5.64\n_cell_angle_alpha 90\n_cell_angle_beta 90\n_cell_angle_gamma 90\nloop_\n_atom_site_type_symbol\n_atom_site_label\n_atom_site_fract_x\n_atom_site_fract_y\n_atom_site_fract_z\n_atom_site_occupancy\nNa Na1 0 0 0 1\nCl Cl1 1/2 1/2 1/2 1\n";

    #[test]
    fn parses_rational_symmetry_coordinates() {
        let operation = parse_xyz_operation("-x+y+1/2, z, -y").unwrap();
        assert_eq!(operation.rotation, [[-1, 1, 0], [0, 0, 1], [0, -1, 0]]);
        assert_eq!(operation.translation, [0.5, 0., 0.]);
    }

    #[test]
    fn parses_uncertainty_numbers_and_triclinic_lattice() {
        let cif = "data_x\n_cell_length_a 5.0(1)\n_cell_length_b 6.0\n_cell_length_c 7.0\n_cell_angle_alpha 80\n_cell_angle_beta 95\n_cell_angle_gamma 105\nloop_\n_atom_site_label\n_atom_site_fract_x\n_atom_site_fract_y\n_atom_site_fract_z\nSi1 0 0 0\n";
        let document = Document::parse(cif).unwrap();
        let block = document.block(0).unwrap();
        let lattice = lattice_from_cif(&block).unwrap();
        assert!((lattice[0][0] - 5.).abs() < 1e-12);
        assert!((lattice[1][0] - 6. * 105_f64.to_radians().cos()).abs() < 1e-12);
    }

    #[test]
    fn expands_space_group_fallback_to_full_conventional_cell() {
        let document = Document::parse(NACL_FM3M).unwrap();
        let structure = parse_cif_block(&document.block(0).unwrap()).unwrap();
        assert_eq!(structure.atomic_numbers, [11, 11, 11, 11, 17, 17, 17, 17]);
        assert_eq!(structure.positions_a.len(), 8);
    }

    #[test]
    fn rejects_disordered_sites_instead_of_silently_dropping_occupancy() {
        let cif = NACL_FM3M.replace("Na Na1 0 0 0 1", "Na Na1 0 0 0 0.5");
        let document = Document::parse(cif).unwrap();
        let error = parse_cif_block(&document.block(0).unwrap()).unwrap_err();
        assert!(error.contains("partially occupied CIF sites"));
    }

    #[test]
    fn reads_pymatgen_mson_structure_without_changing_site_order() {
        let value = serde_json::json!({
            "@module": "pymatgen.core.structure",
            "@class": "Structure",
            "lattice": {
                "matrix": [[4.0, 0.0, 0.0], [0.0, 5.0, 0.0], [0.0, 0.0, 6.0]],
                "pbc": [true, true, true]
            },
            "sites": [
                {"species": [{"element": "Cl", "occu": 1.0}], "abc": [0.5, 0.5, 0.5]},
                {"species": [{"element": "Na", "occu": 1.0}], "abc": [0.0, 0.0, 0.0]}
            ]
        });
        let structure = parse_mson_structure(&value).unwrap();
        assert_eq!(structure.atomic_numbers, [17, 11]);
        assert_eq!(structure.positions_a, [[2.0, 2.5, 3.0], [0.0, 0.0, 0.0]]);
    }

    #[test]
    fn reads_cssr_fractional_sites_and_triclinic_lattice() {
        let contents = "5.6400 5.6400 5.6400\n90.00 90.00 90.00 SPGR =  1 P 1    OPT = 1\n2 0\n0 Na1 Cl1\n1 Na 0.0000 0.0000 0.0000\n2 Cl 0.5000 0.5000 0.5000\n";
        let structure = parse_cssr_structure(contents).unwrap();
        assert_eq!(structure.atomic_numbers, [11, 17]);
        assert_eq!(structure.positions_a, [[0.0; 3], [2.82; 3]]);
    }

    #[test]
    fn reads_xsf_primitive_cell_with_symbols_and_atomic_numbers() {
        let contents = "CRYSTAL\nPRIMVEC\n5.64 0 0\n0 5.64 0\n0 0 5.64\nPRIMCOORD\n2 1\nNa 0 0 0\n17 2.82 2.82 2.82\n";
        let structure = parse_xsf_structure(contents).unwrap();
        assert_eq!(structure.atomic_numbers, [11, 17]);
        assert_eq!(structure.positions_a, [[0.0; 3], [2.82; 3]]);
    }

    #[test]
    fn reads_mson_structure_encoded_as_yaml() {
        let contents = "'@module': pymatgen.core.structure\n'@class': Structure\nlattice:\n  matrix:\n    - [4.0, 0.0, 0.0]\n    - [0.0, 5.0, 0.0]\n    - [0.0, 0.0, 6.0]\n  pbc: [true, true, true]\nsites:\n  - species:\n      - element: Cl\n        occu: 1.0\n    abc: [0.5, 0.5, 0.5]\n  - species:\n      - element: Na\n        occu: 1.0\n    abc: [0.0, 0.0, 0.0]\n";
        let structure = parse_yaml_structure(contents).unwrap();
        assert_eq!(structure.atomic_numbers, [17, 11]);
        assert_eq!(structure.positions_a, [[2.0, 2.5, 3.0], [0.0, 0.0, 0.0]]);
    }

    #[test]
    fn rejects_partial_occupancy_instead_of_replacing_it_with_a_full_atom() {
        let value = serde_json::json!({
            "lattice": {"matrix": [[5.0, 0.0, 0.0], [0.0, 5.0, 0.0], [0.0, 0.0, 5.0]]},
            "sites": [{"species": [{"element": "Na", "occu": 0.5}], "abc": [0.0, 0.0, 0.0]}]
        });
        let error = parse_mson_structure(&value).unwrap_err();
        assert!(error.contains("partially occupied Pymatgen JSON sites"));
    }

    #[test]
    fn reads_chgcar_and_locpot_geometry_while_streaming_grid_values() {
        let contents = "NaCl\n1.0\n5.64 0 0\n0 5.64 0\n0 0 5.64\nNa Cl\n1 1\nDirect\n0 0 0\n0.5 0.5 0.5\n\n2 2 2\n0.1 0.2 0.3 0.4\n0.5 0.6 0.7 0.8\naugmentation occupancies 1 2\n0.3 0.4\n\n2 2 2\n1 2 3 4\n5 6 7 8\n";
        for name in ["CHGCAR", "LOCPOT"] {
            let path = std::env::temp_dir().join(format!(
                "{name}-macer-rust-{}-{}.dat",
                std::process::id(),
                std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .unwrap()
                    .as_nanos()
            ));
            std::fs::write(&path, contents).unwrap();
            let structure = read_structure(&path).unwrap();
            assert_eq!(structure.atomic_numbers, [11, 17]);
            assert_eq!(structure.positions_a, [[0.0; 3], [2.82; 3]]);
            let _ = std::fs::remove_file(path);
        }
    }

    #[test]
    fn reads_gzip_compressed_chgcar() {
        use flate2::write::GzEncoder;
        use flate2::Compression;
        use std::io::Write as _;

        let contents = "NaCl\n1.0\n5.64 0 0\n0 5.64 0\n0 0 5.64\nNa Cl\n1 1\nDirect\n0 0 0\n0.5 0.5 0.5\n\n1 1 1\n42\n";
        let path = std::env::temp_dir().join(format!(
            "CHGCAR-macer-rust-{}-{}.gz",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let file = std::fs::File::create(&path).unwrap();
        let mut encoder = GzEncoder::new(file, Compression::default());
        encoder.write_all(contents.as_bytes()).unwrap();
        encoder.finish().unwrap();
        let structure = read_structure(&path).unwrap();
        assert_eq!(structure.atomic_numbers, [11, 17]);
        let _ = std::fs::remove_file(path);
    }
}
