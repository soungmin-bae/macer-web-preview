//! Native cell/statistics analysis for `macer util xdatcar-tool`.

use crate::plots::write_cell_evolution_plot;
use crate::poscar::read_poscar;
use crate::trajectory::{determinant, inverse, read, Trajectory};
use serde_json::{json, Value};
use std::collections::BTreeMap;
use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::{Path, PathBuf};

pub const HELP: &str = r#"Analyze cell parameters and statistics from XDATCAR or ASE md.traj.

USAGE:
    macer-rust util xdatcar-tool -i|--input <TRAJECTORY> [OPTIONS]

Core options:
    --dt <FS>                  Timestep for the time axis and --skip/--until
    --skip <PS>                Skip the initial time when averaging
    --until <PS>               End time for the averaging window
    --skip-frames <N>          Skip the first N trajectory frames
    --last-percent <PCT>       Average over the final percentage of frames
    --window-start <FRAME>     First averaging frame (inclusive)
    --window-end <FRAME>       Last averaging frame (inclusive)
    --auto-skip                Detect an equilibration start from cell volume
    --outlier-z <Z>            Exclude cell/volume outliers by z-score
    -o|--output <PREFIX>       Output prefix (default: cell_evolution)
    --poscar <PATH>            Write the averaged POSCAR
    --avg-poscar [PATH]        Write the averaged POSCAR (default: POSCAR-average)
    --no-report                Do not write the YAML-compatible JSON report
    --rdf                      Write pair-resolved RDF PDF and numeric data table
    --rmax <ANGSTROM>          RDF cutoff (default: 10.0; reduced for cell safety)
    --bins <N>                 RDF radial bins (default: 200)
    --adp                      Write ADP tables, CIF, summary and averaged POSCAR
    --displacement-map         Also write per-atom displacement statistics
    --symmetry-sample <N>      Sample N frames for space-group tracking

Outputs include a log, cell-evolution PDF, strain table, block table and report.
RDF adds pair-resolved PDF/data output. ADP adds averaged POSCAR, ADP table,
CIF and summary; --displacement-map adds per-atom displacement statistics.
Symmetry sampling writes a CSV table and adds space-group counts to the report.
"#;

#[derive(Debug)]
struct Options {
    inputs: Vec<PathBuf>,
    dt_fs: Option<f64>,
    skip_ps: f64,
    until_ps: Option<f64>,
    skip_frames: usize,
    interval: usize,
    output: String,
    poscar: Option<String>,
    avg_poscar: Option<String>,
    auto_skip: bool,
    outlier_z: Option<f64>,
    block_count: i64,
    last_percent: Option<f64>,
    window_start: Option<isize>,
    window_end: Option<isize>,
    reference_poscar: Option<String>,
    symmetry_sample: i64,
    displacement_map: bool,
    no_report: bool,
    temperature_k: Option<f64>,
    rdf: bool,
    adp: bool,
    rmax: f64,
    bins: usize,
}

impl Default for Options {
    fn default() -> Self {
        Self {
            inputs: Vec::new(),
            dt_fs: None,
            skip_ps: 0.0,
            until_ps: None,
            skip_frames: 0,
            interval: 1,
            output: "cell_evolution".into(),
            poscar: None,
            avg_poscar: None,
            auto_skip: false,
            outlier_z: None,
            block_count: 10,
            last_percent: None,
            window_start: None,
            window_end: None,
            reference_poscar: None,
            symmetry_sample: 0,
            displacement_map: false,
            no_report: false,
            temperature_k: None,
            rdf: false,
            adp: false,
            rmax: 10.0,
            bins: 200,
        }
    }
}

#[derive(Debug)]
struct CellAnalysis {
    summary: Value,
    average_volume: f64,
}

pub(crate) fn run(arguments: impl Iterator<Item = String>) -> Result<(), String> {
    let options = parse_options(arguments)?;
    if options.inputs.is_empty() {
        return Err(format!("missing required -i/--input\n{HELP}"));
    }
    if options.interval == 0 {
        return Err("--interval must be at least 1".into());
    }
    if options.rdf && (!options.rmax.is_finite() || options.rmax <= 0.0 || options.bins == 0) {
        return Err("--rdf requires --rmax > 0 and --bins >= 1".into());
    }
    let multiple = options.inputs.len() > 1;
    let mut summaries = Vec::new();
    let mut volume_avgs = Vec::new();
    for input in &options.inputs {
        let stem = input
            .file_stem()
            .and_then(|value| value.to_str())
            .unwrap_or("trajectory");
        let output = if multiple {
            format!("{}-{stem}", options.output)
        } else {
            options.output.clone()
        };
        let poscar_base = options
            .poscar
            .clone()
            .or_else(|| options.adp.then(|| "POSCAR".to_owned()));
        let poscar = if multiple {
            poscar_base.as_ref().map(|path| format!("{path}-{stem}"))
        } else {
            poscar_base
        };
        let avg_poscar = if multiple {
            options
                .avg_poscar
                .as_ref()
                .map(|path| format!("{path}-{stem}"))
        } else {
            options.avg_poscar.clone()
        };
        let options_for_input = InputOptions {
            input,
            output_prefix: &output,
            poscar_out: poscar.as_deref(),
            avg_poscar_out: avg_poscar.as_deref(),
        };
        match analyze_one(&options, options_for_input) {
            Ok(analysis) => {
                if options.rdf {
                    run_rdf(input, &format!("{output}_rdf"), options.rmax, options.bins)?;
                }
                volume_avgs.push(analysis.average_volume);
                summaries.push(analysis.summary);
            }
            Err(_) => {}
        }
    }
    if multiple && summaries.len() > 1 {
        let min = volume_avgs.iter().copied().fold(f64::INFINITY, f64::min);
        let max = volume_avgs
            .iter()
            .copied()
            .fold(f64::NEG_INFINITY, f64::max);
        let compare = json!({
            "n_runs": summaries.len(),
            "runs": summaries,
            "volume_compare": {
                "min_avg_vol": min,
                "max_avg_vol": max,
                "delta_avg_vol": max - min,
            }
        });
        let path = PathBuf::from(format!("{}-comparison.yaml", options.output));
        fs::write(
            &path,
            serde_json::to_vec_pretty(&compare).map_err(|e| e.to_string())?,
        )
        .map_err(|e| e.to_string())?;
        println!("Multi-run comparison saved: {}", path.display());
    }
    Ok(())
}

fn run_rdf(input: &Path, output_prefix: &str, rmax: f64, bins: usize) -> Result<(), String> {
    println!("Reading trajectory for RDF: {}", input.display());
    let trajectory = read(input)?;
    let result = crate::rdf::compute(&trajectory, rmax, bins)?;
    println!("Using last {} frames for RDF averaging.", result.n_frames);
    if result.safe_rmax < rmax {
        println!(
            "Requested r_max={rmax:.3} is too large for cell; using {:.3} instead.",
            result.safe_rmax
        );
    }
    for curve in &result.curves {
        println!("  - Calculating RDF for {}...", curve.label);
    }
    let pdf_path = PathBuf::from(format!("{output_prefix}.pdf"));
    let data_path = PathBuf::from(format!("{output_prefix}.dat"));
    crate::plots::write_rdf_plot(&pdf_path, &result)?;
    crate::rdf::write_data(&data_path, &result)?;
    println!("RDF data saved to {}", data_path.display());
    println!("RDF plot saved to {}", pdf_path.display());
    Ok(())
}

struct InputOptions<'a> {
    input: &'a Path,
    output_prefix: &'a str,
    poscar_out: Option<&'a str>,
    avg_poscar_out: Option<&'a str>,
}

fn parse_options(arguments: impl Iterator<Item = String>) -> Result<Options, String> {
    let mut options = Options::default();
    let mut arguments = arguments.peekable();
    while let Some(argument) = arguments.next() {
        if argument == "-h" || argument == "--help" {
            print!("{HELP}");
            return Ok(options);
        }
        let (key, inline) = argument
            .split_once('=')
            .map(|(key, value)| (key.to_owned(), Some(value.to_owned())))
            .unwrap_or((argument.clone(), None));
        if key == "-i" || key == "--input" {
            if let Some(value) = inline {
                options.inputs.push(PathBuf::from(value));
            } else {
                while let Some(value) = arguments.peek() {
                    if value.starts_with('-') {
                        break;
                    }
                    options
                        .inputs
                        .push(PathBuf::from(arguments.next().unwrap()));
                }
                if options.inputs.is_empty() {
                    return Err("missing value for --input".into());
                }
            }
            continue;
        }
        match key.as_str() {
            "--auto-skip" => options.auto_skip = true,
            "--no-report" => options.no_report = true,
            "--rdf" => options.rdf = true,
            "--adp" => options.adp = true,
            "--displacement-map" => options.displacement_map = true,
            "--dt" => options.dt_fs = Some(parse_value(&key, inline, &mut arguments)?),
            "--skip" => options.skip_ps = parse_value(&key, inline, &mut arguments)?,
            "--until" => options.until_ps = Some(parse_value(&key, inline, &mut arguments)?),
            "--skip-frames" => options.skip_frames = parse_value(&key, inline, &mut arguments)?,
            "--interval" => options.interval = parse_value(&key, inline, &mut arguments)?,
            "-o" | "--output" => options.output = parse_string(&key, inline, &mut arguments)?,
            "--poscar" => options.poscar = Some(parse_string(&key, inline, &mut arguments)?),
            "--avg-poscar" => {
                options.avg_poscar = Some(match inline {
                    Some(value) => value,
                    None if arguments
                        .peek()
                        .is_some_and(|value| !value.starts_with('-')) =>
                    {
                        arguments.next().unwrap()
                    }
                    None => "POSCAR-average".into(),
                })
            }
            "--outlier-z" => options.outlier_z = Some(parse_value(&key, inline, &mut arguments)?),
            "--block-count" => options.block_count = parse_value(&key, inline, &mut arguments)?,
            "--last-percent" => {
                options.last_percent = Some(parse_value(&key, inline, &mut arguments)?)
            }
            "--window-start" => {
                options.window_start = Some(parse_value(&key, inline, &mut arguments)?)
            }
            "--window-end" => options.window_end = Some(parse_value(&key, inline, &mut arguments)?),
            "--reference-poscar" => {
                options.reference_poscar = Some(parse_string(&key, inline, &mut arguments)?)
            }
            "--symmetry-sample" => {
                options.symmetry_sample = parse_value(&key, inline, &mut arguments)?
            }
            "--temperature-k" => {
                options.temperature_k = Some(parse_value(&key, inline, &mut arguments)?)
            }
            "--rmax" => options.rmax = parse_value(&key, inline, &mut arguments)?,
            "--bins" => options.bins = parse_value(&key, inline, &mut arguments)?,
            "--xdatcar" | "--no-rdf" => return Err(format!("unsupported option: {key}")),
            _ => return Err(format!("unexpected argument: {argument}\n{HELP}")),
        }
    }
    Ok(options)
}

fn parse_value<T: std::str::FromStr>(
    key: &str,
    inline: Option<String>,
    arguments: &mut impl Iterator<Item = String>,
) -> Result<T, String> {
    let value = inline
        .or_else(|| arguments.next())
        .ok_or_else(|| format!("missing value for {key}"))?;
    value
        .parse::<T>()
        .map_err(|_| format!("invalid value for {key}: {value}"))
}

fn parse_string(
    key: &str,
    inline: Option<String>,
    arguments: &mut impl Iterator<Item = String>,
) -> Result<String, String> {
    inline
        .or_else(|| arguments.next())
        .ok_or_else(|| format!("missing value for {key}"))
}

fn analyze_one(options: &Options, paths: InputOptions<'_>) -> Result<CellAnalysis, String> {
    if !paths.input.exists() {
        println!(
            "Error: Trajectory file '{}' not found.",
            paths.input.display()
        );
        return Err("input trajectory not found".into());
    }
    let mut interval = options.interval;
    if interval == 1 {
        if let Some(detected) = crate::md_conductivity::detect_interval(paths.input) {
            interval = detected;
            println!("Auto-detected interval (frame saving frequency): {interval}");
        }
    }
    let mut prefix = paths.output_prefix;
    if let Some(value) = prefix.strip_suffix(".pdf") {
        prefix = value;
    }
    let prefix_path = if prefix.contains('/') || prefix.contains('\\') {
        PathBuf::from(prefix)
    } else {
        paths
            .input
            .parent()
            .unwrap_or_else(|| Path::new("."))
            .join(prefix)
    };
    let log_path = prefix_path.with_extension("log");
    let plot_path = prefix_path.with_extension("pdf");
    let parent = paths.input.parent().unwrap_or_else(|| Path::new("."));
    let poscar_base = paths.poscar_out.map(|value| resolve_path(value, parent));
    let avg_path = if let Some(value) = paths.avg_poscar_out {
        Some(resolve_path(value, parent))
    } else if let Some(base) = &poscar_base {
        Some(append_average_suffix(base))
    } else {
        None
    };
    let mut log = String::new();
    let run_summary = format_run_summary(options);
    log.push_str(&format!(
        "{} Cell Evolution Analysis {}\n{}\nInput: {}\nTime step (dt): {} fs\nInterval (sampling step): {interval}\nSkip first: {:?} ps\n\n",
        "---".repeat(10),
        "---".repeat(10),
        run_summary,
        paths.input.display(),
        options.dt_fs.map_or_else(|| "auto/None".into(), |x| format!("{x:?}")),
        options.skip_ps
    ));
    fs::write(&log_path, &log).map_err(|e| e.to_string())?;
    log_line(
        &mut log,
        &log_path,
        &format!("Reading trajectory: {} ...", paths.input.display()),
    )?;
    let trajectory = match read(paths.input) {
        Ok(value) => value,
        Err(error) => {
            println!("Error reading trajectory: {error}");
            return Err(error);
        }
    };
    let n = trajectory.cells_a.len();
    if n == 0 {
        println!("Error: Empty trajectory.");
        return Err("empty trajectory".into());
    }
    let (a, b, c, volume) = cell_properties(&trajectory.cells_a);
    let mut time_ps = options.dt_fs.map(|dt| {
        (0..n)
            .map(|index| index as f64 * dt * interval as f64 * 1.0e-3)
            .collect::<Vec<_>>()
    });
    if time_ps.is_none() {
        if let Some(frame_dt) = detect_frame_dt_ps(paths.input) {
            time_ps = Some((0..n).map(|index| index as f64 * frame_dt).collect());
            log_line(
                &mut log,
                &log_path,
                &format!("Auto-detected frame spacing from md.csv: {frame_dt:.6} ps/frame"),
            )?;
        } else {
            log_line(&mut log, &log_path, "Warning: --dt not provided and md.csv time info not found. Using frame index axis.")?;
        }
    }
    let (mask, selection) = select_window(
        options,
        [&a, &b, &c, &volume],
        time_ps.as_deref(),
        &mut log,
        &log_path,
    )?;
    let selected = mask
        .iter()
        .enumerate()
        .filter_map(|(i, keep)| keep.then_some(i))
        .collect::<Vec<_>>();
    if selected.is_empty() {
        return Err("averaging selection has no frames".into());
    }
    let selected_a = selected.iter().map(|&i| a[i]).collect::<Vec<_>>();
    let selected_b = selected.iter().map(|&i| b[i]).collect::<Vec<_>>();
    let selected_c = selected.iter().map(|&i| c[i]).collect::<Vec<_>>();
    let selected_v = selected.iter().map(|&i| volume[i]).collect::<Vec<_>>();
    let avgs = [
        mean(&selected_a),
        mean(&selected_b),
        mean(&selected_c),
        mean(&selected_v),
    ];
    let stds = [
        population_std(&selected_a),
        population_std(&selected_b),
        population_std(&selected_c),
        population_std(&selected_v),
    ];
    if let Some(time) = &time_ps {
        let first = time[*selected.first().unwrap()];
        let last = time[*selected.last().unwrap()];
        log_line(
            &mut log,
            &log_path,
            &format!("Total time: {:.2} ps", time[n - 1]),
        )?;
        log_line(
            &mut log,
            &log_path,
            &format!("Averaging window: {selection}"),
        )?;
        log_line(
            &mut log,
            &log_path,
            &format!(
                "Averaging over: {:.2} ps ({} frames)",
                last - first,
                selected.len()
            ),
        )?;
    } else {
        log_line(&mut log, &log_path, &format!("Total frames: {n}"))?;
        log_line(
            &mut log,
            &log_path,
            &format!("Averaging window: {selection} (start={})", selected[0]),
        )?;
        log_line(
            &mut log,
            &log_path,
            &format!("Averaging over: {} frames", selected.len()),
        )?;
    }
    log_line(
        &mut log,
        &log_path,
        "----------------------------------------",
    )?;
    log_line(&mut log, &log_path, "      Mean      Std      (Unit)")?;
    log_line(
        &mut log,
        &log_path,
        &format!(" a:   {:.4}    {:.4}    Ang", avgs[0], stds[0]),
    )?;
    log_line(
        &mut log,
        &log_path,
        &format!(" b:   {:.4}    {:.4}    Ang", avgs[1], stds[1]),
    )?;
    log_line(
        &mut log,
        &log_path,
        &format!(" c:   {:.4}    {:.4}    Ang", avgs[2], stds[2]),
    )?;
    log_line(
        &mut log,
        &log_path,
        &format!(" Vol: {:.4}    {:.4}    Ang^3", avgs[3], stds[3]),
    )?;
    log_line(
        &mut log,
        &log_path,
        "----------------------------------------",
    )?;

    let stats = [
        scalar_stats(&selected_a),
        scalar_stats(&selected_b),
        scalar_stats(&selected_c),
        scalar_stats(&selected_v),
    ];
    let x_selected = if let Some(time) = &time_ps {
        selected.iter().map(|&i| time[i]).collect::<Vec<_>>()
    } else {
        selected.iter().map(|&i| i as f64).collect()
    };
    let drifts = [
        linear_slope(&x_selected, &selected_a),
        linear_slope(&x_selected, &selected_b),
        linear_slope(&x_selected, &selected_c),
        linear_slope(&x_selected, &selected_v),
    ];
    log_line(&mut log, &log_path, "Detailed stats (selected window):")?;
    for (name, values) in [
        ("a", &stats[0]),
        ("b", &stats[1]),
        ("c", &stats[2]),
        ("V", &stats[3]),
    ] {
        log_line(
            &mut log,
            &log_path,
            &format!(
                "  {name}: min={:.4} max={:.4} p05={:.4} p95={:.4}",
                values.min, values.max, values.p05, values.p95
            ),
        )?;
    }
    let x_unit = if time_ps.is_some() { "ps" } else { "frame" };
    log_line(
        &mut log,
        &log_path,
        &format!(
            "Drift slopes (per {x_unit}): da={:.6e}, db={:.6e}, dc={:.6e}, dV={:.6e}",
            drifts[0], drifts[1], drifts[2], drifts[3]
        ),
    )?;

    let blocks = block_statistics(&selected_v, options.block_count.max(1) as usize);
    if !blocks.is_empty() {
        let block_path = prefix_path.with_extension("blocks.dat");
        let mut text = String::from("# block start_idx end_idx mean_vol std_vol\n");
        for (i, start, end, average, std) in &blocks {
            text.push_str(&format!(
                "{i:4} {start:8} {end:8} {:>15} {:>15}\n",
                scientific_e8(*average),
                scientific_e8(*std)
            ));
        }
        fs::write(&block_path, text).map_err(|e| e.to_string())?;
        log_line(
            &mut log,
            &log_path,
            &format!("Block statistics saved to: {}", block_path.display()),
        )?;
    }

    let (strain_summary, strain_data) =
        compute_strain(&trajectory, options.reference_poscar.as_deref(), &mask);
    let mut strain_summary_value = Value::Null;
    if let (Some(summary), Some(rows)) = (strain_summary, strain_data) {
        let strain_path = prefix_path.with_extension("strain.dat");
        let mut text = String::from("# idx exx eyy ezz eyz exz exy dV_over_V\n");
        for (i, row) in rows.iter().enumerate() {
            text.push_str(&format!(
                "{i:8} {:>15} {:>15} {:>15} {:>15} {:>15} {:>15} {:>15}\n",
                scientific_e8(row[0]),
                scientific_e8(row[1]),
                scientific_e8(row[2]),
                scientific_e8(row[3]),
                scientific_e8(row[4]),
                scientific_e8(row[5]),
                scientific_e8(row[6])
            ));
        }
        fs::write(&strain_path, text).map_err(|e| e.to_string())?;
        strain_summary_value = json!(summary);
        log_line(
            &mut log,
            &log_path,
            &format!("Strain data saved to: {}", strain_path.display()),
        )?;
    } else {
        log_line(
            &mut log,
            &log_path,
            "Warning: strain analysis skipped: reference cell is singular or unavailable",
        )?;
    }

    let mut symmetry_counts = json!({});
    if options.symmetry_sample > 0 {
        let samples = crate::symmetry::analyze(&trajectory, options.symmetry_sample as usize);
        let mut csv = String::from("frame,spacegroup\n");
        for (frame, spacegroup) in &samples.rows {
            csv.push_str(&format!("{frame},{spacegroup}\n"));
        }
        let symmetry_path = prefix_path.with_extension("symmetry.csv");
        match fs::write(&symmetry_path, csv) {
            Ok(()) => {
                symmetry_counts = json!(samples.counts);
                log_line(
                    &mut log,
                    &log_path,
                    &format!("Symmetry tracking saved to: {}", symmetry_path.display()),
                )?;
            }
            Err(error) => log_line(
                &mut log,
                &log_path,
                &format!("Warning: symmetry tracking skipped: {error}"),
            )?,
        }
    }

    let temperature = options
        .temperature_k
        .or_else(|| detect_temperature_k(paths.input));
    let bulk_modulus = temperature.and_then(|temp| {
        let variance = population_variance(&selected_v);
        if variance <= 1.0e-16 {
            return None;
        }
        let mean_m3 = avgs[3] * 1.0e-30;
        let variance_m6 = variance * 1.0e-60;
        Some((1.380_649e-23 * temp * mean_m3 / variance_m6) / 1.0e9)
    });
    if let (Some(modulus), Some(temp)) = (bulk_modulus, temperature) {
        log_line(
            &mut log,
            &log_path,
            &format!("Bulk modulus estimate from fluctuations: {modulus:.3} GPa (T={temp:.2} K)"),
        )?;
    }

    let x_plot = time_ps
        .clone()
        .unwrap_or_else(|| (0..n).map(|i| i as f64).collect());
    let start_idx = if options.skip_frames > 0 {
        options.skip_frames.min(n - 1)
    } else {
        selected[0]
    };
    let end_idx = *selected.last().unwrap();
    let start_x = x_plot[start_idx];
    let end_x = x_plot[end_idx];
    let averaged = if avg_path.is_some() {
        match average_structure(&trajectory, &selected) {
            Ok(averaged) => {
                if let Some(target) = &avg_path {
                    match write_poscar(
                        target,
                        &trajectory.atomic_numbers,
                        averaged.0,
                        averaged.1.clone(),
                    ) {
                        Ok(()) => log_line(
                            &mut log,
                            &log_path,
                            &format!("Averaged structure saved to: {}", target.display()),
                        )?,
                        Err(error) => log_line(
                            &mut log,
                            &log_path,
                            &format!("Error calculating averaged structure: {error}"),
                        )?,
                    }
                }
                Some(averaged)
            }
            Err(error) => {
                log_line(
                    &mut log,
                    &log_path,
                    &format!("Error calculating averaged structure: {error}"),
                )?;
                None
            }
        }
    } else {
        log_line(
            &mut log,
            &log_path,
            "Average-structure generation skipped (set --poscar or --avg-poscar to enable).",
        )?;
        None
    };

    let mut adp_species_summary = json!({});
    let mut adp_top_sites = json!([]);
    if options.adp {
        if let (Some(base_path), Some((average_cell, average_fractional))) =
            (poscar_base.as_deref(), averaged.as_ref())
        {
            match write_adp_outputs(
                Path::new(base_path),
                &trajectory,
                &selected,
                *average_cell,
                average_fractional,
                options.displacement_map,
            ) {
                Ok((species, top_sites)) => {
                    adp_species_summary = species;
                    adp_top_sites = top_sites;
                    log_line(
                        &mut log,
                        &log_path,
                        &format!(
                            "ADP table saved to: {}",
                            Path::new(base_path).with_extension("adp.dat").display()
                        ),
                    )?;
                    log_line(
                        &mut log,
                        &log_path,
                        &format!(
                            "ADP CIF saved to: {}",
                            Path::new(base_path).with_extension("adp.cif").display()
                        ),
                    )?;
                    log_line(
                        &mut log,
                        &log_path,
                        &format!(
                            "ADP summary saved to: {}",
                            Path::new(base_path)
                                .with_extension("adp.summary.dat")
                                .display()
                        ),
                    )?;
                    if options.displacement_map {
                        log_line(
                            &mut log,
                            &log_path,
                            &format!(
                                "Displacement map saved to: {}",
                                Path::new(base_path)
                                    .with_extension("displacement.dat")
                                    .display()
                            ),
                        )?;
                    }
                }
                Err(error) => log_line(
                    &mut log,
                    &log_path,
                    &format!("Error calculating/saving ADP outputs: {error}"),
                )?,
            }
        }
    }
    write_cell_evolution_plot(
        &plot_path,
        &x_plot,
        if time_ps.is_some() {
            "Time (ps)"
        } else {
            "Frame index"
        },
        &a,
        &b,
        &c,
        &volume,
        start_x,
        end_x,
        avgs,
        &selection,
    )?;
    log_line(
        &mut log,
        &log_path,
        &format!("Plot saved to {}", plot_path.display()),
    )?;
    log_line(
        &mut log,
        &log_path,
        &format!("Log saved to {}", log_path.display()),
    )?;

    let report = json!({
        "input": paths.input.display().to_string(),
        "selection": selection,
        "n_frames_total": n,
        "n_frames_selected": selected.len(),
        "avg": { "a": avgs[0], "b": avgs[1], "c": avgs[2], "vol": avgs[3] },
        "std": { "a": stds[0], "b": stds[1], "c": stds[2], "vol": stds[3] },
        "stats": { "a": stats[0], "b": stats[1], "c": stats[2], "vol": stats[3] },
        "drift_per_axis_unit": { "a": drifts[0], "b": drifts[1], "c": drifts[2], "vol": drifts[3] },
        "temperature_k": temperature,
        "bulk_modulus_estimate_gpa": bulk_modulus,
        "strain_summary": strain_summary_value,
        "symmetry_counts": symmetry_counts,
        "adp_species_summary": adp_species_summary,
        "adp_top_sites": adp_top_sites,
    });
    if !options.no_report {
        let report_path = prefix_path.with_extension("report.yaml");
        fs::write(
            &report_path,
            serde_json::to_vec_pretty(&report).map_err(|e| e.to_string())?,
        )
        .map_err(|e| e.to_string())?;
        log_line(
            &mut log,
            &log_path,
            &format!("Report bundle saved to: {}", report_path.display()),
        )?;
    }

    Ok(CellAnalysis {
        summary: report,
        average_volume: avgs[3],
    })
}

fn resolve_path(path: &str, directory: &Path) -> PathBuf {
    let path = PathBuf::from(path);
    if path.is_absolute() || path.components().count() > 1 {
        path
    } else {
        directory.join(path)
    }
}

fn append_average_suffix(path: &Path) -> PathBuf {
    let extension = path.extension().and_then(|value| value.to_str());
    let stem = path
        .file_stem()
        .and_then(|value| value.to_str())
        .unwrap_or("POSCAR");
    let name = if stem.ends_with("-average") {
        stem.to_owned()
    } else {
        format!("{stem}-average")
    };
    match extension {
        Some(ext) => path.with_file_name(format!("{name}.{ext}")),
        None => path.with_file_name(name),
    }
}

fn log_line(log: &mut String, path: &Path, line: &str) -> Result<(), String> {
    println!("{line}");
    log.push_str(line);
    log.push('\n');
    let mut file = OpenOptions::new()
        .append(true)
        .open(path)
        .map_err(|e| e.to_string())?;
    writeln!(file, "{line}").map_err(|e| e.to_string())
}

fn format_run_summary(options: &Options) -> String {
    let python_bool = |value: bool| if value { "True" } else { "False" }.to_owned();
    let python_list = |values: &[PathBuf]| {
        format!(
            "[{}]",
            values
                .iter()
                .map(|value| format!("'{}'", value.display().to_string().replace('\'', "\\'")))
                .collect::<Vec<_>>()
                .join(", ")
        )
    };
    let optional = |value: Option<f64>| value.map_or_else(|| "None".into(), |x| format!("{x:?}"));
    let mut values = BTreeMap::from([
        ("auto_skip", python_bool(options.auto_skip)),
        (
            "avg_poscar",
            options
                .avg_poscar
                .as_deref()
                .map_or_else(|| "None".into(), str::to_owned),
        ),
        ("bins", options.bins.to_string()),
        ("block_count", options.block_count.to_string()),
        (
            "category",
            std::env::args()
                .nth(2)
                .unwrap_or_else(|| "xdatcar-tool".into()),
        ),
        ("command", "util".into()),
        ("draw_rdf", python_bool(options.rdf)),
        ("dt", optional(options.dt_fs)),
        ("ff", "None".into()),
        ("input", python_list(&options.inputs)),
        ("interactive", "False".into()),
        ("interval", options.interval.to_string()),
        ("last_percent", optional(options.last_percent)),
        ("model", "None".into()),
        ("no_adp", python_bool(!options.adp)),
        (
            "no_displacement_map",
            python_bool(!options.displacement_map),
        ),
        ("no_report", python_bool(options.no_report)),
        ("outlier_z", optional(options.outlier_z)),
        ("output", options.output.clone()),
        (
            "poscar",
            options
                .poscar
                .as_deref()
                .map_or_else(|| "None".into(), str::to_owned),
        ),
        (
            "reference_poscar",
            options
                .reference_poscar
                .as_deref()
                .map_or_else(|| "None".into(), str::to_owned),
        ),
        ("rmax", format!("{:?}", options.rmax)),
        ("skip", format!("{:?}", options.skip_ps)),
        ("skip_frames", options.skip_frames.to_string()),
        ("symmetry_sample", options.symmetry_sample.to_string()),
        ("temperature_k", optional(options.temperature_k)),
        ("until", optional(options.until_ps)),
        ("verbose", "False".into()),
        (
            "window_end",
            options
                .window_end
                .map_or_else(|| "None".into(), |x| x.to_string()),
        ),
        (
            "window_start",
            options
                .window_start
                .map_or_else(|| "None".into(), |x| x.to_string()),
        ),
    ]);
    let command = std::env::args().collect::<Vec<_>>().join(" ");
    let mut text = format!(
        "--- Execution Summary (util xt analysis) ---\nCommand: {command}\nEffective arguments:"
    );
    for (key, value) in values.iter_mut() {
        text.push_str(&format!("\n  - {key}: {value}"));
    }
    text.push_str("\n--------------------------------------------------");
    text
}

fn cell_properties(cells: &[[[f64; 3]; 3]]) -> (Vec<f64>, Vec<f64>, Vec<f64>, Vec<f64>) {
    let mut a = Vec::with_capacity(cells.len());
    let mut b = Vec::with_capacity(cells.len());
    let mut c = Vec::with_capacity(cells.len());
    let mut volume = Vec::with_capacity(cells.len());
    for cell in cells {
        a.push(norm(cell[0]));
        b.push(norm(cell[1]));
        c.push(norm(cell[2]));
        volume.push(determinant(*cell).abs());
    }
    (a, b, c, volume)
}

fn norm(v: [f64; 3]) -> f64 {
    v.iter().map(|x| x * x).sum::<f64>().sqrt()
}

fn mean(values: &[f64]) -> f64 {
    values.iter().sum::<f64>() / values.len() as f64
}

fn scientific_e8(value: f64) -> String {
    let formatted = format!("{value:.8e}");
    let (mantissa, exponent) = formatted.split_once('e').unwrap_or((&formatted, "0"));
    let exponent = exponent.parse::<i32>().unwrap_or(0);
    format!("{mantissa}e{exponent:+03}")
}

fn population_variance(values: &[f64]) -> f64 {
    if values.is_empty() {
        return f64::NAN;
    }
    let avg = mean(values);
    values
        .iter()
        .map(|value| (value - avg).powi(2))
        .sum::<f64>()
        / values.len() as f64
}

fn population_std(values: &[f64]) -> f64 {
    population_variance(values).sqrt()
}

#[derive(Clone, Copy, Debug, serde::Serialize)]
struct Stats {
    mean: f64,
    std: f64,
    min: f64,
    max: f64,
    p05: f64,
    p95: f64,
}

fn scalar_stats(values: &[f64]) -> Stats {
    let mut sorted = values.to_vec();
    sorted.sort_by(f64::total_cmp);
    Stats {
        mean: mean(values),
        std: population_std(values),
        min: sorted[0],
        max: *sorted.last().unwrap(),
        p05: percentile(&sorted, 5.0),
        p95: percentile(&sorted, 95.0),
    }
}

fn percentile(sorted: &[f64], percentile: f64) -> f64 {
    if sorted.len() == 1 {
        return sorted[0];
    }
    let rank = percentile / 100.0 * (sorted.len() - 1) as f64;
    let lo = rank.floor() as usize;
    let hi = rank.ceil() as usize;
    sorted[lo] + (sorted[hi] - sorted[lo]) * (rank - lo as f64)
}

fn linear_slope(x: &[f64], y: &[f64]) -> f64 {
    if x.len() < 2 {
        return 0.0;
    }
    let x_mean = mean(x);
    let y_mean = mean(y);
    let denominator = x.iter().map(|value| (value - x_mean).powi(2)).sum::<f64>();
    if denominator == 0.0 {
        return 0.0;
    }
    x.iter()
        .zip(y)
        .map(|(x, y)| (x - x_mean) * (y - y_mean))
        .sum::<f64>()
        / denominator
}

fn block_statistics(values: &[f64], requested: usize) -> Vec<(usize, usize, usize, f64, f64)> {
    if values.is_empty() {
        return Vec::new();
    }
    let blocks = requested.max(1).min(values.len());
    (0..blocks)
        .filter_map(|block| {
            let start = block * values.len() / blocks;
            let end = (block + 1) * values.len() / blocks;
            (end > start).then(|| {
                let chunk = &values[start..end];
                (
                    block + 1,
                    start,
                    end - 1,
                    mean(chunk),
                    population_std(chunk),
                )
            })
        })
        .collect()
}

fn select_window(
    options: &Options,
    properties: [&[f64]; 4],
    time_ps: Option<&[f64]>,
    log: &mut String,
    log_path: &Path,
) -> Result<(Vec<bool>, String), String> {
    let n = properties[3].len();
    let mut mask = vec![true; n];
    let selection;
    if options.window_start.is_some() || options.window_end.is_some() {
        let clamp_frame = |frame: isize| frame.clamp(0, n as isize - 1) as usize;
        let start = clamp_frame(options.window_start.unwrap_or(0));
        let end = clamp_frame(options.window_end.unwrap_or(n as isize - 1)).max(start);
        mask.fill(false);
        mask[start..=end].fill(true);
        selection = format!("frame_window[{start}:{end}]");
    } else if let Some(percent) = options.last_percent {
        let percent = percent.clamp(1.0, 100.0);
        let count = ((n as f64 * percent / 100.0).ceil() as usize).max(1);
        mask.fill(false);
        mask[n - count..].fill(true);
        selection = format!("last_{percent:.2}%");
    } else if options.skip_frames > 0 {
        let start = options.skip_frames.min(n - 1);
        mask.fill(false);
        mask[start..].fill(true);
        selection = format!("skip_frames={}", options.skip_frames);
    } else if options.auto_skip {
        let start = detect_equilibration_start(properties[3]);
        mask.fill(false);
        mask[start..].fill(true);
        selection = format!("auto_skip(start_idx={start})");
    } else if let Some(time) = time_ps {
        for (index, value) in time.iter().enumerate() {
            mask[index] = *value >= options.skip_ps;
        }
        let mut time_selection = format!("skip_ps={:?}", options.skip_ps);
        if let Some(until) = options.until_ps {
            if until < options.skip_ps {
                log_line(log, log_path, &format!("Warning: until_ps ({until:?}) is smaller than skip_ps ({:?}). Using last frame only.", options.skip_ps))?;
                mask.fill(false);
                mask[n - 1] = true;
            } else {
                for (index, value) in time.iter().enumerate() {
                    mask[index] &= *value <= until;
                }
                time_selection = format!("time_window_ps[{:?}:{until:?}]", options.skip_ps);
            }
        }
        if !mask.iter().any(|value| *value) {
            let total = time[n - 1];
            if options.until_ps.is_some() {
                log_line(log, log_path, &format!("Warning: requested time window has no frames within total time ({total:.2} ps). Using last frame only."))?;
            } else {
                log_line(log, log_path, &format!("Warning: skip_ps ({:?}) is larger than total time ({total:.2}). Using last frame only.", options.skip_ps))?;
            }
            mask.fill(false);
            mask[n - 1] = true;
        }
        selection = time_selection;
    } else {
        if options.skip_ps > 0.0 {
            log_line(log, log_path, "Warning: skip(ps) requested but time axis is unavailable without --dt/md.csv. Ignoring --skip.")?;
        }
        selection = "all_frames(no_time_axis)".into();
    }
    if let Some(z) = options.outlier_z.filter(|z| *z > 0.0) {
        let mut keep = vec![true; n];
        for values in properties {
            let avg = mean(values);
            let std = population_std(values);
            if std > 1.0e-12 {
                for i in 0..n {
                    keep[i] &= ((values[i] - avg) / std).abs() <= z;
                }
            }
        }
        let before = mask.iter().filter(|&&value| value).count();
        for i in 0..n {
            mask[i] &= keep[i];
        }
        let after = mask.iter().filter(|&&value| value).count();
        log_line(
            log,
            log_path,
            &format!("Outlier filter (--outlier-z {z}): kept {after}/{before} selected frames."),
        )?;
        if after == 0 {
            log_line(log, log_path, "Warning: all selected frames were filtered as outliers. Falling back to last frame.")?;
            mask[n - 1] = true;
        }
    }
    Ok((mask, selection))
}

fn detect_equilibration_start(values: &[f64]) -> usize {
    if values.len() < 4 {
        return 0;
    }
    let tail_start = ((values.len() as f64 * 0.5).floor() as usize).max(1);
    let tail = &values[tail_start..];
    let avg = mean(tail);
    let std = population_std(tail);
    if std <= 1.0e-12 {
        return tail_start;
    }
    values
        .iter()
        .position(|value| (value - avg).abs() <= 0.5 * std)
        .unwrap_or(tail_start)
}

fn detect_frame_dt_ps(input: &Path) -> Option<f64> {
    let columns = crate::plots::csv_columns(&input.parent()?.join("md.csv")).ok()?;
    let time = columns.get("time_fs")?;
    if time.len() < 2 {
        return None;
    }
    let dt = (time[1] - time[0]) * 1.0e-3;
    (dt > 0.0).then_some(dt)
}

fn detect_temperature_k(input: &Path) -> Option<f64> {
    let columns = crate::plots::csv_columns(&input.parent()?.join("md.csv")).ok()?;
    let temperatures = columns.get("T_K")?;
    (!temperatures.is_empty()).then(|| mean(temperatures))
}

fn compute_strain(
    trajectory: &Trajectory,
    reference_poscar: Option<&str>,
    mask: &[bool],
) -> (Option<BTreeMap<String, f64>>, Option<Vec<[f64; 7]>>) {
    let reference = match reference_poscar {
        Some(path) => read_poscar(Path::new(path))
            .map(|structure| structure.cell_a)
            .ok(),
        None => Some(trajectory.cells_a[0]),
    };
    let Some(reference) = reference else {
        return (None, None);
    };
    let Ok(inverse) = inverse(reference) else {
        return (None, None);
    };
    let mut rows = Vec::with_capacity(trajectory.cells_a.len());
    for cell in &trajectory.cells_a {
        let f: [[f64; 3]; 3] = std::array::from_fn(|i| {
            std::array::from_fn(|j| (0..3).map(|k| cell[i][k] * inverse[k][j]).sum::<f64>())
        });
        let mut strain = [[0.0; 3]; 3];
        for i in 0..3 {
            for j in 0..3 {
                strain[i][j] = f[i][j] - if i == j { 1.0 } else { 0.0 };
                if strain[i][j].abs() < 1.0e-14 {
                    strain[i][j] = 0.0;
                }
            }
        }
        rows.push([
            strain[0][0],
            strain[1][1],
            strain[2][2],
            strain[1][2],
            strain[0][2],
            strain[0][1],
            strain[0][0] + strain[1][1] + strain[2][2],
        ]);
    }
    let indices = mask
        .iter()
        .enumerate()
        .filter_map(|(i, selected)| selected.then_some(i))
        .collect::<Vec<_>>();
    let mut summary = BTreeMap::new();
    for (index, name) in [
        "exx_mean",
        "eyy_mean",
        "ezz_mean",
        "eyz_mean",
        "exz_mean",
        "exy_mean",
        "dV_over_V_mean",
    ]
    .iter()
    .enumerate()
    {
        summary.insert(
            (*name).to_owned(),
            mean(&indices.iter().map(|&i| rows[i][index]).collect::<Vec<_>>()),
        );
    }
    (Some(summary), Some(rows))
}

fn average_structure(
    trajectory: &Trajectory,
    selected: &[usize],
) -> Result<([[f64; 3]; 3], Vec<[f64; 3]>), String> {
    let n_atoms = trajectory.atomic_numbers.len();
    let mut cell = [[0.0; 3]; 3];
    for &frame in selected {
        for i in 0..3 {
            for j in 0..3 {
                cell[i][j] += trajectory.cells_a[frame][i][j] / selected.len() as f64;
            }
        }
    }
    let mut unwrapped = vec![vec![[0.0; 3]; n_atoms]; selected.len()];
    unwrapped[0].clone_from(&trajectory.fractional_positions[selected[0]]);
    for frame_index in 1..selected.len() {
        let previous = &trajectory.fractional_positions[selected[frame_index - 1]];
        let current = &trajectory.fractional_positions[selected[frame_index]];
        for atom in 0..n_atoms {
            for axis in 0..3 {
                let delta = current[atom][axis] - previous[atom][axis];
                let delta = delta - round_ties_even(delta);
                unwrapped[frame_index][atom][axis] = unwrapped[frame_index - 1][atom][axis] + delta;
            }
        }
    }
    let positions = (0..n_atoms)
        .map(|atom| {
            let mut avg = [0.0; 3];
            for frames in &unwrapped {
                for axis in 0..3 {
                    avg[axis] += frames[atom][axis] / selected.len() as f64;
                }
            }
            for value in &mut avg {
                *value = value.rem_euclid(1.0);
            }
            avg
        })
        .collect();
    Ok((cell, positions))
}

fn round_ties_even(value: f64) -> f64 {
    let floor = value.floor();
    let fraction = value - floor;
    if fraction < 0.5 {
        floor
    } else if fraction > 0.5 {
        floor + 1.0
    } else if floor % 2.0 == 0.0 {
        floor
    } else {
        floor + 1.0
    }
}

fn write_poscar(
    path: &Path,
    numbers: &[u8],
    cell: [[f64; 3]; 3],
    fractional: Vec<[f64; 3]>,
) -> Result<(), String> {
    let symbols = numbers
        .iter()
        .map(|&number| crate::elements::SYMBOLS[number as usize])
        .collect::<Vec<_>>();
    let mut groups: Vec<(&str, usize)> = Vec::new();
    for &symbol in &symbols {
        if let Some((last_symbol, count)) = groups.last_mut() {
            if *last_symbol == symbol {
                *count += 1;
                continue;
            }
        }
        groups.push((symbol, 1));
    }
    let mut output = String::from("macer-rust averaged structure\n1.0\n");
    for row in cell {
        output.push_str(&format!(
            "{:20.12} {:20.12} {:20.12}\n",
            row[0], row[1], row[2]
        ));
    }
    output.push_str(
        &groups
            .iter()
            .map(|(symbol, _)| *symbol)
            .collect::<Vec<_>>()
            .join(" "),
    );
    output.push('\n');
    output.push_str(
        &groups
            .iter()
            .map(|(_, count)| count.to_string())
            .collect::<Vec<_>>()
            .join(" "),
    );
    output.push_str("\nCartesian\n");
    for position in &fractional {
        let cartesian: [f64; 3] =
            std::array::from_fn(|axis| (0..3).map(|j| position[j] * cell[j][axis]).sum());
        output.push_str(&format!(
            "{:20.12} {:20.12} {:20.12}\n",
            cartesian[0], cartesian[1], cartesian[2]
        ));
    }
    fs::write(path, output).map_err(|e| e.to_string())
}

fn write_adp_outputs(
    base: &Path,
    trajectory: &Trajectory,
    selected: &[usize],
    average_cell: [[f64; 3]; 3],
    average_fractional: &[[f64; 3]],
    displacement_map: bool,
) -> Result<(Value, Value), String> {
    if selected.is_empty() || average_fractional.len() != trajectory.atomic_numbers.len() {
        return Err(
            "ADP requires a nonempty selected window and one mean position per atom".into(),
        );
    }
    let n_atoms = trajectory.atomic_numbers.len();
    let mut unwrapped = vec![vec![[0.0; 3]; n_atoms]; selected.len()];
    unwrapped[0].clone_from(&trajectory.fractional_positions[selected[0]]);
    for frame_index in 1..selected.len() {
        let previous = &trajectory.fractional_positions[selected[frame_index - 1]];
        let current = &trajectory.fractional_positions[selected[frame_index]];
        for atom in 0..n_atoms {
            for axis in 0..3 {
                let delta = current[atom][axis] - previous[atom][axis];
                unwrapped[frame_index][atom][axis] =
                    unwrapped[frame_index - 1][atom][axis] + delta - round_ties_even(delta);
            }
        }
    }
    let mean_unwrapped = (0..n_atoms)
        .map(|atom| {
            std::array::from_fn(|axis| {
                unwrapped.iter().map(|frame| frame[atom][axis]).sum::<f64>() / selected.len() as f64
            })
        })
        .collect::<Vec<[f64; 3]>>();
    let symbols = trajectory.symbols()?;
    let mut cartesian_displacements = vec![vec![[0.0; 3]; n_atoms]; selected.len()];
    for frame in 0..selected.len() {
        for atom in 0..n_atoms {
            let fractional_delta: [f64; 3] = std::array::from_fn(|axis| {
                unwrapped[frame][atom][axis] - mean_unwrapped[atom][axis]
            });
            cartesian_displacements[frame][atom] = std::array::from_fn(|axis| {
                (0..3)
                    .map(|row| fractional_delta[row] * average_cell[row][axis])
                    .sum()
            });
        }
    }

    let tensors = (0..n_atoms)
        .map(|atom| {
            std::array::from_fn(|i| {
                std::array::from_fn(|j| {
                    cartesian_displacements
                        .iter()
                        .map(|frame| frame[atom][i] * frame[atom][j])
                        .sum::<f64>()
                        / selected.len() as f64
                })
            })
        })
        .collect::<Vec<[[f64; 3]; 3]>>();
    let mut atom_uiso = Vec::with_capacity(n_atoms);
    let mut species_uiso: BTreeMap<String, Vec<f64>> = BTreeMap::new();
    let mut adp_table =
        String::from("# atom_index symbol U11 U22 U33 U23 U13 U12 Uiso Biso(=8*pi^2*Uiso)\n");
    for (atom, (symbol, tensor)) in symbols.iter().zip(&tensors).enumerate() {
        let u11 = tensor[0][0];
        let u22 = tensor[1][1];
        let u33 = tensor[2][2];
        let u23 = tensor[1][2];
        let u13 = tensor[0][2];
        let u12 = tensor[0][1];
        let uiso = (u11 + u22 + u33) / 3.0;
        let biso = 8.0 * std::f64::consts::PI.powi(2) * uiso;
        adp_table.push_str(&format!(
            "{:6} {:>3} {:>15} {:>15} {:>15} {:>15} {:>15} {:>15} {:>15} {:>15}\n",
            atom + 1,
            symbol,
            scientific_e8(u11),
            scientific_e8(u22),
            scientific_e8(u33),
            scientific_e8(u23),
            scientific_e8(u13),
            scientific_e8(u12),
            scientific_e8(uiso),
            scientific_e8(biso)
        ));
        atom_uiso.push((atom + 1, *symbol, uiso));
        species_uiso
            .entry((*symbol).to_owned())
            .or_default()
            .push(uiso);
    }
    let adp_table_path = base.with_extension("adp.dat");
    fs::write(&adp_table_path, adp_table).map_err(|error| error.to_string())?;

    let mut species_summary = serde_json::Map::new();
    let mut summary_table = String::from("# species n Uiso_mean Uiso_std\n");
    for (symbol, values) in &species_uiso {
        let average = mean(values);
        let std = population_std(values);
        species_summary.insert(
            symbol.clone(),
            json!({"n": values.len(), "Uiso_mean": average, "Uiso_std": std}),
        );
        summary_table.push_str(&format!(
            "{symbol:>3} {:6} {:>15} {:>15}\n",
            values.len(),
            scientific_e8(average),
            scientific_e8(std)
        ));
    }
    let mut ranked = atom_uiso.clone();
    ranked.sort_by(|left, right| right.2.total_cmp(&left.2));
    let top = ranked.iter().take(10).collect::<Vec<_>>();
    summary_table.push_str("\n# top_sites_by_Uiso atom_index symbol Uiso\n");
    for (index, symbol, uiso) in &top {
        summary_table.push_str(&format!(
            "{:6} {:>3} {:>15}\n",
            index,
            symbol,
            scientific_e8(*uiso)
        ));
    }
    fs::write(base.with_extension("adp.summary.dat"), summary_table)
        .map_err(|error| error.to_string())?;
    write_adp_cif(
        &base.with_extension("adp.cif"),
        &symbols,
        average_cell,
        average_fractional,
        &tensors,
    )?;

    if displacement_map {
        let mut displacement = String::from("# atom_index symbol dx dy dz norm_mean norm_std\n");
        for (atom, symbol) in symbols.iter().enumerate() {
            let mean_vector: [f64; 3] = std::array::from_fn(|axis| {
                cartesian_displacements
                    .iter()
                    .map(|frame| frame[atom][axis])
                    .sum::<f64>()
                    / selected.len() as f64
            });
            let norms = cartesian_displacements
                .iter()
                .map(|frame| norm(frame[atom]))
                .collect::<Vec<_>>();
            displacement.push_str(&format!(
                "{:6} {:>3} {:>15} {:>15} {:>15} {:>15} {:>15}\n",
                atom + 1,
                symbol,
                scientific_e8(mean_vector[0]),
                scientific_e8(mean_vector[1]),
                scientific_e8(mean_vector[2]),
                scientific_e8(norm(mean_vector)),
                scientific_e8(population_std(&norms))
            ));
        }
        fs::write(base.with_extension("displacement.dat"), displacement)
            .map_err(|error| error.to_string())?;
    }

    let top_value = Value::Array(
        top.iter()
            .map(|(index, symbol, uiso)| json!([index, symbol, uiso]))
            .collect(),
    );
    Ok((Value::Object(species_summary), top_value))
}

fn write_adp_cif(
    path: &Path,
    symbols: &[&str],
    cell: [[f64; 3]; 3],
    fractional: &[[f64; 3]],
    tensors: &[[[f64; 3]; 3]],
) -> Result<(), String> {
    if symbols.len() != fractional.len() || symbols.len() != tensors.len() {
        return Err("ADP CIF arrays have different atom counts".into());
    }
    let angle = |first: [f64; 3], second: [f64; 3]| {
        let cosine =
            (0..3).map(|i| first[i] * second[i]).sum::<f64>() / (norm(first) * norm(second));
        cosine.clamp(-1.0, 1.0).acos().to_degrees()
    };
    let lengths = [norm(cell[0]), norm(cell[1]), norm(cell[2])];
    let angles = [
        angle(cell[1], cell[2]),
        angle(cell[0], cell[2]),
        angle(cell[0], cell[1]),
    ];
    let mut output = format!(
        "data_md_average_adp\n_symmetry_space_group_name_H-M 'P 1'\n_symmetry_Int_Tables_number 1\n_cell_length_a {:.10}\n_cell_length_b {:.10}\n_cell_length_c {:.10}\n_cell_angle_alpha {:.10}\n_cell_angle_beta {:.10}\n_cell_angle_gamma {:.10}\n\nloop_\n_symmetry_equiv_pos_as_xyz\n'x, y, z'\n\nloop_\n_atom_site_label\n_atom_site_type_symbol\n_atom_site_fract_x\n_atom_site_fract_y\n_atom_site_fract_z\n_atom_site_U_iso_or_equiv\n",
        lengths[0], lengths[1], lengths[2], angles[0], angles[1], angles[2]
    );
    for (index, (symbol, position)) in symbols.iter().zip(fractional).enumerate() {
        let uiso = (tensors[index][0][0] + tensors[index][1][1] + tensors[index][2][2]) / 3.0;
        output.push_str(&format!(
            "{:<6} {:<3} {:12.8} {:12.8} {:12.8} {:12.8}\n",
            format!("{symbol}{}", index + 1),
            symbol,
            position[0],
            position[1],
            position[2],
            uiso
        ));
    }
    output.push_str(
        "\nloop_\n_atom_site_aniso_label\n_atom_site_aniso_U_11\n_atom_site_aniso_U_22\n_atom_site_aniso_U_33\n_atom_site_aniso_U_23\n_atom_site_aniso_U_13\n_atom_site_aniso_U_12\n",
    );
    for (index, (symbol, tensor)) in symbols.iter().zip(tensors).enumerate() {
        output.push_str(&format!(
            "{:<6} {:12.8} {:12.8} {:12.8} {:12.8} {:12.8} {:12.8}\n",
            format!("{symbol}{}", index + 1),
            tensor[0][0],
            tensor[1][1],
            tensor[2][2],
            tensor[1][2],
            tensor[0][2],
            tensor[0][1]
        ));
    }
    fs::write(path, output).map_err(|error| error.to_string())
}

#[cfg(test)]
mod tests {
    use super::{linear_slope, percentile, scalar_stats, select_window, write_poscar, Options};
    use std::fs;
    use std::path::Path;

    #[test]
    fn population_statistics_and_linear_percentiles_match_numpy_defaults() {
        let stats = scalar_stats(&[1.0, 2.0, 4.0, 8.0]);
        assert_eq!(stats.mean, 3.75);
        assert!((stats.std - 2.680951323690902).abs() < 1e-14);
        assert_eq!(percentile(&[1.0, 2.0, 4.0, 8.0], 5.0), 1.15);
        assert!((linear_slope(&[0.0, 1.0, 2.0], &[1.0, 3.0, 5.0]) - 2.0).abs() < 1e-14);
    }

    #[test]
    fn outlier_filter_checks_each_cell_axis_and_volume() {
        let mut options = Options::default();
        options.outlier_z = Some(1.0);
        let properties = [
            &[1.0, 1.0, 1.0, 1.0, 10.0][..],
            &[1.0, 1.0, 1.0, 1.0, 1.0][..],
            &[1.0, 1.0, 1.0, 1.0, 1.0][..],
            &[1.0, 1.0, 1.0, 1.0, 1.0][..],
        ];
        let path = std::env::temp_dir().join(format!(
            "macer-rust-xdatcar-outlier-{}.log",
            std::process::id()
        ));
        fs::write(&path, "").unwrap();
        let (mask, _) = select_window(
            &options,
            properties,
            None,
            &mut String::new(),
            Path::new(&path),
        )
        .unwrap();
        let _ = fs::remove_file(path);
        assert_eq!(mask, [true, true, true, true, false]);
    }

    #[test]
    fn averaged_poscar_preserves_interleaved_atom_order() {
        let path = std::env::temp_dir().join(format!(
            "macer-rust-xdatcar-average-order-{}.vasp",
            std::process::id()
        ));
        let numbers = [29, 16, 29, 16];
        let fractional = [
            [0.1, 0.2, 0.3],
            [0.4, 0.5, 0.6],
            [0.7, 0.8, 0.9],
            [0.2, 0.3, 0.4],
        ];
        write_poscar(
            &path,
            &numbers,
            [[2.0, 0.0, 0.0], [0.0, 2.0, 0.0], [0.0, 0.0, 2.0]],
            fractional.to_vec(),
        )
        .unwrap();
        let structure = crate::poscar::read_poscar(&path).unwrap();
        let _ = fs::remove_file(&path);
        assert_eq!(structure.atomic_numbers, numbers);
        assert_eq!(
            structure.positions_a,
            fractional.map(|position| position.map(|value| value * 2.0))
        );
    }
}
