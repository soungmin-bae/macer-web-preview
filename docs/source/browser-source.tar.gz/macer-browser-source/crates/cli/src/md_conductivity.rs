//! Native implementation of `macer util md conductivity`.

use crate::plots::write_md_conductivity_plot;
use crate::trajectory::{determinant, multiply_row, read, Trajectory};
use std::collections::{BTreeMap, BTreeSet};
use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::{Path, PathBuf};

const E_CHARGE_C: f64 = 1.602_176_63e-19;
const KB_J_PER_K: f64 = 1.380_649e-23;
const ANGSTROM_M: f64 = 1.0e-10;

pub const HELP: &str = r#"Calculate ionic conductivity from an ASE `md.traj` or VASP `XDATCAR`.

USAGE:
    macer-rust util md conductivity -i|--input <TRAJECTORY> -t|--temp <K>
        [--dt <FS>] [--interval <N>] [--charges <"Li:1,S:-2">]

Outputs `md_results.log` and `md_results.pdf` beside the input trajectory.
"#;

pub(crate) fn run(arguments: impl Iterator<Item = String>) -> Result<(), String> {
    let mut input = None;
    let mut temp_k = None;
    let mut dt_fs = 2.0;
    let mut interval = 1usize;
    let mut charges_argument: Option<String> = None;
    let mut arguments = arguments.peekable();
    while let Some(argument) = arguments.next() {
        if argument == "-h" || argument == "--help" {
            print!("{HELP}");
            return Ok(());
        }
        let (option, value) = match argument.split_once('=') {
            Some((option, value)) => (option.to_owned(), value.to_owned()),
            None => (
                argument.clone(),
                arguments
                    .next()
                    .ok_or_else(|| format!("missing value for {argument}"))?,
            ),
        };
        match option.as_str() {
            "-i" | "--input" => input = Some(value),
            "-t" | "--temp" => {
                temp_k = Some(
                    value
                        .parse::<f64>()
                        .map_err(|_| format!("invalid temperature: {value}"))?,
                )
            }
            "--dt" => {
                dt_fs = value
                    .parse::<f64>()
                    .map_err(|_| format!("invalid timestep: {value}"))?
            }
            "--interval" => {
                interval = value
                    .parse::<usize>()
                    .map_err(|_| format!("invalid interval: {value}"))?
            }
            "--charges" => charges_argument = Some(value),
            _ => return Err(format!("unexpected argument: {argument}\n{HELP}")),
        }
    }

    let input_display = input.ok_or_else(|| format!("missing required --input\n{HELP}"))?;
    let input_path = PathBuf::from(&input_display);
    let temp_k = temp_k.ok_or_else(|| format!("missing required --temp\n{HELP}"))?;
    if !temp_k.is_finite() || temp_k <= 0.0 {
        return Err("temperature must be a finite value greater than zero".into());
    }
    if !dt_fs.is_finite() || dt_fs <= 0.0 {
        return Err("timestep must be a finite value greater than zero".into());
    }
    if interval == 0 {
        return Err("interval must be a positive integer".into());
    }
    if !input_path.exists() {
        println!("Error: Trajectory file '{input_display}' not found.");
        return Ok(());
    }

    let mut notices = Vec::new();
    if interval == 1 {
        if let Some(detected) = detect_interval(&input_path) {
            interval = detected;
            notices.push(format!("Auto-detected interval: {interval}"));
        }
    }
    let parent = input_path.parent().unwrap_or_else(|| Path::new("."));
    let log_path = parent.join("md_results.log");
    let plot_path = parent.join("md_results.pdf");
    let summary = run_summary(
        &input_display,
        temp_k,
        dt_fs,
        interval,
        charges_argument.as_deref(),
    );
    let heading = format!(
        "{} MD Conductivity Analysis {}",
        "---".repeat(10),
        "---".repeat(10)
    );
    let log = format!("{heading}\n{summary}\nInput: {input_display}\nTemp: {:?} K\nTime step: {:?} fs\nInterval: {interval}\n", temp_k, dt_fs);
    fs::write(&log_path, log).map_err(|error| error.to_string())?;
    for notice in notices {
        println!("{notice}");
    }
    log_and_print(&log_path, &format!("Reading trajectory: {input_display}"))?;
    let trajectory = match read(&input_path) {
        Ok(trajectory) => trajectory,
        Err(error) => {
            println!("Error reading trajectory: {error}");
            if input_display.contains("XDATCAR") {
                println!("Tip: VASP XDATCAR reading can be strict. Try using 'md.traj' instead for better compatibility.");
            }
            return Ok(());
        }
    };
    if trajectory.fractional_positions.len() < 2 {
        println!("Error: Trajectory is too short or empty. Need at least 2 frames.");
        return Ok(());
    }
    let symbols = trajectory.symbols()?;
    let species = symbols.iter().copied().collect::<BTreeSet<_>>();
    let volume_a3 = determinant(trajectory.cell_a).abs();
    if !volume_a3.is_finite() || volume_a3 <= 0.0 {
        return Err("trajectory has an invalid unit-cell volume".into());
    }
    let mut charges = default_charges();
    let mut explicit_charges = BTreeSet::new();
    if let Some(override_text) = charges_argument.as_deref() {
        for entry in override_text.split(',') {
            if let Some((symbol, charge)) = entry.split_once(':') {
                let charge = charge
                    .trim()
                    .parse::<f64>()
                    .map_err(|_| format!("invalid oxidation state in --charges entry {entry:?}"))?;
                charges.insert(symbol.trim().to_owned(), charge);
                explicit_charges.insert(symbol.trim().to_owned());
            }
        }
    }

    log_and_print(
        &log_path,
        &format!(
            "Steps: {}, Volume: {volume_a3:.2} A^3",
            trajectory.fractional_positions.len()
        ),
    )?;
    log_and_print(&log_path, "Using oxidation states:")?;
    for symbol in &species {
        let charge = charges.get(*symbol).copied();
        match charge {
            Some(charge) => {
                let value = if explicit_charges.contains(*symbol) {
                    format!("{charge:?}")
                } else if charge.fract() == 0.0 {
                    format!("{charge:.0}")
                } else {
                    format!("{charge}")
                };
                log_and_print(&log_path, &format!("  {symbol}: {value}"))?
            }
            None => log_and_print(
                &log_path,
                &format!("  {symbol}: 0 (Warning: not found in defaults, using 0.0)"),
            )?,
        }
        charges.entry((*symbol).to_owned()).or_insert(0.0);
    }

    let times_ps = (0..trajectory.fractional_positions.len())
        .map(|index| index as f64 * dt_fs * interval as f64 * 1.0e-3)
        .collect::<Vec<_>>();
    let mut species_results = Vec::new();
    let mut curves = Vec::new();
    let mut total_sigma_s_per_m = 0.0;
    for symbol in species {
        let atom_indices = symbols
            .iter()
            .enumerate()
            .filter_map(|(index, current)| (*current == symbol).then_some(index))
            .collect::<Vec<_>>();
        let msd = calculate_msd(&trajectory, &atom_indices);
        let start = (msd.len() as f64 * 0.1) as usize;
        let end = (msd.len() as f64 * 0.9) as usize;
        let (slope, intercept) = if end > start + 1 {
            linear_fit(&times_ps[start..end], &msd[start..end])
        } else {
            (0.0, 0.0)
        };
        let diffusion_cm2_s = (slope / 6.0) * 1.0e-8 * 1.0e4;
        let charge_c = charges.get(symbol).copied().unwrap_or(0.0) * E_CHARGE_C;
        let sigma_s_per_m = if charge_c != 0.0 {
            ((atom_indices.len() as f64 / (volume_a3 * ANGSTROM_M.powi(3)))
                * charge_c.powi(2)
                * (slope / 6.0 * 1.0e-8))
                / (KB_J_PER_K * temp_k)
        } else {
            0.0
        };
        total_sigma_s_per_m += sigma_s_per_m;
        let fit = (0..times_ps.len())
            .map(|index| {
                if end > start + 1 && (start..end).contains(&index) {
                    slope * times_ps[index] + intercept
                } else {
                    f64::NAN
                }
            })
            .collect::<Vec<_>>();
        curves.push((symbol, msd, fit, diffusion_cm2_s));
        species_results.push((symbol, diffusion_cm2_s, sigma_s_per_m));
    }
    for (symbol, diffusion, sigma) in species_results {
        log_and_print(&log_path, &format!("\n--- Species: {symbol} ---"))?;
        log_and_print(
            &log_path,
            &format!("  Diff. Coeff (D): {} cm^2/s", scientific_py(diffusion, 3)),
        )?;
        log_and_print(
            &log_path,
            &format!(
                "  Conductivity (sigma_NE): {} S/m ({:.2} mS/cm)",
                scientific_py(sigma, 3),
                sigma * 10.0
            ),
        )?;
    }
    log_and_print(
        &log_path,
        &format!(
            "\nTotal Conductivity: {:.2} mS/cm",
            total_sigma_s_per_m * 10.0
        ),
    )?;

    let curve_refs = curves
        .iter()
        .map(|(symbol, msd, fit, diffusion)| (*symbol, msd.as_slice(), fit.as_slice(), *diffusion))
        .collect::<Vec<_>>();
    write_md_conductivity_plot(
        &plot_path,
        &times_ps,
        &curve_refs,
        temp_k,
        total_sigma_s_per_m * 10.0,
    )?;
    log_and_print(&log_path, &format!("Plot saved to {}", plot_path.display()))?;
    log_and_print(&log_path, &format!("Log saved to {}", log_path.display()))?;
    Ok(())
}

fn log_and_print(path: &Path, line: &str) -> Result<(), String> {
    println!("{line}");
    let mut log = OpenOptions::new()
        .append(true)
        .open(path)
        .map_err(|error| error.to_string())?;
    writeln!(log, "{line}").map_err(|error| error.to_string())
}

fn calculate_msd(trajectory: &Trajectory, atom_indices: &[usize]) -> Vec<f64> {
    let mut cumulative = vec![[0.0; 3]; atom_indices.len()];
    let mut result = vec![0.0; trajectory.fractional_positions.len()];
    for frame in 1..trajectory.fractional_positions.len() {
        let mut squared_sum = 0.0;
        for (local, &atom) in atom_indices.iter().enumerate() {
            let previous = trajectory.fractional_positions[frame - 1][atom];
            let current = trajectory.fractional_positions[frame][atom];
            let mut delta = [0.0; 3];
            for axis in 0..3 {
                delta[axis] = current[axis] - previous[axis];
                if trajectory.pbc[axis] {
                    delta[axis] -= round_ties_even(delta[axis]);
                }
                cumulative[local][axis] += delta[axis];
            }
            let cartesian = multiply_row(cumulative[local], trajectory.cell_a);
            squared_sum += cartesian.iter().map(|value| value * value).sum::<f64>();
        }
        result[frame] = squared_sum / atom_indices.len() as f64;
    }
    result
}

fn round_ties_even(value: f64) -> f64 {
    let lower = value.floor();
    let fraction = value - lower;
    if fraction < 0.5 {
        lower
    } else if fraction > 0.5 {
        lower + 1.0
    } else if lower % 2.0 == 0.0 {
        lower
    } else {
        lower + 1.0
    }
}

fn linear_fit(x: &[f64], y: &[f64]) -> (f64, f64) {
    let count = x.len() as f64;
    let mean_x = x.iter().sum::<f64>() / count;
    let mean_y = y.iter().sum::<f64>() / count;
    let slope = x
        .iter()
        .zip(y)
        .map(|(x, y)| (x - mean_x) * (y - mean_y))
        .sum::<f64>()
        / x.iter().map(|x| (x - mean_x).powi(2)).sum::<f64>();
    (slope, mean_y - slope * mean_x)
}

fn default_charges() -> BTreeMap<String, f64> {
    include_str!("../data/pydefect_oxidation_state_0.9.11.yaml")
        .lines()
        .filter_map(|line| {
            let (symbol, value) = line.split_once(':')?;
            Some((symbol.trim().to_owned(), value.trim().parse::<f64>().ok()?))
        })
        .collect()
}

pub(crate) fn detect_interval(input: &Path) -> Option<usize> {
    let xdatcar = if input
        .file_name()
        .and_then(|name| name.to_str())
        .is_some_and(|name| name.contains("XDATCAR"))
    {
        Some(input.to_path_buf())
    } else {
        let candidate = input.parent()?.join("XDATCAR");
        candidate.exists().then_some(candidate)
    };
    if let Some(path) = xdatcar {
        if let Ok(text) = fs::read_to_string(path) {
            let indices = text
                .lines()
                .filter_map(|line| {
                    line.split_once("Direct configuration=")?
                        .1
                        .split_whitespace()
                        .next()?
                        .parse::<i64>()
                        .ok()
                })
                .take(2)
                .collect::<Vec<_>>();
            if indices.len() == 2 {
                if let Ok(interval) = usize::try_from(indices[1] - indices[0]) {
                    if interval > 0 {
                        return Some(interval);
                    }
                }
            }
        }
    }
    let csv = input.parent()?.join("md.csv");
    // Preserve Macer's legacy auto-detection contract: only the capitalized
    // `Step` column is considered here; native output's `step` stays opt-in.
    let text = fs::read_to_string(csv).ok()?;
    let mut rows = text.lines();
    let headers = rows.next()?.split(',').collect::<Vec<_>>();
    let step_index = headers.iter().position(|header| *header == "Step")?;
    let steps = rows
        .filter_map(|row| row.split(',').nth(step_index)?.parse::<i64>().ok())
        .take(2)
        .collect::<Vec<_>>();
    (steps.len() == 2)
        .then(|| usize::try_from(steps[1] - steps[0]).ok())
        .flatten()
        .filter(|interval| *interval > 0)
}

fn run_summary(
    input: &str,
    temp_k: f64,
    dt_fs: f64,
    interval: usize,
    charges: Option<&str>,
) -> String {
    let command = std::env::args().collect::<Vec<_>>().join(" ");
    let mut values = BTreeMap::new();
    values.insert("action", "conductivity".to_owned());
    values.insert("category", "md".to_owned());
    values.insert(
        "charges",
        charges.map(str::to_owned).unwrap_or_else(|| "None".into()),
    );
    values.insert("command", "util".to_owned());
    values.insert("dt", format!("{dt_fs:?}"));
    values.insert("ff", "None".to_owned());
    values.insert("input", input.to_owned());
    values.insert("interactive", "False".to_owned());
    values.insert("interval", interval.to_string());
    values.insert("model", "None".to_owned());
    values.insert("temp", format!("{temp_k:?}"));
    values.insert("verbose", "False".to_owned());
    let mut text = format!(
        "--- Execution Summary (util md conductivity) ---\nCommand: {command}\nEffective arguments:"
    );
    for (key, value) in values {
        text.push_str(&format!("\n  - {key}: {value}"));
    }
    text.push_str("\n--------------------------------------------------");
    text
}

fn scientific_py(value: f64, decimals: usize) -> String {
    if value.is_nan() {
        return "nan".into();
    }
    if value.is_infinite() {
        return if value.is_sign_positive() {
            "inf"
        } else {
            "-inf"
        }
        .into();
    }
    let rendered = format!("{value:.decimals$e}");
    let (mantissa, exponent) = rendered
        .split_once('e')
        .expect("scientific formatting has an exponent");
    let exponent = exponent
        .parse::<i32>()
        .expect("scientific exponent is numeric");
    format!(
        "{mantissa}e{}{abs:02}",
        if exponent >= 0 { "+" } else { "-" },
        abs = exponent.abs()
    )
}

#[cfg(test)]
mod tests {
    use super::{calculate_msd, default_charges, linear_fit, round_ties_even};
    use crate::trajectory::Trajectory;

    #[test]
    fn computes_unwrapped_fractional_msd_and_fit() {
        let cell = [[2.0, 0.0, 0.0], [0.0, 3.0, 0.0], [0.0, 0.0, 4.0]];
        let trajectory = Trajectory {
            atomic_numbers: vec![3],
            cell_a: cell,
            cells_a: vec![cell; 3],
            pbc: [true; 3],
            fractional_positions: vec![
                vec![[0.9, 0.0, 0.0]],
                vec![[0.1, 0.0, 0.0]],
                vec![[0.3, 0.0, 0.0]],
            ],
        };
        let msd = calculate_msd(&trajectory, &[0]);
        for (actual, expected) in msd.iter().zip([0.0, 0.16, 0.64]) {
            assert!((actual - expected).abs() < 1.0e-12);
        }
        let (slope, intercept) = linear_fit(&[0.0, 1.0, 2.0], &msd);
        assert!((slope - 0.32).abs() < 1.0e-12);
        assert!((intercept + 0.053_333_333_333_333_33).abs() < 1.0e-12);
    }

    #[test]
    fn oxidation_defaults_match_pinned_pydefect_table() {
        let charges = default_charges();
        assert_eq!(charges.get("Cu"), Some(&1.0));
        assert_eq!(charges.get("S"), Some(&-2.0));
        assert_eq!(charges.get("Fe"), Some(&2.0));
        assert_eq!(charges.get("H"), Some(&1.0));
    }

    #[test]
    fn wrapped_half_cell_displacements_use_numpy_round_ties_to_even() {
        assert_eq!(round_ties_even(0.5), 0.0);
        assert_eq!(round_ties_even(1.5), 2.0);
        assert_eq!(round_ties_even(-0.5), 0.0);
        assert_eq!(round_ties_even(-1.5), -2.0);
    }
}
