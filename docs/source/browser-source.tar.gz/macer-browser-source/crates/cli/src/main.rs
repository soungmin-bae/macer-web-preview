#![recursion_limit = "256"]

use crate::model_io::{load_evaluator, validate_model_files};
use macer_rust_model::evaluation::OrderedGraph;
use std::path::Path;
mod cell_filter;
mod elements;
mod madelung;
mod md;
mod md_conductivity;
mod md_outputs;
mod md_util;
mod model_io;
mod model_list;
mod netcdf;
mod npz;
mod plots;
mod poscar;
mod rdf;
mod relax;
mod relax_outputs;
mod structure_io;
mod supercell;
mod symmetry;
mod trajectory;
mod ulm;
mod util;
mod vasp_mlff;
mod xdatcar_tool;

const HELP: &str = "\
macer-rust — native Rust atomistic simulation

USAGE:
    macer-rust <COMMAND> [OPTIONS]

COMMANDS:
    relax            Run native single-point, fixed-cell, and variable-cell relaxation slices
    md               Run molecular dynamics with MatterSim 1M/5M, Lennard-Jones, or EMT
    util             Structure and analysis utilities
    vasp4to5         Convert VASP4 POSCAR to VASP5 (add symbols)
    build-graph      Build an ordered graph from a structure JSON file
    evaluate-graph   Evaluate a graph with a supported MatterSim model
    validate-model   Validate a MatterSim 1M/5M manifest and weights file
    --version        Print the package version

Use `macer-rust <COMMAND> --help` for command options.
";

fn command_help(arguments: &[String]) -> &'static str {
    let command = arguments.first().map(String::as_str);
    if command == Some("util") && arguments.get(1).map(String::as_str) == Some("md") {
        return md_util::HELP;
    }
    if command == Some("util")
        && arguments
            .get(1)
            .is_some_and(|argument| madelung::is_madelung_command(argument))
    {
        return madelung::HELP;
    }
    if command == Some("util")
        && arguments.get(1).map(String::as_str) == Some("model")
        && arguments.get(2).map(String::as_str) == Some("list")
    {
        return model_list::HELP;
    }
    if command == Some("util")
        && arguments
            .get(1)
            .is_some_and(|arg| arg == "vasp-mlff" || arg == "vmlff")
        && arguments.get(2).map(String::as_str) == Some("inspect")
    {
        return vasp_mlff::HELP;
    }
    if command == Some("util")
        && arguments
            .get(1)
            .is_some_and(|arg| arg == "xdatcar-tool" || arg == "xt")
    {
        return xdatcar_tool::HELP;
    }
    if command == Some("util") {
        let subcommand = arguments.get(1).map(String::as_str);
        let is_supercell = matches!(subcommand, Some("supercell" | "sc"))
            || (subcommand == Some("pydefect")
                && matches!(
                    arguments.get(2).map(String::as_str),
                    Some("supercell" | "sc")
                ));
        if is_supercell {
            return supercell::HELP;
        }
    }
    match command {
        Some("relax") => relax::HELP,
        Some("md") => md::HELP,
        Some("build-graph") => "Usage: macer-rust build-graph <structure.json>\n",
        Some("evaluate-graph") => {
            "Usage: macer-rust evaluate-graph <manifest.json> <weights.safetensors> <graph.json> [cpu|cuda]\n"
        }
        Some("validate-model") => {
            "Usage: macer-rust validate-model <manifest.json> <weights.safetensors>\n"
        }
        Some("util") | Some("vasp4to5") => util::HELP,
        _ => HELP,
    }
}

fn run() -> Result<(), String> {
    let arguments = std::env::args().skip(1).collect::<Vec<_>>();
    if arguments
        .iter()
        .any(|argument| argument == "--help" || argument == "-h")
    {
        print!("{}", command_help(&arguments));
        return Ok(());
    }
    let mut arguments = arguments.into_iter();
    match arguments.next().as_deref() {
        Some("relax") => relax::run(arguments),
        Some("md") => md::run(arguments),
        Some("util") => util::run(arguments),
        Some("vasp4to5") => util::run_vasp4to5(arguments),
        Some("build-graph") => {
            let structure_path = arguments.next().ok_or("missing structure JSON path")?;
            if arguments.next().is_some() {
                return Err("usage: macer-rust build-graph <structure.json>".into());
            }
            let bytes = std::fs::read(structure_path).map_err(|e| e.to_string())?;
            let structure: macer_rust_core::types::Structure =
                serde_json::from_slice(&bytes).map_err(|e| e.to_string())?;
            let graph = OrderedGraph::from_structure(&structure)?;
            println!(
                "{}",
                serde_json::to_string(&graph).map_err(|e| e.to_string())?
            );
            Ok(())
        }
        Some("evaluate-graph") => {
            let manifest_path = arguments.next().ok_or("missing manifest path")?;
            let weights_path = arguments.next().ok_or("missing weights path")?;
            let graph_path = arguments.next().ok_or("missing graph path")?;
            let device_name = arguments.next().unwrap_or_else(|| "cpu".into());
            if arguments.next().is_some() {
                return Err("usage: macer-rust evaluate-graph <manifest.json> <weights.safetensors> <graph.json> [cpu|cuda]".into());
            }
            let device = match device_name.as_str() {
                "cpu" => candle_core::Device::Cpu,
                #[cfg(feature = "cuda")]
                "cuda" => candle_core::Device::new_cuda(0).map_err(|e| e.to_string())?,
                _ => return Err(format!("unsupported device: {device_name}")),
            };
            let evaluator =
                load_evaluator(Path::new(&manifest_path), Path::new(&weights_path), device)?;
            let graph_bytes = std::fs::read(graph_path).map_err(|e| e.to_string())?;
            let graph: OrderedGraph =
                serde_json::from_slice(&graph_bytes).map_err(|e| e.to_string())?;
            let result = evaluator.evaluate(&graph)?;
            println!(
                "{}",
                serde_json::to_string(&result).map_err(|e| e.to_string())?
            );
            Ok(())
        }
        Some("validate-model") => {
            let manifest_path = arguments.next().ok_or("missing manifest path")?;
            let weights_path = arguments.next().ok_or("missing weights path")?;
            if arguments.next().is_some() {
                return Err(
                    "usage: macer-rust validate-model <manifest.json> <weights.safetensors>".into(),
                );
            }
            let manifest =
                validate_model_files(Path::new(&manifest_path), Path::new(&weights_path))?;
            println!(
                "{} weights verified: {} tensors",
                manifest.model_id,
                manifest.tensors.len(),
            );
            Ok(())
        }
        Some("--version") | Some("-V") => {
            println!("macer-rust {}", env!("CARGO_PKG_VERSION"));
            Ok(())
        }
        _ => Err(HELP.into()),
    }
}

fn main() {
    if let Err(error) = run() {
        eprintln!("macer-rust: {error}");
        std::process::exit(2);
    }
}
