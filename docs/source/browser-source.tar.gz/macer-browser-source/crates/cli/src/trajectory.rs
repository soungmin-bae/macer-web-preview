//! Python-free readers for the trajectory formats used by `macer util md`.

use serde_json::Value;
use std::fs;
use std::path::Path;

#[derive(Debug, Clone)]
pub(crate) struct Trajectory {
    pub atomic_numbers: Vec<u8>,
    pub cell_a: [[f64; 3]; 3],
    pub cells_a: Vec<[[f64; 3]; 3]>,
    pub pbc: [bool; 3],
    /// Fractional coordinates in file atom order, one frame per outer element.
    pub fractional_positions: Vec<Vec<[f64; 3]>>,
}

impl Trajectory {
    pub fn symbols(&self) -> Result<Vec<&'static str>, String> {
        self.atomic_numbers
            .iter()
            .map(|&number| {
                crate::elements::SYMBOLS
                    .get(number as usize)
                    .copied()
                    .filter(|symbol| *symbol != "X")
                    .ok_or_else(|| format!("unsupported atomic number {number} in trajectory"))
            })
            .collect()
    }
}

pub(crate) fn read(path: &Path) -> Result<Trajectory, String> {
    let bytes = fs::read(path).map_err(|error| error.to_string())?;
    if bytes.starts_with(b"- of Ulm") {
        read_ulm(&bytes)
    } else {
        let content = std::str::from_utf8(&bytes)
            .map_err(|_| "trajectory is neither ASE ULM nor UTF-8 XDATCAR".to_string())?;
        read_xdatcar(content)
    }
}

fn read_ulm(bytes: &[u8]) -> Result<Trajectory, String> {
    if bytes.len() < 56 || &bytes[..8] != b"- of Ulm" {
        return Err("invalid ASE ULM trajectory header".into());
    }
    let version = read_i64(bytes, 24)?;
    if version != 3 {
        return Err(format!("unsupported ASE ULM version {version}; expected 3"));
    }
    let item_count = read_i64(bytes, 32)?;
    let table_offset = read_i64(bytes, 40)?;
    if item_count < 0 || table_offset < 0 {
        return Err("ASE ULM trajectory has an incomplete header".into());
    }
    let item_count = item_count as usize;
    let table_offset = table_offset as usize;
    let mut frames = Vec::with_capacity(item_count);
    let mut cells = Vec::with_capacity(item_count);
    let mut atomic_numbers = None;
    let mut initial_cell = None;
    let mut pbc = [true; 3];

    for frame_index in 0..item_count {
        let table_entry = table_offset
            .checked_add(frame_index.checked_mul(8).ok_or("ULM offset overflow")?)
            .ok_or("ULM offset overflow")?;
        let item_offset = read_i64(bytes, table_entry)?;
        if item_offset < 0 {
            return Err(format!("ASE ULM frame {frame_index} has an invalid offset"));
        }
        let item_offset = item_offset as usize;
        let json_len = read_u64(bytes, item_offset)? as usize;
        let json_start = item_offset.checked_add(8).ok_or("ULM offset overflow")?;
        let json_end = json_start
            .checked_add(json_len)
            .filter(|&end| end <= bytes.len())
            .ok_or_else(|| format!("ASE ULM frame {frame_index} JSON is truncated"))?;
        let item: Value = serde_json::from_slice(&bytes[json_start..json_end])
            .map_err(|error| format!("invalid ASE ULM frame {frame_index}: {error}"))?;

        if frame_index == 0 {
            if let Some(values) = item.get("pbc").and_then(Value::as_array) {
                if values.len() == 3 {
                    for (axis, value) in values.iter().enumerate() {
                        pbc[axis] = value.as_bool().unwrap_or(true);
                    }
                }
            }
        }

        let frame_cell = parse_cell(item.get("cell"), bytes)?;
        initial_cell.get_or_insert(frame_cell);
        cells.push(frame_cell);
        let positions_descriptor = item
            .get("positions.")
            .or_else(|| item.get("positions"))
            .ok_or_else(|| format!("ASE ULM frame {frame_index} has no positions"))?;
        let positions = read_float_array(positions_descriptor, bytes)?;
        if positions.len() % 3 != 0 {
            return Err(format!("ASE ULM frame {frame_index} positions are not Nx3"));
        }
        let n_atoms = positions.len() / 3;
        if let Some(numbers_descriptor) = item.get("numbers.").or_else(|| item.get("numbers")) {
            if atomic_numbers.is_none() {
                atomic_numbers = Some(read_integer_array(numbers_descriptor, bytes)?);
            }
        }
        let mut fractional = Vec::with_capacity(n_atoms);
        let inverse_cell = inverse(frame_cell)?;
        for xyz in positions.chunks_exact(3) {
            // ASE stores Cartesian positions and row-vector cell axes.
            let mut position = multiply_row([xyz[0], xyz[1], xyz[2]], inverse_cell);
            for axis in 0..3 {
                if pbc[axis] {
                    position[axis] -= position[axis].floor();
                }
            }
            fractional.push(position);
        }
        frames.push(fractional);
    }

    let atomic_numbers = atomic_numbers.ok_or("ASE ULM trajectory has no atomic numbers")?;
    let cell_a = initial_cell.ok_or("ASE ULM trajectory has no frames")?;
    validate_frames(&atomic_numbers, &frames)?;
    Ok(Trajectory {
        atomic_numbers,
        cell_a,
        cells_a: cells,
        pbc,
        fractional_positions: frames,
    })
}

fn parse_cell(value: Option<&Value>, bytes: &[u8]) -> Result<[[f64; 3]; 3], String> {
    let value = value.ok_or("ASE ULM frame has no cell")?;
    if value.get("ndarray").is_some() {
        let values = read_float_array(value, bytes)?;
        return matrix_from_flat(&values);
    }
    let rows = value.as_array().ok_or("ASE ULM cell must be a 3x3 array")?;
    if rows.len() != 3 {
        return Err("ASE ULM cell must be a 3x3 array".into());
    }
    let mut cell = [[0.0; 3]; 3];
    for (i, row) in rows.iter().enumerate() {
        let values = row
            .as_array()
            .filter(|values| values.len() == 3)
            .ok_or("ASE ULM cell must be a 3x3 array")?;
        for (j, value) in values.iter().enumerate() {
            cell[i][j] = value.as_f64().ok_or("ASE ULM cell contains a non-number")?;
        }
    }
    Ok(cell)
}

fn read_float_array(descriptor: &Value, bytes: &[u8]) -> Result<Vec<f64>, String> {
    let (length, dtype, offset) = array_descriptor(descriptor)?;
    let width = match dtype {
        "float64" => 8,
        "float32" => 4,
        other => return Err(format!("unsupported ASE trajectory float dtype {other}")),
    };
    let start = usize::try_from(offset).map_err(|_| "negative ULM array offset")?;
    let end = start
        .checked_add(length.checked_mul(width).ok_or("ULM array size overflow")?)
        .filter(|&end| end <= bytes.len())
        .ok_or("ASE ULM float array is truncated")?;
    let data = &bytes[start..end];
    Ok(if width == 8 {
        data.chunks_exact(8)
            .map(|chunk| f64::from_le_bytes(chunk.try_into().expect("eight-byte chunk")))
            .collect()
    } else {
        data.chunks_exact(4)
            .map(|chunk| f32::from_le_bytes(chunk.try_into().expect("four-byte chunk")) as f64)
            .collect()
    })
}

fn read_integer_array(descriptor: &Value, bytes: &[u8]) -> Result<Vec<u8>, String> {
    let (length, dtype, offset) = array_descriptor(descriptor)?;
    let width = match dtype {
        "int64" => 8,
        "int32" => 4,
        other => return Err(format!("unsupported ASE trajectory integer dtype {other}")),
    };
    let start = usize::try_from(offset).map_err(|_| "negative ULM array offset")?;
    let end = start
        .checked_add(length.checked_mul(width).ok_or("ULM array size overflow")?)
        .filter(|&end| end <= bytes.len())
        .ok_or("ASE ULM integer array is truncated")?;
    bytes[start..end]
        .chunks_exact(width)
        .map(|chunk| {
            let number = if width == 8 {
                i64::from_le_bytes(chunk.try_into().expect("eight-byte chunk"))
            } else {
                i32::from_le_bytes(chunk.try_into().expect("four-byte chunk")) as i64
            };
            u8::try_from(number).map_err(|_| format!("invalid atomic number {number} in ULM"))
        })
        .collect()
}

fn array_descriptor(value: &Value) -> Result<(usize, &str, i64), String> {
    let descriptor = value
        .get("ndarray")
        .and_then(Value::as_array)
        .filter(|value| value.len() == 3)
        .ok_or("invalid ASE ULM ndarray descriptor")?;
    let shape = descriptor[0]
        .as_array()
        .ok_or("invalid ASE ULM ndarray shape")?;
    let mut length = 1usize;
    for dimension in shape {
        length = length
            .checked_mul(
                usize::try_from(
                    dimension
                        .as_u64()
                        .ok_or("invalid ASE ULM array dimension")?,
                )
                .map_err(|_| "ULM array dimension overflow")?,
            )
            .ok_or("ULM array size overflow")?;
    }
    let dtype = descriptor[1]
        .as_str()
        .ok_or("invalid ASE ULM ndarray dtype")?;
    let offset = descriptor[2]
        .as_i64()
        .ok_or("invalid ASE ULM ndarray offset")?;
    Ok((length, dtype, offset))
}

fn read_i64(bytes: &[u8], offset: usize) -> Result<i64, String> {
    let value = bytes
        .get(offset..offset + 8)
        .ok_or("ASE ULM file is truncated")?;
    Ok(i64::from_le_bytes(
        value.try_into().expect("eight-byte slice"),
    ))
}

fn read_u64(bytes: &[u8], offset: usize) -> Result<u64, String> {
    let value = bytes
        .get(offset..offset + 8)
        .ok_or("ASE ULM file is truncated")?;
    Ok(u64::from_le_bytes(
        value.try_into().expect("eight-byte slice"),
    ))
}

fn read_xdatcar(content: &str) -> Result<Trajectory, String> {
    let lines = content.lines().collect::<Vec<_>>();
    let mut header = parse_xdatcar_header(&lines, 0).ok_or("invalid XDATCAR header".to_string())?;
    let atomic_numbers = header.atomic_numbers.clone();
    let cell_a = header.cell_a;
    let pbc = [true; 3];
    let mut index = header.next_line;
    let mut frames = Vec::new();
    let mut cells = Vec::new();
    let mut dropped = 0usize;

    while index < lines.len() {
        let line = lines[index].trim();
        if line.is_empty() {
            index += 1;
            continue;
        }
        if let Some(new_header) = parse_xdatcar_header(&lines, index) {
            header = new_header;
            index = header.next_line;
            continue;
        }
        if line
            .to_ascii_lowercase()
            .starts_with("direct configuration")
        {
            let count = header.atomic_numbers.len();
            let remaining = lines.len().saturating_sub(index + 1);
            if remaining < count {
                dropped += 1;
                break;
            }
            let mut positions = Vec::with_capacity(count);
            let mut valid = true;
            for row in &lines[index + 1..index + 1 + count] {
                let numbers = row
                    .split_whitespace()
                    .take(3)
                    .map(str::parse::<f64>)
                    .collect::<Result<Vec<_>, _>>();
                match numbers {
                    Ok(values) if values.len() == 3 => {
                        positions.push([values[0], values[1], values[2]])
                    }
                    _ => {
                        valid = false;
                        break;
                    }
                }
            }
            if valid {
                cells.push(header.cell_a);
                frames.push(
                    positions
                        .into_iter()
                        .map(|mut position| {
                            for value in &mut position {
                                *value -= value.floor();
                            }
                            position
                        })
                        .collect(),
                );
                index += count + 1;
            } else {
                dropped += 1;
                index += 1;
            }
            continue;
        }
        index += 1;
    }
    if dropped > 0 {
        eprintln!("Warning: dropped {dropped} malformed trailing/partial XDATCAR frame(s).");
    }
    validate_frames(&atomic_numbers, &frames)?;
    if cells.len() != frames.len() {
        return Err("trajectory frame and cell counts differ".into());
    }
    Ok(Trajectory {
        atomic_numbers,
        cell_a,
        cells_a: cells,
        pbc,
        fractional_positions: frames,
    })
}

struct XdatcarHeader {
    atomic_numbers: Vec<u8>,
    cell_a: [[f64; 3]; 3],
    next_line: usize,
}

fn parse_xdatcar_header(lines: &[&str], start: usize) -> Option<XdatcarHeader> {
    if start + 5 >= lines.len() {
        return None;
    }
    let title = lines[start].trim();
    let scale = lines[start + 1]
        .split_whitespace()
        .next()?
        .parse::<f64>()
        .ok()?;
    let mut raw_cell = [[0.0; 3]; 3];
    for i in 0..3 {
        let row = lines[start + 2 + i]
            .split_whitespace()
            .take(3)
            .map(str::parse::<f64>)
            .collect::<Result<Vec<_>, _>>()
            .ok()?;
        if row.len() != 3 {
            return None;
        }
        for j in 0..3 {
            raw_cell[i][j] = row[j];
        }
    }
    let scale_factor = if scale < 0.0 {
        let raw_volume = determinant(raw_cell).abs();
        if raw_volume <= 0.0 {
            return None;
        }
        (scale.abs() / raw_volume).cbrt()
    } else {
        scale
    };
    let cell = raw_cell.map(|row| row.map(|value| value * scale_factor));
    let line5 = lines[start + 5].split_whitespace().collect::<Vec<_>>();
    let line5_counts =
        !line5.is_empty() && line5.iter().all(|value| value.parse::<usize>().is_ok());
    let (species, counts, next_line) = if line5_counts {
        let counts = line5
            .iter()
            .map(|value| value.parse::<usize>().ok())
            .collect::<Option<Vec<_>>>()?;
        let from_title = title
            .replace(',', " ")
            .split_whitespace()
            .filter(|token| token.len() <= 2 && token.chars().all(char::is_alphabetic))
            .map(normalize_symbol)
            .collect::<Vec<_>>();
        let species = if from_title.len() == counts.len() {
            from_title
        } else {
            const FALLBACK: [&str; 20] = [
                "H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne", "Na", "Mg", "Al", "Si", "P",
                "S", "Cl", "Ar", "K", "Ca",
            ];
            (0..counts.len())
                .map(|i| FALLBACK[i % FALLBACK.len()].to_owned())
                .collect()
        };
        (species, counts, start + 6)
    } else {
        if start + 6 >= lines.len() {
            return None;
        }
        let species = line5
            .iter()
            .map(|symbol| normalize_symbol(symbol))
            .collect::<Vec<_>>();
        let counts = lines[start + 6]
            .split_whitespace()
            .map(str::parse::<usize>)
            .collect::<Result<Vec<_>, _>>()
            .ok()?;
        if species.len() != counts.len() {
            return None;
        }
        (species, counts, start + 7)
    };
    let mut atomic_numbers = Vec::new();
    for (symbol, count) in species.iter().zip(counts) {
        let atomic_number = crate::elements::SYMBOLS
            .iter()
            .position(|candidate| *candidate == symbol)
            .filter(|&number| number > 0)
            .and_then(|number| u8::try_from(number).ok())?;
        atomic_numbers.extend(std::iter::repeat(atomic_number).take(count));
    }
    if atomic_numbers.is_empty() || determinant(cell).abs() < 1.0e-15 {
        return None;
    }
    Some(XdatcarHeader {
        atomic_numbers,
        cell_a: cell,
        next_line,
    })
}

fn normalize_symbol(symbol: &str) -> String {
    let mut chars = symbol.chars();
    chars
        .next()
        .map(|first| first.to_ascii_uppercase().to_string() + &chars.as_str().to_ascii_lowercase())
        .unwrap_or_default()
}

fn validate_frames(atomic_numbers: &[u8], frames: &[Vec<[f64; 3]>]) -> Result<(), String> {
    if atomic_numbers.is_empty() {
        return Err("trajectory has no atoms".into());
    }
    for (index, frame) in frames.iter().enumerate() {
        if frame.len() != atomic_numbers.len() {
            return Err(format!(
                "trajectory frame {index} has {} atoms; expected {}",
                frame.len(),
                atomic_numbers.len()
            ));
        }
        if frame.iter().flatten().any(|value| !value.is_finite()) {
            return Err(format!(
                "trajectory frame {index} contains non-finite coordinates"
            ));
        }
    }
    Ok(())
}

fn matrix_from_flat(values: &[f64]) -> Result<[[f64; 3]; 3], String> {
    if values.len() != 9 {
        return Err("ASE ULM cell must contain nine values".into());
    }
    Ok([
        [values[0], values[1], values[2]],
        [values[3], values[4], values[5]],
        [values[6], values[7], values[8]],
    ])
}

pub(crate) fn multiply_row(vector: [f64; 3], matrix: [[f64; 3]; 3]) -> [f64; 3] {
    std::array::from_fn(|j| (0..3).map(|i| vector[i] * matrix[i][j]).sum())
}

pub(crate) fn inverse(matrix: [[f64; 3]; 3]) -> Result<[[f64; 3]; 3], String> {
    let det = determinant(matrix);
    if !det.is_finite() || det.abs() < 1.0e-15 {
        return Err("trajectory cell is singular".into());
    }
    let m = matrix;
    Ok([
        [
            (m[1][1] * m[2][2] - m[1][2] * m[2][1]) / det,
            (m[0][2] * m[2][1] - m[0][1] * m[2][2]) / det,
            (m[0][1] * m[1][2] - m[0][2] * m[1][1]) / det,
        ],
        [
            (m[1][2] * m[2][0] - m[1][0] * m[2][2]) / det,
            (m[0][0] * m[2][2] - m[0][2] * m[2][0]) / det,
            (m[0][2] * m[1][0] - m[0][0] * m[1][2]) / det,
        ],
        [
            (m[1][0] * m[2][1] - m[1][1] * m[2][0]) / det,
            (m[0][1] * m[2][0] - m[0][0] * m[2][1]) / det,
            (m[0][0] * m[1][1] - m[0][1] * m[1][0]) / det,
        ],
    ])
}

pub(crate) fn determinant(m: [[f64; 3]; 3]) -> f64 {
    m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
        - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
        + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0])
}

#[cfg(test)]
mod tests {
    use super::{determinant, inverse, multiply_row, read, read_xdatcar};
    use std::path::Path;

    #[test]
    fn parses_vasp_xdatcar_and_unwraps_cell_geometry() {
        let content = "Cu S\n1.0\n2 0 0\n0 2 0\n0 0 2\nCu S\n1 1\nDirect configuration= 1\n0.9 0 0\n0.2 0 0\nDirect configuration= 2\n0.1 0 0\n0.3 0 0\n";
        let trajectory = read_xdatcar(content).unwrap();
        assert_eq!(trajectory.atomic_numbers, [29, 16]);
        assert_eq!(trajectory.pbc, [true; 3]);
        assert_eq!(trajectory.fractional_positions.len(), 2);
        assert_eq!(trajectory.cells_a.len(), 2);
        let cell = trajectory.cell_a;
        let inverse = inverse(cell).unwrap();
        let cart = multiply_row([0.5, 0.25, 0.75], cell);
        let back = multiply_row(cart, inverse);
        for (actual, expected) in back.iter().zip([0.5, 0.25, 0.75]) {
            assert!((actual - expected).abs() < 1.0e-12);
        }
    }

    #[test]
    fn supports_negative_vasp_scale_as_target_cell_volume() {
        let content = "Li\n-8\n3 0 0\n0 3 0\n0 0 3\nLi\n1\nDirect configuration= 1\n0 0 0\nDirect configuration= 2\n0.1 0 0\n";
        let trajectory = read_xdatcar(content).unwrap();
        assert!((determinant(trajectory.cell_a).abs() - 8.0).abs() < 1.0e-12);
    }

    #[test]
    fn reads_existing_ase_ulm_trajectory_without_python() {
        let root = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../evidence/mattersim_1m_md_cpu_parity_2026-10-23/macer/md.traj");
        if root.exists() {
            let trajectory = read(&root).unwrap();
            assert_eq!(trajectory.atomic_numbers.len(), 12);
            assert_eq!(trajectory.fractional_positions.len(), 6);
        }
    }
}
