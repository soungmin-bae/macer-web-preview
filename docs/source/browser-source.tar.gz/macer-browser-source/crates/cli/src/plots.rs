//! Small self-contained PDF plots for the default `macer md` diagnostics.
//! This keeps native MD output independent of Python and plotting runtimes.

use std::collections::HashMap;
use std::fs;
use std::path::Path;

type Point = (f64, f64);

struct Series<'a> {
    label: &'a str,
    points: Vec<Point>,
    color: (f64, f64, f64),
}

struct Panel<'a> {
    y_label: &'a str,
    series: Vec<Series<'a>>,
    x_label: Option<&'a str>,
    show_legend: bool,
    x_limits: Option<(f64, f64)>,
    y_limits: Option<(f64, f64)>,
}

pub(crate) fn csv_columns(path: &Path) -> Result<HashMap<String, Vec<f64>>, String> {
    let text = fs::read_to_string(path).map_err(|error| error.to_string())?;
    let mut lines = text.lines();
    let headers = lines
        .next()
        .ok_or_else(|| "MD CSV is empty".to_string())?
        .split(',')
        .map(str::to_string)
        .collect::<Vec<_>>();
    let mut columns = headers
        .iter()
        .map(|header| (header.clone(), Vec::new()))
        .collect::<HashMap<_, _>>();
    for (row_index, line) in lines.enumerate() {
        if line.trim().is_empty() {
            continue;
        }
        let values = line
            .split(',')
            .map(|field| {
                field
                    .parse::<f64>()
                    .map_err(|_| format!("invalid numeric MD CSV value at row {}", row_index + 2))
            })
            .collect::<Result<Vec<_>, _>>()?;
        if values.len() != headers.len() {
            return Err(format!(
                "MD CSV row {} has the wrong number of columns",
                row_index + 2
            ));
        }
        for (header, value) in headers.iter().zip(values) {
            columns
                .get_mut(header)
                .expect("header initialized")
                .push(value);
        }
    }
    if columns.values().any(Vec::is_empty) {
        return Err("MD CSV has no data rows".into());
    }
    Ok(columns)
}

fn column<'a>(columns: &'a HashMap<String, Vec<f64>>, name: &str) -> Result<&'a [f64], String> {
    columns
        .get(name)
        .map(Vec::as_slice)
        .ok_or_else(|| format!("MD CSV is missing column {name}"))
}

fn series<'a>(x: &[f64], y: &[f64], label: &'a str, color: (f64, f64, f64)) -> Vec<Series<'a>> {
    vec![Series {
        label,
        points: x.iter().copied().zip(y.iter().copied()).collect(),
        color,
    }]
}

fn draw_panel(
    stream: &mut String,
    panel: &Panel<'_>,
    width: f64,
    bottom: f64,
    height: f64,
) -> Result<(), String> {
    const LEFT: f64 = 74.0;
    const RIGHT: f64 = 24.0;
    const TOP: f64 = 24.0;
    const BOTTOM: f64 = 42.0;
    let plot_left = LEFT;
    let plot_right = width - RIGHT;
    let plot_bottom = bottom + BOTTOM;
    let plot_top = bottom + height - TOP;
    let x_values = panel
        .series
        .iter()
        .flat_map(|item| item.points.iter().map(|point| point.0))
        .collect::<Vec<_>>();
    let y_values = panel
        .series
        .iter()
        .flat_map(|item| item.points.iter().map(|point| point.1))
        .collect::<Vec<_>>();
    let (x_min, x_max) = panel.x_limits.unwrap_or_else(|| {
        if x_values.is_empty() {
            (0.0, 1.0)
        } else {
            padded_range(&x_values)
        }
    });
    let (y_min, y_max) = panel.y_limits.unwrap_or_else(|| {
        if y_values.is_empty() {
            (0.0, 1.0)
        } else {
            padded_range(&y_values)
        }
    });

    stream.push_str("0.84 0.84 0.84 RG 0.45 w\n");
    for tick in 0..=4 {
        let fraction = tick as f64 / 4.0;
        let y = plot_bottom + fraction * (plot_top - plot_bottom);
        stream.push_str(&format!(
            "{plot_left:.3} {y:.3} m {plot_right:.3} {y:.3} l S\n"
        ));
        let value = y_min + fraction * (y_max - y_min);
        text_right(
            stream,
            plot_left - 6.0,
            y - 3.0,
            8.0,
            &tick_label(value, y_max - y_min),
        );
    }
    stream.push_str("0.1 0.1 0.1 RG 0.8 w\n");
    stream.push_str(&format!(
        "{plot_left:.3} {plot_bottom:.3} m {plot_left:.3} {plot_top:.3} l S\n"
    ));
    stream.push_str(&format!(
        "{plot_left:.3} {plot_bottom:.3} m {plot_right:.3} {plot_bottom:.3} l S\n"
    ));

    for item in &panel.series {
        if item.label.is_empty() {
            stream.push_str("[4 3] 0 d\n");
        }
        stream.push_str(&format!(
            "{:.4} {:.4} {:.4} RG 1.15 w\n",
            item.color.0, item.color.1, item.color.2
        ));
        let mut pen_down = false;
        for (x, y) in &item.points {
            if !x.is_finite() || !y.is_finite() {
                pen_down = false;
                continue;
            }
            let px = plot_left + (x - x_min) / (x_max - x_min) * (plot_right - plot_left);
            let py = plot_bottom + (y - y_min) / (y_max - y_min) * (plot_top - plot_bottom);
            stream.push_str(&format!(
                "{px:.3} {py:.3} {}\n",
                if pen_down { "l" } else { "m" }
            ));
            pen_down = true;
        }
        stream.push_str("S\n");
        if item.label.is_empty() {
            stream.push_str("[] 0 d\n");
        }
    }

    text_vertical(
        stream,
        10.0,
        bottom + height / 2.0 - 4.0,
        9.0,
        panel.y_label,
    );
    if let Some(label) = panel.x_label {
        text_center(
            stream,
            (plot_left + plot_right) / 2.0,
            bottom + 10.0,
            9.0,
            label,
        );
        for tick in 0..=4 {
            let fraction = tick as f64 / 4.0;
            let x = plot_left + fraction * (plot_right - plot_left);
            let value = x_min + fraction * (x_max - x_min);
            text_center(
                stream,
                x,
                plot_bottom - 14.0,
                7.5,
                &tick_label(value, x_max - x_min),
            );
        }
    }
    if panel.show_legend {
        let mut legend_x = plot_left + 5.0;
        let legend_y = plot_top - 13.0;
        for item in &panel.series {
            if item.label.is_empty() {
                continue;
            }
            stream.push_str(&format!(
                "{:.4} {:.4} {:.4} RG 1.5 w {legend_x:.3} {legend_y:.3} m {:.3} {legend_y:.3} l S\n",
                item.color.0, item.color.1, item.color.2, legend_x + 14.0
            ));
            text(stream, legend_x + 18.0, legend_y - 3.0, 8.0, item.label);
            legend_x += (item.label.chars().count() as f64 * 4.2 + 30.0).max(48.0);
        }
    }
    Ok(())
}

fn padded_range(values: &[f64]) -> (f64, f64) {
    let minimum = values.iter().copied().fold(f64::INFINITY, f64::min);
    let maximum = values.iter().copied().fold(f64::NEG_INFINITY, f64::max);
    let padding = if maximum > minimum {
        (maximum - minimum) * 0.06
    } else {
        (maximum.abs() * 0.05).max(1.0)
    };
    (minimum - padding, maximum + padding)
}

fn tick_label(value: f64, span: f64) -> String {
    let interval = span / 4.0;
    if interval >= 10_000.0 {
        return format!("{value:.1e}");
    }
    let decimals = if interval < 1.0 {
        ((-interval.log10()).ceil() as usize + 1).min(7)
    } else {
        2
    };
    let adjusted = if value.abs() < interval * 1.0e-5 {
        0.0
    } else {
        value
    };
    format!("{adjusted:.decimals$}")
}

fn text(stream: &mut String, x: f64, y: f64, size: f64, value: &str) {
    let escaped = value
        .replace('\\', "\\\\")
        .replace('(', "\\(")
        .replace(')', "\\)");
    stream.push_str("0.1 0.1 0.1 rg\nBT /F1 ");
    stream.push_str(&format!("{size:.2} Tf "));
    stream.push_str(&format!("{x:.3} {y:.3} Td ({escaped}) Tj ET\n"));
}

fn text_center(stream: &mut String, x: f64, y: f64, size: f64, value: &str) {
    let estimated_width = value.chars().count() as f64 * size * 0.52;
    text(stream, x - estimated_width / 2.0, y, size, value);
}

fn text_right(stream: &mut String, x: f64, y: f64, size: f64, value: &str) {
    let estimated_width = value.chars().count() as f64 * size * 0.52;
    text(stream, x - estimated_width, y, size, value);
}

fn text_vertical(stream: &mut String, x: f64, y: f64, size: f64, value: &str) {
    let escaped = value
        .replace('\\', "\\\\")
        .replace('(', "\\(")
        .replace(')', "\\)");
    stream.push_str("0.1 0.1 0.1 rg\nBT /F1 ");
    stream.push_str(&format!(
        "{size:.2} Tf 0 1 -1 0 {x:.3} {y:.3} Tm ({escaped}) Tj ET\n"
    ));
}

fn write_pdf(path: &Path, width: f64, height: f64, panels: &[Panel<'_>]) -> Result<(), String> {
    write_pdf_titled(path, width, height, panels, None)
}

fn write_pdf_titled(
    path: &Path,
    width: f64,
    height: f64,
    panels: &[Panel<'_>],
    title: Option<&str>,
) -> Result<(), String> {
    if panels.is_empty() {
        return Err("cannot create an empty PDF plot".into());
    }
    let panel_height = (height - 32.0) / panels.len() as f64;
    let mut content = String::from("1 J 1 j\n");
    if let Some(title) = title {
        text_center(&mut content, width / 2.0, height - 18.0, 11.0, title);
    }
    for (index, panel) in panels.iter().enumerate() {
        let bottom = 16.0 + (panels.len() - 1 - index) as f64 * panel_height;
        draw_panel(&mut content, panel, width, bottom, panel_height)?;
    }
    let stream_len = content.len();
    let objects = [
        "<< /Type /Catalog /Pages 2 0 R >>".to_string(),
        "<< /Type /Pages /Kids [3 0 R] /Count 1 >>".to_string(),
        format!(
            "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {width:.0} {height:.0}] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>"
        ),
        format!("<< /Length {stream_len} >>\nstream\n{content}endstream"),
        "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>".to_string(),
    ];
    let mut pdf = b"%PDF-1.4\n%macerrust\n".to_vec();
    let mut offsets = vec![0usize];
    for (index, object) in objects.iter().enumerate() {
        offsets.push(pdf.len());
        pdf.extend_from_slice(format!("{} 0 obj\n{}\nendobj\n", index + 1, object).as_bytes());
    }
    let xref_offset = pdf.len();
    pdf.extend_from_slice(
        format!("xref\n0 {}\n0000000000 65535 f \n", objects.len() + 1).as_bytes(),
    );
    for offset in offsets.iter().skip(1) {
        pdf.extend_from_slice(format!("{offset:010} 00000 n \n").as_bytes());
    }
    pdf.extend_from_slice(
        format!(
            "trailer\n<< /Size {} /Root 1 0 R >>\nstartxref\n{xref_offset}\n%%EOF\n",
            objects.len() + 1
        )
        .as_bytes(),
    );
    fs::write(path, pdf).map_err(|error| error.to_string())
}

pub fn write_md_plots(output: &Path) -> Result<(), String> {
    let columns = csv_columns(&output.join("md.csv"))?;
    let time_ps = column(&columns, "time_fs")?
        .iter()
        .map(|value| value / 1000.0)
        .collect::<Vec<_>>();
    let thermo = [
        Panel {
            y_label: "Temp (K)",
            series: series(
                column(&columns, "time_fs")?,
                column(&columns, "T_K")?,
                "Temperature",
                (0.122, 0.467, 0.706),
            ),
            x_label: None,
            show_legend: false,
            x_limits: None,
            y_limits: None,
        },
        Panel {
            y_label: "E_pot (eV)",
            series: series(
                column(&columns, "time_fs")?,
                column(&columns, "Epot_eV")?,
                "E_pot",
                (1.0, 0.498, 0.055),
            ),
            x_label: None,
            show_legend: false,
            x_limits: None,
            y_limits: None,
        },
        Panel {
            y_label: "Pressure (GPa)",
            series: series(
                column(&columns, "time_fs")?,
                column(&columns, "P_GPa")?,
                "Pressure",
                (0.173, 0.627, 0.173),
            ),
            x_label: Some("Time (ps)"),
            show_legend: false,
            x_limits: None,
            y_limits: None,
        },
    ];
    // Plot x values in picoseconds, matching macer's default analysis axes.
    let mut thermo = thermo;
    for panel in &mut thermo {
        for item in &mut panel.series {
            for point in &mut item.points {
                point.0 /= 1000.0;
            }
        }
    }
    let cell = [
        Panel {
            y_label: "Lattice Constant (A)",
            series: vec![
                Series {
                    label: "a",
                    points: time_ps
                        .iter()
                        .copied()
                        .zip(column(&columns, "a_A")?.iter().copied())
                        .collect(),
                    color: (0.122, 0.467, 0.706),
                },
                Series {
                    label: "b",
                    points: time_ps
                        .iter()
                        .copied()
                        .zip(column(&columns, "b_A")?.iter().copied())
                        .collect(),
                    color: (1.0, 0.498, 0.055),
                },
                Series {
                    label: "c",
                    points: time_ps
                        .iter()
                        .copied()
                        .zip(column(&columns, "c_A")?.iter().copied())
                        .collect(),
                    color: (0.173, 0.627, 0.173),
                },
            ],
            x_label: None,
            show_legend: true,
            x_limits: None,
            y_limits: None,
        },
        Panel {
            y_label: "Volume (A^3)",
            series: series(
                &time_ps,
                column(&columns, "Vol_A3")?,
                "Volume",
                (0.839, 0.153, 0.157),
            ),
            x_label: Some("Time (ps)"),
            show_legend: false,
            x_limits: None,
            y_limits: None,
        },
    ];
    write_pdf(&output.join("md_thermo.pdf"), 576.0, 720.0, &thermo)?;
    write_pdf(&output.join("md_cell.pdf"), 576.0, 576.0, &cell)
}

pub fn write_md_log_plot(input: &Path, output: &Path) -> Result<(), String> {
    let columns = csv_columns(input)?;
    let time = column(&columns, "time_fs")?;
    let temperature = column(&columns, "T_K")?;
    let potential_energy = column(&columns, "Epot_eV")?;
    if time.len() != temperature.len() || time.len() != potential_energy.len() {
        return Err("MD CSV columns have different lengths".into());
    }
    let mut panels = vec![
        Panel {
            y_label: "Temperature (K)",
            series: series(time, temperature, "Temperature", (1.0, 0.0, 0.0)),
            x_label: None,
            show_legend: false,
            x_limits: None,
            y_limits: None,
        },
        Panel {
            y_label: "Potential Energy (eV)",
            series: series(time, potential_energy, "Potential Energy", (0.0, 0.0, 1.0)),
            x_label: None,
            show_legend: false,
            x_limits: None,
            y_limits: None,
        },
    ];
    let pressure = columns.get("P_GPa");
    panels.push(Panel {
        y_label: "Pressure (GPa)",
        series: pressure
            .map(|values| series(time, values, "Pressure", (0.0, 0.5, 0.0)))
            .unwrap_or_default(),
        x_label: Some("Time (fs)"),
        show_legend: false,
        x_limits: None,
        y_limits: None,
    });
    if let Some(pressure) = pressure {
        if time.len() != pressure.len() {
            return Err("MD CSV columns have different lengths".into());
        }
    }
    write_pdf(output, 720.0, 864.0, &panels)
}

pub(crate) fn write_md_conductivity_plot(
    path: &Path,
    time_ps: &[f64],
    curves: &[(&str, &[f64], &[f64], f64)],
    temp_k: f64,
    sigma_ms_per_cm: f64,
) -> Result<(), String> {
    if time_ps.is_empty() || curves.is_empty() {
        return Err("conductivity plot needs nonempty trajectory data".into());
    }
    let colors = [
        (0.122, 0.467, 0.706),
        (1.0, 0.498, 0.055),
        (0.173, 0.627, 0.173),
        (0.839, 0.153, 0.157),
        (0.58, 0.40, 0.74),
        (0.55, 0.34, 0.29),
        (0.89, 0.47, 0.76),
        (0.50, 0.50, 0.50),
    ];
    let labels = curves
        .iter()
        .map(|(symbol, _, _, diffusion)| format!("{symbol} (D={})", scientific_label(*diffusion)))
        .collect::<Vec<_>>();
    let mut plot_series = Vec::with_capacity(curves.len() * 2);
    for (index, ((_, msd, fit, _), label)) in curves.iter().zip(&labels).enumerate() {
        if msd.len() != time_ps.len() || fit.len() != time_ps.len() {
            return Err(format!(
                "conductivity MSD series {index} has the wrong length"
            ));
        }
        plot_series.push(Series {
            label,
            points: time_ps.iter().copied().zip(msd.iter().copied()).collect(),
            color: colors[index % colors.len()],
        });
        plot_series.push(Series {
            label: "",
            points: time_ps.iter().copied().zip(fit.iter().copied()).collect(),
            color: (0.45, 0.45, 0.45),
        });
    }
    let panels = [Panel {
        y_label: "MSD (A^2)",
        series: plot_series,
        x_label: Some("Time (ps)"),
        show_legend: true,
        x_limits: None,
        y_limits: None,
    }];
    let title = format!("MSD @ {temp_k:?}K (Total sigma = {sigma_ms_per_cm:.2} mS/cm)");
    write_pdf_titled(path, 576.0, 432.0, &panels, Some(&title))
}

pub(crate) fn write_rdf_plot(path: &Path, result: &crate::rdf::ResultData) -> Result<(), String> {
    if result.radii.is_empty() || result.curves.is_empty() {
        return Err("RDF plot requires at least one pair curve".into());
    }
    let colors = [
        (0.122, 0.467, 0.706),
        (1.0, 0.498, 0.055),
        (0.173, 0.627, 0.173),
        (0.839, 0.153, 0.157),
        (0.58, 0.40, 0.74),
        (0.55, 0.34, 0.29),
        (0.89, 0.47, 0.76),
        (0.50, 0.50, 0.50),
    ];
    let series = result
        .curves
        .iter()
        .enumerate()
        .map(|(index, curve)| {
            if curve.values.len() != result.radii.len() {
                return Err(format!("RDF curve {} has the wrong length", curve.label));
            }
            Ok(Series {
                label: &curve.label,
                points: result
                    .radii
                    .iter()
                    .copied()
                    .zip(curve.values.iter().copied())
                    .collect(),
                color: colors[index % colors.len()],
            })
        })
        .collect::<Result<Vec<_>, String>>()?;
    let max_value = result
        .curves
        .iter()
        .flat_map(|curve| curve.values.iter().copied())
        .fold(0.0_f64, f64::max);
    let y_max = if max_value > 0.0 {
        max_value * 1.05
    } else {
        1.0
    };
    let panel = Panel {
        y_label: "Radial Distribution g(r)",
        series,
        x_label: Some("Distance r (A)"),
        show_legend: true,
        x_limits: Some((0.0, result.safe_rmax)),
        y_limits: Some((0.0, y_max)),
    };
    let title = format!(
        "Radial Distribution Function (Averaged over last {} frames)",
        result.n_frames
    );
    write_pdf_titled(path, 720.0, 432.0, &[panel], Some(&title))
}

pub(crate) fn write_cell_evolution_plot(
    path: &Path,
    x: &[f64],
    x_label: &str,
    a: &[f64],
    b: &[f64],
    c: &[f64],
    volume: &[f64],
    start_x: f64,
    end_x: f64,
    averages: [f64; 4],
    selection: &str,
) -> Result<(), String> {
    if x.is_empty()
        || [a, b, c, volume]
            .iter()
            .any(|values| values.len() != x.len())
    {
        return Err("cell-evolution plot requires equal, nonempty series".into());
    }
    let x_span = padded_range(x);
    let lattice_min = a
        .iter()
        .chain(b)
        .chain(c)
        .copied()
        .fold(f64::INFINITY, f64::min);
    let lattice_max = a
        .iter()
        .chain(b)
        .chain(c)
        .copied()
        .fold(f64::NEG_INFINITY, f64::max);
    let volume_min = volume.iter().copied().fold(f64::INFINITY, f64::min);
    let volume_max = volume.iter().copied().fold(f64::NEG_INFINITY, f64::max);
    let cell = Panel {
        y_label: "Lattice Constant (A)",
        series: vec![
            Series {
                label: "a",
                points: x.iter().copied().zip(a.iter().copied()).collect(),
                color: (0.122, 0.467, 0.706),
            },
            Series {
                label: "b",
                points: x.iter().copied().zip(b.iter().copied()).collect(),
                color: (1.0, 0.498, 0.055),
            },
            Series {
                label: "c",
                points: x.iter().copied().zip(c.iter().copied()).collect(),
                color: (0.173, 0.627, 0.173),
            },
            Series {
                label: "",
                points: vec![(start_x, averages[0]), (end_x, averages[0])],
                color: (0.122, 0.467, 0.706),
            },
            Series {
                label: "",
                points: vec![(start_x, averages[1]), (end_x, averages[1])],
                color: (1.0, 0.498, 0.055),
            },
            Series {
                label: "",
                points: vec![(start_x, averages[2]), (end_x, averages[2])],
                color: (0.173, 0.627, 0.173),
            },
            Series {
                label: "Start Avg",
                points: vec![(start_x, lattice_min), (start_x, lattice_max)],
                color: (0.15, 0.15, 0.15),
            },
            Series {
                label: "End Avg",
                points: vec![(end_x, lattice_min), (end_x, lattice_max)],
                color: (0.45, 0.45, 0.45),
            },
        ],
        x_label: None,
        show_legend: true,
        x_limits: None,
        y_limits: None,
    };
    let vol = Panel {
        y_label: "Volume (A^3)",
        series: vec![
            Series {
                label: "Volume",
                points: x.iter().copied().zip(volume.iter().copied()).collect(),
                color: (0.839, 0.153, 0.157),
            },
            Series {
                label: "",
                points: vec![(start_x, averages[3]), (end_x, averages[3])],
                color: (0.839, 0.153, 0.157),
            },
            Series {
                label: "",
                points: vec![(start_x, volume_min), (start_x, volume_max)],
                color: (0.15, 0.15, 0.15),
            },
            Series {
                label: "",
                points: vec![(end_x, volume_min), (end_x, volume_max)],
                color: (0.45, 0.45, 0.45),
            },
        ],
        x_label: Some(x_label),
        show_legend: true,
        x_limits: None,
        y_limits: None,
    };
    let title = format!("Cell Parameters Evolution ({selection})");
    let _ = x_span;
    write_pdf_titled(path, 576.0, 576.0, &[cell, vol], Some(&title))
}

fn scientific_label(value: f64) -> String {
    if !value.is_finite() {
        return if value.is_nan() {
            "nan".into()
        } else if value.is_sign_positive() {
            "inf".into()
        } else {
            "-inf".into()
        };
    }
    let rendered = format!("{value:.1e}");
    let (mantissa, exponent) = rendered
        .split_once('e')
        .expect("scientific exponent exists");
    let exponent = exponent
        .parse::<i32>()
        .expect("scientific exponent numeric");
    format!(
        "{mantissa}e{}{abs:02}",
        if exponent >= 0 { "+" } else { "-" },
        abs = exponent.abs()
    )
}

pub fn write_relax_single_point_plot(
    path: &Path,
    energy_ev: f64,
    fmax_ev_per_a: f64,
) -> Result<(), String> {
    let panels = [
        Panel {
            y_label: "Energy (eV)",
            series: vec![Series {
                label: "Total energy",
                points: vec![(0.0, energy_ev)],
                color: (0.122, 0.467, 0.706),
            }],
            x_label: Some("Single point"),
            show_legend: false,
            x_limits: None,
            y_limits: None,
        },
        Panel {
            y_label: "Fmax (eV/A)",
            series: vec![Series {
                label: "Maximum force",
                points: vec![(0.0, fmax_ev_per_a)],
                color: (0.839, 0.153, 0.157),
            }],
            x_label: None,
            show_legend: false,
            x_limits: None,
            y_limits: None,
        },
    ];
    write_pdf(path, 576.0, 420.0, &panels)
}

pub fn write_relax_history_plot(
    path: &Path,
    energies_ev: &[f64],
    fmax_ev_per_a: &[f64],
) -> Result<(), String> {
    if energies_ev.is_empty() || energies_ev.len() != fmax_ev_per_a.len() {
        return Err("relaxation plot history must have matching, nonempty series".into());
    }
    let steps = (0..energies_ev.len())
        .map(|step| step as f64)
        .collect::<Vec<_>>();
    let panels = [
        Panel {
            y_label: "Energy (eV)",
            series: series(&steps, energies_ev, "Total energy", (0.122, 0.467, 0.706)),
            x_label: Some("Optimization step"),
            show_legend: false,
            x_limits: None,
            y_limits: None,
        },
        Panel {
            y_label: "Fmax (eV/A)",
            series: series(
                &steps,
                fmax_ev_per_a,
                "Maximum force",
                (0.839, 0.153, 0.157),
            ),
            x_label: None,
            show_legend: false,
            x_limits: None,
            y_limits: None,
        },
    ];
    write_pdf(path, 576.0, 520.0, &panels)
}

#[cfg(test)]
mod tests {
    use super::{scientific_label, write_md_log_plot, write_md_plots};
    use std::fs;

    #[test]
    fn writes_parseable_single_page_pdf_diagnostics_from_md_csv() {
        let dir = std::env::temp_dir().join(format!("macer-rust-pdf-{}", std::process::id()));
        fs::create_dir_all(&dir).unwrap();
        fs::write(
            dir.join("md.csv"),
            "step,time_fs,Epot_eV,Ekin_eV,Etot_eV,T_K,a_A,b_A,c_A,Vol_A3,P_GPa,H_eV\n\
             0,0,-10,0,-10,0,2,3,4,24,0,-10\n\
             1,1,-9.9,0.1,-9.8,10,2.01,3,4,24.12,0.1,-9.7\n",
        )
        .unwrap();
        write_md_plots(&dir).unwrap();
        for name in ["md_thermo.pdf", "md_cell.pdf"] {
            let bytes = fs::read(dir.join(name)).unwrap();
            let text = String::from_utf8_lossy(&bytes);
            assert!(text.starts_with("%PDF-1.4"));
            assert!(text.contains("/Subtype /Type1 /BaseFont /Helvetica"));
            assert!(text.contains("%%EOF"));
        }
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn writes_legacy_md_plot_panels_even_without_pressure_column() {
        let dir = std::env::temp_dir().join(format!("macer-rust-md-plot-{}", std::process::id()));
        fs::create_dir_all(&dir).unwrap();
        let csv = dir.join("md.csv");
        let pdf = dir.join("md_plot.pdf");
        fs::write(&csv, "step,time_fs,T_K,Epot_eV\n0,0,100,-10\n1,1,200,-9\n").unwrap();
        write_md_log_plot(&csv, &pdf).unwrap();
        let bytes = fs::read(&pdf).unwrap();
        let text = String::from_utf8_lossy(&bytes);
        assert!(text.starts_with("%PDF-1.4"));
        assert!(text.contains("Temperature \\(K\\)"));
        assert!(text.contains("Potential Energy \\(eV\\)"));
        assert!(text.contains("Pressure \\(GPa\\)"));
        assert!(text.contains("Time \\(fs\\)"));
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn plot_scientific_labels_keep_python_exponent_padding() {
        assert_eq!(scientific_label(2.7e-9), "2.7e-09");
        assert_eq!(scientific_label(1.0e12), "1.0e+12");
    }
}
