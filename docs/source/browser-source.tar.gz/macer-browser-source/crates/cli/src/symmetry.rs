//! Space-group sampling for trajectory analysis, implemented with Moyo.

use moyo::base::{Cell, Lattice, Position};
use moyo::MoyoDataset;
use std::collections::BTreeMap;

use crate::trajectory::Trajectory;

const SYMPREC_ANGSTROM: f64 = 1.0e-2;

#[derive(Debug)]
pub(crate) struct SymmetrySamples {
    pub rows: Vec<(usize, String)>,
    pub counts: BTreeMap<String, usize>,
}

pub(crate) fn analyze(trajectory: &Trajectory, requested_samples: usize) -> SymmetrySamples {
    let n_frames = trajectory.fractional_positions.len();
    let frame_indices = sample_indices(n_frames, requested_samples);
    let numbers = trajectory
        .atomic_numbers
        .iter()
        .map(|&number| i32::from(number))
        .collect::<Vec<_>>();
    let mut rows = Vec::with_capacity(frame_indices.len());
    let mut counts = BTreeMap::new();

    for frame_index in frame_indices {
        let cell = Cell::new(
            Lattice::from_basis(trajectory.cells_a[frame_index]),
            trajectory.fractional_positions[frame_index]
                .iter()
                .map(|position| Position::new(position[0], position[1], position[2]))
                .collect(),
            numbers.clone(),
        );
        let spacegroup = MoyoDataset::with_default(&cell, SYMPREC_ANGSTROM)
            .map(|dataset| {
                let compact_symbol = dataset.hm_symbol.split_whitespace().collect::<String>();
                format!("{compact_symbol} ({})", dataset.number)
            })
            .unwrap_or_else(|_| "N/A".to_owned());
        *counts.entry(spacegroup.clone()).or_insert(0) += 1;
        rows.push((frame_index, spacegroup));
    }

    SymmetrySamples { rows, counts }
}

fn sample_indices(n_frames: usize, requested_samples: usize) -> Vec<usize> {
    let count = n_frames.min(requested_samples);
    if count == 0 {
        return Vec::new();
    }
    if count == 1 {
        return vec![0];
    }
    let step = (n_frames - 1) as f64 / (count - 1) as f64;
    let mut indices = Vec::with_capacity(count);
    for sample in 0..count {
        let frame = (sample as f64 * step).floor() as usize;
        if indices.last().copied() != Some(frame) {
            indices.push(frame);
        }
    }
    indices
}

#[cfg(test)]
mod tests {
    use super::sample_indices;

    #[test]
    fn sample_indices_match_unique_integer_linspace() {
        assert_eq!(sample_indices(7, 0), Vec::<usize>::new());
        assert_eq!(sample_indices(7, 1), [0]);
        assert_eq!(sample_indices(7, 4), [0, 2, 4, 6]);
        assert_eq!(sample_indices(7, 20), [0, 1, 2, 3, 4, 5, 6]);
        assert_eq!(sample_indices(10, 4), [0, 3, 6, 9]);
    }
}
