//! Minimal NumPy NPZ writer for macer's `md-restart-v2` interchange format.
//! Arrays use only numeric and fixed-width Unicode dtypes, so no pickle code
//! is needed by the Python-free Rust runtime.

use macer_rust_core::dynamics::DynamicsState;
use macer_rust_core::types::{Potential, Structure};
use std::collections::HashMap;
use std::fs::{self, File, OpenOptions};
use std::io::Write;
use std::path::Path;

const ASE_FS: f64 = 0.098_226_947_884_640_63;

struct ZipEntry {
    name: String,
    data: Vec<u8>,
    crc32: u32,
    local_offset: u32,
}

pub fn write_macer_restart_npz(
    path: &Path,
    state: &DynamicsState,
    ensemble: &str,
    dt_fs: f64,
    output_dir: &Path,
) -> Result<(), String> {
    let legacy_step = state
        .step
        .checked_add(2)
        .ok_or("macer restart step counter overflow")?;
    let step = i64::try_from(legacy_step).map_err(|_| "macer restart step exceeds int64")?;
    let natom = i64::try_from(state.structure.atomic_numbers.len())
        .map_err(|_| "atom count exceeds int64")?;
    let symbols: Vec<String> = state
        .structure
        .atomic_numbers
        .iter()
        .map(|&z| {
            crate::elements::SYMBOLS
                .get(z as usize)
                .map(|symbol| symbol.to_string())
                .ok_or_else(|| format!("atomic number {z} has no element symbol"))
        })
        .collect::<Result<_, _>>()?;
    let masses: Vec<f64> = state.masses_amu.iter().copied().collect();
    let velocities: Vec<f64> = state
        .velocities_a_per_fs
        .iter()
        .flatten()
        .map(|&velocity| velocity / ASE_FS)
        .collect();
    let positions: Vec<f64> = state
        .structure
        .positions_a
        .iter()
        .flatten()
        .copied()
        .collect();
    let cell: Vec<f64> = state.structure.cell_a.iter().flatten().copied().collect();
    let meta_json = format!(
        "{{\"output_dir\":{},\"source\":\"md\"}}",
        serde_json::to_string(&output_dir.display().to_string()).map_err(|e| e.to_string())?
    );

    let mut entries = Vec::new();
    add_unicode(&mut entries, "schema_version", "()", &["md-restart-v2"])?;
    add_unicode(
        &mut entries,
        "producer",
        "()",
        &["macer.molecular_dynamics.restart"],
    )?;
    add_unicode(&mut entries, "created_at", "()", &[&utc_timestamp()])?;
    add_unicode(&mut entries, "units_length", "()", &["angstrom"])?;
    add_unicode(&mut entries, "units_cell", "()", &["angstrom"])?;
    add_unicode(&mut entries, "units_velocity", "()", &["angstrom/ase_time"])?;
    add_unicode(&mut entries, "units_mass", "()", &["amu"])?;
    add_i64(&mut entries, "step", "()", &[step])?;
    add_unicode(&mut entries, "ensemble", "()", &[ensemble])?;
    add_f64(&mut entries, "tstep_fs", "()", &[dt_fs])?;
    add_i64(&mut entries, "natom", "()", &[natom])?;
    add_f64(&mut entries, "cell", "(3, 3)", &cell)?;
    add_unicode(
        &mut entries,
        "symbols",
        &format!("({},)", symbols.len()),
        &symbols.iter().map(String::as_str).collect::<Vec<_>>(),
    )?;
    add_f64(
        &mut entries,
        "positions",
        &format!("({}, 3)", symbols.len()),
        &positions,
    )?;
    add_f64(
        &mut entries,
        "velocities",
        &format!("({}, 3)", symbols.len()),
        &velocities,
    )?;
    add_f64(
        &mut entries,
        "masses",
        &format!("({},)", symbols.len()),
        &masses,
    )?;
    add_bool(&mut entries, "pbc", "(3,)", &state.structure.pbc)?;
    add_f64(&mut entries, "lattice_velocities", "(3, 3)", &[0.0; 9])?;
    add_unicode(&mut entries, "meta_json", "()", &[&meta_json])?;

    let archive = make_npz(entries)?;
    atomic_replace(path, &archive)
}

fn add_unicode(
    entries: &mut Vec<ZipEntry>,
    name: &str,
    shape: &str,
    values: &[&str],
) -> Result<(), String> {
    let width = values
        .iter()
        .map(|value| value.chars().count())
        .max()
        .unwrap_or(1)
        .max(1);
    let mut data = Vec::new();
    for value in values {
        let mut encoded: Vec<u32> = value.chars().map(|character| character as u32).collect();
        encoded.resize(width, 0);
        for point in encoded {
            data.extend_from_slice(&point.to_le_bytes());
        }
    }
    entries.push(zip_entry(
        name,
        npy_array(&format!("<U{width}"), shape, &data)?,
    )?);
    Ok(())
}

fn add_f64(
    entries: &mut Vec<ZipEntry>,
    name: &str,
    shape: &str,
    values: &[f64],
) -> Result<(), String> {
    if values.iter().any(|value| !value.is_finite()) {
        return Err(format!("restart array {name} contains a non-finite value"));
    }
    let mut data = Vec::with_capacity(values.len() * 8);
    for value in values {
        data.extend_from_slice(&value.to_le_bytes());
    }
    entries.push(zip_entry(name, npy_array("<f8", shape, &data)?)?);
    Ok(())
}

fn add_i64(
    entries: &mut Vec<ZipEntry>,
    name: &str,
    shape: &str,
    values: &[i64],
) -> Result<(), String> {
    let mut data = Vec::with_capacity(values.len() * 8);
    for value in values {
        data.extend_from_slice(&value.to_le_bytes());
    }
    entries.push(zip_entry(name, npy_array("<i8", shape, &data)?)?);
    Ok(())
}

fn add_bool(
    entries: &mut Vec<ZipEntry>,
    name: &str,
    shape: &str,
    values: &[bool],
) -> Result<(), String> {
    let data: Vec<u8> = values.iter().map(|&value| u8::from(value)).collect();
    entries.push(zip_entry(name, npy_array("|b1", shape, &data)?)?);
    Ok(())
}

fn npy_array(descr: &str, shape: &str, data: &[u8]) -> Result<Vec<u8>, String> {
    let mut header = format!("{{'descr': '{descr}', 'fortran_order': False, 'shape': {shape}, }}");
    // NPY v1 requires the magic, version, header length and header to align to
    // a 16-byte boundary; the header terminates with a newline.
    let preamble = 10usize;
    let padding = (16 - (preamble + header.len() + 1) % 16) % 16;
    header.extend(std::iter::repeat_n(' ', padding));
    header.push('\n');
    let header_len = u16::try_from(header.len()).map_err(|_| "NPY header exceeds v1 limit")?;
    let mut result = Vec::with_capacity(preamble + header.len() + data.len());
    result.extend_from_slice(b"\x93NUMPY");
    result.extend_from_slice(&[1, 0]);
    result.extend_from_slice(&header_len.to_le_bytes());
    result.extend_from_slice(header.as_bytes());
    result.extend_from_slice(data);
    Ok(result)
}

fn zip_entry(name: &str, data: Vec<u8>) -> Result<ZipEntry, String> {
    let name = format!("{name}.npy");
    if name.len() > u16::MAX as usize || data.len() > u32::MAX as usize {
        return Err("NPZ entry exceeds ZIP32 size limit".into());
    }
    Ok(ZipEntry {
        name,
        crc32: crc32(&data),
        data,
        local_offset: 0,
    })
}

fn make_npz(mut entries: Vec<ZipEntry>) -> Result<Vec<u8>, String> {
    let mut archive = Vec::new();
    for entry in &mut entries {
        entry.local_offset =
            u32::try_from(archive.len()).map_err(|_| "NPZ archive exceeds ZIP32")?;
        push_u32(&mut archive, 0x0403_4b50);
        push_u16(&mut archive, 20);
        push_u16(&mut archive, 0);
        push_u16(&mut archive, 0); // stored, no compression
        push_u16(&mut archive, 0); // DOS timestamp
        push_u16(&mut archive, 0x0021); // 1980-01-01
        push_u32(&mut archive, entry.crc32);
        push_u32(&mut archive, entry.data.len() as u32);
        push_u32(&mut archive, entry.data.len() as u32);
        push_u16(&mut archive, entry.name.len() as u16);
        push_u16(&mut archive, 0);
        archive.extend_from_slice(entry.name.as_bytes());
        archive.extend_from_slice(&entry.data);
    }
    let central_offset = u32::try_from(archive.len()).map_err(|_| "NPZ archive exceeds ZIP32")?;
    for entry in &entries {
        push_u32(&mut archive, 0x0201_4b50);
        push_u16(&mut archive, 20);
        push_u16(&mut archive, 20);
        push_u16(&mut archive, 0);
        push_u16(&mut archive, 0);
        push_u16(&mut archive, 0);
        push_u16(&mut archive, 0x0021);
        push_u32(&mut archive, entry.crc32);
        push_u32(&mut archive, entry.data.len() as u32);
        push_u32(&mut archive, entry.data.len() as u32);
        push_u16(&mut archive, entry.name.len() as u16);
        push_u16(&mut archive, 0);
        push_u16(&mut archive, 0);
        push_u16(&mut archive, 0);
        push_u16(&mut archive, 0);
        push_u32(&mut archive, 0);
        push_u32(&mut archive, entry.local_offset);
        archive.extend_from_slice(entry.name.as_bytes());
    }
    let central_size = archive
        .len()
        .checked_sub(central_offset as usize)
        .ok_or("invalid NPZ central directory size")?;
    let entry_count = u16::try_from(entries.len()).map_err(|_| "too many NPZ arrays")?;
    push_u32(&mut archive, 0x0605_4b50);
    push_u16(&mut archive, 0);
    push_u16(&mut archive, 0);
    push_u16(&mut archive, entry_count);
    push_u16(&mut archive, entry_count);
    push_u32(
        &mut archive,
        u32::try_from(central_size).map_err(|_| "NPZ central directory too large")?,
    );
    push_u32(&mut archive, central_offset);
    push_u16(&mut archive, 0);
    Ok(archive)
}

fn push_u16(output: &mut Vec<u8>, value: u16) {
    output.extend_from_slice(&value.to_le_bytes());
}

fn push_u32(output: &mut Vec<u8>, value: u32) {
    output.extend_from_slice(&value.to_le_bytes());
}

fn crc32(data: &[u8]) -> u32 {
    let mut crc = !0u32;
    for &byte in data {
        crc ^= u32::from(byte);
        for _ in 0..8 {
            crc = (crc >> 1) ^ (0xedb8_8320 & 0u32.wrapping_sub(crc & 1));
        }
    }
    !crc
}

fn atomic_replace(path: &Path, bytes: &[u8]) -> Result<(), String> {
    if path.extension().and_then(|ext| ext.to_str()) != Some("npz") {
        return Err("macer restart path must have a .npz extension".into());
    }
    let temporary = path.with_file_name(format!(
        "{}.tmp",
        path.file_name().unwrap_or_default().to_string_lossy()
    ));
    let backup = path.with_file_name("restart.prev.npz");
    let mut file = File::create(&temporary).map_err(|e| e.to_string())?;
    file.write_all(bytes).map_err(|e| e.to_string())?;
    file.sync_all().map_err(|e| e.to_string())?;
    drop(file);
    let had_old = path.exists();
    if had_old {
        if backup.exists() {
            fs::remove_file(&backup).map_err(|e| e.to_string())?;
        }
        fs::rename(path, &backup).map_err(|e| e.to_string())?;
    }
    if let Err(error) = fs::rename(&temporary, path) {
        if had_old && !path.exists() {
            let _ = fs::rename(&backup, path);
        }
        let _ = fs::remove_file(&temporary);
        return Err(error.to_string());
    }
    if let Some(parent) = path.parent() {
        if let Ok(directory) = OpenOptions::new().read(true).open(parent) {
            let _ = directory.sync_all();
        }
    }
    Ok(())
}

/// Load the numeric and object-string fields in macer's uncompressed
/// `np.savez` restart, then rebuild the model evaluation in Rust. The POSCAR
/// is not required because the restart carries atom symbols and cell.
pub fn read_macer_restart_npz(
    path: &Path,
    expected_ensemble: &str,
    expected_dt_fs: f64,
    seed: u64,
    evaluator: &mut impl Potential,
) -> Result<DynamicsState, String> {
    let arrays = read_npz(path)?;
    let schema = scalar_string(&arrays, "schema_version", &["md-restart-v2"])?;
    if schema != "md-restart-v2" {
        return Err(format!("unsupported Macer restart schema: {schema}"));
    }
    let velocity_units = scalar_string(&arrays, "units_velocity", &["angstrom/ase_time"])?;
    if velocity_units != "angstrom/ase_time" {
        return Err(format!(
            "unsupported restart velocity units: {velocity_units}"
        ));
    }
    let saved_ensemble = scalar_string(
        &arrays,
        "ensemble",
        &["nve", "nvt", "npt", "nte", "langevin"],
    )?;
    if saved_ensemble != expected_ensemble {
        return Err(format!(
            "restart ensemble is {saved_ensemble}, requested {expected_ensemble}"
        ));
    }
    let saved_dt = scalar_f64(&arrays, "tstep_fs")?;
    if (saved_dt - expected_dt_fs).abs() > 1e-12 {
        return Err(format!(
            "restart timestep is {saved_dt} fs, requested {expected_dt_fs} fs"
        ));
    }
    let legacy_step = scalar_i64(&arrays, "step")?;
    if legacy_step < 2 {
        return Err(format!(
            "restart step {legacy_step} is too small for md-restart-v2"
        ));
    }
    let natom = usize::try_from(scalar_i64(&arrays, "natom")?)
        .map_err(|_| "restart atom count is invalid")?;
    if natom == 0 {
        return Err("restart has zero atoms".into());
    }
    let symbols = string_array(&arrays, "symbols", natom)?;
    let atomic_numbers: Vec<u8> = symbols
        .iter()
        .map(|symbol| {
            crate::elements::SYMBOLS
                .iter()
                .position(|candidate| *candidate == symbol)
                .and_then(|atomic_number| u8::try_from(atomic_number).ok())
                .filter(|&atomic_number| atomic_number > 0)
                .ok_or_else(|| format!("restart contains unsupported element symbol: {symbol}"))
        })
        .collect::<Result<_, _>>()?;
    let cell_values = f64_array(&arrays, "cell", &[3, 3])?;
    let positions_values = f64_array(&arrays, "positions", &[natom, 3])?;
    let velocity_values = f64_array(&arrays, "velocities", &[natom, 3])?;
    let masses_amu = f64_array(&arrays, "masses", &[natom])?;
    let pbc_values = bool_array(&arrays, "pbc", &[3])?;
    let cell = to_matrix3(&cell_values);
    let positions = to_vec3(&positions_values);
    let velocities = to_vec3(&velocity_values)
        .into_iter()
        .map(|velocity| velocity.map(|component| component * ASE_FS))
        .collect();
    let structure = Structure {
        atomic_numbers,
        positions_a: positions,
        cell_a: cell,
        pbc: [pbc_values[0], pbc_values[1], pbc_values[2]],
    };
    structure.validate()?;
    if masses_amu
        .iter()
        .any(|mass| !mass.is_finite() || *mass <= 0.0)
    {
        return Err("restart masses must be positive and finite".into());
    }
    let mut state = DynamicsState::initialize(structure, masses_amu, velocities, seed, evaluator)?;
    // Macer's observer counter begins at 0, emits logical steps 0 and 1 for
    // the initial state, then advances once per physical integration step.
    state.step = u64::try_from(legacy_step - 2).map_err(|_| "restart step is invalid")?;
    state.time_fs = state.step as f64 * expected_dt_fs;
    Ok(state)
}

#[derive(Clone, Debug)]
struct NpyArray {
    descr: String,
    shape: Vec<usize>,
    data: Vec<u8>,
}

fn read_npz(path: &Path) -> Result<HashMap<String, NpyArray>, String> {
    let bytes = fs::read(path).map_err(|error| error.to_string())?;
    let mut arrays = HashMap::new();
    let mut cursor = 0usize;
    while cursor + 4 <= bytes.len() {
        let signature = read_u32(&bytes, cursor)?;
        if signature != 0x0403_4b50 {
            break; // central directory
        }
        if cursor + 30 > bytes.len() {
            return Err("truncated NPZ local file header".into());
        }
        let flags = read_u16(&bytes, cursor + 6)?;
        let method = read_u16(&bytes, cursor + 8)?;
        let crc = read_u32(&bytes, cursor + 14)?;
        let compressed_size_32 = read_u32(&bytes, cursor + 18)?;
        let uncompressed_size_32 = read_u32(&bytes, cursor + 22)?;
        let name_len = read_u16(&bytes, cursor + 26)? as usize;
        let extra_len = read_u16(&bytes, cursor + 28)? as usize;
        if flags & 0x0008 != 0 || method != 0 {
            return Err(
                "Macer restart NPZ must use stored entries without data descriptors".into(),
            );
        }
        let name_start = cursor + 30;
        let extra_start = name_start
            .checked_add(name_len)
            .ok_or("NPZ entry offset overflow")?;
        let extra_end = extra_start
            .checked_add(extra_len)
            .ok_or("NPZ entry extra offset overflow")?;
        if extra_end > bytes.len() {
            return Err("truncated NPZ entry extra data".into());
        }
        let (compressed_size, uncompressed_size) =
            if compressed_size_32 == u32::MAX || uncompressed_size_32 == u32::MAX {
                let mut extra_cursor = extra_start;
                let mut sizes = None;
                while extra_cursor + 4 <= extra_end {
                    let identifier = read_u16(&bytes, extra_cursor)?;
                    let field_len = read_u16(&bytes, extra_cursor + 2)? as usize;
                    extra_cursor += 4;
                    let field_end = extra_cursor
                        .checked_add(field_len)
                        .ok_or("NPZ ZIP64 extra size overflow")?;
                    if field_end > extra_end {
                        return Err("truncated NPZ extra field".into());
                    }
                    if identifier == 0x0001 {
                        let mut field_cursor = extra_cursor;
                        let uncompressed = if uncompressed_size_32 == u32::MAX {
                            let value = read_u64(&bytes, field_cursor)? as usize;
                            field_cursor += 8;
                            value
                        } else {
                            uncompressed_size_32 as usize
                        };
                        let compressed = if compressed_size_32 == u32::MAX {
                            read_u64(&bytes, field_cursor)? as usize
                        } else {
                            compressed_size_32 as usize
                        };
                        sizes = Some((compressed, uncompressed));
                        break;
                    }
                    extra_cursor = field_end;
                }
                sizes.ok_or("NPZ ZIP64 sizes are missing")?
            } else {
                (compressed_size_32 as usize, uncompressed_size_32 as usize)
            };
        if compressed_size != uncompressed_size {
            return Err("Macer restart NPZ contains an unexpected compressed entry".into());
        }
        let data_start = extra_end;
        let data_end = data_start
            .checked_add(compressed_size)
            .ok_or("NPZ entry size overflow")?;
        if data_end > bytes.len() {
            return Err("truncated NPZ array entry".into());
        }
        let name = std::str::from_utf8(&bytes[name_start..name_start + name_len])
            .map_err(|error| error.to_string())?;
        if !name.ends_with(".npy") {
            return Err(format!("unexpected NPZ entry name: {name}"));
        }
        let payload = &bytes[data_start..data_end];
        if crc32(payload) != crc {
            return Err(format!("CRC32 mismatch for NPZ entry {name}"));
        }
        let key = name.trim_end_matches(".npy").to_string();
        arrays.insert(key, parse_npy(payload)?);
        cursor = data_end;
    }
    Ok(arrays)
}

fn parse_npy(bytes: &[u8]) -> Result<NpyArray, String> {
    if bytes.len() < 10 || &bytes[..6] != b"\x93NUMPY" {
        return Err("invalid NPY array header".into());
    }
    let major = bytes[6];
    let (header_start, header_len) = match major {
        1 => (10usize, read_u16(bytes, 8)? as usize),
        2 | 3 => (12usize, read_u32(bytes, 8)? as usize),
        _ => return Err(format!("unsupported NPY format version {major}")),
    };
    let data_start = header_start
        .checked_add(header_len)
        .ok_or("NPY header length overflow")?;
    if data_start > bytes.len() {
        return Err("truncated NPY header".into());
    }
    let header =
        std::str::from_utf8(&bytes[header_start..data_start]).map_err(|error| error.to_string())?;
    if !header.contains("'fortran_order': False") && !header.contains("\"fortran_order\": False") {
        return Err("Fortran-ordered NPY arrays are unsupported".into());
    }
    let descr_start = header
        .find("'descr': '")
        .or_else(|| header.find("\"descr\": \""))
        .ok_or("NPY header has no descr")?;
    let (start, delimiter) = if header[descr_start..].starts_with("'descr'") {
        (descr_start + 10, '\'')
    } else {
        (descr_start + 10, '\"')
    };
    let descr_end = header[start..]
        .find(delimiter)
        .ok_or("unterminated NPY descr")?
        + start;
    let descr = header[start..descr_end].to_string();
    let shape_start = header
        .find("'shape': ")
        .or_else(|| header.find("\"shape\": "))
        .ok_or("NPY header has no shape")?;
    let shape_start = header[shape_start..]
        .find('(')
        .map(|offset| shape_start + offset + 1)
        .ok_or("NPY shape is not a tuple")?;
    let shape_end = header[shape_start..]
        .find(')')
        .map(|offset| shape_start + offset)
        .ok_or("unterminated NPY shape")?;
    let shape: Vec<usize> = header[shape_start..shape_end]
        .split(',')
        .filter_map(|dimension| {
            let dimension = dimension.trim();
            (!dimension.is_empty()).then(|| dimension.parse::<usize>())
        })
        .collect::<Result<_, _>>()
        .map_err(|error: std::num::ParseIntError| error.to_string())?;
    Ok(NpyArray {
        descr,
        shape,
        data: bytes[data_start..].to_vec(),
    })
}

fn scalar_i64(arrays: &HashMap<String, NpyArray>, name: &str) -> Result<i64, String> {
    let array = required_array(arrays, name)?;
    if !array.shape.is_empty() || !array.descr.ends_with("i8") || array.data.len() != 8 {
        return Err(format!("restart {name} must be a scalar int64"));
    }
    let raw: [u8; 8] = array
        .data
        .as_slice()
        .try_into()
        .map_err(|_| "invalid int64 payload")?;
    Ok(if array.descr.starts_with('>') {
        i64::from_be_bytes(raw)
    } else {
        i64::from_le_bytes(raw)
    })
}

fn scalar_f64(arrays: &HashMap<String, NpyArray>, name: &str) -> Result<f64, String> {
    let values = f64_array(arrays, name, &[])?;
    Ok(values[0])
}

fn f64_array(
    arrays: &HashMap<String, NpyArray>,
    name: &str,
    expected_shape: &[usize],
) -> Result<Vec<f64>, String> {
    let array = required_array(arrays, name)?;
    if array.shape != expected_shape || !array.descr.ends_with("f8") {
        return Err(format!("restart {name} has an unsupported shape or dtype"));
    }
    if array.data.len() != expected_shape.iter().product::<usize>().max(1) * 8 {
        return Err(format!(
            "restart {name} payload length does not match its shape"
        ));
    }
    let values = array
        .data
        .chunks_exact(8)
        .map(|chunk| {
            let bytes: [u8; 8] = chunk.try_into().expect("chunks_exact gives eight bytes");
            if array.descr.starts_with('>') {
                f64::from_be_bytes(bytes)
            } else {
                f64::from_le_bytes(bytes)
            }
        })
        .collect::<Vec<_>>();
    if values.iter().any(|value| !value.is_finite()) {
        return Err(format!("restart {name} contains a non-finite value"));
    }
    Ok(values)
}

fn bool_array(
    arrays: &HashMap<String, NpyArray>,
    name: &str,
    expected_shape: &[usize],
) -> Result<Vec<bool>, String> {
    let array = required_array(arrays, name)?;
    if array.shape != expected_shape || !array.descr.ends_with("b1") {
        return Err(format!("restart {name} has an unsupported shape or dtype"));
    }
    if array.data.len() != expected_shape.iter().product::<usize>() {
        return Err(format!(
            "restart {name} payload length does not match its shape"
        ));
    }
    array
        .data
        .iter()
        .map(|&value| match value {
            0 => Ok(false),
            1 => Ok(true),
            _ => Err(format!("restart {name} contains an invalid boolean")),
        })
        .collect()
}

fn scalar_string(
    arrays: &HashMap<String, NpyArray>,
    name: &str,
    accepted: &[&str],
) -> Result<String, String> {
    let array = required_array(arrays, name)?;
    if !array.shape.is_empty() {
        return Err(format!("restart {name} must be a scalar string"));
    }
    let strings = read_strings(array)?;
    strings
        .iter()
        .find(|value| accepted.contains(&value.as_str()))
        .cloned()
        .ok_or_else(|| format!("restart {name} is not one of the supported values"))
}

fn string_array(
    arrays: &HashMap<String, NpyArray>,
    name: &str,
    length: usize,
) -> Result<Vec<String>, String> {
    let array = required_array(arrays, name)?;
    if array.shape != [length] {
        return Err(format!("restart {name} has the wrong shape"));
    }
    read_strings(array)
}

fn read_strings(array: &NpyArray) -> Result<Vec<String>, String> {
    if array.descr == "|O" {
        let parsed = parse_object_pickle(&array.data)?;
        let expected_len = array.shape.iter().product::<usize>().max(1);
        let strings = parsed
            .lists
            .iter()
            .find(|list| {
                list.len() == expected_len
                    && list
                        .iter()
                        .all(|value| matches!(value, PickleValue::String(_)))
            })
            .map(|list| {
                list.iter()
                    .filter_map(|value| match value {
                        PickleValue::String(value) => Some(value.clone()),
                        _ => None,
                    })
                    .collect::<Vec<_>>()
            });
        if let Some(strings) = strings {
            return Ok(strings);
        }
        if array.shape.is_empty() {
            if let Some(value) = parsed.strings.iter().find(|value| {
                *value == "md-restart-v2"
                    || *value == "angstrom/ase_time"
                    || ["nve", "nvt", "npt", "nte", "langevin"].contains(&value.as_str())
            }) {
                return Ok(vec![value.clone()]);
            }
            if let Some(value) = parsed.strings.iter().find(|value| value.starts_with('{')) {
                return Ok(vec![value.clone()]);
            }
        }
        return Err("NPY object array does not contain the expected strings".into());
    }
    let width = array
        .descr
        .strip_prefix("<U")
        .or_else(|| array.descr.strip_prefix("=U"))
        .ok_or("restart string array must be UTF-32 Unicode or object strings")?
        .parse::<usize>()
        .map_err(|error| error.to_string())?;
    let count = array.shape.iter().product::<usize>().max(1);
    let byte_width = width.checked_mul(4).ok_or("unicode width overflow")?;
    if array.data.len() != count * byte_width {
        return Err("Unicode payload length does not match shape".into());
    }
    array
        .data
        .chunks_exact(byte_width)
        .map(|chunk| {
            let mut value = String::new();
            for codepoint in chunk.chunks_exact(4) {
                let raw: [u8; 4] = codepoint.try_into().expect("chunks_exact gives four bytes");
                let point = u32::from_le_bytes(raw);
                if point == 0 {
                    break;
                }
                value.push(char::from_u32(point).ok_or("invalid Unicode code point")?);
            }
            Ok(value)
        })
        .collect()
}

fn required_array<'a>(
    arrays: &'a HashMap<String, NpyArray>,
    name: &str,
) -> Result<&'a NpyArray, String> {
    arrays
        .get(name)
        .ok_or_else(|| format!("restart NPZ is missing {name}"))
}

fn to_matrix3(values: &[f64]) -> [[f64; 3]; 3] {
    std::array::from_fn(|row| std::array::from_fn(|column| values[row * 3 + column]))
}

fn to_vec3(values: &[f64]) -> Vec<[f64; 3]> {
    values
        .chunks_exact(3)
        .map(|row| [row[0], row[1], row[2]])
        .collect()
}

fn read_u16(bytes: &[u8], offset: usize) -> Result<u16, String> {
    let slice = bytes.get(offset..offset + 2).ok_or("truncated u16 field")?;
    Ok(u16::from_le_bytes([slice[0], slice[1]]))
}

fn read_u32(bytes: &[u8], offset: usize) -> Result<u32, String> {
    let slice = bytes.get(offset..offset + 4).ok_or("truncated u32 field")?;
    Ok(u32::from_le_bytes([slice[0], slice[1], slice[2], slice[3]]))
}

fn read_u64(bytes: &[u8], offset: usize) -> Result<u64, String> {
    let slice = bytes.get(offset..offset + 8).ok_or("truncated u64 field")?;
    Ok(u64::from_le_bytes([
        slice[0], slice[1], slice[2], slice[3], slice[4], slice[5], slice[6], slice[7],
    ]))
}

#[derive(Clone, Debug)]
enum PickleValue {
    Mark,
    Integer,
    String(String),
    Bytes,
    List(Vec<PickleValue>),
    Tuple,
    Global,
    Other,
}

#[derive(Debug, Default)]
struct PickleOutput {
    strings: Vec<String>,
    lists: Vec<Vec<PickleValue>>,
}

fn parse_object_pickle(bytes: &[u8]) -> Result<PickleOutput, String> {
    let mut output = PickleOutput::default();
    let mut stack = Vec::<PickleValue>::new();
    let mut memo = HashMap::<usize, PickleValue>::new();
    let mut next_memo_index = 0usize;
    let mut cursor = 0usize;
    let mut frame_end = None;
    while cursor < bytes.len() {
        if let Some(end) = frame_end {
            if cursor == end {
                frame_end = None;
            } else if cursor > end {
                return Err("pickle opcode exceeds its FRAME boundary".into());
            }
        }
        let opcode = bytes[cursor];
        cursor += 1;
        match opcode {
            b'.' => break,
            0x80 => cursor = skip(bytes, cursor, 1)?,
            0x95 => {
                if frame_end.is_some() {
                    return Err("pickle FRAME begins before the previous frame ends".into());
                }
                let frame_len = usize::try_from(read_u64(bytes, cursor)?)
                    .map_err(|_| "pickle FRAME size exceeds this platform")?;
                cursor += 8;
                let end = cursor
                    .checked_add(frame_len)
                    .ok_or("pickle FRAME size overflow")?;
                if end > bytes.len() {
                    return Err("truncated pickle FRAME".into());
                }
                frame_end = Some(end);
            }
            b'c' => {
                cursor = skip_line(bytes, cursor)?;
                cursor = skip_line(bytes, cursor)?;
                stack.push(PickleValue::Global);
            }
            b'(' => stack.push(PickleValue::Mark),
            b']' => stack.push(PickleValue::List(Vec::new())),
            b')' => stack.push(PickleValue::Tuple),
            b'K' => {
                let _ = *bytes.get(cursor).ok_or("truncated pickle BININT1")?;
                cursor += 1;
                stack.push(PickleValue::Integer);
            }
            b'M' => {
                let _ = read_u16(bytes, cursor)?;
                cursor += 2;
                stack.push(PickleValue::Integer);
            }
            b'J' => {
                let _ = read_i32(bytes, cursor)?;
                cursor += 4;
                stack.push(PickleValue::Integer);
            }
            0x8c => {
                let len = *bytes
                    .get(cursor)
                    .ok_or("truncated pickle SHORT_BINUNICODE")? as usize;
                cursor += 1;
                let end = cursor
                    .checked_add(len)
                    .ok_or("pickle string size overflow")?;
                let value = String::from_utf8(
                    bytes
                        .get(cursor..end)
                        .ok_or("truncated pickle SHORT_BINUNICODE")?
                        .to_vec(),
                )
                .map_err(|error| error.to_string())?;
                cursor = end;
                output.strings.push(value.clone());
                stack.push(PickleValue::String(value));
            }
            b'X' => {
                let len = read_u32(bytes, cursor)? as usize;
                cursor += 4;
                let end = cursor
                    .checked_add(len)
                    .ok_or("pickle string size overflow")?;
                let value = String::from_utf8(
                    bytes
                        .get(cursor..end)
                        .ok_or("truncated pickle BINUNICODE")?
                        .to_vec(),
                )
                .map_err(|error| error.to_string())?;
                cursor = end;
                output.strings.push(value.clone());
                stack.push(PickleValue::String(value));
            }
            b'C' => {
                let len = *bytes.get(cursor).ok_or("truncated pickle SHORT_BINBYTES")? as usize;
                cursor += 1;
                cursor = skip(bytes, cursor, len)?;
                stack.push(PickleValue::Bytes);
            }
            b'R' => {
                pop(&mut stack)?;
                pop(&mut stack)?;
                stack.push(PickleValue::Other);
            }
            b'b' => {
                pop(&mut stack)?;
                pop(&mut stack)?;
                stack.push(PickleValue::Other);
            }
            b't' => {
                tuple_from_mark(&mut stack)?;
            }
            0x85 => {
                tuple_last(&mut stack, 1)?;
            }
            0x86 => {
                tuple_last(&mut stack, 2)?;
            }
            0x87 => {
                tuple_last(&mut stack, 3)?;
            }
            b'q' => {
                let index = *bytes.get(cursor).ok_or("truncated pickle BINPUT")? as usize;
                cursor += 1;
                memo.insert(index, stack.last().ok_or("empty pickle stack")?.clone());
                next_memo_index = next_memo_index.max(index + 1);
            }
            0x94 => {
                memo.insert(
                    next_memo_index,
                    stack.last().ok_or("empty pickle MEMOIZE stack")?.clone(),
                );
                next_memo_index = next_memo_index
                    .checked_add(1)
                    .ok_or("pickle memo index overflow")?;
            }
            b'h' => {
                let index = *bytes.get(cursor).ok_or("truncated pickle BINGET")? as usize;
                cursor += 1;
                stack.push(
                    memo.get(&index)
                        .ok_or("pickle memo reference is missing")?
                        .clone(),
                );
            }
            0x93 => {
                let name = pop(&mut stack)?;
                let module = pop(&mut stack)?;
                if !matches!(name, PickleValue::String(_))
                    || !matches!(module, PickleValue::String(_))
                {
                    return Err("pickle STACK_GLOBAL requires module and name strings".into());
                }
                stack.push(PickleValue::Global);
            }
            b'e' => append_after_mark(&mut stack, &mut output.lists)?,
            b'a' => append_one(&mut stack, &mut output.lists)?,
            b'N' => stack.push(PickleValue::Other),
            0x88 | 0x89 => stack.push(PickleValue::Other),
            b'0' => {
                pop(&mut stack)?;
            }
            b'1' => {
                let mark = find_mark(&stack)?;
                stack.truncate(mark);
            }
            b'2' => {
                let value = stack.last().ok_or("empty pickle stack")?.clone();
                stack.push(value);
            }
            _ => {
                return Err(format!(
                    "unsupported opcode 0x{opcode:02x} in Macer object array"
                ))
            }
        }
        if let Some(end) = frame_end {
            if cursor > end {
                return Err("pickle opcode exceeds its FRAME boundary".into());
            }
            if cursor == end {
                frame_end = None;
            }
        }
    }
    if frame_end.is_some_and(|end| cursor != end) {
        return Err("pickle stream ended before the FRAME boundary".into());
    }
    Ok(output)
}

fn append_after_mark(
    stack: &mut Vec<PickleValue>,
    lists: &mut Vec<Vec<PickleValue>>,
) -> Result<(), String> {
    let mark = find_mark(stack)?;
    if mark == 0 {
        return Err("pickle APPENDS has no target list".into());
    }
    let values = stack.drain(mark + 1..).collect::<Vec<_>>();
    stack.pop();
    match stack.get_mut(mark - 1) {
        Some(PickleValue::List(list)) => {
            list.extend(values);
            lists.push(list.clone());
            Ok(())
        }
        _ => Err("pickle APPENDS target is not a list".into()),
    }
}

fn append_one(
    stack: &mut Vec<PickleValue>,
    lists: &mut Vec<Vec<PickleValue>>,
) -> Result<(), String> {
    let value = pop(stack)?;
    match stack.last_mut() {
        Some(PickleValue::List(list)) => {
            list.push(value);
            lists.push(list.clone());
            Ok(())
        }
        _ => Err("pickle APPEND target is not a list".into()),
    }
}

fn tuple_from_mark(stack: &mut Vec<PickleValue>) -> Result<(), String> {
    let mark = find_mark(stack)?;
    let values = stack.drain(mark + 1..).collect::<Vec<_>>();
    stack.pop();
    let _ = values;
    stack.push(PickleValue::Tuple);
    Ok(())
}

fn tuple_last(stack: &mut Vec<PickleValue>, count: usize) -> Result<(), String> {
    if stack.len() < count {
        return Err("truncated pickle tuple".into());
    }
    let values = stack.drain(stack.len() - count..).collect::<Vec<_>>();
    let _ = values;
    stack.push(PickleValue::Tuple);
    Ok(())
}

fn find_mark(stack: &[PickleValue]) -> Result<usize, String> {
    stack
        .iter()
        .rposition(|value| matches!(value, PickleValue::Mark))
        .ok_or("pickle MARK is missing".into())
}

fn pop(stack: &mut Vec<PickleValue>) -> Result<PickleValue, String> {
    stack.pop().ok_or_else(|| "pickle stack underflow".into())
}

fn skip(bytes: &[u8], cursor: usize, count: usize) -> Result<usize, String> {
    cursor
        .checked_add(count)
        .filter(|&end| end <= bytes.len())
        .ok_or("truncated pickle field".into())
}

fn skip_line(bytes: &[u8], cursor: usize) -> Result<usize, String> {
    bytes
        .get(cursor..)
        .and_then(|tail| tail.iter().position(|&value| value == b'\n'))
        .map(|offset| cursor + offset + 1)
        .ok_or("unterminated pickle GLOBAL".into())
}

fn read_i32(bytes: &[u8], offset: usize) -> Result<i32, String> {
    let slice = bytes.get(offset..offset + 4).ok_or("truncated i32 field")?;
    Ok(i32::from_le_bytes([slice[0], slice[1], slice[2], slice[3]]))
}

fn utc_timestamp() -> String {
    let seconds = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs() as i64;
    let days = seconds.div_euclid(86_400);
    let second_of_day = seconds.rem_euclid(86_400);
    let z = days + 719_468;
    let era = if z >= 0 { z } else { z - 146_096 }.div_euclid(146_097);
    let day_of_era = z - era * 146_097;
    let year_of_era =
        (day_of_era - day_of_era / 1_460 + day_of_era / 36_524 - day_of_era / 146_096) / 365;
    let mut year = year_of_era + era * 400;
    let day_of_year = day_of_era - (365 * year_of_era + year_of_era / 4 - year_of_era / 100);
    let month_prime = (5 * day_of_year + 2) / 153;
    let day = day_of_year - (153 * month_prime + 2) / 5 + 1;
    let month = month_prime + if month_prime < 10 { 3 } else { -9 };
    if month <= 2 {
        year += 1;
    }
    let hour = second_of_day / 3_600;
    let minute = second_of_day % 3_600 / 60;
    let second = second_of_day % 60;
    format!("{year:04}-{month:02}-{day:02}T{hour:02}:{minute:02}:{second:02}+00:00")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn npy_v1_header_is_aligned_and_unicode_payload_is_ucs4() {
        let array = npy_array("<U2", "(2,)", &[b'C', 0, 0, 0, b'u', 0, 0, 0]).unwrap();
        assert_eq!(&array[..8], b"\x93NUMPY\x01\x00");
        let header_len = u16::from_le_bytes([array[8], array[9]]) as usize;
        assert_eq!((10 + header_len) % 16, 0);
        assert!(std::str::from_utf8(&array[10..10 + header_len])
            .unwrap()
            .contains("'<U2'"));
    }

    #[test]
    fn crc32_matches_standard_zip_vector() {
        assert_eq!(crc32(b"123456789"), 0xcbf4_3926);
    }

    #[test]
    fn reads_captured_macer_restart_v2_with_zip64_and_object_symbols() {
        let path = Path::new(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../evidence/public_cli_smoke_cpu_cus96_2026-10-23/macer/restart.npz"
        ));
        let arrays = read_npz(path).unwrap();
        assert_eq!(
            scalar_string(&arrays, "schema_version", &["md-restart-v2"]).unwrap(),
            "md-restart-v2"
        );
        assert_eq!(scalar_i64(&arrays, "step").unwrap(), 4);
        assert_eq!(scalar_i64(&arrays, "natom").unwrap(), 96);
        assert_eq!(scalar_string(&arrays, "ensemble", &["nve"]).unwrap(), "nve");
        let symbols = string_array(&arrays, "symbols", 96).unwrap();
        assert_eq!(&symbols[..6], &["Cu", "Cu", "Cu", "Cu", "Cu", "Cu"]);
        assert_eq!(&symbols[6..12], &["S", "S", "S", "S", "S", "S"]);
        assert_eq!(
            f64_array(&arrays, "positions", &[96, 3]).unwrap().len(),
            288
        );
        assert_eq!(bool_array(&arrays, "pbc", &[3]).unwrap(), [true; 3]);
    }

    #[test]
    fn reads_numpy_24_protocol4_macer_restart_object_symbols() {
        let path = Path::new(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../evidence/restart_numpy246_protocol4_2026-10-23/macer/restart.npz"
        ));
        let arrays = read_npz(path).unwrap();
        assert_eq!(
            scalar_string(&arrays, "schema_version", &["md-restart-v2"]).unwrap(),
            "md-restart-v2"
        );
        let symbols = string_array(&arrays, "symbols", 96).unwrap();
        assert_eq!(&symbols[..6], &["Cu", "Cu", "Cu", "Cu", "Cu", "Cu"]);
        assert_eq!(&symbols[6..12], &["S", "S", "S", "S", "S", "S"]);
    }

    #[test]
    fn parses_framed_pickle_protocol4_unicode_without_executing_globals() {
        let frame = [
            b']', 0x94, b'(', 0x8c, 2, b'C', b'u', 0x94, 0x8c, 1, b'S', 0x94, b'e', b'.',
        ];
        let mut pickle = vec![0x80, 4, 0x95];
        pickle.extend_from_slice(&(frame.len() as u64).to_le_bytes());
        pickle.extend_from_slice(&frame);

        let parsed = parse_object_pickle(&pickle).unwrap();
        assert!(parsed
            .strings
            .ends_with(&["Cu".to_string(), "S".to_string()]));
        assert!(parsed.lists.iter().any(|list| {
            list.iter()
                .filter_map(|value| match value {
                    PickleValue::String(value) => Some(value.as_str()),
                    _ => None,
                })
                .eq(["Cu", "S"])
        }));
    }

    #[test]
    fn rejects_truncated_pickle_frame() {
        let mut pickle = vec![0x80, 4, 0x95];
        pickle.extend_from_slice(&16u64.to_le_bytes());
        pickle.extend_from_slice(&[b']', b'.']);
        assert_eq!(
            parse_object_pickle(&pickle).unwrap_err(),
            "truncated pickle FRAME"
        );
    }
}
