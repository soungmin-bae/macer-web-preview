//! VASP ML_FF periodic neighbor images, with Macer's stable ordering.

use macer_rust_core::{neighbors::radius_graph, Structure};

#[derive(Clone, Debug, PartialEq)]
pub struct NeighborImage {
    pub center: usize,
    pub neighbor: usize,
    pub neighbor_type: usize,
    pub shift: [i32; 3],
    pub vector_angstrom: [f64; 3],
    pub distance_angstrom: f64,
}

/// Enumerate all neighbor images within the ML_FF cutoff.
///
/// `type_atomic_numbers` is the species order from the ML_FF payload. The
/// returned groups follow Macer's ordering by neighbor type, distance, atom
/// index, then integer lattice shift. The model format currently requires
/// fully periodic 3D structures for this calculator path.
pub fn enumerate_periodic_neighbor_images(
    structure: &Structure,
    type_atomic_numbers: &[u8],
    cutoff_angstrom: f64,
) -> Result<Vec<Vec<NeighborImage>>, String> {
    structure.validate()?;
    if !cutoff_angstrom.is_finite() || cutoff_angstrom <= 0.0 {
        return Err("cutoff_angstrom must be finite and positive".into());
    }
    if structure.pbc != [true; 3] {
        return Err("native VASP ML_FF evaluator requires full 3D PBC".into());
    }
    if type_atomic_numbers.is_empty() {
        return Err("ML_FF species list must not be empty".into());
    }
    let mut seen = [false; 119];
    for &z in type_atomic_numbers {
        if z == 0 || z > 118 || seen[z as usize] {
            return Err("ML_FF species must be unique atomic numbers in 1..=118".into());
        }
        seen[z as usize] = true;
    }
    let type_by_z = |z: u8| {
        type_atomic_numbers
            .iter()
            .position(|&candidate| candidate == z)
            .ok_or_else(|| format!("atomic number {z} is absent from ML_FF species"))
    };
    let atom_types = structure
        .atomic_numbers
        .iter()
        .copied()
        .map(type_by_z)
        .collect::<Result<Vec<_>, _>>()?;

    let graph = radius_graph(structure, cutoff_angstrom, cutoff_angstrom)?;
    let mut groups = vec![Vec::new(); structure.atomic_numbers.len()];
    let cutoff2 = cutoff_angstrom * cutoff_angstrom;
    for edge in 0..graph.source.len() {
        let center = graph.source[edge] as usize;
        let neighbor = graph.destination[edge] as usize;
        let shift = graph.offsets[edge].map(|value| value.round() as i32);
        let vector_angstrom = std::array::from_fn(|axis| {
            let lattice_shift = (0..3)
                .map(|cell_axis| shift[cell_axis] as f64 * structure.cell_a[cell_axis][axis])
                .sum::<f64>();
            structure.positions_a[neighbor][axis] - structure.positions_a[center][axis]
                + lattice_shift
        });
        let distance2 = vector_angstrom
            .iter()
            .map(|value| value * value)
            .sum::<f64>();
        // The shared core graph uses a small boundary tolerance. Macer's
        // ML_FF enumerator uses an exact <= cutoff comparison.
        if distance2 == 0.0 || distance2 > cutoff2 {
            continue;
        }
        groups[center].push(NeighborImage {
            center,
            neighbor,
            neighbor_type: atom_types[neighbor],
            shift,
            vector_angstrom,
            distance_angstrom: distance2.sqrt(),
        });
    }
    for neighbors in &mut groups {
        neighbors.sort_by(|left, right| {
            left.neighbor_type
                .cmp(&right.neighbor_type)
                .then_with(|| left.distance_angstrom.total_cmp(&right.distance_angstrom))
                .then_with(|| left.neighbor.cmp(&right.neighbor))
                .then_with(|| left.shift.cmp(&right.shift))
        });
    }
    Ok(groups)
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::Value;

    const GOLDEN: &str =
        include_str!("../../../evidence/vasp_mlff_neighbors_2026-10-24/macer_reference.json");

    #[test]
    fn mixed_species_triclinic_periodic_images_match_macer() {
        let golden: Value = serde_json::from_str(GOLDEN).unwrap();
        let structure = Structure {
            atomic_numbers: serde_json::from_value(golden["atomic_numbers"].clone()).unwrap(),
            positions_a: serde_json::from_value(golden["positions_a"].clone()).unwrap(),
            cell_a: serde_json::from_value(golden["cell_a"].clone()).unwrap(),
            pbc: [true; 3],
        };
        let species: Vec<u8> =
            serde_json::from_value(golden["type_atomic_numbers"].clone()).unwrap();
        let cutoff = golden["cutoff_angstrom"].as_f64().unwrap();
        let actual = enumerate_periodic_neighbor_images(&structure, &species, cutoff).unwrap();
        let expected = golden["neighbors"].as_array().unwrap();
        assert_eq!(actual.len(), expected.len());
        for (center, (group, expected_group)) in actual.iter().zip(expected).enumerate() {
            assert_eq!(group.len(), expected_group.as_array().unwrap().len());
            for (item, expected_item) in group.iter().zip(expected_group.as_array().unwrap()) {
                assert_eq!(item.center, center);
                assert_eq!(
                    item.neighbor,
                    expected_item["neighbor"].as_u64().unwrap() as usize
                );
                assert_eq!(
                    item.neighbor_type,
                    expected_item["neighbor_type"].as_u64().unwrap() as usize
                );
                assert_eq!(
                    item.shift,
                    serde_json::from_value::<[i32; 3]>(expected_item["shift"].clone()).unwrap()
                );
                for axis in 0..3 {
                    assert!(
                        (item.vector_angstrom[axis]
                            - expected_item["vector_angstrom"][axis].as_f64().unwrap())
                        .abs()
                            < 1.0e-12
                    );
                }
                assert!(
                    (item.distance_angstrom - expected_item["distance_angstrom"].as_f64().unwrap())
                        .abs()
                        < 1.0e-12
                );
            }
        }
    }

    #[test]
    fn rejects_partial_pbc_and_unmapped_species() {
        let structure = Structure {
            atomic_numbers: vec![14],
            positions_a: vec![[0.0; 3]],
            cell_a: [[3.0, 0.0, 0.0], [0.0, 3.0, 0.0], [0.0, 0.0, 3.0]],
            pbc: [true, true, false],
        };
        assert!(enumerate_periodic_neighbor_images(&structure, &[14], 2.0)
            .unwrap_err()
            .contains("full 3D PBC"));
        let structure = Structure {
            pbc: [true; 3],
            ..structure
        };
        assert!(enumerate_periodic_neighbor_images(&structure, &[8], 2.0)
            .unwrap_err()
            .contains("absent from ML_FF species"));
    }
}
