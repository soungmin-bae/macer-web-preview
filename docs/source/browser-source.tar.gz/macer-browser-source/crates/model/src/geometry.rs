//! Differentiable periodic edge geometry shared by CPU and optional CUDA.

use candle_core::{Result, Tensor};

/// Directed edge lengths from positions in Å and periodic image offsets.
/// The returned tensor retains derivatives with respect to positions and cell.
pub fn edge_lengths(
    positions: &Tensor,
    cell: &Tensor,
    source: &[u32],
    destination: &[u32],
    offsets: &[[f32; 3]],
) -> Result<Tensor> {
    let device = positions.device();
    let n = source.len();
    if destination.len() != n || offsets.len() != n {
        candle_core::bail!("edge indices and periodic offsets have different lengths")
    }
    if positions.rank() != 2 || positions.dim(1)? != 3 || cell.dims() != [3, 3] {
        candle_core::bail!("expected positions [atoms,3] and cell [3,3]")
    }
    if cell.device().location() != device.location() {
        candle_core::bail!("positions and cell must share a device")
    }
    let atom_count = positions.dim(0)?;
    if source
        .iter()
        .chain(destination)
        .any(|&i| i as usize >= atom_count)
    {
        candle_core::bail!("edge index outside atom range")
    }
    let source = Tensor::from_vec(source.to_vec(), n, device)?;
    let destination = Tensor::from_vec(destination.to_vec(), n, device)?;
    let offsets = Tensor::from_vec(offsets.iter().flatten().copied().collect(), (n, 3), device)?;
    let from = positions.index_select(&source, 0)?;
    let to = positions.index_select(&destination, 0)?;
    let shifted = to.add(&offsets.matmul(cell)?)?;
    let vector = shifted.sub(&from)?;
    vector.sqr()?.sum(1)?.sqrt()
}

#[cfg(test)]
mod tests {
    use super::*;
    use candle_core::{Device, Var};
    use serde::Deserialize;

    #[derive(Deserialize)]
    struct GeometryGolden {
        positions_a: Vec<[f32; 3]>,
        cell_a: [[f32; 3]; 3],
        source: Vec<u32>,
        destination: Vec<u32>,
        offsets: Vec<[f32; 3]>,
        edge_lengths_a: Vec<f32>,
        sum_length_position_grad: Vec<[f32; 3]>,
        sum_length_cell_grad: [[f32; 3]; 3],
    }

    fn check_cus12_golden(device: &Device) -> Result<()> {
        let fixture: GeometryGolden = serde_json::from_str(include_str!(
            "../../../reference/fixtures/golden/cus12_geometry.json"
        ))
        .expect("valid pinned geometry fixture");
        let atoms = fixture.positions_a.len();
        let positions = Var::from_vec(
            fixture.positions_a.iter().flatten().copied().collect(),
            (atoms, 3),
            device,
        )?;
        let cell = Var::from_vec(
            fixture.cell_a.iter().flatten().copied().collect(),
            (3, 3),
            device,
        )?;
        let lengths = edge_lengths(
            &positions,
            &cell,
            &fixture.source,
            &fixture.destination,
            &fixture.offsets,
        )?;
        let actual_lengths = lengths.to_vec1::<f32>()?;
        let max_length_error = actual_lengths
            .iter()
            .zip(&fixture.edge_lengths_a)
            .map(|(actual, expected)| (actual - expected).abs())
            .fold(0f32, f32::max);
        assert!(
            max_length_error < 1e-5,
            "maximum CuS edge length error: {max_length_error}"
        );
        let gradients = lengths.sum_all()?.backward()?;
        let actual_positions = gradients.get(&positions).unwrap().to_vec2::<f32>()?;
        let actual_cell = gradients.get(&cell).unwrap().to_vec2::<f32>()?;
        let max_position_error = actual_positions
            .iter()
            .flatten()
            .zip(fixture.sum_length_position_grad.iter().flatten())
            .map(|(actual, expected)| (actual - expected).abs())
            .fold(0f32, f32::max);
        let max_cell_error = actual_cell
            .iter()
            .flatten()
            .zip(fixture.sum_length_cell_grad.iter().flatten())
            .map(|(actual, expected)| (actual - expected).abs())
            .fold(0f32, f32::max);
        println!(
            "CuS12 geometry max errors: length={max_length_error:.3e} A, position_grad={max_position_error:.3e}, cell_grad={max_cell_error:.3e}"
        );
        assert!(
            max_position_error < 1e-4,
            "maximum CuS position gradient error: {max_position_error}"
        );
        assert!(
            max_cell_error < 1e-4,
            "maximum CuS cell gradient error: {max_cell_error}"
        );
        Ok(())
    }

    #[test]
    fn periodic_geometry_has_position_and_cell_gradients() -> Result<()> {
        let device = Device::Cpu;
        let positions = Var::from_vec(vec![0f32, 0., 0., 1., 0., 0.], (2, 3), &device)?;
        let cell = Var::from_vec(vec![3f32, 0., 0., 0., 3., 0., 0., 0., 3.], (3, 3), &device)?;
        let length = edge_lengths(&positions, &cell, &[0], &[1], &[[-1., 0., 0.]])?;
        assert_eq!(length.to_vec1::<f32>()?, vec![2.]);
        let gradients = length.sum_all()?.backward()?;
        assert_eq!(
            gradients.get(&positions).unwrap().to_vec2::<f32>()?,
            vec![vec![1., 0., 0.], vec![-1., 0., 0.]]
        );
        assert_eq!(gradients.get(&cell).unwrap().to_vec2::<f32>()?[0][0], 1.);
        Ok(())
    }

    #[test]
    fn cpu_cus12_geometry_matches_torch_golden() -> Result<()> {
        check_cus12_golden(&Device::Cpu)
    }

    #[cfg(feature = "cuda")]
    #[test]
    fn cuda_periodic_geometry_has_gradients() -> Result<()> {
        let device = Device::new_cuda(0)?;
        let positions = Var::from_vec(vec![0f32, 0., 0., 1., 0., 0.], (2, 3), &device)?;
        let cell = Var::from_vec(vec![3f32, 0., 0., 0., 3., 0., 0., 0., 3.], (3, 3), &device)?;
        let length = edge_lengths(&positions, &cell, &[0], &[1], &[[-1., 0., 0.]])?;
        let actual = length.to_vec1::<f32>()?[0];
        assert!((actual - 2.0).abs() < 1e-6, "CUDA length: {actual}");
        let gradients = length.sum_all()?.backward()?;
        let position_gradient = gradients.get(&positions).unwrap().to_vec2::<f32>()?;
        let cell_gradient = gradients.get(&cell).unwrap().to_vec2::<f32>()?;
        assert!((position_gradient[0][0] - 1.0).abs() < 1e-6);
        assert!((position_gradient[1][0] + 1.0).abs() < 1e-6);
        assert!((cell_gradient[0][0] - 1.0).abs() < 1e-6);
        Ok(())
    }

    #[cfg(feature = "cuda")]
    #[test]
    fn cuda_cus12_geometry_matches_torch_golden() -> Result<()> {
        check_cus12_golden(&Device::new_cuda(0)?)
    }
}
