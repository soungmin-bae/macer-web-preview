//! Geometry boundary for a WebGPU neural network. The network and its reverse
//! pass run on GPU; this initial bridge preserves Rust's analytic geometry VJP.

use super::{Evaluator, OrderedGraph, PyTorchNorm3};
use candle_core::{Tensor, Var};
use macer_rust_core::types::Evaluation;
use serde::{Deserialize, Serialize};

#[derive(Serialize)]
pub struct GeometryFeatures {
    pub graph: OrderedGraph,
    pub rbf: Vec<Vec<f32>>,
    pub sbf: Vec<Vec<f32>>,
    pub cutoff: Vec<Vec<f32>>,
}

#[derive(Deserialize)]
pub struct FeatureGradients {
    pub energy_ev: f64,
    pub rbf: Vec<Vec<f32>>,
    pub sbf: Vec<Vec<f32>>,
    pub cutoff: Vec<Vec<f32>>,
}

#[derive(Serialize)]
pub struct GeometryConstants {
    n1: Vec<f32>,
    n2: Vec<f32>,
    fnr_weights: Vec<f32>,
    dn: [f32; 4],
    en: [f32; 4],
    sbf_factor: f32,
    sbf_coef: Vec<Vec<Vec<f32>>>,
}

struct GeometryTape {
    positions: Var,
    strain: Var,
    rbf: Tensor,
    sbf: Tensor,
    cutoff: Tensor,
}

impl Evaluator {
    pub fn webgpu_geometry_constants(&self) -> Result<GeometryConstants, String> {
        let coefficients = |name| {
            self.w(name)
                .flatten_all()
                .and_then(|t| t.to_vec1::<f32>())
                .map_err(|e| e.to_string())
        };
        Ok(GeometryConstants {
            n1: coefficients("rbf.n_1_pi_cutoff")?,
            n2: coefficients("rbf.n_2_pi_cutoff")?,
            fnr_weights: coefficients("rbf.fnr_weights")?,
            dn: self.rbf_dn,
            en: self.rbf_en,
            sbf_factor: self.sbf_factor,
            sbf_coef: self.sbf_coef.clone(),
        })
    }

    fn webgpu_geometry_tape(&self, graph: &OrderedGraph) -> Result<GeometryTape, String> {
        graph.validate()?;
        if !self.device.is_cpu() {
            return Err("WebGPU geometry bridge requires the CPU/WASM evaluator".into());
        }
        let result = (|| -> candle_core::Result<GeometryTape> {
            let n = graph.atomic_numbers.len();
            let positions = Var::from_vec(
                graph.positions_a.iter().flatten().copied().collect(),
                (n, 3),
                &self.device,
            )?;
            let strain = Var::zeros((3, 3), candle_core::DType::F32, &self.device)?;
            let deformation =
                Tensor::eye(3, candle_core::DType::F32, &self.device)?.add(&strain)?;
            let pos = positions.matmul(&deformation)?;
            let cell = Tensor::from_vec(
                graph.cell_a.iter().flatten().copied().collect(),
                (3, 3),
                &self.device,
            )?
            .matmul(&deformation)?;
            let cached = self.graph_tensors(graph)?;
            let vector = pos.index_select(&cached.source, 0)?.sub(
                &pos.index_select(&cached.destination, 0)?
                    .add(&cached.offsets.matmul(&cell)?)?,
            )?;
            let lengths = vector.apply_op1(PyTorchNorm3)?;
            let rij = lengths.index_select(&cached.first, 0)?;
            let rik = lengths.index_select(&cached.second, 0)?;
            let cosine = vector
                .index_select(&cached.first, 0)?
                .mul(&vector.index_select(&cached.second, 0)?)?
                .sum(1)?
                .div(&rij.mul(&rik)?)?
                .clamp(-1. + 1e-7, 1. - 1e-7)?;
            Ok(GeometryTape {
                positions,
                strain,
                rbf: self.rbf(&lengths)?,
                sbf: self.sbf(&rik, &cosine)?,
                cutoff: Self::polynomial(&rij, 4.)?
                    .mul(&Self::polynomial(&rik, 4.)?)?
                    .unsqueeze(1)?,
            })
        })();
        result.map_err(|e| e.to_string())
    }

    pub fn webgpu_features(&self, graph: &OrderedGraph) -> Result<GeometryFeatures, String> {
        let tape = self.webgpu_geometry_tape(graph)?;
        let features = GeometryFeatures {
            graph: graph.clone(),
            rbf: tape.rbf.to_vec2().map_err(|e| e.to_string())?,
            sbf: tape.sbf.to_vec2().map_err(|e| e.to_string())?,
            cutoff: tape.cutoff.to_vec2().map_err(|e| e.to_string())?,
        };
        if features
            .rbf
            .iter()
            .chain(&features.sbf)
            .chain(&features.cutoff)
            .flatten()
            .any(|v| !v.is_finite())
        {
            return Err("non-finite WebGPU geometry features".into());
        }
        Ok(features)
    }

    pub fn webgpu_geometry_backward(
        &self,
        graph: &OrderedGraph,
        gradients: FeatureGradients,
    ) -> Result<Evaluation, String> {
        let tape = self.webgpu_geometry_tape(graph)?;
        let dot = |value: &Tensor, gradient: Vec<Vec<f32>>| -> Result<Tensor, String> {
            let (rows, cols) = value.dims2().map_err(|e| e.to_string())?;
            if gradient.len() != rows
                || gradient.iter().any(|r| r.len() != cols)
                || gradient.iter().flatten().any(|v| !v.is_finite())
            {
                return Err("invalid or non-finite WebGPU feature gradient".into());
            }
            let data = gradient.into_iter().flatten().collect::<Vec<_>>();
            let grad =
                Tensor::from_vec(data, (rows, cols), &self.device).map_err(|e| e.to_string())?;
            value
                .mul(&grad)
                .and_then(|v| v.sum_all())
                .map_err(|e| e.to_string())
        };
        let objective = dot(&tape.rbf, gradients.rbf)?
            .add(&dot(&tape.sbf, gradients.sbf)?)
            .map_err(|e| e.to_string())?
            .add(&dot(&tape.cutoff, gradients.cutoff)?)
            .map_err(|e| e.to_string())?;
        let backward = objective.backward().map_err(|e| e.to_string())?;
        let force = backward
            .get(&tape.positions)
            .ok_or("missing WebGPU position gradient")?
            .to_vec2::<f32>()
            .map_err(|e| e.to_string())?;
        let strain = backward
            .get(&tape.strain)
            .ok_or("missing WebGPU strain gradient")?
            .to_vec2::<f32>()
            .map_err(|e| e.to_string())?;
        let a = graph.cell_a.map(|r| r.map(f64::from));
        let volume = a[0][0] * (a[1][1] * a[2][2] - a[1][2] * a[2][1])
            - a[0][1] * (a[1][0] * a[2][2] - a[1][2] * a[2][0])
            + a[0][2] * (a[1][0] * a[2][1] - a[1][1] * a[2][0]);
        if volume.abs() < 1e-12 {
            return Err("zero WebGPU geometry volume".into());
        }
        let evaluation = Evaluation {
            energy_ev: gradients.energy_ev,
            forces_ev_per_a: force
                .iter()
                .map(|r| [-r[0] as f64, -r[1] as f64, -r[2] as f64])
                .collect(),
            stress_ev_per_a3: std::array::from_fn(|i| {
                std::array::from_fn(|j| strain[i][j] as f64 / volume)
            }),
            energies_ev: None,
            stresses_ev_per_a3: None,
        };
        evaluation.validate(graph.atomic_numbers.len())?;
        Ok(evaluation)
    }
}
