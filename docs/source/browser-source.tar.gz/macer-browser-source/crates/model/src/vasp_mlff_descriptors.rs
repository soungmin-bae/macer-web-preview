//! VASP ML_FF SOAP expansion coefficients built from periodic neighbor images.

use crate::vasp_mlff::{spline_eval_vasp, RadialSplineSet, AUTOA_ANGSTROM_PER_BOHR};
use crate::vasp_mlff_neighbors::NeighborImage;
use std::f64::consts::PI;

#[derive(Clone, Debug, PartialEq, serde::Serialize)]
pub struct AngularDescriptorIndex {
    pub active_index: usize,
    pub candidate_index_1based: usize,
    pub center_type: usize,
    pub neighbor_type_a: usize,
    pub neighbor_type_b: usize,
    pub l: usize,
    pub radial_i_1based: usize,
    pub radial_j_1based: usize,
    pub pair_weight: f64,
}

#[derive(Clone, Debug, PartialEq, serde::Deserialize, serde::Serialize)]
pub struct AngularSICDescriptorIndex {
    pub active_index: usize,
    pub candidate_index_1based: usize,
    pub center_type: usize,
    pub neighbor_type: usize,
    pub l: usize,
    pub radial_i_1based: usize,
    pub radial_j_1based: usize,
}

/// Reconstruct the DESC_TYPE=0 angular active-index table in Macer's order.
pub fn build_desc_type0_angular_layout(
    nrb: &[usize],
    ntypes: usize,
    active_candidates_by_center: &[Vec<usize>],
) -> Result<Vec<Vec<AngularDescriptorIndex>>, String> {
    if nrb.is_empty() || ntypes == 0 || active_candidates_by_center.len() != ntypes {
        return Err("nrb, species count, and active descriptor rows are inconsistent".into());
    }
    if nrb.len() > 33 || nrb.contains(&0) {
        return Err("nrb must contain 1..=33 positive angular channels".into());
    }
    let candidate_count = nrb
        .iter()
        .try_fold(0usize, |total, &count| {
            count
                .checked_mul(count + 1)
                .and_then(|pairs| total.checked_add(pairs / 2))
        })
        .and_then(|per_pair| per_pair.checked_mul(ntypes))
        .and_then(|per_center| per_center.checked_mul(ntypes))
        .ok_or_else(|| "angular candidate count overflows usize".to_string())?;
    if candidate_count > 16_000_000 {
        return Err(
            "angular descriptor layout exceeds the 16-million-candidate safety limit".into(),
        );
    }
    let mut layouts = Vec::with_capacity(ntypes);
    for (center_type, requested) in active_candidates_by_center.iter().enumerate() {
        let mut is_active = vec![false; candidate_count + 1];
        for &candidate in requested {
            if candidate == 0 || candidate > candidate_count || is_active[candidate] {
                return Err(format!(
                    "invalid or duplicate active angular candidate {candidate} for center type {center_type}"
                ));
            }
            is_active[candidate] = true;
        }
        let mut layout = Vec::with_capacity(requested.len());
        let mut candidate = 0usize;
        for neighbor_type_a in 0..ntypes {
            for neighbor_type_b in 0..ntypes {
                for (l, &count) in nrb.iter().enumerate() {
                    for radial_i in 1..=count {
                        for radial_j in radial_i..=count {
                            candidate += 1;
                            if is_active[candidate] {
                                layout.push(AngularDescriptorIndex {
                                    active_index: layout.len(),
                                    candidate_index_1based: candidate,
                                    center_type,
                                    neighbor_type_a,
                                    neighbor_type_b,
                                    l,
                                    radial_i_1based: radial_i,
                                    radial_j_1based: radial_j,
                                    pair_weight: if radial_i == radial_j {
                                        1.0
                                    } else {
                                        2.0_f64.sqrt()
                                    },
                                });
                            }
                        }
                    }
                }
            }
        }
        if layout.len() != requested.len() {
            return Err(format!(
                "active angular descriptor count mismatch for center type {center_type}"
            ));
        }
        layouts.push(layout);
    }
    Ok(layouts)
}

/// Reconstruct the DESC_TYPE=0 LSIC active-index table in Macer's order.
pub fn build_desc_type0_sic_layout(
    nrb: &[usize],
    ntypes: usize,
    active_candidates_by_center: &[Vec<usize>],
) -> Result<Vec<Vec<AngularSICDescriptorIndex>>, String> {
    if nrb.is_empty() || ntypes == 0 || active_candidates_by_center.len() != ntypes {
        return Err("nrb, species count, and active LSIC rows are inconsistent".into());
    }
    if nrb.len() > 33 || nrb.contains(&0) {
        return Err("nrb must contain 1..=33 positive angular channels".into());
    }
    let candidate_count = nrb
        .iter()
        .try_fold(0usize, |total, &count| {
            count
                .checked_mul(count + 1)
                .and_then(|pairs| total.checked_add(pairs / 2))
        })
        .and_then(|per_type| per_type.checked_mul(ntypes))
        .ok_or_else(|| "LSIC candidate count overflows usize".to_string())?;
    if candidate_count > 16_000_000 {
        return Err("LSIC layout exceeds the 16-million-candidate safety limit".into());
    }

    let mut layouts = Vec::with_capacity(ntypes);
    for (center_type, requested) in active_candidates_by_center.iter().enumerate() {
        let mut is_active = vec![false; candidate_count + 1];
        for &candidate in requested {
            if candidate == 0 || candidate > candidate_count || is_active[candidate] {
                return Err(format!(
                    "invalid or duplicate active LSIC candidate {candidate} for center type {center_type}"
                ));
            }
            is_active[candidate] = true;
        }
        let mut layout = Vec::with_capacity(requested.len());
        let mut candidate = 0usize;
        for neighbor_type in 0..ntypes {
            for (l, &count) in nrb.iter().enumerate() {
                for radial_i in 1..=count {
                    for radial_j in radial_i..=count {
                        candidate += 1;
                        if is_active[candidate] {
                            layout.push(AngularSICDescriptorIndex {
                                active_index: layout.len(),
                                candidate_index_1based: candidate,
                                center_type,
                                neighbor_type,
                                l,
                                radial_i_1based: radial_i,
                                radial_j_1based: radial_j,
                            });
                        }
                    }
                }
            }
        }
        if layout.len() != requested.len() {
            return Err(format!(
                "active LSIC descriptor count mismatch for center type {center_type}"
            ));
        }
        layouts.push(layout);
    }
    Ok(layouts)
}

fn clm_type_stride(nrb: &[usize]) -> usize {
    nrb.iter()
        .enumerate()
        .map(|(l, &count)| (2 * l + 1) * count)
        .sum()
}

fn clm_index(
    nrb: &[usize],
    type_stride: usize,
    neighbor_type: usize,
    l: usize,
    radial: usize,
    m: usize,
) -> usize {
    neighbor_type * type_stride
        + nrb[..l]
            .iter()
            .enumerate()
            .map(|(ll, &count)| (2 * ll + 1) * count)
            .sum::<usize>()
        + m * nrb[l]
        + radial
}

/// Compute the radial C00 channels for one center from its CLM coefficients.
pub fn compute_c00_from_clm(
    clm: &[f64],
    nrb: &[usize],
    ntypes: usize,
    mrb: usize,
) -> Result<Vec<f64>, String> {
    if nrb.is_empty() || ntypes == 0 || mrb < nrb[0] {
        return Err("invalid C00 descriptor dimensions".into());
    }
    let stride = clm_type_stride(nrb);
    if clm.len() != stride.saturating_mul(ntypes) {
        return Err("CLM array size does not match nrb and species count".into());
    }
    let mut c00 = vec![0.0; mrb.saturating_mul(ntypes)];
    if c00.len() > 16_000_000 {
        return Err("C00 descriptor exceeds the 16-million-value safety limit".into());
    }
    for neighbor_type in 0..ntypes {
        for radial in 0..nrb[0] {
            c00[mrb * neighbor_type + radial] =
                clm[clm_index(nrb, stride, neighbor_type, 0, radial, 0)];
        }
    }
    Ok(c00)
}

fn soap_prefactor(
    l: usize,
    lafilt: bool,
    iafilt: Option<u8>,
    afilt: Option<f64>,
) -> Result<f64, String> {
    let base = (8.0 * PI.powi(2) / (2 * l + 1) as f64).sqrt();
    if !lafilt {
        return Ok(base);
    }
    match iafilt {
        Some(1) => Ok(base / ((2 * l + 1) as f64).sqrt()),
        Some(2) => {
            let alpha = afilt.ok_or_else(|| "afilt is required for IAFILT=2".to_string())?;
            if !alpha.is_finite() {
                return Err("afilt must be finite".into());
            }
            Ok(base / (1.0 + alpha * ((l * (l + 1)) as f64).powi(2)).powi(2))
        }
        other => Err(format!("unsupported angular filter IAFILT={other:?}")),
    }
}

/// Compute the active PS angular descriptor vector for one center.
pub fn compute_active_ps_from_clm(
    clm: &[f64],
    layout: &[AngularDescriptorIndex],
    nrb: &[usize],
    ntypes: usize,
    lafilt: bool,
    iafilt: Option<u8>,
    afilt: Option<f64>,
) -> Result<Vec<f64>, String> {
    if nrb.is_empty() || ntypes == 0 {
        return Err("nrb and ntypes must be nonempty".into());
    }
    let stride = clm_type_stride(nrb);
    if clm.len() != stride.saturating_mul(ntypes) {
        return Err("CLM array size does not match nrb and species count".into());
    }
    let mut ps = vec![0.0; layout.len()];
    let mut seen = vec![false; layout.len()];
    for item in layout {
        if item.active_index >= layout.len() || seen[item.active_index] {
            return Err("angular active indices must be unique and contiguous".into());
        }
        seen[item.active_index] = true;
        if item.l >= nrb.len()
            || item.neighbor_type_a >= ntypes
            || item.neighbor_type_b >= ntypes
            || item.radial_i_1based == 0
            || item.radial_i_1based > nrb[item.l]
            || item.radial_j_1based == 0
            || item.radial_j_1based > nrb[item.l]
            || item.radial_j_1based < item.radial_i_1based
            || !item.pair_weight.is_finite()
        {
            return Err("invalid active angular descriptor index".into());
        }
        let mut pair_sum = 0.0;
        for m in 0..(2 * item.l + 1) {
            let left = clm_index(
                nrb,
                stride,
                item.neighbor_type_a,
                item.l,
                item.radial_i_1based - 1,
                m,
            );
            let right = clm_index(
                nrb,
                stride,
                item.neighbor_type_b,
                item.l,
                item.radial_j_1based - 1,
                m,
            );
            pair_sum += clm[left] * clm[right];
        }
        ps[item.active_index] =
            item.pair_weight * soap_prefactor(item.l, lafilt, iafilt, afilt)? * pair_sum;
    }
    Ok(ps)
}

/// Compute Macer's LSIC self-interaction contribution for one center.
pub fn compute_active_sic_from_neighbors(
    neighbors: &[NeighborImage],
    layout: &[AngularSICDescriptorIndex],
    splines: &RadialSplineSet,
    nrb: &[usize],
    ntypes: usize,
) -> Result<Vec<f64>, String> {
    if nrb.is_empty() || ntypes == 0 {
        return Err("nrb and ntypes must be nonempty".into());
    }
    if splines.fnl.len() < 2
        || splines.fnl.iter().any(|grid| {
            grid.len() < 5
                || grid.iter().take(5).any(|column| {
                    column.len() != nrb.len()
                        || column
                            .iter()
                            .zip(nrb)
                            .any(|(channel, &count)| channel.len() < count)
                })
        })
    {
        return Err("radial spline table shape does not match nrb".into());
    }
    let mut coefficients = nrb
        .iter()
        .map(|&count| vec![Vec::<[f64; 5]>::new(); count])
        .collect::<Vec<_>>();
    for (l, &count) in nrb.iter().enumerate() {
        for radial in 0..count {
            coefficients[l][radial] = splines
                .fnl
                .iter()
                .map(|grid| {
                    [
                        grid[0][l][radial],
                        grid[1][l][radial],
                        grid[2][l][radial],
                        grid[3][l][radial],
                        grid[4][l][radial],
                    ]
                })
                .collect();
        }
    }
    let mut sic = vec![0.0; layout.len()];
    let mut seen = vec![false; layout.len()];
    for item in layout {
        if item.active_index >= layout.len() || seen[item.active_index] {
            return Err("LSIC active indices must be unique and contiguous".into());
        }
        seen[item.active_index] = true;
        if item.neighbor_type >= ntypes
            || item.l >= nrb.len()
            || item.radial_i_1based == 0
            || item.radial_i_1based > nrb[item.l]
            || item.radial_j_1based < item.radial_i_1based
            || item.radial_j_1based > nrb[item.l]
        {
            return Err("invalid active LSIC descriptor index".into());
        }
    }
    for neighbor in neighbors {
        if neighbor.neighbor_type >= ntypes {
            return Err(format!(
                "neighbor type {} is outside ntypes={ntypes}",
                neighbor.neighbor_type
            ));
        }
        if !neighbor.distance_angstrom.is_finite() || neighbor.distance_angstrom <= 0.0 {
            return Err("neighbor distance must be finite and positive".into());
        }
        let unit = neighbor
            .vector_angstrom
            .map(|component| component / neighbor.distance_angstrom);
        let ylm = real_spherical_harmonics_vasp(unit, nrb.len() - 1)?;
        let distance_bohr = neighbor.distance_angstrom / AUTOA_ANGSTROM_PER_BOHR;
        for item in layout
            .iter()
            .filter(|item| item.neighbor_type == neighbor.neighbor_type)
        {
            let (value_i, _) = spline_eval_vasp(
                &coefficients[item.l][item.radial_i_1based - 1],
                distance_bohr,
                splines.drspl,
            )?;
            let (value_j, _) = spline_eval_vasp(
                &coefficients[item.l][item.radial_j_1based - 1],
                distance_bohr,
                splines.drspl,
            )?;
            let harmonic_start = item.l * item.l;
            let angular_norm = ylm[harmonic_start..harmonic_start + 2 * item.l + 1]
                .iter()
                .map(|value| value * value)
                .sum::<f64>();
            sic[item.active_index] += value_i * value_j * angular_norm;
        }
    }
    Ok(sic)
}

/// Subtract the LSIC contribution from active PS entries that have a matching
/// same-species pair in the SIC layout.
pub fn subtract_sic_from_active_ps(
    ps: &mut [f64],
    angular_layout: &[AngularDescriptorIndex],
    sic_layout: &[AngularSICDescriptorIndex],
    sic: &[f64],
    lafilt: bool,
    iafilt: Option<u8>,
    afilt: Option<f64>,
) -> Result<(), String> {
    if ps.len() != angular_layout.len() || sic.len() != sic_layout.len() {
        return Err("PS and LSIC vector sizes must match their descriptor layouts".into());
    }
    let sic_indices = sic_layout
        .iter()
        .map(|item| {
            (
                (
                    item.neighbor_type,
                    item.l,
                    item.radial_i_1based,
                    item.radial_j_1based,
                ),
                item.active_index,
            )
        })
        .collect::<std::collections::HashMap<_, _>>();
    for item in angular_layout {
        if item.neighbor_type_a != item.neighbor_type_b {
            continue;
        }
        let key = (
            item.neighbor_type_a,
            item.l,
            item.radial_i_1based,
            item.radial_j_1based,
        );
        if let Some(&sic_index) = sic_indices.get(&key) {
            if item.active_index >= ps.len() || sic_index >= sic.len() {
                return Err("descriptor layout contains an out-of-range active index".into());
            }
            ps[item.active_index] -=
                item.pair_weight * soap_prefactor(item.l, lafilt, iafilt, afilt)? * sic[sic_index];
        }
    }
    Ok(())
}

/// Apply Macer's LSUPERVEC weighted descriptor normalization.
pub fn normalize_supervector_descriptors(
    c00: Option<&[f64]>,
    ps: Option<&[f64]>,
    w1: f64,
    w2: f64,
    lnorm1: bool,
    lnorm2: bool,
    eps: f64,
) -> Result<(Option<Vec<f64>>, Option<Vec<f64>>, f64), String> {
    if !w1.is_finite() || !w2.is_finite() || w1 < 0.0 || w2 < 0.0 || !eps.is_finite() || eps < 0.0 {
        return Err("descriptor weights and epsilon must be finite and non-negative".into());
    }
    if c00
        .into_iter()
        .flatten()
        .chain(ps.into_iter().flatten())
        .any(|v| !v.is_finite())
    {
        return Err("descriptor values must be finite".into());
    }
    let mut c00_out = c00.map(|values| values.to_vec());
    let mut ps_out = ps.map(|values| values.to_vec());
    let mut norm2 = 0.0;
    if let Some(values) = &c00_out {
        if w1 > 0.0 {
            norm2 += w1 * values.iter().map(|v| v * v).sum::<f64>();
        }
    }
    if let Some(values) = &ps_out {
        if w2 > 0.0 {
            norm2 += w2 * values.iter().map(|v| v * v).sum::<f64>();
        }
    }
    let norm = norm2.sqrt();
    if norm >= eps {
        if lnorm1 && w1 > 0.0 {
            if let Some(values) = &mut c00_out {
                let scale = w1.sqrt() / norm;
                values.iter_mut().for_each(|value| *value *= scale);
            }
        }
        if lnorm2 && w2 > 0.0 {
            if let Some(values) = &mut ps_out {
                let scale = w2.sqrt() / norm;
                values.iter_mut().for_each(|value| *value *= scale);
            }
        }
    }
    Ok((c00_out, ps_out, norm))
}

/// Return VASP-ordered real spherical harmonics, flattened by `l*l + m+l`.
pub fn real_spherical_harmonics_vasp(
    unit_vector: [f64; 3],
    lmax: usize,
) -> Result<Vec<f64>, String> {
    if lmax > 32 {
        return Err("lmax exceeds the supported safety limit of 32".into());
    }
    if unit_vector.iter().any(|value| !value.is_finite()) {
        return Err("unit vector must contain finite values".into());
    }
    let norm = unit_vector
        .iter()
        .map(|value| value * value)
        .sum::<f64>()
        .sqrt();
    if (norm - 1.0).abs() > 1.0e-10 {
        return Err("real spherical harmonics require a normalized vector".into());
    }
    let z = unit_vector[2].clamp(-1.0, 1.0);
    let phi = unit_vector[1].atan2(unit_vector[0]);
    let mut out = vec![0.0; (lmax + 1) * (lmax + 1)];
    let mut pmm = 1.0;
    for m in 0..=lmax {
        if m > 0 {
            pmm *= -((2 * m - 1) as f64) * (1.0 - z * z).max(0.0).sqrt();
        }
        let mut p_lm2 = 0.0;
        let mut p_lm1 = pmm;
        for l in m..=lmax {
            let p_lm = if l == m {
                pmm
            } else if l == m + 1 {
                z * (2 * m + 1) as f64 * pmm
            } else {
                ((2 * l - 1) as f64 * z * p_lm1 - (l + m - 1) as f64 * p_lm2) / (l - m) as f64
            };
            let normalization =
                (((2 * l + 1) as f64 / (4.0 * PI)) * factorial_ratio(l - m, l + m)).sqrt();
            for signed_m in -(m as isize)..=(m as isize) {
                if signed_m.unsigned_abs() != m {
                    continue;
                }
                let harmonic = normalization * p_lm;
                let value = if signed_m == 0 {
                    harmonic
                } else {
                    let parity = if m % 2 == 0 { 1.0 } else { -1.0 };
                    let angular = if signed_m < 0 {
                        (m as f64 * phi).sin()
                    } else {
                        (m as f64 * phi).cos()
                    };
                    2.0_f64.sqrt() * parity * harmonic * angular
                };
                out[l * l + (signed_m + l as isize) as usize] = value;
            }
            p_lm2 = p_lm1;
            p_lm1 = p_lm;
        }
    }
    Ok(out)
}

fn factorial_ratio(numerator: usize, denominator: usize) -> f64 {
    (numerator + 1..=denominator).fold(1.0, |value, factor| value / factor as f64)
}

/// Compute one center atom's VASP fast-layout `CLM` expansion coefficients.
pub fn compute_clm_from_neighbors(
    neighbors: &[NeighborImage],
    splines: &RadialSplineSet,
    nrb: &[usize],
    ntypes: usize,
) -> Result<Vec<f64>, String> {
    if ntypes == 0 || nrb.is_empty() {
        return Err("ntypes and nrb must be nonempty".into());
    }
    let lmax = nrb.len() - 1;
    if lmax > 32 {
        return Err("lmax exceeds the supported safety limit of 32".into());
    }
    if splines.fnl.len() < 2
        || splines.fnl.iter().any(|grid| {
            grid.len() < 5
                || grid.iter().take(5).any(|column| {
                    column.len() != nrb.len()
                        || column
                            .iter()
                            .zip(nrb)
                            .any(|(channel, &count)| channel.len() < count)
                })
        })
    {
        return Err("radial spline table shape does not match nrb".into());
    }
    let per_type = nrb
        .iter()
        .enumerate()
        .try_fold(0usize, |total, (l, &count)| {
            total.checked_add((2 * l + 1).checked_mul(count)?)
        })
        .ok_or_else(|| "CLM descriptor size overflows usize".to_string())?;
    let clm_size = ntypes
        .checked_mul(per_type)
        .ok_or_else(|| "CLM descriptor size overflows usize".to_string())?;
    if clm_size > 16_000_000 {
        return Err("CLM descriptor exceeds the 16-million-value safety limit".into());
    }
    let mut clm = vec![0.0; clm_size];
    if neighbors.is_empty() {
        return Ok(clm);
    }
    let mut coefficients = nrb
        .iter()
        .map(|&count| vec![Vec::<[f64; 5]>::new(); count])
        .collect::<Vec<_>>();
    for l in 0..=lmax {
        for radial in 0..nrb[l] {
            coefficients[l][radial] = splines
                .fnl
                .iter()
                .map(|grid| {
                    [
                        grid[0][l][radial],
                        grid[1][l][radial],
                        grid[2][l][radial],
                        grid[3][l][radial],
                        grid[4][l][radial],
                    ]
                })
                .collect();
        }
    }
    for neighbor in neighbors {
        if neighbor.neighbor_type >= ntypes {
            return Err(format!(
                "neighbor type {} is outside ntypes={ntypes}",
                neighbor.neighbor_type
            ));
        }
        if !neighbor.distance_angstrom.is_finite() || neighbor.distance_angstrom <= 0.0 {
            return Err("neighbor distance must be finite and positive".into());
        }
        let unit = neighbor
            .vector_angstrom
            .map(|component| component / neighbor.distance_angstrom);
        let ylm = real_spherical_harmonics_vasp(unit, lmax)?;
        let distance_bohr = neighbor.distance_angstrom / AUTOA_ANGSTROM_PER_BOHR;
        for l in 0..=lmax {
            for radial in 0..nrb[l] {
                let (value, _) =
                    spline_eval_vasp(&coefficients[l][radial], distance_bohr, splines.drspl)?;
                if value == 0.0 {
                    continue;
                }
                let type_offset = neighbor.neighbor_type * per_type;
                let angular_offset = nrb[..l]
                    .iter()
                    .enumerate()
                    .map(|(ll, &count)| (2 * ll + 1) * count)
                    .sum::<usize>();
                for local_m in 0..2 * l + 1 {
                    let index = type_offset + angular_offset + local_m * nrb[l] + radial;
                    clm[index] += value * ylm[l * l + local_m];
                }
            }
        }
    }
    Ok(clm)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::vasp_mlff::{
        angular_wion_from_payload, build_angular_basis_from_payload, build_gaussian_radial_splines,
    };
    use crate::vasp_mlff_neighbors::enumerate_periodic_neighbor_images;
    use macer_rust_core::Structure;
    use serde_json::Value;

    const GOLDEN: &str =
        include_str!("../../../evidence/vasp_mlff_descriptors_2026-10-24/macer_reference.json");
    const LSIC_GOLDEN: &str =
        include_str!("../../../evidence/vasp_mlff_lsic_2026-10-24/macer_reference.json");
    const HARMONICS_GOLDEN: &str = include_str!(
        "../../../evidence/vasp_mlff_inspect_parity_2026-10-24/real_spherical_harmonics_expected.json"
    );

    #[test]
    fn real_spherical_harmonics_match_macer_for_axis_and_oblique_vectors() {
        let golden: Value = serde_json::from_str(HARMONICS_GOLDEN).unwrap();
        let vectors: Vec<[f64; 3]> =
            serde_json::from_value(golden["unit_vectors"].clone()).unwrap();
        let expected = golden["harmonics"].as_array().unwrap();
        let lmax = golden["lmax"].as_u64().unwrap() as usize;
        for (vector_index, vector) in vectors.into_iter().enumerate() {
            let actual = real_spherical_harmonics_vasp(vector, lmax).unwrap();
            let expected_row: Vec<f64> =
                serde_json::from_value(expected[vector_index].clone()).unwrap();
            assert_eq!(actual.len(), expected_row.len());
            for (index, (actual, expected)) in actual.iter().zip(expected_row).enumerate() {
                assert!(
                    (actual - expected).abs() <= 2.0e-12 * expected.abs().max(1.0),
                    "vector={vector_index} YLM[{index}] actual={actual:.16e} expected={expected:.16e}"
                );
            }
        }
    }

    #[test]
    fn clm_expansion_matches_macer_for_mixed_species_triclinic_cell() {
        let golden: Value = serde_json::from_str(GOLDEN).unwrap();
        let input = &golden["input"];
        let structure = Structure {
            atomic_numbers: serde_json::from_value(input["atomic_numbers"].clone()).unwrap(),
            positions_a: serde_json::from_value(input["positions_a"].clone()).unwrap(),
            cell_a: serde_json::from_value(input["cell_a"].clone()).unwrap(),
            pbc: [true; 3],
        };
        let species: Vec<u8> =
            serde_json::from_value(input["type_atomic_numbers"].clone()).unwrap();
        let neighbors = enumerate_periodic_neighbor_images(
            &structure,
            &species,
            input["neighbor_cutoff_angstrom"].as_f64().unwrap(),
        )
        .unwrap();
        let basis = build_angular_basis_from_payload(
            input["radial_cutoff_angstrom"].as_f64().unwrap(),
            input["nr"].as_u64().unwrap() as usize,
            input["mrb"].as_u64().unwrap() as usize,
            input["lmax"].as_u64().unwrap() as usize,
            0,
            false,
            false,
        )
        .unwrap();
        let wion = angular_wion_from_payload(input["sion_angstrom"].as_f64().unwrap(), 2).unwrap();
        let splines =
            build_gaussian_radial_splines(&basis, input["mspl"].as_u64().unwrap() as usize, wion)
                .unwrap();
        let expected_nrb: Vec<usize> = serde_json::from_value(golden["nrb"].clone()).unwrap();
        assert_eq!(basis.nrb, expected_nrb);
        let expected_clm = golden["clm"].as_array().unwrap();
        for (center, group) in neighbors.iter().enumerate() {
            let actual =
                compute_clm_from_neighbors(group, &splines, &basis.nrb, species.len()).unwrap();
            let expected: Vec<f64> = serde_json::from_value(expected_clm[center].clone()).unwrap();
            assert_eq!(actual.len(), expected.len());
            for (index, (a, e)) in actual.iter().zip(expected).enumerate() {
                assert!(
                    (a - e).abs() <= 2.0e-10 * e.abs().max(1.0),
                    "center={center} CLM[{index}] actual={a:.16e} expected={e:.16e}"
                );
            }
        }
    }

    #[test]
    fn c00_ps_layout_filters_and_supervector_norm_match_macer() {
        let golden: Value = serde_json::from_str(GOLDEN).unwrap();
        let nrb: Vec<usize> = serde_json::from_value(golden["nrb"].clone()).unwrap();
        let active: Vec<Vec<usize>> =
            serde_json::from_value(golden["active_candidate_indices"].clone()).unwrap();
        let layouts = build_desc_type0_angular_layout(&nrb, 2, &active).unwrap();
        let parameters = &golden["supervector_parameters"];
        for (center, expected) in golden["descriptors"].as_array().unwrap().iter().enumerate() {
            let center_type = expected["center_type"].as_u64().unwrap() as usize;
            let clm: Vec<f64> = serde_json::from_value(golden["clm"][center].clone()).unwrap();
            let c00 = compute_c00_from_clm(
                &clm,
                &nrb,
                2,
                golden["input"]["mrb"].as_u64().unwrap() as usize,
            )
            .unwrap();
            let ps =
                compute_active_ps_from_clm(&clm, &layouts[center_type], &nrb, 2, false, None, None)
                    .unwrap();
            assert_values_close(&c00, &expected["c00"], 2.0e-10, "C00");
            assert_values_close(&ps, &expected["ps"], 2.0e-10, "PS");

            let filtered1 = compute_active_ps_from_clm(
                &clm,
                &layouts[center_type],
                &nrb,
                2,
                true,
                Some(1),
                None,
            )
            .unwrap();
            assert_values_close(&filtered1, &expected["ps_filter1"], 2.0e-10, "PS filter 1");
            let filtered2 = compute_active_ps_from_clm(
                &clm,
                &layouts[center_type],
                &nrb,
                2,
                true,
                Some(2),
                Some(0.015),
            )
            .unwrap();
            assert_values_close(&filtered2, &expected["ps_filter2"], 2.0e-10, "PS filter 2");

            let (c00_normalized, ps_normalized, norm) = normalize_supervector_descriptors(
                Some(&c00),
                Some(&ps),
                parameters["w1"].as_f64().unwrap(),
                parameters["w2"].as_f64().unwrap(),
                parameters["lnorm1"].as_bool().unwrap(),
                parameters["lnorm2"].as_bool().unwrap(),
                1.0e-10,
            )
            .unwrap();
            assert!((norm - expected["rnorm"].as_f64().unwrap()).abs() < 2.0e-10);
            assert_values_close(
                c00_normalized.as_ref().unwrap(),
                &expected["c00_normalized"],
                2.0e-10,
                "normalized C00",
            );
            assert_values_close(
                ps_normalized.as_ref().unwrap(),
                &expected["ps_normalized"],
                2.0e-10,
                "normalized PS",
            );
        }
    }

    #[test]
    fn lsic_layout_matches_macer_candidate_order() {
        let golden: Value = serde_json::from_str(LSIC_GOLDEN).unwrap();
        let nrb: Vec<usize> = serde_json::from_value(golden["nrb"].clone()).unwrap();
        let active: Vec<Vec<usize>> =
            serde_json::from_value(golden["sic_active_candidate_indices"].clone()).unwrap();
        let actual = build_desc_type0_sic_layout(&nrb, 2, &active).unwrap();
        for (center_type, actual) in actual.iter().enumerate() {
            let expected = golden["descriptors"]
                .as_array()
                .unwrap()
                .iter()
                .find(|row| row["center_type"].as_u64() == Some(center_type as u64))
                .unwrap();
            let expected: Vec<AngularSICDescriptorIndex> =
                serde_json::from_value(expected["sic_layout"].clone()).unwrap();
            assert_eq!(actual, &expected, "center type {center_type}");
        }
    }

    #[test]
    fn lsic_values_and_ps_correction_match_macer_reference() {
        let golden: Value = serde_json::from_str(LSIC_GOLDEN).unwrap();
        let input = &golden["input"];
        let structure = Structure {
            atomic_numbers: serde_json::from_value(input["atomic_numbers"].clone()).unwrap(),
            positions_a: serde_json::from_value(input["positions_a"].clone()).unwrap(),
            cell_a: serde_json::from_value(input["cell_a"].clone()).unwrap(),
            pbc: [true; 3],
        };
        let species: Vec<u8> =
            serde_json::from_value(input["type_atomic_numbers"].clone()).unwrap();
        let neighbors = enumerate_periodic_neighbor_images(
            &structure,
            &species,
            input["neighbor_cutoff_angstrom"].as_f64().unwrap(),
        )
        .unwrap();
        let nrb: Vec<usize> = serde_json::from_value(golden["nrb"].clone()).unwrap();
        let active_sic: Vec<Vec<usize>> =
            serde_json::from_value(golden["sic_active_candidate_indices"].clone()).unwrap();
        let sic_layouts = build_desc_type0_sic_layout(&nrb, species.len(), &active_sic).unwrap();
        let clm_golden: Value = serde_json::from_str(GOLDEN).unwrap();
        let active_angular: Vec<Vec<usize>> =
            serde_json::from_value(clm_golden["active_candidate_indices"].clone()).unwrap();
        let angular_layouts =
            build_desc_type0_angular_layout(&nrb, species.len(), &active_angular).unwrap();
        let basis = build_angular_basis_from_payload(
            input["radial_cutoff_angstrom"].as_f64().unwrap(),
            input["nr"].as_u64().unwrap() as usize,
            input["mrb"].as_u64().unwrap() as usize,
            input["lmax"].as_u64().unwrap() as usize,
            0,
            false,
            false,
        )
        .unwrap();
        let wion = angular_wion_from_payload(input["sion_angstrom"].as_f64().unwrap(), 2).unwrap();
        let splines =
            build_gaussian_radial_splines(&basis, input["mspl"].as_u64().unwrap() as usize, wion)
                .unwrap();
        let clm_rows = serde_json::from_value::<Vec<Vec<f64>>>(clm_golden["clm"].clone()).unwrap();

        for (center, expected) in golden["descriptors"].as_array().unwrap().iter().enumerate() {
            let center_type = expected["center_type"].as_u64().unwrap() as usize;
            let sic = compute_active_sic_from_neighbors(
                &neighbors[center],
                &sic_layouts[center_type],
                &splines,
                &nrb,
                species.len(),
            )
            .unwrap();
            assert_values_close(&sic, &expected["sic"], 3.0e-10, "LSIC");

            let clm = &clm_rows[center];
            let mut ps = compute_active_ps_from_clm(
                clm,
                &angular_layouts[center_type],
                &nrb,
                species.len(),
                false,
                None,
                None,
            )
            .unwrap();
            assert_values_close(&ps, &expected["ps_without_sic"], 2.0e-10, "PS without LSIC");
            subtract_sic_from_active_ps(
                &mut ps,
                &angular_layouts[center_type],
                &sic_layouts[center_type],
                &sic,
                false,
                None,
                None,
            )
            .unwrap();
            assert_values_close(&ps, &expected["ps_with_sic"], 5.0e-10, "PS with LSIC");
        }
    }

    fn assert_values_close(actual: &[f64], expected: &Value, tolerance: f64, name: &str) {
        let expected: Vec<f64> = serde_json::from_value(expected.clone()).unwrap();
        assert_eq!(actual.len(), expected.len(), "{name} shape");
        for (index, (actual, expected)) in actual.iter().zip(expected).enumerate() {
            assert!(
                (actual - expected).abs() <= tolerance * expected.abs().max(1.0),
                "{name}[{index}] actual={actual:.16e} expected={expected:.16e}"
            );
        }
    }
}
