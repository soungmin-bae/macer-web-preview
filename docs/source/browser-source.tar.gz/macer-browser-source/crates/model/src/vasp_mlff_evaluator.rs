//! Native CPU energy/force/stress evaluation for the supported VASP ML_FF slice.
//!
//! This module consumes validated payload arrays and Rust-built radial
//! splines. File parsing remains in the CLI adapter. Candle's f64 reverse-mode
//! differentiation is used for Cartesian forces and homogeneous strain stress.

use candle_core::{DType, Device, Tensor, Var};
use macer_rust_core::types::{
    CalculationProperty, Calculator, CalculatorCapabilities, CalculatorError, CalculatorEvaluation,
    Evaluation, Potential,
};
use macer_rust_core::{neighbors::scaled_positions, Structure};

use crate::vasp_mlff::{RadialSplineSet, AUTOA_ANGSTROM_PER_BOHR};
use crate::vasp_mlff_descriptors::{AngularDescriptorIndex, AngularSICDescriptorIndex};
use crate::vasp_mlff_neighbors::{enumerate_periodic_neighbor_images, NeighborImage};

pub const EV_A3_TO_KBAR: f64 = 1602.176_620_8;

#[derive(Clone, Debug, PartialEq)]
pub struct VaspMLFFDescriptorChannel {
    pub cutoff_angstrom: f64,
    pub nrb: Vec<usize>,
    pub mrb: usize,
    pub splines: RadialSplineSet,
}

#[derive(Clone, Debug, PartialEq)]
pub struct VaspMLFFModelArrays {
    /// Per-species linear output weights, each with shape `[NB]`.
    pub wmat: Vec<Vec<f64>>,
    /// Per-species radial descriptor matrices `[descriptor][NB]`.
    pub c00: Option<Vec<Vec<Vec<f64>>>>,
    /// Per-species angular descriptor matrices `[descriptor][NB]`.
    pub ps: Option<Vec<Vec<Vec<f64>>>>,
}

#[derive(Clone, Debug, PartialEq)]
pub struct VaspMLFFModelConfig {
    pub type_atomic_numbers: Vec<u8>,
    pub w1: f64,
    pub w2: f64,
    pub lnorm1: bool,
    pub lnorm2: bool,
    pub lsic: bool,
    pub nhyp2: usize,
    pub iscale_toten: i32,
    pub eatom_ref_ev: Vec<f64>,
    pub totenav_ev_per_atom: f64,
    pub lafilt2: bool,
    pub iafilt2: Option<u8>,
    pub afilt2: Option<f64>,
    pub arrays: VaspMLFFModelArrays,
    pub radial: Option<VaspMLFFDescriptorChannel>,
    pub angular: Option<VaspMLFFDescriptorChannel>,
    pub angular_layout: Vec<Vec<AngularDescriptorIndex>>,
    pub sic_layout: Vec<Vec<AngularSICDescriptorIndex>>,
}

#[derive(Clone, Debug, PartialEq)]
pub struct VaspMLFFPrediction {
    pub energy_free_ev: f64,
    pub forces_ev_per_angstrom: Vec<[f64; 3]>,
    pub stress_kbar: Option<[[f64; 3]; 3]>,
}

#[derive(Clone, Debug)]
pub struct VaspMLFFModel {
    config: VaspMLFFModelConfig,
}

impl VaspMLFFModel {
    pub fn new(config: VaspMLFFModelConfig) -> Result<Self, String> {
        validate_config(&config)?;
        Ok(Self { config })
    }

    /// Evaluate one fully periodic structure on the CPU using f64 arithmetic.
    pub fn evaluate(
        &self,
        structure: &Structure,
        include_stress: bool,
    ) -> Result<VaspMLFFPrediction, String> {
        structure.validate()?;
        let config = &self.config;
        let type_indices = map_structure_types(structure, &config.type_atomic_numbers)?;
        let radial_neighbors = config
            .radial
            .as_ref()
            .map(|channel| {
                enumerate_periodic_neighbor_images(
                    structure,
                    &config.type_atomic_numbers,
                    channel.cutoff_angstrom,
                )
            })
            .transpose()?;
        let angular_neighbors = config
            .angular
            .as_ref()
            .map(|channel| {
                enumerate_periodic_neighbor_images(
                    structure,
                    &config.type_atomic_numbers,
                    channel.cutoff_angstrom,
                )
            })
            .transpose()?;
        let device = Device::Cpu;
        let atom_count = structure.atomic_numbers.len();

        let positions = Var::from_vec(
            structure
                .positions_a
                .iter()
                .flatten()
                .copied()
                .collect::<Vec<_>>(),
            (atom_count, 3),
            &device,
        )
        .map_err(candle_error)?;
        let cell = Tensor::from_vec(
            structure
                .cell_a
                .iter()
                .flatten()
                .copied()
                .collect::<Vec<_>>(),
            (3, 3),
            &device,
        )
        .map_err(candle_error)?;
        let energy = energy_tensor(
            config,
            &type_indices,
            radial_neighbors.as_deref(),
            angular_neighbors.as_deref(),
            positions.as_tensor(),
            &cell,
        )?;
        let energy_free_ev = energy.to_scalar::<f64>().map_err(candle_error)?;
        let gradients = energy.backward().map_err(candle_error)?;
        let position_gradient = gradients
            .get(positions.as_tensor())
            .ok_or_else(|| "energy graph did not retain position gradients".to_owned())?
            .to_vec2::<f64>()
            .map_err(candle_error)?;
        let forces_ev_per_angstrom = position_gradient
            .into_iter()
            .map(|row| [-row[0], -row[1], -row[2]])
            .collect();

        let stress_kbar = if include_stress {
            Some(stress_tensor(
                config,
                structure,
                &type_indices,
                radial_neighbors.as_deref(),
                angular_neighbors.as_deref(),
                &device,
            )?)
        } else {
            None
        };
        Ok(VaspMLFFPrediction {
            energy_free_ev,
            forces_ev_per_angstrom,
            stress_kbar,
        })
    }
}

impl Potential for VaspMLFFModel {
    fn evaluate(&mut self, structure: &Structure) -> Result<Evaluation, String> {
        let prediction = VaspMLFFModel::evaluate(self, structure, true)?;
        let stress_kbar = prediction
            .stress_kbar
            .ok_or_else(|| "VASP ML_FF stress evaluation was omitted".to_owned())?;
        let stress_ev_per_a3 =
            std::array::from_fn(|i| std::array::from_fn(|j| -stress_kbar[i][j] / EV_A3_TO_KBAR));
        Ok(Evaluation {
            energy_ev: prediction.energy_free_ev,
            forces_ev_per_a: prediction.forces_ev_per_angstrom,
            stress_ev_per_a3,
            energies_ev: None,
            stresses_ev_per_a3: None,
        })
    }
}

impl Calculator for VaspMLFFModel {
    fn capabilities(&self) -> CalculatorCapabilities {
        CalculatorCapabilities::energy_forces_stress(false)
    }

    fn evaluate_properties(
        &mut self,
        structure: &Structure,
        requested: &[CalculationProperty],
    ) -> Result<CalculatorEvaluation, CalculatorError> {
        if requested.is_empty() {
            return Ok(CalculatorEvaluation::default());
        }
        for property in requested {
            if !self.capabilities().supports(*property) {
                return Err(CalculatorError::UnsupportedCapability(*property));
            }
        }
        let prediction = VaspMLFFModel::evaluate(
            self,
            structure,
            requested.contains(&CalculationProperty::Stress),
        )
        .map_err(CalculatorError::Evaluation)?;
        let result = CalculatorEvaluation {
            energy_ev: requested
                .contains(&CalculationProperty::Energy)
                .then_some(prediction.energy_free_ev),
            forces_ev_per_a: requested
                .contains(&CalculationProperty::Forces)
                .then_some(prediction.forces_ev_per_angstrom),
            stress_ev_per_a3: prediction.stress_kbar.map(|stress| {
                std::array::from_fn(|i| std::array::from_fn(|j| -stress[i][j] / EV_A3_TO_KBAR))
            }),
        };
        result
            .validate(structure.atomic_numbers.len(), requested)
            .map_err(|error| CalculatorError::Evaluation(error.to_string()))?;
        Ok(result)
    }
}

fn validate_config(config: &VaspMLFFModelConfig) -> Result<(), String> {
    let ntypes = config.type_atomic_numbers.len();
    if ntypes == 0
        || config
            .type_atomic_numbers
            .iter()
            .any(|&z| z == 0 || z > 118)
        || config
            .type_atomic_numbers
            .iter()
            .enumerate()
            .any(|(i, z)| config.type_atomic_numbers[..i].contains(z))
    {
        return Err("VASP ML_FF species must be unique atomic numbers in 1..=118".into());
    }
    if !config.w1.is_finite()
        || !config.w2.is_finite()
        || config.w1 < 0.0
        || config.w2 < 0.0
        || !config.totenav_ev_per_atom.is_finite()
        || config.eatom_ref_ev.len() != ntypes
        || config.eatom_ref_ev.iter().any(|value| !value.is_finite())
    {
        return Err("invalid VASP ML_FF weights or reference energies".into());
    }
    if config.iscale_toten > 2 || config.iscale_toten < 0 {
        return Err(format!(
            "ISCALE_TOTEN={} is not implemented",
            config.iscale_toten
        ));
    }
    if config.w1 > 0.0 && (config.radial.is_none() || config.arrays.c00.is_none()) {
        return Err("W1 requires radial splines and C00 model matrices".into());
    }
    if config.w2 > 0.0 && (config.angular.is_none() || config.arrays.ps.is_none()) {
        return Err("W2 requires angular splines and PS model matrices".into());
    }
    if config.angular_layout.len() != ntypes || config.sic_layout.len() != ntypes {
        return Err("VASP ML_FF descriptor layouts do not match the species count".into());
    }
    if config.w2 > 0.0 && config.lafilt2 && !matches!(config.iafilt2, Some(1 | 2)) {
        return Err(format!("IAFILT2={:?} is not implemented", config.iafilt2));
    }
    if config.lafilt2 && config.iafilt2 == Some(2) && config.afilt2.is_none_or(|x| !x.is_finite()) {
        return Err("IAFILT2=2 requires a finite AFILT2".into());
    }
    if config.nhyp2 > 16 {
        return Err("NHYP2 exceeds the supported value of 16".into());
    }

    if config.arrays.wmat.len() != ntypes || config.arrays.wmat.iter().any(Vec::is_empty) {
        return Err("WMat array shape does not match the species count".into());
    }
    let nb_by_type = config.arrays.wmat.iter().map(Vec::len).collect::<Vec<_>>();
    for (type_index, weights) in config.arrays.wmat.iter().enumerate() {
        if weights.iter().any(|value| !value.is_finite()) {
            return Err(format!("invalid WMat row for species index {type_index}"));
        }
    }
    validate_model_matrix(
        config.arrays.c00.as_deref(),
        ntypes,
        &nb_by_type,
        config.w1 > 0.0,
        "C00",
    )?;
    validate_model_matrix(
        config.arrays.ps.as_deref(),
        ntypes,
        &nb_by_type,
        config.w2 > 0.0,
        "PS",
    )?;
    if config.w1 > 0.0 {
        let channel = config.radial.as_ref().unwrap();
        let matrix = config.arrays.c00.as_ref().unwrap();
        for (type_index, rows) in matrix.iter().enumerate() {
            if rows.len() != channel.mrb * ntypes {
                return Err(format!(
                    "C00 row count is invalid for species index {type_index}"
                ));
            }
        }
    }
    if config.w2 > 0.0 {
        let matrix = config.arrays.ps.as_ref().unwrap();
        for (type_index, rows) in matrix.iter().enumerate() {
            if rows.len() != config.angular_layout[type_index].len() {
                return Err(format!(
                    "PS row count is invalid for species index {type_index}"
                ));
            }
        }
    }
    Ok(())
}

fn validate_model_matrix(
    matrix: Option<&[Vec<Vec<f64>>]>,
    ntypes: usize,
    nb_by_type: &[usize],
    required: bool,
    name: &str,
) -> Result<(), String> {
    if !required {
        return Ok(());
    }
    let matrix = matrix.ok_or_else(|| format!("{name} model matrix is required"))?;
    if matrix.len() != ntypes
        || matrix.iter().zip(nb_by_type).any(|(rows, &nb)| {
            rows.iter()
                .any(|row| row.len() != nb || row.iter().any(|x| !x.is_finite()))
        })
    {
        return Err(format!("{name} model matrix shape or values are invalid"));
    }
    Ok(())
}

fn map_structure_types(structure: &Structure, species: &[u8]) -> Result<Vec<usize>, String> {
    structure
        .atomic_numbers
        .iter()
        .map(|atomic_number| {
            species
                .iter()
                .position(|candidate| candidate == atomic_number)
                .ok_or_else(|| {
                    format!(
                        "atomic number {atomic_number} is absent from VASP ML_FF species {:?}",
                        species
                    )
                })
        })
        .collect()
}

fn energy_tensor(
    config: &VaspMLFFModelConfig,
    type_indices: &[usize],
    radial_neighbors: Option<&[Vec<NeighborImage>]>,
    angular_neighbors: Option<&[Vec<NeighborImage>]>,
    positions: &Tensor,
    cell: &Tensor,
) -> Result<Tensor, String> {
    let device = positions.device();
    let zero = Tensor::new(0.0_f64, device).map_err(candle_error)?;
    let mut learned_energy = zero.clone();
    let ntypes = config.type_atomic_numbers.len();

    for type_index in 0..ntypes {
        let atom_indices = type_indices
            .iter()
            .enumerate()
            .filter_map(|(atom_index, &atom_type)| (atom_type == type_index).then_some(atom_index))
            .collect::<Vec<_>>();
        if atom_indices.is_empty() {
            continue;
        }
        for &atom_index in &atom_indices {
            let mut c00 = None;
            if config.w1 > 0.0 {
                let channel = config.radial.as_ref().unwrap();
                let neighbors = &radial_neighbors.unwrap()[atom_index];
                let geometric = prepare_neighbors(neighbors, positions, cell, 0)?;
                let clm = compute_clm_tensor(&geometric, channel, ntypes, device)?;
                let mut radial = vec![zero.clone(); channel.mrb * ntypes];
                for neighbor_type in 0..ntypes {
                    for radial_index in 0..channel.nrb[0] {
                        let index = clm_index(&channel.nrb, neighbor_type, 0, radial_index, 0);
                        radial[channel.mrb * neighbor_type + radial_index] = clm[index].clone();
                    }
                }
                c00 = Some(radial);
            }

            let mut ps = None;
            if config.w2 > 0.0 {
                let channel = config.angular.as_ref().unwrap();
                let neighbors = &angular_neighbors.unwrap()[atom_index];
                let geometric =
                    prepare_neighbors(neighbors, positions, cell, channel.nrb.len() - 1)?;
                let clm = compute_clm_tensor(&geometric, channel, ntypes, device)?;
                let layout = &config.angular_layout[type_index];
                let mut descriptors = vec![zero.clone(); layout.len()];
                for item in layout {
                    let mut pair_sum = zero.clone();
                    for m in 0..(2 * item.l + 1) {
                        let left = clm_index(
                            &channel.nrb,
                            item.neighbor_type_a,
                            item.l,
                            item.radial_i_1based - 1,
                            m,
                        );
                        let right = clm_index(
                            &channel.nrb,
                            item.neighbor_type_b,
                            item.l,
                            item.radial_j_1based - 1,
                            m,
                        );
                        pair_sum = pair_sum
                            .add(
                                &clm[left]
                                    .mul(&clm[right])
                                    .map_err(candle_error)
                                    .map_err(to_string)?,
                            )
                            .map_err(candle_error)
                            .map_err(to_string)?;
                    }
                    let coefficient = item.pair_weight
                        * soap_prefactor(item.l, config.lafilt2, config.iafilt2, config.afilt2)?;
                    descriptors[item.active_index] = pair_sum
                        .affine(coefficient, 0.0)
                        .map_err(candle_error)
                        .map_err(to_string)?;
                }
                if config.lsic {
                    let sic_layout = &config.sic_layout[type_index];
                    let sic = compute_sic_tensor(&geometric, sic_layout, channel, ntypes, device)?;
                    subtract_sic_tensor(
                        &mut descriptors,
                        layout,
                        sic_layout,
                        &sic,
                        config.lafilt2,
                        config.iafilt2,
                        config.afilt2,
                    )?;
                }
                ps = Some(descriptors);
            }

            let (c00, ps) = normalize_tensor_descriptors(
                c00,
                ps,
                config.w1,
                config.w2,
                config.lnorm1,
                config.lnorm2,
                device,
            )?;
            let mut soap = vec![zero.clone(); config.arrays.wmat[type_index].len()];
            if let (Some(c00), Some(matrix)) = (c00.as_ref(), config.arrays.c00.as_ref()) {
                let model_rows = &matrix[type_index];
                for output in 0..soap.len() {
                    for descriptor in 0..model_rows.len() {
                        soap[output] = soap[output]
                            .add(
                                &c00[descriptor]
                                    .affine(model_rows[descriptor][output], 0.0)
                                    .map_err(candle_error)
                                    .map_err(to_string)?,
                            )
                            .map_err(candle_error)
                            .map_err(to_string)?;
                    }
                }
            }
            if let (Some(ps), Some(matrix)) = (ps.as_ref(), config.arrays.ps.as_ref()) {
                let model_rows = &matrix[type_index];
                for output in 0..soap.len() {
                    for descriptor in 0..model_rows.len() {
                        soap[output] = soap[output]
                            .add(
                                &ps[descriptor]
                                    .affine(model_rows[descriptor][output], 0.0)
                                    .map_err(candle_error)
                                    .map_err(to_string)?,
                            )
                            .map_err(candle_error)
                            .map_err(to_string)?;
                    }
                }
            }
            for (output, descriptor_value) in soap.into_iter().enumerate() {
                let raised = descriptor_value
                    .powf(config.nhyp2 as f64)
                    .map_err(candle_error)
                    .map_err(to_string)?;
                learned_energy = learned_energy
                    .add(
                        &raised
                            .affine(config.arrays.wmat[type_index][output], 0.0)
                            .map_err(candle_error)
                            .map_err(to_string)?,
                    )
                    .map_err(candle_error)
                    .map_err(to_string)?;
            }
        }
    }

    if config.iscale_toten != 0 {
        let reference_shift = if config.iscale_toten == 2 {
            config.totenav_ev_per_atom
        } else {
            0.0
        };
        for type_index in 0..ntypes {
            let atom_count = type_indices.iter().filter(|&&x| x == type_index).count();
            let shift = atom_count as f64 * (config.eatom_ref_ev[type_index] + reference_shift);
            learned_energy = learned_energy
                .affine(1.0, shift)
                .map_err(candle_error)
                .map_err(to_string)?;
        }
    }
    Ok(learned_energy)
}

fn stress_tensor(
    config: &VaspMLFFModelConfig,
    structure: &Structure,
    type_indices: &[usize],
    radial_neighbors: Option<&[Vec<NeighborImage>]>,
    angular_neighbors: Option<&[Vec<NeighborImage>]>,
    device: &Device,
) -> Result<[[f64; 3]; 3], String> {
    let atom_count = structure.atomic_numbers.len();
    let scaled = structure
        .positions_a
        .iter()
        .map(|&position| scaled_positions(structure.cell_a, position))
        .collect::<Result<Vec<_>, _>>()?;
    let scaled_positions = Tensor::from_vec(
        scaled.into_iter().flatten().collect::<Vec<_>>(),
        (atom_count, 3),
        device,
    )
    .map_err(candle_error)
    .map_err(to_string)?;
    let cell0 = Tensor::from_vec(
        structure
            .cell_a
            .iter()
            .flatten()
            .copied()
            .collect::<Vec<_>>(),
        (3, 3),
        device,
    )
    .map_err(candle_error)
    .map_err(to_string)?;
    let strain = Var::zeros((3, 3), DType::F64, device)
        .map_err(candle_error)
        .map_err(to_string)?;
    let identity = Tensor::eye(3, DType::F64, device)
        .map_err(candle_error)
        .map_err(to_string)?;
    let deformation = identity
        .add(strain.as_tensor())
        .map_err(candle_error)
        .map_err(to_string)?;
    let cell = cell0
        .matmul(&deformation)
        .map_err(candle_error)
        .map_err(to_string)?;
    let positions = scaled_positions
        .matmul(&cell)
        .map_err(candle_error)
        .map_err(to_string)?;
    if positions.dim(0).map_err(candle_error).map_err(to_string)? != atom_count {
        return Err("internal strained position shape mismatch".into());
    }
    let energy = energy_tensor(
        config,
        type_indices,
        radial_neighbors,
        angular_neighbors,
        &positions,
        &cell,
    )?;
    let gradients = energy.backward().map_err(candle_error).map_err(to_string)?;
    let strain_gradient = gradients
        .get(strain.as_tensor())
        .ok_or_else(|| "energy graph did not retain strain gradients".to_owned())?
        .to_vec2::<f64>()
        .map_err(candle_error)
        .map_err(to_string)?;
    let volume = determinant(structure.cell_a).abs();
    if !volume.is_finite() || volume <= 0.0 {
        return Err("cell volume must be finite and positive".into());
    }
    Ok(std::array::from_fn(|i| {
        std::array::from_fn(|j| -strain_gradient[i][j] / volume * EV_A3_TO_KBAR)
    }))
}

#[derive(Clone)]
struct GeometricNeighbor {
    neighbor_type: usize,
    distance_bohr: Tensor,
    harmonics: Vec<Tensor>,
}

fn prepare_neighbors(
    neighbors: &[NeighborImage],
    positions: &Tensor,
    cell: &Tensor,
    lmax: usize,
) -> Result<Vec<GeometricNeighbor>, String> {
    neighbors
        .iter()
        .map(|neighbor| {
            let vector = periodic_vector(neighbor, positions, cell)?;
            let distance2 = vector.iter().try_fold(
                Tensor::new(0.0_f64, positions.device()).map_err(candle_error)?,
                |sum, component| {
                    let square = component.sqr().map_err(candle_error)?;
                    sum.add(&square).map_err(candle_error)
                },
            )?;
            let distance = distance2.sqrt().map_err(candle_error)?;
            let unit = [
                vector[0]
                    .div(&distance)
                    .map_err(candle_error)
                    .map_err(to_string)?,
                vector[1]
                    .div(&distance)
                    .map_err(candle_error)
                    .map_err(to_string)?,
                vector[2]
                    .div(&distance)
                    .map_err(candle_error)
                    .map_err(to_string)?,
            ];
            let harmonics = real_spherical_harmonics_tensor(&unit, lmax)?;
            let distance_bohr = distance
                .affine(1.0 / AUTOA_ANGSTROM_PER_BOHR, 0.0)
                .map_err(candle_error)
                .map_err(to_string)?;
            Ok(GeometricNeighbor {
                neighbor_type: neighbor.neighbor_type,
                distance_bohr,
                harmonics,
            })
        })
        .collect()
}

fn periodic_vector(
    neighbor: &NeighborImage,
    positions: &Tensor,
    cell: &Tensor,
) -> Result<[Tensor; 3], String> {
    let from = positions
        .get(neighbor.center)
        .map_err(candle_error)
        .map_err(to_string)?;
    let to = positions
        .get(neighbor.neighbor)
        .map_err(candle_error)
        .map_err(to_string)?;
    let mut vector = Vec::with_capacity(3);
    for cart_axis in 0..3 {
        let mut value = to
            .get(cart_axis)
            .map_err(candle_error)
            .map_err(to_string)?
            .sub(
                &from
                    .get(cart_axis)
                    .map_err(candle_error)
                    .map_err(to_string)?,
            )
            .map_err(candle_error)
            .map_err(to_string)?;
        for cell_axis in 0..3 {
            value = value
                .add(
                    &cell
                        .get(cell_axis)
                        .map_err(candle_error)
                        .map_err(to_string)?
                        .get(cart_axis)
                        .map_err(candle_error)
                        .map_err(to_string)?
                        .affine(neighbor.shift[cell_axis] as f64, 0.0)
                        .map_err(candle_error)
                        .map_err(to_string)?,
                )
                .map_err(candle_error)
                .map_err(to_string)?;
        }
        vector.push(value);
    }
    Ok(vector.try_into().expect("three vector coordinates"))
}

fn compute_clm_tensor(
    neighbors: &[GeometricNeighbor],
    channel: &VaspMLFFDescriptorChannel,
    ntypes: usize,
    device: &Device,
) -> Result<Vec<Tensor>, String> {
    let per_type = channel
        .nrb
        .iter()
        .enumerate()
        .map(|(l, count)| (2 * l + 1) * count)
        .sum::<usize>();
    let mut clm = vec![
        Tensor::new(0.0_f64, device)
            .map_err(candle_error)
            .map_err(to_string)?;
        per_type * ntypes
    ];
    for neighbor in neighbors {
        for (l, &radial_count) in channel.nrb.iter().enumerate() {
            for radial in 0..radial_count {
                let value =
                    spline_value_tensor(&channel.splines, l, radial, &neighbor.distance_bohr)?;
                if value
                    .to_scalar::<f64>()
                    .map_err(candle_error)
                    .map_err(to_string)?
                    == 0.0
                {
                    continue;
                }
                for m in 0..(2 * l + 1) {
                    let index = clm_index(&channel.nrb, neighbor.neighbor_type, l, radial, m);
                    let contribution = value
                        .mul(&neighbor.harmonics[l * l + m])
                        .map_err(candle_error)
                        .map_err(to_string)?;
                    clm[index] = clm[index]
                        .add(&contribution)
                        .map_err(candle_error)
                        .map_err(to_string)?;
                }
            }
        }
    }
    Ok(clm)
}

fn compute_sic_tensor(
    neighbors: &[GeometricNeighbor],
    layout: &[AngularSICDescriptorIndex],
    channel: &VaspMLFFDescriptorChannel,
    _ntypes: usize,
    device: &Device,
) -> Result<Vec<Tensor>, String> {
    let mut sic = vec![
        Tensor::new(0.0_f64, device)
            .map_err(candle_error)
            .map_err(to_string)?;
        layout.len()
    ];
    for neighbor in neighbors {
        for item in layout
            .iter()
            .filter(|item| item.neighbor_type == neighbor.neighbor_type)
        {
            let value_i = spline_value_tensor(
                &channel.splines,
                item.l,
                item.radial_i_1based - 1,
                &neighbor.distance_bohr,
            )?;
            let value_j = spline_value_tensor(
                &channel.splines,
                item.l,
                item.radial_j_1based - 1,
                &neighbor.distance_bohr,
            )?;
            let mut angular_norm = Tensor::new(0.0_f64, device)
                .map_err(candle_error)
                .map_err(to_string)?;
            for m in 0..(2 * item.l + 1) {
                let harmonic = &neighbor.harmonics[item.l * item.l + m];
                let square = harmonic.sqr().map_err(candle_error).map_err(to_string)?;
                angular_norm = angular_norm
                    .add(&square)
                    .map_err(candle_error)
                    .map_err(to_string)?;
            }
            let value = value_i
                .mul(&value_j)
                .and_then(|value| value.mul(&angular_norm))
                .map_err(candle_error)
                .map_err(to_string)?;
            sic[item.active_index] = sic[item.active_index]
                .add(&value)
                .map_err(candle_error)
                .map_err(to_string)?;
        }
    }
    Ok(sic)
}

fn subtract_sic_tensor(
    ps: &mut [Tensor],
    angular_layout: &[AngularDescriptorIndex],
    sic_layout: &[AngularSICDescriptorIndex],
    sic: &[Tensor],
    lafilt: bool,
    iafilt: Option<u8>,
    afilt: Option<f64>,
) -> Result<(), String> {
    for angular in angular_layout {
        if angular.neighbor_type_a != angular.neighbor_type_b {
            continue;
        }
        let sic_index = sic_layout.iter().find(|sic_item| {
            sic_item.neighbor_type == angular.neighbor_type_a
                && sic_item.l == angular.l
                && sic_item.radial_i_1based == angular.radial_i_1based
                && sic_item.radial_j_1based == angular.radial_j_1based
        });
        if let Some(sic_item) = sic_index {
            let coefficient =
                angular.pair_weight * soap_prefactor(angular.l, lafilt, iafilt, afilt)?;
            let correction = sic[sic_item.active_index]
                .affine(coefficient, 0.0)
                .map_err(candle_error)
                .map_err(to_string)?;
            ps[angular.active_index] = ps[angular.active_index]
                .sub(&correction)
                .map_err(candle_error)
                .map_err(to_string)?;
        }
    }
    Ok(())
}

fn normalize_tensor_descriptors(
    c00: Option<Vec<Tensor>>,
    ps: Option<Vec<Tensor>>,
    w1: f64,
    w2: f64,
    lnorm1: bool,
    lnorm2: bool,
    device: &Device,
) -> Result<(Option<Vec<Tensor>>, Option<Vec<Tensor>>), String> {
    let zero = Tensor::new(0.0_f64, device)
        .map_err(candle_error)
        .map_err(to_string)?;
    let mut norm2 = zero;
    if let Some(values) = &c00 {
        if w1 > 0.0 {
            for value in values {
                norm2 = norm2
                    .add(
                        &value
                            .sqr()
                            .map_err(candle_error)
                            .map_err(to_string)?
                            .affine(w1, 0.0)
                            .map_err(candle_error)
                            .map_err(to_string)?,
                    )
                    .map_err(candle_error)
                    .map_err(to_string)?;
            }
        }
    }
    if let Some(values) = &ps {
        if w2 > 0.0 {
            for value in values {
                norm2 = norm2
                    .add(
                        &value
                            .sqr()
                            .map_err(candle_error)
                            .map_err(to_string)?
                            .affine(w2, 0.0)
                            .map_err(candle_error)
                            .map_err(to_string)?,
                    )
                    .map_err(candle_error)
                    .map_err(to_string)?;
            }
        }
    }
    let norm = norm2.sqrt().map_err(candle_error).map_err(to_string)?;
    let norm_value = norm
        .to_scalar::<f64>()
        .map_err(candle_error)
        .map_err(to_string)?;
    if norm_value >= 1.0e-10 {
        let mut c00 = c00;
        let mut ps = ps;
        if lnorm1 && w1 > 0.0 {
            if let Some(values) = &mut c00 {
                let scale = norm
                    .recip()
                    .and_then(|value| value.affine(w1.sqrt(), 0.0))
                    .map_err(candle_error)
                    .map_err(to_string)?;
                for value in values {
                    *value = value.mul(&scale).map_err(candle_error).map_err(to_string)?;
                }
            }
        }
        if lnorm2 && w2 > 0.0 {
            if let Some(values) = &mut ps {
                let scale = norm
                    .recip()
                    .and_then(|value| value.affine(w2.sqrt(), 0.0))
                    .map_err(candle_error)
                    .map_err(to_string)?;
                for value in values {
                    *value = value.mul(&scale).map_err(candle_error).map_err(to_string)?;
                }
            }
        }
        Ok((c00, ps))
    } else {
        Ok((c00, ps))
    }
}

fn spline_value_tensor(
    splines: &RadialSplineSet,
    l: usize,
    radial: usize,
    distance_bohr: &Tensor,
) -> Result<Tensor, String> {
    let value = distance_bohr
        .to_scalar::<f64>()
        .map_err(candle_error)
        .map_err(to_string)?;
    let interval = ((value / splines.drspl).trunc() as isize).max(1) as usize - 1;
    let index = interval.min(splines.fnl.len() - 2);
    let coefficients = (0..splines.fnl.len())
        .map(|grid| std::array::from_fn(|column| splines.fnl[grid][column][l][radial]))
        .collect::<Vec<[f64; 5]>>();
    let coefficient = coefficients[index];
    let dx = distance_bohr
        .affine(1.0, -coefficient[0])
        .map_err(candle_error)
        .map_err(to_string)?;
    let mut output = dx
        .affine(coefficient[4], coefficient[3])
        .map_err(candle_error)
        .map_err(to_string)?;
    output = output
        .mul(&dx)
        .and_then(|value| value.affine(1.0, coefficient[2]))
        .and_then(|value| value.mul(&dx))
        .and_then(|value| value.affine(1.0, coefficient[1]))
        .map_err(candle_error)
        .map_err(to_string)?;
    Ok(output)
}

fn clm_index(nrb: &[usize], neighbor_type: usize, l: usize, radial: usize, m: usize) -> usize {
    let type_stride = nrb
        .iter()
        .enumerate()
        .map(|(ll, &count)| (2 * ll + 1) * count)
        .sum::<usize>();
    let angular_offset = nrb[..l]
        .iter()
        .enumerate()
        .map(|(ll, &count)| (2 * ll + 1) * count)
        .sum::<usize>();
    neighbor_type * type_stride + angular_offset + m * nrb[l] + radial
}

fn soap_prefactor(
    l: usize,
    lafilt: bool,
    iafilt: Option<u8>,
    afilt: Option<f64>,
) -> Result<f64, String> {
    let base = (8.0 * std::f64::consts::PI.powi(2) / (2 * l + 1) as f64).sqrt();
    if !lafilt {
        return Ok(base);
    }
    match iafilt {
        Some(1) => Ok(base / ((2 * l + 1) as f64).sqrt()),
        Some(2) => {
            let alpha = afilt.ok_or_else(|| "AFILT2 is required for IAFILT2=2".to_owned())?;
            Ok(base / (1.0 + alpha * ((l * (l + 1)) as f64).powi(2)).powi(2))
        }
        other => Err(format!("unsupported angular filter IAFILT2={other:?}")),
    }
}

fn real_spherical_harmonics_tensor(unit: &[Tensor; 3], lmax: usize) -> Result<Vec<Tensor>, String> {
    if lmax > 32 {
        return Err("lmax exceeds the supported safety limit of 32".into());
    }
    let device = unit[0].device();
    let zero = Tensor::new(0.0_f64, device)
        .map_err(candle_error)
        .map_err(to_string)?;
    let one = Tensor::new(1.0_f64, device)
        .map_err(candle_error)
        .map_err(to_string)?;
    let mut real_power = Vec::with_capacity(lmax + 1);
    let mut imag_power = Vec::with_capacity(lmax + 1);
    real_power.push(one);
    imag_power.push(zero.clone());
    for m in 1..=lmax {
        let real = real_power[m - 1]
            .mul(&unit[0])
            .and_then(|value| value.sub(&imag_power[m - 1].mul(&unit[1])?))
            .map_err(candle_error)
            .map_err(to_string)?;
        let imag = real_power[m - 1]
            .mul(&unit[1])
            .and_then(|value| value.add(&imag_power[m - 1].mul(&unit[0])?))
            .map_err(candle_error)
            .map_err(to_string)?;
        real_power.push(real);
        imag_power.push(imag);
    }

    let mut values = vec![zero; (lmax + 1) * (lmax + 1)];
    let mut qmm = 1.0_f64;
    for m in 0..=lmax {
        if m > 0 {
            qmm *= -((2 * m - 1) as f64);
        }
        let mut q_lm2: Option<Tensor> = None;
        let mut q_lm1: Option<Tensor> = None;
        for l in m..=lmax {
            let q_lm = if l == m {
                Tensor::new(qmm, device)
                    .map_err(candle_error)
                    .map_err(to_string)?
            } else if l == m + 1 {
                unit[2]
                    .affine((2 * m + 1) as f64, 0.0)
                    .and_then(|value| value.affine(qmm, 0.0))
                    .map_err(candle_error)
                    .map_err(to_string)?
            } else {
                let first = unit[2]
                    .mul(q_lm1.as_ref().unwrap())
                    .and_then(|value| value.affine((2 * l - 1) as f64, 0.0))
                    .map_err(candle_error)
                    .map_err(to_string)?;
                let second = q_lm2
                    .as_ref()
                    .unwrap()
                    .affine((l + m - 1) as f64, 0.0)
                    .map_err(candle_error)
                    .map_err(to_string)?;
                first
                    .sub(&second)
                    .and_then(|value| value.affine(1.0 / (l - m) as f64, 0.0))
                    .map_err(candle_error)
                    .map_err(to_string)?
            };
            let norm = (((2 * l + 1) as f64 / (4.0 * std::f64::consts::PI))
                * factorial_ratio(l - m, l + m))
            .sqrt();
            if m == 0 {
                values[l * l + l] = q_lm
                    .affine(norm, 0.0)
                    .map_err(candle_error)
                    .map_err(to_string)?;
            } else {
                let parity = if m % 2 == 0 { 1.0 } else { -1.0 };
                let coefficient = std::f64::consts::SQRT_2 * parity * norm;
                values[l * l + (l - m)] = q_lm
                    .mul(&imag_power[m])
                    .and_then(|value| value.affine(coefficient, 0.0))
                    .map_err(candle_error)
                    .map_err(to_string)?;
                values[l * l + (l + m)] = q_lm
                    .mul(&real_power[m])
                    .and_then(|value| value.affine(coefficient, 0.0))
                    .map_err(candle_error)
                    .map_err(to_string)?;
            }
            q_lm2 = q_lm1;
            q_lm1 = Some(q_lm);
        }
    }
    Ok(values)
}

fn factorial_ratio(numerator: usize, denominator: usize) -> f64 {
    (numerator + 1..=denominator).fold(1.0, |value, factor| value / factor as f64)
}

fn determinant(matrix: [[f64; 3]; 3]) -> f64 {
    matrix[0][0] * (matrix[1][1] * matrix[2][2] - matrix[1][2] * matrix[2][1])
        - matrix[0][1] * (matrix[1][0] * matrix[2][2] - matrix[1][2] * matrix[2][0])
        + matrix[0][2] * (matrix[1][0] * matrix[2][1] - matrix[1][1] * matrix[2][0])
}

fn candle_error(error: candle_core::Error) -> String {
    error.to_string()
}

fn to_string(error: String) -> String {
    error
}
