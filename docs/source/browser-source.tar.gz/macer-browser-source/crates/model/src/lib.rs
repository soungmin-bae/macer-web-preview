//! Versioned MatterSim weight contract. Runtime code never loads PyTorch files.

use safetensors::SafeTensors;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

pub mod evaluation;
pub mod geometry;
#[cfg(feature = "nep89")]
pub use macer_rust_nep::{
    nep89, nep89_descriptors, nep89_evaluator, nep89_neighbors, nep89_network, nep89_zbl,
};
pub mod vasp_mlff;
pub mod vasp_mlff_descriptors;
pub mod vasp_mlff_evaluator;
pub mod vasp_mlff_neighbors;

pub const SCHEMA_VERSION: &str = "macer-rust-model-v2";
pub const REFERENCE_1M_SHA256: &str =
    "28b0b0b0f13efefee06b47ea4c9105a26bd3e2c8396da193430da96b3b49a8be";
pub const REFERENCE_5M_SHA256: &str =
    "e3df9fa708725e3d453140646c7d1838324b347a3d1214cf1440522146f872b5";
pub const REFERENCE_1M_WEIGHTS_SHA256: &str =
    "066a89694bc3badd77ae91a4829c2e51fba1d47e8cd1d1219a75147961e8260c";
pub const REFERENCE_5M_WEIGHTS_SHA256: &str =
    "af187816aaee69f3f04d214e091b0f681d261a7aac4e174e86e1d25375928f26";
pub const CAPABILITIES_SCHEMA_VERSION: &str = "macer-rust-evaluator-capabilities-v2";

#[derive(Clone, Debug, Deserialize, Serialize, PartialEq)]
pub struct ModelArgs {
    pub num_blocks: usize,
    pub units: usize,
    pub max_l: usize,
    pub max_n: usize,
    pub cutoff: f64,
    pub max_z: usize,
    pub threebody_cutoff: f64,
}

#[derive(Clone, Debug, Deserialize, Serialize, PartialEq)]
pub struct TensorSpec {
    pub name: String,
    pub dtype: String,
    pub shape: Vec<usize>,
}

#[derive(Clone, Debug, Deserialize, Serialize, PartialEq)]
pub struct ModelManifest {
    pub schema_version: String,
    pub model_id: String,
    pub model_name: String,
    pub source_checkpoint_sha256: String,
    pub weights_sha256: String,
    pub model_args: ModelArgs,
    pub tensors: Vec<TensorSpec>,
}

fn valid_sha256(value: &str) -> bool {
    value.len() == 64 && value.bytes().all(|b| b.is_ascii_hexdigit())
}

impl ModelManifest {
    /// Parse a manifest supplied by the host application. The model crate does
    /// not choose where bytes come from; native CLIs may read files while a
    /// browser can pass the response body directly.
    pub fn from_json_bytes(bytes: &[u8]) -> Result<Self, String> {
        let manifest: Self =
            serde_json::from_slice(bytes).map_err(|e| format!("manifest parse failed: {e}"))?;
        manifest.validate()?;
        Ok(manifest)
    }

    pub fn validate(&self) -> Result<(), String> {
        if self.schema_version != SCHEMA_VERSION {
            return Err(format!(
                "unsupported manifest schema: {}",
                self.schema_version
            ));
        }
        if self.model_name != "m3gnet" {
            return Err(format!("unsupported model: {}", self.model_name));
        }
        if !valid_sha256(&self.source_checkpoint_sha256) || !valid_sha256(&self.weights_sha256) {
            return Err("invalid checkpoint or weights SHA-256".into());
        }
        let (checkpoint_sha, weights_sha, model_id, num_blocks, units, tensor_count) =
            match self.model_id.as_str() {
                "mattersim-v1.0.0-1M" => (
                    REFERENCE_1M_SHA256,
                    REFERENCE_1M_WEIGHTS_SHA256,
                    "MatterSim 1M",
                    3,
                    128,
                    89,
                ),
                "mattersim-v1.0.0-5M" => (
                    REFERENCE_5M_SHA256,
                    REFERENCE_5M_WEIGHTS_SHA256,
                    "MatterSim 5M",
                    4,
                    256,
                    111,
                ),
                _ => return Err(format!("unsupported MatterSim model ID: {}", self.model_id)),
            };
        if self.source_checkpoint_sha256 != checkpoint_sha {
            return Err(format!("checkpoint hash does not match {model_id}"));
        }
        if self.weights_sha256 != weights_sha {
            return Err(format!("neutral weights hash does not match {model_id}"));
        }
        let args = &self.model_args;
        if args.num_blocks != num_blocks
            || args.units != units
            || args.max_l != 4
            || args.max_n != 4
            || args.cutoff != 5.0
            || args.max_z != 94
            || args.threebody_cutoff != 4.0
        {
            return Err(format!("model architecture differs from {model_id}"));
        }
        if self.tensors.len() != tensor_count {
            return Err(format!(
                "expected {tensor_count} tensors for {model_id}, found {}",
                self.tensors.len()
            ));
        }
        let mut prior = "";
        for tensor in &self.tensors {
            if tensor.name.as_str() <= prior {
                return Err("tensor names must be unique and sorted".into());
            }
            let elements = tensor
                .shape
                .iter()
                .try_fold(1usize, |count, &size| count.checked_mul(size));
            if tensor.dtype != "F32" || elements.is_none_or(|count| count == 0) {
                return Err(format!(
                    "unsupported tensor dtype or shape: {}",
                    tensor.name
                ));
            }
            prior = &tensor.name;
        }
        Ok(())
    }
}

/// Computational backends compiled into this model crate. Hardware discovery
/// remains a host responsibility because successful compilation does not mean
/// that a CUDA device is present at runtime.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize)]
#[serde(rename_all = "lowercase")]
pub enum ComputeBackend {
    Cpu,
    Cuda,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
pub struct UnitContract {
    pub energy: &'static str,
    pub force: &'static str,
    pub stress: &'static str,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
pub struct EvaluatorCapabilities {
    pub schema_version: &'static str,
    pub model_name: &'static str,
    pub supported_model_ids: Vec<&'static str>,
    pub manifest_schema_version: &'static str,
    pub weights_format: &'static str,
    pub outputs: Vec<&'static str>,
    pub units: UnitContract,
    pub compiled_backends: Vec<ComputeBackend>,
}

/// Describe the versioned model/runtime contract without probing host hardware.
pub fn evaluator_capabilities() -> EvaluatorCapabilities {
    #[cfg(feature = "cuda")]
    let compiled_backends = vec![ComputeBackend::Cpu, ComputeBackend::Cuda];
    #[cfg(not(feature = "cuda"))]
    let compiled_backends = vec![ComputeBackend::Cpu];
    EvaluatorCapabilities {
        schema_version: CAPABILITIES_SCHEMA_VERSION,
        model_name: "mattersim-m3gnet",
        supported_model_ids: vec!["mattersim-v1.0.0-1M", "mattersim-v1.0.0-5M"],
        manifest_schema_version: SCHEMA_VERSION,
        weights_format: "safetensors-f32",
        outputs: vec!["energy", "forces", "stress"],
        units: UnitContract {
            energy: "eV",
            force: "eV/angstrom",
            stress: "eV/angstrom^3",
        },
        compiled_backends,
    }
}

/// Validate model weights directly from an in-memory package. This is shared
/// by native and browser hosts and intentionally performs no file I/O.
pub fn validate_weights_bytes(manifest: &ModelManifest, bytes: &[u8]) -> Result<(), String> {
    manifest.validate()?;
    let actual_sha = hex::encode(Sha256::digest(bytes));
    if actual_sha != manifest.weights_sha256 {
        return Err("weights SHA-256 does not match manifest".into());
    }
    let tensors =
        SafeTensors::deserialize(bytes).map_err(|e| format!("invalid safetensors file: {e}"))?;
    if tensors.len() != manifest.tensors.len() {
        return Err("weight tensor count differs from manifest".into());
    }
    for spec in &manifest.tensors {
        let tensor = tensors
            .tensor(&spec.name)
            .map_err(|_| format!("missing weight tensor: {}", spec.name))?;
        if format!("{:?}", tensor.dtype()) != spec.dtype || tensor.shape() != spec.shape {
            return Err(format!(
                "weight tensor type or shape differs: {}",
                spec.name
            ));
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn valid_manifest() -> ModelManifest {
        ModelManifest {
            schema_version: SCHEMA_VERSION.into(),
            model_id: "mattersim-v1.0.0-5M".into(),
            model_name: "m3gnet".into(),
            source_checkpoint_sha256: REFERENCE_5M_SHA256.into(),
            weights_sha256: REFERENCE_5M_WEIGHTS_SHA256.into(),
            model_args: ModelArgs {
                num_blocks: 4,
                units: 256,
                max_l: 4,
                max_n: 4,
                cutoff: 5.0,
                max_z: 94,
                threebody_cutoff: 4.0,
            },
            tensors: (0..111)
                .map(|index| TensorSpec {
                    name: format!("tensor-{index:03}"),
                    dtype: "F32".into(),
                    shape: vec![1],
                })
                .collect(),
        }
    }

    #[test]
    fn invalid_manifest_is_rejected_before_weight_loading() {
        let mut manifest = valid_manifest();
        manifest.tensors.clear();
        assert!(manifest.validate().is_err());
    }

    #[test]
    fn manifest_is_parsed_and_validated_from_memory() {
        let manifest = valid_manifest();
        let bytes = serde_json::to_vec(&manifest).unwrap();
        assert_eq!(ModelManifest::from_json_bytes(&bytes).unwrap(), manifest);
        assert!(ModelManifest::from_json_bytes(b"not-json")
            .unwrap_err()
            .starts_with("manifest parse failed:"));
    }

    #[test]
    fn both_pinned_mattersim_variants_have_distinct_architecture_contracts() {
        let mut one_m = valid_manifest();
        one_m.model_id = "mattersim-v1.0.0-1M".into();
        one_m.source_checkpoint_sha256 = REFERENCE_1M_SHA256.into();
        one_m.weights_sha256 = REFERENCE_1M_WEIGHTS_SHA256.into();
        one_m.model_args.num_blocks = 3;
        one_m.model_args.units = 128;
        one_m.tensors = (0..89)
            .map(|index| TensorSpec {
                name: format!("tensor-{index:03}"),
                dtype: "F32".into(),
                shape: vec![1],
            })
            .collect();
        assert!(one_m.validate().is_ok());
        assert!(valid_manifest().validate().is_ok());

        one_m.model_args.units = 256;
        assert!(one_m
            .validate()
            .unwrap_err()
            .contains("architecture differs from MatterSim 1M"));
    }

    #[test]
    fn weight_hash_is_checked_before_safetensors_parsing() {
        let manifest = valid_manifest();
        let error = validate_weights_bytes(&manifest, b"untrusted model bytes").unwrap_err();
        assert_eq!(error, "weights SHA-256 does not match manifest");
    }

    #[test]
    fn evaluator_capabilities_are_versioned_and_explicit() {
        let capabilities = evaluator_capabilities();
        assert_eq!(capabilities.schema_version, CAPABILITIES_SCHEMA_VERSION);
        assert_eq!(capabilities.manifest_schema_version, SCHEMA_VERSION);
        assert_eq!(capabilities.weights_format, "safetensors-f32");
        assert_eq!(capabilities.outputs, ["energy", "forces", "stress"]);
        assert_eq!(
            capabilities.supported_model_ids,
            ["mattersim-v1.0.0-1M", "mattersim-v1.0.0-5M"]
        );
        assert!(capabilities
            .compiled_backends
            .contains(&ComputeBackend::Cpu));
        let json = serde_json::to_value(capabilities).unwrap();
        assert_eq!(json["schema_version"], CAPABILITIES_SCHEMA_VERSION);
        assert_eq!(json["supported_model_ids"][0], "mattersim-v1.0.0-1M");
        assert_eq!(json["units"]["force"], "eV/angstrom");
        assert_eq!(json["compiled_backends"][0], "cpu");
    }
}
