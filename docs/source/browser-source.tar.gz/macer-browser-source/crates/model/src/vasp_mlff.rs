//! Pure Rust numerical building blocks for VASP `ML_FF` evaluation.
//!
//! This module deliberately accepts scalar configuration instead of reading
//! files. The CLI owns ML_FF parsing; browser and native callers can share the
//! same numerical implementation after supplying validated metadata.

use std::f64::consts::PI;

pub const AUTOA_ANGSTROM_PER_BOHR: f64 = 0.529_177_249;
const MAX_BASIS_GRID_POINTS: usize = 2_000_000;
const MAX_BASIS_VALUES: usize = 20_000_000;
const MAX_RADIAL_FUNCTIONS: usize = 4_096;

#[derive(Clone, Debug, PartialEq)]
pub struct BesselRadialBasis {
    pub dr: f64,
    pub rcut_angstrom: f64,
    /// Basis wave numbers, indexed `[l][radial_index]`.
    pub qgrid: Vec<Vec<f64>>,
    /// Number of active radial functions for each angular channel.
    pub nrb: Vec<usize>,
    /// Radial grid, indexed `[grid_index]`.
    pub rg: Vec<f64>,
    /// Normalized radial functions, indexed `[grid_index][radial_index][l]`.
    pub rb: Vec<Vec<Vec<f64>>>,
    /// Radial normalization integrals, indexed `[l][radial_index]`.
    pub rnorm: Vec<Vec<f64>>,
}

#[derive(Clone, Debug, PartialEq)]
pub struct RadialSplineSet {
    pub drspl: f64,
    /// VASP's five-column spline table indexed `[grid][column][l][radial]`.
    pub fnl: Vec<Vec<Vec<Vec<f64>>>>,
}

fn spherical_bessel_series(x: f64, l: usize) -> f64 {
    let x2 = x * x / 2.0;
    let mut factor = 1.0;
    for order in 1..=l {
        factor *= x / (2 * order + 1) as f64;
    }

    let mut total = 1.0;
    let mut delta = 1.0;
    for index in 1..=40 {
        delta = -delta * x2 / (index * (2 * (l + index) + 1)) as f64;
        if delta.abs() < 1.0e-16 {
            return factor * total;
        }
        total += delta;
    }
    factor * total
}

/// Evaluate the spherical Bessel function using VASP's recurrence policy.
pub fn spherical_bessel_jn_vasp(x: f64, l: usize) -> Result<f64, String> {
    if !x.is_finite() || x < 0.0 {
        return Err("Bessel argument must be finite and non-negative".into());
    }
    if x < 1.0 {
        return Ok(spherical_bessel_series(x, l));
    }
    let mut bj = x.sin() / x;
    let mut bjp = (-x.cos() + bj) / x;
    for order in 2..=l + 1 {
        let next = -bj + (2 * order - 1) as f64 * bjp / x;
        bj = bjp;
        bjp = next;
    }
    Ok(bj)
}

/// Find the first `count` spherical-Bessel roots with VASP's scan and
/// bisection tolerances. The resulting values define ML_FF basis ordering.
pub fn bessel_zeros_vasp(l: usize, count: usize) -> Result<Vec<f64>, String> {
    if count == 0 {
        return Err("Bessel zero count must be positive".into());
    }
    const STEP: f64 = 0.1;
    const BREAK_TOL: f64 = 1.0e-10;
    let mut x = STEP;
    let mut bj1 = spherical_bessel_jn_vasp(x, l)?;
    let mut roots = Vec::with_capacity(count);
    while roots.len() < count {
        let bj2 = loop {
            x += STEP;
            let value = spherical_bessel_jn_vasp(x, l)?;
            if bj1 * value < 0.0 {
                break value;
            }
            bj1 = value;
        };

        let mut step = STEP;
        let mut xx = x;
        let mut right_value = bj2;
        loop {
            step *= 0.5;
            if bj1 * right_value < 0.0 {
                xx -= step;
            } else {
                xx += step;
            }
            right_value = spherical_bessel_jn_vasp(xx, l)?;
            if step <= BREAK_TOL {
                break;
            }
        }
        roots.push(xx);
        bj1 = spherical_bessel_jn_vasp(x, l)?;
    }
    Ok(roots)
}

/// Construct the normalized basis from VASP's `RJ_RSBESSEL` parameters.
///
/// `rcut_angstrom` is expressed in the caller's working length unit. Payload
/// values in `ML_FF` are in Angstrom; VASP constructs these basis tables in
/// Bohr, so payload adapters must convert before calling this function.
pub fn build_bessel_radial_basis(
    rcut_angstrom: f64,
    nr: usize,
    mrb: usize,
    lmax: usize,
) -> Result<BesselRadialBasis, String> {
    if !rcut_angstrom.is_finite() || rcut_angstrom <= 0.0 {
        return Err("radial cutoff must be finite and positive".into());
    }
    if nr == 0 || mrb == 0 {
        return Err("nr and mrb must be positive".into());
    }
    if mrb > MAX_RADIAL_FUNCTIONS {
        return Err(format!(
            "mrb exceeds the supported safety limit of {MAX_RADIAL_FUNCTIONS}"
        ));
    }
    if lmax > 64 {
        return Err("lmax exceeds the supported safety limit of 64".into());
    }
    let grid_points = nr
        .checked_mul(mrb)
        .ok_or_else(|| "radial basis dimensions overflow usize".to_owned())?;
    let basis_values = grid_points
        .checked_mul(lmax + 1)
        .ok_or_else(|| "radial basis dimensions overflow usize".to_owned())?;
    if grid_points > MAX_BASIS_GRID_POINTS || basis_values > MAX_BASIS_VALUES {
        return Err("radial basis exceeds the supported allocation safety limit".into());
    }

    let mut zero_grid = vec![vec![0.0; mrb]; lmax + 1];
    let mut qmax = 1.0e12_f64;
    for (l, row) in zero_grid.iter_mut().enumerate() {
        *row = bessel_zeros_vasp(l, mrb)?;
        qmax = qmax.min(row[mrb - 1]);
    }

    let mut nrb = vec![0_usize; lmax + 1];
    let mut qgrid = vec![vec![0.0; mrb]; lmax + 1];
    for l in 0..=lmax {
        for radial_index in 0..mrb {
            if zero_grid[l][radial_index] <= qmax || radial_index == 0 {
                nrb[l] += 1;
                qgrid[l][radial_index] = zero_grid[l][radial_index] / rcut_angstrom;
            }
        }
    }

    let dr = rcut_angstrom / nr as f64;
    let rg = (1..=nr).map(|index| index as f64 * dr).collect::<Vec<_>>();
    let mut rb = vec![vec![vec![0.0; lmax + 1]; mrb]; nr];
    let mut rnorm = vec![vec![0.0; mrb]; lmax + 1];
    for l in 0..=lmax {
        for radial_index in 0..nrb[l] {
            let values = rg
                .iter()
                .map(|&radius| spherical_bessel_jn_vasp(qgrid[l][radial_index] * radius, l))
                .collect::<Result<Vec<_>, _>>()?;
            let norm = values
                .iter()
                .zip(&rg)
                .map(|(value, radius)| (value * radius).powi(2))
                .sum::<f64>()
                * dr;
            let norm = norm.sqrt();
            if !norm.is_finite() || norm <= 0.0 {
                return Err(format!(
                    "zero radial-basis norm for l={l} irb={}",
                    radial_index + 1
                ));
            }
            for (grid_index, value) in values.into_iter().enumerate() {
                rb[grid_index][radial_index][l] = value / norm;
            }
            rnorm[l][radial_index] = norm;
        }
    }

    Ok(BesselRadialBasis {
        dr,
        rcut_angstrom,
        qgrid,
        nrb,
        rg,
        rb,
        rnorm,
    })
}

/// Convert an ML_FF Angstrom cutoff into VASP's internal Bohr length.
pub fn payload_cutoff_bohr(cutoff_angstrom: f64) -> f64 {
    cutoff_angstrom / AUTOA_ANGSTROM_PER_BOHR
}

/// Build the payload's angular radial basis after validating its supported
/// basis family. Window and variable transforms are handled as explicit gates.
pub fn build_angular_basis_from_payload(
    cutoff_angstrom: f64,
    nr: usize,
    mrb: usize,
    lmax: usize,
    basis_type: i32,
    lvartran: bool,
    lwindow: bool,
) -> Result<BesselRadialBasis, String> {
    if basis_type != 0 {
        return Err(format!("BASIS_TYPE2={basis_type} is not implemented"));
    }
    if lvartran {
        return Err("LVARTRAN radial basis is not implemented yet".into());
    }
    if lwindow {
        return Err("LWINDOW radial basis is not implemented yet".into());
    }
    build_bessel_radial_basis(payload_cutoff_bohr(cutoff_angstrom), nr, mrb, lmax)
}

pub fn build_radial_basis_from_payload(
    cutoff_angstrom: f64,
    nr: usize,
    mrb: usize,
    lmax: usize,
    lvartran: bool,
    lwindow: bool,
) -> Result<BesselRadialBasis, String> {
    if lvartran {
        return Err("LVARTRAN radial basis is not implemented yet".into());
    }
    if lwindow {
        return Err("LWINDOW radial basis is not implemented yet".into());
    }
    build_bessel_radial_basis(payload_cutoff_bohr(cutoff_angstrom), nr, mrb, lmax)
}

pub fn angular_wion_from_payload(sion_angstrom: f64, ibroad: i32) -> Result<f64, String> {
    if ibroad != 2 {
        return Err(format!("IBROAD2={ibroad} is not implemented"));
    }
    if !sion_angstrom.is_finite() || sion_angstrom <= 0.0 {
        return Err("SION2 must be finite and positive".into());
    }
    let sion_bohr = payload_cutoff_bohr(sion_angstrom);
    Ok(0.5 / sion_bohr.powi(2))
}

pub fn radial_wion_from_payload(sion_angstrom: f64, ibroad: i32) -> Result<f64, String> {
    if ibroad != 2 {
        return Err(format!("IBROAD1={ibroad} is not implemented"));
    }
    if !sion_angstrom.is_finite() || sion_angstrom <= 0.0 {
        return Err("SION1 must be finite and positive".into());
    }
    let sion_bohr = payload_cutoff_bohr(sion_angstrom);
    Ok(0.5 / sion_bohr.powi(2))
}

pub fn bp_cutoff_vasp(radius: f64, cutoff: f64) -> f64 {
    if radius <= cutoff {
        0.5 * ((PI * radius / cutoff).cos() + 1.0)
    } else {
        0.0
    }
}

pub fn bp_cutoff_derivative_vasp(radius: f64, cutoff: f64) -> f64 {
    if radius <= cutoff {
        -0.5 * PI / cutoff * (PI * radius / cutoff).sin()
    } else {
        0.0
    }
}

/// Build VASP's five-column cubic-spline coefficients from an `(x, f(x))`
/// table, optionally fixing the first derivative at the first grid point.
pub fn spline_coefficients_vasp(
    table: &[[f64; 2]],
    first_derivative: Option<f64>,
) -> Result<Vec<[f64; 5]>, String> {
    if table.len() < 2 {
        return Err("at least two spline points are required".into());
    }
    let mut p = vec![[0.0; 5]; table.len()];
    for (row, values) in p.iter_mut().zip(table) {
        row[0] = values[0];
        row[1] = values[1];
    }
    if let Some(derivative) = first_derivative {
        let dx = p[1][0] - p[0][0];
        p[0][3] = -0.5;
        p[0][2] = (3.0 / dx) * ((p[1][1] - p[0][1]) / dx - derivative);
    }
    for i in 1..p.len() - 1 {
        let s = (p[i][0] - p[i - 1][0]) / (p[i + 1][0] - p[i - 1][0]);
        let r = s * p[i - 1][3] + 2.0;
        p[i][3] = (s - 1.0) / r;
        p[i][2] = (6.0
            * ((p[i + 1][1] - p[i][1]) / (p[i + 1][0] - p[i][0])
                - (p[i][1] - p[i - 1][1]) / (p[i][0] - p[i - 1][0]))
            / (p[i + 1][0] - p[i - 1][0])
            - s * p[i - 1][2])
            / r;
    }
    let last = p.len() - 1;
    p[last][3] = 0.0;
    p[last][2] = 0.0;
    for i in (0..last).rev() {
        p[i][3] = p[i][3] * p[i + 1][3] + p[i][2];
    }
    for i in 0..last {
        let dx = p[i + 1][0] - p[i][0];
        let r = (p[i + 1][3] - p[i][3]) / 6.0;
        p[i][4] = r / dx;
        p[i][3] /= 2.0;
        p[i][2] = (p[i + 1][1] - p[i][1]) / dx - (p[i][3] + r) * dx;
    }
    Ok(p)
}

pub fn spline_eval_vasp(coefficients: &[[f64; 5]], x: f64, dr: f64) -> Result<(f64, f64), String> {
    if coefficients.len() < 2 || !x.is_finite() || !dr.is_finite() || dr <= 0.0 {
        return Err("invalid spline evaluation input".into());
    }
    let interval = ((x / dr).trunc() as isize).max(1) as usize - 1;
    let k = interval.min(coefficients.len() - 2);
    let dx = x - coefficients[k][0];
    let c = coefficients[k];
    let value = ((c[4] * dx + c[3]) * dx + c[2]) * dx + c[1];
    let derivative = (3.0 * c[4] * dx + 2.0 * c[3]) * dx + c[2];
    Ok((value, derivative))
}

fn factorial2_vasp(lmax: usize) -> Vec<f64> {
    let mut values = vec![1.0; lmax + 1];
    for l in 1..=lmax {
        values[l] = (2 * l + 1) as f64 * values[l - 1];
    }
    values
}

/// VASP `IL0` modified spherical Bessel values with stabilizing exponentials.
pub fn il0_scaled_vasp(
    lmax: usize,
    r: &[f64],
    ri: f64,
    rj: &[f64],
) -> Result<Vec<Vec<f64>>, String> {
    if r.len() != rj.len() {
        return Err("IL0 radius arrays must have equal lengths".into());
    }
    let mut values = vec![vec![0.0; lmax + 1]; r.len()];
    let fac2 = factorial2_vasp(lmax);
    for index in 0..r.len() {
        let radius = r[index];
        let a = (radius - ri - rj[index]).exp();
        let b = (-radius - ri - rj[index]).exp();
        if radius.powi(2) > 1.0e-8 {
            values[index][0] = 0.5 * (a - b) / radius;
        } else {
            values[index][0] = (-(ri + rj[index])).exp();
        }
        if lmax == 0 {
            continue;
        }
        if radius.powi(3) > 1.0e-8 {
            values[index][1] = (0.5 * radius * (a + b) - 0.5 * (a - b)) / radius.powi(2);
        } else {
            values[index][1] = radius / fac2[1] * (-(ri + rj[index])).exp();
        }
        for l in 2..=lmax {
            if radius.powi((l + 2) as i32) > 1.0e-8 {
                values[index][l] =
                    values[index][l - 2] - (2 * (l - 1) + 1) as f64 / radius * values[index][l - 1];
            } else {
                values[index][l] = radius.powi(l as i32) / fac2[l] * (-(ri + rj[index])).exp();
            }
        }
    }
    Ok(values)
}

/// VASP `IL1` modified spherical Bessel values and derivatives.
pub fn il1_vasp(lmax: usize, r: &[f64]) -> (Vec<Vec<f64>>, Vec<Vec<f64>>) {
    let mut values = vec![vec![0.0; lmax + 1]; r.len()];
    let mut derivatives = vec![vec![0.0; lmax + 1]; r.len()];
    let fac2 = factorial2_vasp(lmax);
    for (index, &radius) in r.iter().enumerate() {
        if radius.powi(2) > 1.0e-8 {
            values[index][0] = radius.sinh() / radius;
            derivatives[index][0] = (radius * radius.cosh() - radius.sinh()) / radius.powi(2);
        } else {
            values[index][0] = 1.0;
        }
        if lmax == 0 {
            continue;
        }
        if radius.powi(3) > 1.0e-8 {
            values[index][1] = (radius * radius.cosh() - radius.sinh()) / radius.powi(2);
            derivatives[index][1] = (values[index][0]
                + 2.0 * (values[index][0] - 3.0 * values[index][1] / radius))
                / 3.0;
        } else {
            values[index][1] = radius / fac2[1];
            derivatives[index][1] = 1.0 / fac2[1];
        }
        for l in 2..=lmax {
            if radius.powi((l + 2) as i32) > 1.0e-8 {
                values[index][l] =
                    values[index][l - 2] - (2 * (l - 1) + 1) as f64 / radius * values[index][l - 1];
            } else {
                values[index][l] = radius.powi(l as i32) / fac2[l];
            }
        }
        for l in 2..=lmax {
            if radius.powi((l + 2) as i32) > 1.0e-8 {
                derivatives[index][l] =
                    values[index][l - 1] - (2 * l + 1) as f64 / radius * values[index][l];
                derivatives[index][l] = (l as f64 * values[index][l - 1]
                    + (l + 1) as f64 * derivatives[index][l])
                    / (2 * l + 1) as f64;
            } else {
                derivatives[index][l] = l as f64 * radius.powi(l as i32 - 1) / fac2[l];
            }
        }
    }
    (values, derivatives)
}

/// Construct the production IBROAD=2 / ICUT=1 Gaussian radial splines.
pub fn build_gaussian_radial_splines(
    basis: &BesselRadialBasis,
    mspl: usize,
    wion: f64,
) -> Result<RadialSplineSet, String> {
    if mspl <= 1 || !wion.is_finite() || wion <= 0.0 {
        return Err("mspl must exceed one and wion must be finite and positive".into());
    }
    let nspl = mspl;
    let lmax = basis.qgrid.len() - 1;
    let mrb = basis.qgrid[0].len();
    let spline_values = nspl
        .checked_mul(5)
        .and_then(|count| count.checked_mul(lmax + 1))
        .and_then(|count| count.checked_mul(mrb))
        .ok_or_else(|| "radial spline dimensions overflow usize".to_owned())?;
    if spline_values > MAX_BASIS_VALUES {
        return Err("radial splines exceed the supported allocation safety limit".into());
    }
    let drspl = basis.rcut_angstrom / nspl as f64;
    let spline_r = (1..=nspl)
        .map(|index| index as f64 * drspl)
        .collect::<Vec<_>>();
    let mut fnl = vec![vec![vec![vec![0.0; mrb]; lmax + 1]; 5]; nspl];
    let fcut = spline_r
        .iter()
        .map(|&radius| bp_cutoff_vasp(radius, basis.rcut_angstrom))
        .collect::<Vec<_>>();
    for ispl in 0..nspl {
        for l in 0..=lmax {
            for n in 0..mrb {
                fnl[ispl][0][l][n] = spline_r[ispl];
            }
        }
    }

    let prefac = 4.0 * PI * (wion / PI).powf(1.5);
    let tg2_dr = basis
        .rg
        .iter()
        .map(|radius| radius.powi(2) * basis.dr)
        .collect::<Vec<_>>();
    let rj = basis
        .rg
        .iter()
        .map(|radius| wion * radius.powi(2))
        .collect::<Vec<_>>();
    for ispl in 0..nspl {
        let rion = spline_r[ispl];
        let r = basis
            .rg
            .iter()
            .map(|radius| 2.0 * wion * rion * radius)
            .collect::<Vec<_>>();
        let ril = il0_scaled_vasp(lmax, &r, wion * rion.powi(2), &rj)?;
        for l in 0..=lmax {
            for n in 0..basis.nrb[l] {
                let mut sum = 0.0;
                for grid in 0..basis.rg.len() {
                    let cr = prefac * fcut[ispl] * ril[grid][l] * tg2_dr[grid];
                    sum += basis.rb[grid][n][l] * cr;
                }
                fnl[ispl][1][l][n] = sum;
            }
        }
    }

    let exp21 = basis
        .rg
        .iter()
        .map(|radius| (-wion * radius.powi(2)).exp())
        .collect::<Vec<_>>();
    let exp22 = (-wion * spline_r[0].powi(2)).exp();
    let dexp22 = -2.0 * wion * spline_r[0] * exp22;
    let first_r = basis
        .rg
        .iter()
        .map(|radius| 2.0 * wion * spline_r[0] * radius)
        .collect::<Vec<_>>();
    let (ril_first, dril_first) = il1_vasp(lmax, &first_r);
    let mut dfnl0 = vec![vec![0.0; mrb]; lmax + 1];
    let dfcut0 = bp_cutoff_derivative_vasp(spline_r[0], basis.rcut_angstrom);
    for l in 0..=lmax {
        for n in 0..basis.nrb[l] {
            let mut sum = 0.0;
            for grid in 0..basis.rg.len() {
                let dcr = prefac
                    * (dfcut0 * exp22 * exp21[grid] * ril_first[grid][l]
                        + fcut[0] * dexp22 * exp21[grid] * ril_first[grid][l]
                        + fcut[0]
                            * exp22
                            * exp21[grid]
                            * dril_first[grid][l]
                            * 2.0
                            * wion
                            * basis.rg[grid])
                    * tg2_dr[grid];
                sum += basis.rb[grid][n][l] * dcr;
            }
            dfnl0[l][n] = sum;
        }
    }

    for l in 0..=lmax {
        for n in 0..basis.nrb[l] {
            let table = (0..nspl)
                .map(|ispl| [spline_r[ispl], fnl[ispl][1][l][n]])
                .collect::<Vec<_>>();
            let coefficients = spline_coefficients_vasp(&table, Some(dfnl0[l][n]))?;
            for ispl in 0..nspl {
                for column in 0..5 {
                    fnl[ispl][column][l][n] = coefficients[ispl][column];
                }
            }
        }
    }
    Ok(RadialSplineSet { drspl, fnl })
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::Value;

    const EXPECTED: &str = include_str!(
        "../../../evidence/vasp_mlff_inspect_parity_2026-10-24/radial_basis_expected.json"
    );
    const EXPECTED_GAUSSIAN_SPLINES: &str = include_str!(
        "../../../evidence/vasp_mlff_gaussian_splines_2026-10-24/macer_reference.json"
    );
    const EXPECTED_SPLINES: &str = include_str!(
        "../../../evidence/vasp_mlff_inspect_parity_2026-10-24/radial_spline_expected.json"
    );
    const EXPECTED_RADIAL_DESCRIPTOR: &str = include_str!(
        "../../../evidence/vasp_mlff_inspect_parity_2026-10-24/radial_descriptor_expected.json"
    );

    fn assert_close(actual: f64, expected: f64, tolerance: f64, name: &str) {
        assert!(
            (actual - expected).abs() <= tolerance * expected.abs().max(1.0),
            "{name}: actual={actual:.17e}, expected={expected:.17e}, tolerance={tolerance:.2e}"
        );
    }

    #[test]
    fn bessel_roots_and_complete_basis_match_macer_golden() {
        let expected: Value = serde_json::from_str(EXPECTED).unwrap();
        let basis = build_angular_basis_from_payload(5.0, 64, 8, 2, 0, false, false).unwrap();
        let expected_nrb: Vec<usize> = serde_json::from_value(expected["nrb"].clone()).unwrap();
        assert_eq!(basis.nrb, expected_nrb);
        assert_close(basis.dr, expected["dr"].as_f64().unwrap(), 1.0e-14, "dr");
        for (name, actual, expected) in [
            (
                "qgrid",
                serde_json::to_value(&basis.qgrid).unwrap(),
                &expected["qgrid"],
            ),
            (
                "rg",
                serde_json::to_value(&basis.rg).unwrap(),
                &expected["rg"],
            ),
            (
                "rb",
                serde_json::to_value(&basis.rb).unwrap(),
                &expected["rb"],
            ),
            (
                "rnorm",
                serde_json::to_value(&basis.rnorm).unwrap(),
                &expected["rnorm"],
            ),
        ] {
            compare_json_float_tree(&actual, expected, 2.0e-11, name);
        }
    }

    fn compare_json_float_tree(actual: &Value, expected: &Value, tolerance: f64, name: &str) {
        match (actual, expected) {
            (Value::Number(a), Value::Number(e)) => {
                assert_close(a.as_f64().unwrap(), e.as_f64().unwrap(), tolerance, name)
            }
            (Value::Array(a), Value::Array(e)) => {
                assert_eq!(a.len(), e.len(), "shape mismatch for {name}");
                for (index, (a, e)) in a.iter().zip(e).enumerate() {
                    compare_json_float_tree(a, e, tolerance, &format!("{name}[{index}]"));
                }
            }
            (a, e) => assert_eq!(a, e, "shape/type mismatch for {name}"),
        }
    }

    #[test]
    fn rejects_unsupported_basis_features_before_building() {
        assert!(
            build_angular_basis_from_payload(5.0, 64, 8, 2, 4, false, false)
                .unwrap_err()
                .contains("BASIS_TYPE2=4")
        );
        assert!(
            build_angular_basis_from_payload(5.0, 64, 8, 2, 0, true, false)
                .unwrap_err()
                .contains("LVARTRAN")
        );
        assert!(build_bessel_radial_basis(5.0, 2_000_001, 1, 0)
            .unwrap_err()
            .contains("allocation safety limit"));
    }

    #[test]
    fn gaussian_radial_splines_match_full_macer_golden() {
        let spline_golden: Value = serde_json::from_str(EXPECTED_SPLINES).unwrap();
        let basis = build_angular_basis_from_payload(5.0, 64, 8, 2, 0, false, false).unwrap();
        let wion = angular_wion_from_payload(0.5, 2).unwrap();
        let splines = build_gaussian_radial_splines(&basis, 32, wion).unwrap();
        assert_close(
            splines.drspl,
            spline_golden["drspl"].as_f64().unwrap(),
            1.0e-14,
            "drspl",
        );
        let actual_fnl = serde_json::to_value(&splines.fnl).unwrap();
        compare_json_float_tree(&actual_fnl, &spline_golden["fnl"], 5.0e-10, "fnl");

        let queries = spline_golden["queries"].as_array().unwrap();
        for (sample_index, (l, n)) in [(0_usize, 0_usize), (1, 1), (2, 3)].into_iter().enumerate() {
            let coefficients = (0..splines.fnl.len())
                .map(|grid| std::array::from_fn(|column| splines.fnl[grid][column][l][n]))
                .collect::<Vec<[f64; 5]>>();
            for (query_index, query) in queries.iter().enumerate() {
                let x = query.as_f64().unwrap();
                let (value, derivative) =
                    spline_eval_vasp(&coefficients, x, splines.drspl).unwrap();
                let expected = &spline_golden["samples"][sample_index][query_index];
                assert_close(
                    value,
                    expected["value"].as_f64().unwrap(),
                    5.0e-10,
                    "spline value",
                );
                assert_close(
                    derivative,
                    expected["derivative"].as_f64().unwrap(),
                    5.0e-10,
                    "spline derivative",
                );
            }
        }
    }

    #[test]
    fn gaussian_radial_splines_match_frozen_macer_reference() {
        let expected: Value = serde_json::from_str(EXPECTED_GAUSSIAN_SPLINES).unwrap();
        let parameters = &expected["parameters"];
        let basis = build_angular_basis_from_payload(
            parameters["rcut_angstrom"].as_f64().unwrap(),
            parameters["nr"].as_u64().unwrap() as usize,
            parameters["mrb"].as_u64().unwrap() as usize,
            parameters["lmax"].as_u64().unwrap() as usize,
            0,
            false,
            false,
        )
        .unwrap();
        let sion = parameters["sion_angstrom"].as_f64().unwrap();
        let wion = angular_wion_from_payload(sion, 2).unwrap();
        assert_close(wion, parameters["wion"].as_f64().unwrap(), 1.0e-14, "wion");
        let actual = build_gaussian_radial_splines(
            &basis,
            parameters["mspl"].as_u64().unwrap() as usize,
            wion,
        )
        .unwrap();
        assert_close(
            actual.drspl,
            expected["drspl"].as_f64().unwrap(),
            1.0e-14,
            "drspl",
        );
        compare_json_float_tree(
            &serde_json::to_value(actual.fnl).unwrap(),
            &expected["fnl"],
            3.0e-10,
            "fnl",
        );
    }

    #[test]
    fn radial_descriptor_basis_and_splines_match_macer_payload() {
        let expected: Value = serde_json::from_str(EXPECTED_RADIAL_DESCRIPTOR).unwrap();
        let parameters = &expected["parameters"];
        let basis = build_radial_basis_from_payload(
            parameters["rcut_angstrom"].as_f64().unwrap(),
            parameters["nr"].as_u64().unwrap() as usize,
            parameters["mrb"].as_u64().unwrap() as usize,
            parameters["lmax"].as_u64().unwrap() as usize,
            false,
            false,
        )
        .unwrap();
        let expected_basis = &expected["basis"];
        let expected_nrb: Vec<usize> =
            serde_json::from_value(expected_basis["nrb"].clone()).unwrap();
        assert_eq!(basis.nrb, expected_nrb);
        compare_json_float_tree(
            &serde_json::to_value(&basis.qgrid).unwrap(),
            &expected_basis["qgrid"],
            3.0e-11,
            "radial qgrid",
        );
        compare_json_float_tree(
            &serde_json::to_value(&basis.rg).unwrap(),
            &expected_basis["rg"],
            3.0e-11,
            "radial rg",
        );
        compare_json_float_tree(
            &serde_json::to_value(&basis.rb).unwrap(),
            &expected_basis["rb"],
            3.0e-11,
            "radial rb",
        );
        compare_json_float_tree(
            &serde_json::to_value(&basis.rnorm).unwrap(),
            &expected_basis["rnorm"],
            3.0e-11,
            "radial rnorm",
        );
        assert_close(
            basis.dr,
            expected_basis["dr"].as_f64().unwrap(),
            1.0e-14,
            "radial dr",
        );
        let wion =
            radial_wion_from_payload(parameters["sion_angstrom"].as_f64().unwrap(), 2).unwrap();
        assert_close(
            wion,
            parameters["wion"].as_f64().unwrap(),
            1.0e-14,
            "radial wion",
        );
        let splines = build_gaussian_radial_splines(
            &basis,
            parameters["mspl"].as_u64().unwrap() as usize,
            wion,
        )
        .unwrap();
        assert_close(
            splines.drspl,
            expected["splines"]["drspl"].as_f64().unwrap(),
            1.0e-14,
            "radial drspl",
        );
        compare_json_float_tree(
            &serde_json::to_value(splines.fnl).unwrap(),
            &expected["splines"]["fnl"],
            3.0e-10,
            "radial spline fnl",
        );
    }
}
