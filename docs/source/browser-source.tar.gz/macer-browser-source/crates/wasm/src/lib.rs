use candle_core::Device;
use macer_rust_core::types::{Evaluation, Potential, Structure};
use macer_rust_model::evaluation::{webgpu_geometry::FeatureGradients, Evaluator, OrderedGraph};
use macer_rust_relax::{RelaxSession, RelaxSettings};
use serde::Serialize;
use wasm_bindgen::prelude::*;

#[derive(Serialize)]
struct EvaluationEvent {
    energy_ev: f64,
    forces_ev_per_a: Vec<[f64; 3]>,
    stress_ev_per_a3: [[f64; 3]; 3],
}

#[wasm_bindgen]
pub struct BrowserEngine {
    evaluator: Evaluator,
    session: Option<RelaxSession>,
}

#[wasm_bindgen]
impl BrowserEngine {
    #[wasm_bindgen(constructor)]
    pub fn new(manifest: &[u8], weights: &[u8]) -> Result<BrowserEngine, JsValue> {
        let evaluator = Evaluator::from_bytes(manifest, weights, Device::Cpu).map_err(js_error)?;
        Ok(Self {
            evaluator,
            session: None,
        })
    }

    pub fn evaluate_json(&mut self, structure_json: &str) -> Result<String, JsValue> {
        let structure: Structure = serde_json::from_str(structure_json).map_err(js_error)?;
        structure.validate().map_err(js_error)?;
        let evaluation = <Evaluator as Potential>::evaluate(&mut self.evaluator, &structure)
            .map_err(js_error)?;
        serde_json::to_string(&EvaluationEvent {
            energy_ev: evaluation.energy_ev,
            forces_ev_per_a: evaluation.forces_ev_per_a,
            stress_ev_per_a3: evaluation.stress_ev_per_a3,
        })
        .map_err(js_error)
    }

    pub fn start_relax(
        &mut self,
        structure_json: &str,
        settings_json: &str,
    ) -> Result<(), JsValue> {
        let structure: Structure = serde_json::from_str(structure_json).map_err(js_error)?;
        let settings: RelaxSettings = serde_json::from_str(settings_json).map_err(js_error)?;
        self.session = Some(RelaxSession::new(structure, settings).map_err(js_error)?);
        Ok(())
    }

    /// Runs one complete force evaluation and returns its matched geometry/E/F/stress snapshot.
    pub fn advance_relax(&mut self) -> Result<String, JsValue> {
        let session = self
            .session
            .as_mut()
            .ok_or_else(|| JsValue::from_str("relax has not been started"))?;
        let snapshot = session.advance(&mut self.evaluator).map_err(js_error)?;
        serde_json::to_string(&snapshot).map_err(js_error)
    }

    pub fn relax_status(&self) -> String {
        self.session
            .as_ref()
            .map(|session| format!("{:?}", session.status()).to_lowercase())
            .unwrap_or_else(|| "idle".into())
    }

    pub fn webgpu_features_json(&self, structure_json: &str) -> Result<String, JsValue> {
        let structure: Structure = serde_json::from_str(structure_json).map_err(js_error)?;
        structure.validate().map_err(js_error)?;
        let graph = OrderedGraph::from_structure(&structure).map_err(js_error)?;
        serde_json::to_string(&self.evaluator.webgpu_features(&graph).map_err(js_error)?)
            .map_err(js_error)
    }

    pub fn webgpu_ordered_graph_json(&self, structure_json: &str) -> Result<String, JsValue> {
        let structure: Structure = serde_json::from_str(structure_json).map_err(js_error)?;
        structure.validate().map_err(js_error)?;
        let graph = OrderedGraph::from_structure(&structure).map_err(js_error)?;
        graph.validate().map_err(js_error)?;
        serde_json::to_string(&graph).map_err(js_error)
    }

    pub fn webgpu_geometry_constants_json(&self) -> Result<String, JsValue> {
        serde_json::to_string(
            &self
                .evaluator
                .webgpu_geometry_constants()
                .map_err(js_error)?,
        )
        .map_err(js_error)
    }

    pub fn webgpu_geometry_backward_json(
        &self,
        structure_json: &str,
        gradients_json: &str,
    ) -> Result<String, JsValue> {
        let structure: Structure = serde_json::from_str(structure_json).map_err(js_error)?;
        structure.validate().map_err(js_error)?;
        let gradients: FeatureGradients = serde_json::from_str(gradients_json).map_err(js_error)?;
        let graph = OrderedGraph::from_structure(&structure).map_err(js_error)?;
        let mut result = self
            .evaluator
            .webgpu_geometry_backward(&graph, gradients)
            .map_err(js_error)?;
        if !structure.pbc.iter().any(|&v| v) {
            result.stress_ev_per_a3 = [[0.; 3]; 3];
        }
        serde_json::to_string(&result).map_err(js_error)
    }

    pub fn prepare_relax_evaluation_json(&mut self) -> Result<String, JsValue> {
        let session = self
            .session
            .as_mut()
            .ok_or_else(|| JsValue::from_str("relax has not been started"))?;
        serde_json::to_string(session.prepare_evaluation().map_err(js_error)?).map_err(js_error)
    }

    pub fn replace_prepared_relax_positions_json(
        &mut self,
        positions_json: &str,
    ) -> Result<(), JsValue> {
        let positions: Vec<[f64; 3]> = serde_json::from_str(positions_json).map_err(js_error)?;
        let session = self
            .session
            .as_mut()
            .ok_or_else(|| JsValue::from_str("relax has not been started"))?;
        session
            .replace_prepared_positions(positions)
            .map_err(js_error)
    }

    pub fn replace_prepared_relax_cell_state_json(
        &mut self,
        structure_json: &str,
        velocities_json: &str,
        dt_fs: f64,
        alpha: f64,
        positive_steps: u32,
        initialized: bool,
    ) -> Result<(), JsValue> {
        let structure: Structure = serde_json::from_str(structure_json).map_err(js_error)?;
        let velocities: Vec<[f64; 3]> = serde_json::from_str(velocities_json).map_err(js_error)?;
        let session = self
            .session
            .as_mut()
            .ok_or_else(|| JsValue::from_str("relax has not been started"))?;
        session
            .replace_prepared_cell_state(
                structure,
                velocities,
                dt_fs,
                alpha,
                positive_steps as usize,
                initialized,
            )
            .map_err(js_error)
    }

    pub fn accept_relax_evaluation_json(
        &mut self,
        evaluation_json: &str,
    ) -> Result<String, JsValue> {
        let evaluation: Evaluation = serde_json::from_str(evaluation_json).map_err(js_error)?;
        let session = self
            .session
            .as_mut()
            .ok_or_else(|| JsValue::from_str("relax has not been started"))?;
        serde_json::to_string(&session.accept_evaluation(evaluation).map_err(js_error)?)
            .map_err(js_error)
    }

    pub fn recheck_relax_evaluation_json(
        &mut self,
        evaluation_json: &str,
    ) -> Result<String, JsValue> {
        let evaluation: Evaluation = serde_json::from_str(evaluation_json).map_err(js_error)?;
        let session = self
            .session
            .as_mut()
            .ok_or_else(|| JsValue::from_str("relax has not been started"))?;
        serde_json::to_string(
            &session
                .recheck_last_evaluation(evaluation)
                .map_err(js_error)?,
        )
        .map_err(js_error)
    }
}

fn js_error(error: impl std::fmt::Display) -> JsValue {
    JsValue::from_str(&error.to_string())
}
