//! Run the pinned MatterSim or NEP model through the native symmetry Relax path.
use candle_core::Device;
use macer_rust_core::types::{Potential, Structure};
use macer_rust_model::evaluation::Evaluator;
use macer_rust_nep::nep89::Nep4ZblModel;
use macer_rust_relax::{symmetry::SymmetryOperations, RelaxSession, RelaxSettings, RelaxStatus};
use std::{env, fs, process};

fn execute<P: Potential>(
    mut potential: P,
    structure: Structure,
    settings: RelaxSettings,
    operations: SymmetryOperations,
) -> Result<(), String> {
    let mut session = RelaxSession::new(structure, settings)?.with_symmetry(operations, 1e-4)?;
    loop {
        let snapshot = session.advance(&mut potential)?;
        println!("{}", serde_json::to_string(&snapshot).map_err(|e| e.to_string())?);
        if snapshot.status != RelaxStatus::Running {
            break;
        }
    }
    Ok(())
}

fn run() -> Result<(), String> {
    let args = env::args().skip(1).collect::<Vec<_>>();
    if args.len() != 6 {
        return Err("usage: run_symmetry_model <mattersim|nep89> <structure.json> <settings.json> <operations.json> <manifest.json|-> <weights>".into());
    }
    let structure: Structure = serde_json::from_slice(&fs::read(&args[1]).map_err(|e| e.to_string())?)
        .map_err(|e| e.to_string())?;
    let settings: RelaxSettings = serde_json::from_slice(&fs::read(&args[2]).map_err(|e| e.to_string())?)
        .map_err(|e| e.to_string())?;
    let operations: SymmetryOperations = serde_json::from_slice(&fs::read(&args[3]).map_err(|e| e.to_string())?)
        .map_err(|e| e.to_string())?;
    let weights = fs::read(&args[5]).map_err(|e| e.to_string())?;
    match args[0].as_str() {
        "mattersim" => {
            if args[4] == "-" { return Err("MatterSim requires a manifest".into()); }
            let manifest = fs::read(&args[4]).map_err(|e| e.to_string())?;
            let model = Evaluator::from_bytes(&manifest, &weights, Device::Cpu)?;
            execute(model, structure, settings, operations)
        }
        "nep89" => execute(
            Nep4ZblModel::from_bytes(&weights)?,
            structure,
            settings,
            operations,
        ),
        _ => Err(format!("unknown model: {}", args[0])),
    }
}

fn main() {
    if let Err(error) = run() {
        eprintln!("run_symmetry_model: {error}");
        process::exit(2);
    }
}
