use macer_rust_core::types::Structure;
use macer_rust_nep::nep89::{Nep4ZblModel, NEP89_REFERENCE_BYTES, NEP89_REFERENCE_SHA256};
use macer_rust_relax::{RelaxSession, RelaxSettings, RelaxSnapshot, RelaxStatus};
use serde::Serialize;
use std::fs;

#[derive(Serialize)]
struct Report {
    schema: &'static str,
    model_sha256: String,
    model_bytes: usize,
    settings: RelaxSettings,
    snapshots: Vec<RelaxSnapshot>,
}

fn run() -> Result<(), Box<dyn std::error::Error>> {
    let args = std::env::args().skip(1).collect::<Vec<_>>();
    if args.len() != 2 {
        return Err(
            "usage: nep89_browser_structure_reference <structure.json> <output.json>".into(),
        );
    }
    let model_path = std::env::var_os("MACER_NEP89_MODEL")
        .ok_or("set MACER_NEP89_MODEL to the external pinned checkpoint")?;
    let model_bytes = fs::read(model_path)?;
    let mut model = Nep4ZblModel::from_bytes(&model_bytes)?;
    if model.source_sha256 != NEP89_REFERENCE_SHA256 || model_bytes.len() != NEP89_REFERENCE_BYTES {
        return Err("model does not match the pinned NEP89 checkpoint".into());
    }

    let initial: Structure = serde_json::from_slice(&fs::read(&args[0])?)?;
    initial.validate()?;
    let settings = RelaxSettings::default();
    let mut session = RelaxSession::new(initial, settings.clone())?;
    let mut snapshots = Vec::with_capacity(settings.max_steps + 1);
    loop {
        let snapshot = session.advance(&mut model)?;
        let finished = snapshot.status != RelaxStatus::Running;
        snapshots.push(snapshot);
        if finished {
            break;
        }
    }
    let report = Report {
        schema: "macer-nep89-browser-structure-native-reference-v1",
        model_sha256: model.source_sha256,
        model_bytes: model_bytes.len(),
        settings,
        snapshots,
    };
    fs::write(&args[1], serde_json::to_vec_pretty(&report)?)?;
    Ok(())
}

fn main() {
    if let Err(error) = run() {
        eprintln!("nep89_browser_structure_reference: {error}");
        std::process::exit(2);
    }
}
