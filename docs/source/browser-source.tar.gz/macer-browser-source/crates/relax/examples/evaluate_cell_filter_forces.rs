//! Evaluate fixed structures and emit the shared cell-filter FIRE forces.
use candle_core::Device;
use macer_rust_core::types::{Potential, Structure};
use macer_rust_model::evaluation::Evaluator;
use macer_rust_relax::{cell_filter::FrechetCellFilter, RelaxSettings};
use serde::Deserialize;
use std::{env, fs, io::Write, process};

#[derive(Deserialize)]
struct InputRow {
    step: usize,
    structure: Structure,
}

fn main() {
    if let Err(error) = run() {
        eprintln!("evaluate_cell_filter_forces: {error}");
        process::exit(2);
    }
}

fn run() -> Result<(), String> {
    let args = env::args().skip(1).collect::<Vec<_>>();
    if args.len() != 6 {
        return Err("usage: evaluate_cell_filter_forces <reference-structure.json> <structures.json> <settings.json> <manifest.json> <weights.safetensors> <output.jsonl>".into());
    }
    let reference: Structure =
        serde_json::from_slice(&fs::read(&args[0]).map_err(|e| e.to_string())?)
            .map_err(|e| e.to_string())?;
    let input: Vec<InputRow> =
        serde_json::from_slice(&fs::read(&args[1]).map_err(|e| e.to_string())?)
            .map_err(|e| e.to_string())?;
    let settings: RelaxSettings =
        serde_json::from_slice(&fs::read(&args[2]).map_err(|e| e.to_string())?)
            .map_err(|e| e.to_string())?;
    let manifest = fs::read(&args[3]).map_err(|e| e.to_string())?;
    let weights = fs::read(&args[4]).map_err(|e| e.to_string())?;
    let mut evaluator = Evaluator::from_bytes(&manifest, &weights, Device::Cpu)?;
    let output = fs::File::create(&args[5]).map_err(|e| e.to_string())?;
    let mut writer = std::io::BufWriter::new(output);
    for row in input {
        let filter = FrechetCellFilter::new(
            &reference,
            settings.pressure_gpa / 160.217_662_08,
            &[],
            settings.optimize_cell_shape && !settings.optimize_cell_volume,
            !settings.optimize_cell_shape && settings.optimize_cell_volume,
            !settings.optimize_positions,
        )
        .with_atom_constraints(settings.movable.clone(), settings.fractional_constraints)?;
        let coordinates = filter.coordinates_for_structure(&row.structure)?;
        let evaluation = Potential::evaluate(&mut evaluator, &row.structure)?;
        let optimizer_forces = filter.forces(&row.structure, &evaluation, &coordinates)?;
        serde_json::to_writer(
            &mut writer,
            &serde_json::json!({
                "step": row.step,
                "evaluation": evaluation,
                "optimizer_forces": optimizer_forces,
            }),
        )
        .map_err(|error| error.to_string())?;
        writer.write_all(b"\n").map_err(|error| error.to_string())?;
    }
    writer.flush().map_err(|error| error.to_string())?;
    Ok(())
}
