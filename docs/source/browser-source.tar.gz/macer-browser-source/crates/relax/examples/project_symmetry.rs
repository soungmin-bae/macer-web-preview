use macer_rust_relax::symmetry::{normalize_reference, SymmetryOperations, SymmetryProjector};
use serde::Deserialize;
use std::io::{self, Read};
#[derive(Deserialize)]
struct Case {
    operations: SymmetryOperations,
    cell: [[f64; 3]; 3],
    masks: Vec<[bool; 3]>,
    fractional: bool,
    values: Vec<[f64; 3]>,
    stress: [[f64; 3]; 3],
    positions: Vec<[f64; 3]>,
}
fn main() {
    let mut text = String::new();
    io::stdin().read_to_string(&mut text).unwrap();
    let cases: Vec<Case> = serde_json::from_str(&text).unwrap();
    let output:Vec<_>=cases.into_iter().map(|c|{let reference=macer_rust_core::types::Structure{atomic_numbers:vec![1;c.values.len()],positions_a:c.positions,cell_a:c.cell,pbc:[true;3]};let(corrected,operations,correction)=normalize_reference(&reference,&c.operations,1e-4).unwrap();let p=SymmetryProjector::new(operations.clone(),corrected.cell_a,&c.masks,c.fractional).unwrap();let projected=p.project_atoms(&c.values).unwrap();let twice=p.project_atoms(&projected).unwrap();serde_json::json!({"normalizedCell":corrected.cell_a,"normalizedOperations":operations,"maximumCorrectionAngstrom":correction,"projected":projected,"twice":twice,"dof":p.degrees_of_freedom(),"cell":p.project_cell(c.stress,true,true),"tracefree":p.project_cell(c.stress,true,false),"hydrostatic":p.project_cell(c.stress,false,true)})}).collect();
    println!("{}", serde_json::to_string(&output).unwrap());
}
