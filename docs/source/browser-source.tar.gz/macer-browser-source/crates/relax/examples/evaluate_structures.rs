use candle_core::Device;
use macer_rust_core::types::{Potential, Structure};
use macer_rust_model::evaluation::Evaluator;
use serde::Deserialize;
use std::{env, fs, process};

#[derive(Deserialize)]
struct InputRow {
    step: usize,
    structure: Structure,
}

fn main() {
    if let Err(error) = run() {
        eprintln!("evaluate_structures: {error}");
        process::exit(2);
    }
}

fn run() -> Result<(), String> {
    let args = env::args().skip(1).collect::<Vec<_>>();
    if args.len() != 3 {
        return Err(
            "usage: evaluate_structures <structures.json> <manifest.json> <weights.safetensors>"
                .into(),
        );
    }
    let input: Vec<InputRow> =
        serde_json::from_slice(&fs::read(&args[0]).map_err(|e| e.to_string())?)
            .map_err(|e| e.to_string())?;
    let manifest = fs::read(&args[1]).map_err(|e| e.to_string())?;
    let weights = fs::read(&args[2]).map_err(|e| e.to_string())?;
    let mut evaluator = Evaluator::from_bytes(&manifest, &weights, Device::Cpu)?;
    for row in input {
        let evaluation = Potential::evaluate(&mut evaluator, &row.structure)?;
        println!(
            "{}",
            serde_json::json!({"step": row.step, "evaluation": evaluation})
        );
    }
    Ok(())
}
