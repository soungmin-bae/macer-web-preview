//! Asymmetric synthetic E/F/stress regression, not a model qualification.
use macer_rust_core::types::{Evaluation, Structure};
use macer_rust_relax::{symmetry::SymmetryOperations, RelaxSession, RelaxSettings, RelaxStatus};
use serde::Deserialize;
use std::io::{self, Read};
#[derive(Deserialize)]
struct Case {
    name: String,
    operations: SymmetryOperations,
    cell: [[f64; 3]; 3],
    masks: Vec<[bool; 3]>,
    fractional: bool,
    values: Vec<[f64; 3]>,
    stress: [[f64; 3]; 3],
    positions: Vec<[f64; 3]>,
}
fn main() {
    let mut text = String::new();
    io::stdin().read_to_string(&mut text).unwrap();
    let cases: Vec<Case> = serde_json::from_str(&text).unwrap();
    let mut output = Vec::new();
    for c in cases {
        for pressure in [0., 3., -1.] {
            let structure = Structure {
                atomic_numbers: vec![1; c.positions.len()],
                positions_a: c.positions.clone(),
                cell_a: c.cell,
                pbc: [true; 3],
            };
            let settings = RelaxSettings {
                max_steps: 3,
                pressure_gpa: pressure,
                movable: c.masks.clone(),
                fractional_constraints: c.fractional,
                ..Default::default()
            };
            let mut session = RelaxSession::new(structure, settings)
                .unwrap()
                .with_symmetry(c.operations.clone(), 1e-4)
                .unwrap();
            let mut snapshots = Vec::new();
            for _ in 0..4 {
                session.prepare_evaluation().unwrap();
                let evaluation = Evaluation {
                    energy_ev: 1.,
                    forces_ev_per_a: c.values.clone(),
                    stress_ev_per_a3: c.stress,
                    energies_ev: None,
                    stresses_ev_per_a3: None,
                };
                let snapshot = session.accept_evaluation(evaluation).unwrap();
                let finished = snapshot.status != RelaxStatus::Running;
                snapshots.push(snapshot);
                if finished {
                    break;
                }
            }
            output.push(
                serde_json::json!({"case":c.name,"pressureGpa":pressure,"snapshots":snapshots}),
            );
        }
    }
    println!("{}", serde_json::to_string(&output).unwrap());
}
