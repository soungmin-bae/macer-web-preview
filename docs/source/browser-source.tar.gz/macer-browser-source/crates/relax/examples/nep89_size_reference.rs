use macer_rust_core::types::Structure;
use macer_rust_nep::nep89::{Nep4ZblModel, NEP89_REFERENCE_BYTES, NEP89_REFERENCE_SHA256};
use macer_rust_relax::{RelaxSession, RelaxSettings, RelaxStatus};
use serde::Serialize;
use std::fs;
use std::path::PathBuf;

#[derive(Serialize)]
struct Report {
    schema: &'static str,
    input: InputIdentity,
    model: ModelIdentity,
    settings: RelaxSettings,
    snapshots: Vec<macer_rust_relax::RelaxSnapshot>,
}

#[derive(Serialize)]
struct InputIdentity {
    atoms: usize,
    cell_a: [[f64; 3]; 3],
    pbc: [bool; 3],
}

#[derive(Serialize)]
struct ModelIdentity {
    bytes: usize,
    sha256: String,
}

fn parse_fixture(text: &str) -> Result<Structure, String> {
    let tokens = text.split_whitespace().collect::<Vec<_>>();
    let mut cursor = 0;
    let atom_count = tokens
        .get(cursor)
        .ok_or("fixture has no atom count")?
        .parse::<usize>()
        .map_err(|error| error.to_string())?;
    cursor += 1;
    let mut cell_a = [[0.0; 3]; 3];
    for row in &mut cell_a {
        for value in row {
            *value = tokens
                .get(cursor)
                .ok_or("fixture cell is truncated")?
                .parse::<f64>()
                .map_err(|error| error.to_string())?;
            cursor += 1;
        }
    }
    let mut atomic_numbers = Vec::with_capacity(atom_count);
    let mut positions_a = Vec::with_capacity(atom_count);
    for _ in 0..atom_count {
        let element = *tokens.get(cursor).ok_or("fixture atom row is missing")?;
        cursor += 1;
        if element != "Si" {
            return Err(format!(
                "unexpected element in fixed scale fixture: {element}"
            ));
        }
        atomic_numbers.push(14);
        let mut position = [0.0; 3];
        for value in &mut position {
            *value = tokens
                .get(cursor)
                .ok_or("fixture coordinate row is truncated")?
                .parse::<f64>()
                .map_err(|error| error.to_string())?;
            cursor += 1;
        }
        positions_a.push(position);
    }
    if cursor != tokens.len() {
        return Err("fixture has trailing values".into());
    }
    let structure = Structure {
        atomic_numbers,
        positions_a,
        cell_a,
        pbc: [true; 3],
    };
    structure.validate()?;
    Ok(structure)
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let model_path = std::env::var_os("MACER_NEP89_MODEL")
        .ok_or("set MACER_NEP89_MODEL to the external pinned checkpoint")?;
    let model_bytes = fs::read(&model_path)?;
    let mut model = Nep4ZblModel::from_bytes(&model_bytes)?;
    if model.source_sha256 != NEP89_REFERENCE_SHA256 || model_bytes.len() != NEP89_REFERENCE_BYTES {
        return Err("model does not match the pinned NEP89 checkpoint".into());
    }
    let root = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../..");
    let input_path = std::env::args_os()
        .nth(1)
        .map(PathBuf::from)
        .unwrap_or_else(|| root.join("reference/fixtures/nep89/si64_supercell2.input"));
    let initial = parse_fixture(&fs::read_to_string(&input_path)?)?;
    let mut settings = RelaxSettings::default();
    settings.max_steps = 500;
    let input = InputIdentity {
        atoms: initial.atomic_numbers.len(),
        cell_a: initial.cell_a,
        pbc: initial.pbc,
    };
    let mut session = RelaxSession::new(initial, settings.clone())?;
    let mut snapshots = Vec::new();
    loop {
        let snapshot = session.advance(&mut model)?;
        let done = snapshot.status != RelaxStatus::Running;
        snapshots.push(snapshot);
        if done {
            break;
        }
    }
    let final_snapshot = snapshots.last().ok_or("Relax emitted no snapshots")?;
    if final_snapshot.status != RelaxStatus::Converged {
        return Err(format!(
            "64-atom reference did not converge: status={:?}, step={}, fmax={}, stress={:?}",
            final_snapshot.status,
            final_snapshot.step,
            final_snapshot.max_force_ev_per_a,
            final_snapshot.max_stress_residual_gpa
        )
        .into());
    }
    let report = Report {
        schema: "macer-nep89-browser-scale-native-reference-v1",
        input,
        model: ModelIdentity {
            bytes: model_bytes.len(),
            sha256: model.source_sha256,
        },
        settings,
        snapshots,
    };
    let json = serde_json::to_string_pretty(&report)?;
    if let Some(output_path) = std::env::args_os().nth(2) {
        fs::write(output_path, format!("{json}\n"))?;
    } else {
        println!("{json}");
    }
    Ok(())
}
