use macer_rust_core::types::Structure;
use macer_rust_nep::nep89::{Nep4ZblModel, NEP89_REFERENCE_BYTES, NEP89_REFERENCE_SHA256};
use macer_rust_relax::{RelaxSession, RelaxSettings, RelaxStatus};
use serde::Serialize;
use std::fs;
use std::path::{Path, PathBuf};

#[derive(Serialize)]
struct FixtureResult {
    name: &'static str,
    settings: RelaxSettings,
    snapshots: Vec<macer_rust_relax::RelaxSnapshot>,
}

#[derive(Serialize)]
struct Report {
    schema: &'static str,
    model: ModelIdentity,
    cases: Vec<FixtureResult>,
}

#[derive(Serialize)]
struct ModelIdentity {
    bytes: usize,
    sha256: String,
}

fn parse_fixture(text: &str, pbc: [bool; 3], model: &Nep4ZblModel) -> Result<Structure, String> {
    let tokens = text.split_whitespace().collect::<Vec<_>>();
    let mut cursor = 0;
    let atom_count = tokens
        .get(cursor)
        .ok_or("fixture has no atom count")?
        .parse::<usize>()
        .map_err(|error| error.to_string())?;
    cursor += 1;
    let mut cell_a = [[0.0; 3]; 3];
    for row in &mut cell_a {
        for value in row {
            *value = tokens
                .get(cursor)
                .ok_or("fixture cell is truncated")?
                .parse::<f64>()
                .map_err(|error| error.to_string())?;
            cursor += 1;
        }
    }
    let mut atomic_numbers = Vec::with_capacity(atom_count);
    let mut positions_a = Vec::with_capacity(atom_count);
    for _ in 0..atom_count {
        let symbol = *tokens.get(cursor).ok_or("fixture is missing an atom")?;
        cursor += 1;
        let type_index = model
            .config
            .element_symbols
            .iter()
            .position(|candidate| candidate == symbol)
            .ok_or_else(|| format!("fixture element {symbol} is absent from the model"))?;
        let atomic_number = model.config.atomic_numbers[type_index];
        atomic_numbers.push(atomic_number);
        let mut position = [0.0; 3];
        for value in &mut position {
            *value = tokens
                .get(cursor)
                .ok_or("fixture is missing an atom coordinate")?
                .parse::<f64>()
                .map_err(|error| error.to_string())?;
            cursor += 1;
        }
        positions_a.push(position);
    }
    if cursor != tokens.len() {
        return Err("fixture has trailing values".into());
    }
    let structure = Structure {
        atomic_numbers,
        positions_a,
        cell_a,
        pbc,
    };
    structure.validate()?;
    Ok(structure)
}

fn settings(max_steps: usize, movable: Vec<[bool; 3]>) -> RelaxSettings {
    RelaxSettings {
        max_steps,
        fmax_ev_per_a: 1.0e-8,
        smax_gpa: 1.0e-8,
        optimize_cell_shape: false,
        optimize_cell_volume: false,
        fractional_constraints: false,
        movable,
        ..RelaxSettings::default()
    }
}

fn run_case(
    model: &mut Nep4ZblModel,
    fixture_path: &Path,
    name: &'static str,
    pbc: [bool; 3],
    settings: RelaxSettings,
) -> Result<FixtureResult, String> {
    let initial = parse_fixture(
        &fs::read_to_string(fixture_path).map_err(|e| e.to_string())?,
        pbc,
        model,
    )?;
    let mut session = RelaxSession::new(initial, settings.clone())?;
    let mut snapshots = Vec::with_capacity(settings.max_steps + 1);
    loop {
        let snapshot = session.advance(model)?;
        let is_complete = snapshot.status != RelaxStatus::Running;
        snapshots.push(snapshot);
        if is_complete {
            break;
        }
    }
    let last = snapshots.last().ok_or("relax emitted no snapshots")?;
    if last.status != RelaxStatus::MaxSteps || last.step != settings.max_steps {
        return Err(format!(
            "{name}: expected max_steps at {}, received {:?} at step {}",
            settings.max_steps, last.status, last.step
        ));
    }
    Ok(FixtureResult {
        name,
        settings,
        snapshots,
    })
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let model_path = std::env::var_os("MACER_NEP89_MODEL")
        .ok_or("set MACER_NEP89_MODEL to the external pinned checkpoint")?;
    let model_bytes = fs::read(&model_path)?;
    let mut model = Nep4ZblModel::from_bytes(&model_bytes)?;
    if model.source_sha256 != NEP89_REFERENCE_SHA256 || model_bytes.len() != NEP89_REFERENCE_BYTES {
        return Err("model does not match the pinned NEP89 checkpoint".into());
    }

    let root = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../..");
    let fixtures = root.join("reference/fixtures/nep89");
    let mut cases = Vec::with_capacity(5);
    let mixed_initial = parse_fixture(
        &fs::read_to_string(fixtures.join("skew_mixed.input"))?,
        [true; 3],
        &model,
    )?;
    let mut mixed_mask = vec![[false; 3]; mixed_initial.atomic_numbers.len()];
    mixed_mask[0][0] = true;
    cases.push(run_case(
        &mut model,
        &fixtures.join("skew_mixed.input"),
        "mixed_triclinic_fixed_cell_atom0_x",
        [true; 3],
        settings(2, mixed_mask),
    )?);
    cases.push(run_case(
        &mut model,
        &fixtures.join("skew_mixed.input"),
        "mixed_triclinic_fixed_cell_all_positions",
        [true; 3],
        settings(2, vec![[true; 3]; mixed_initial.atomic_numbers.len()]),
    )?);
    let mut mixed_poscar_mask = vec![[false; 3]; mixed_initial.atomic_numbers.len()];
    mixed_poscar_mask[0][0] = true;
    let mut mixed_poscar_settings = settings(2, mixed_poscar_mask);
    mixed_poscar_settings.fractional_constraints = true;
    cases.push(run_case(
        &mut model,
        &fixtures.join("skew_mixed.input"),
        "mixed_triclinic_poscar_a_axis_only",
        [true; 3],
        mixed_poscar_settings,
    )?);
    cases.push(run_case(
        &mut model,
        &fixtures.join("zbl_si2.input"),
        "zbl_si2_fixed_cell",
        [true; 3],
        settings(2, Vec::new()),
    )?);
    cases.push(run_case(
        &mut model,
        &fixtures.join("nonperiodic_mixed.input"),
        "mixed_cluster_nonperiodic_fixed_zero_cell",
        [false; 3],
        settings(1, Vec::new()),
    )?);
    let al_initial = parse_fixture(
        &fs::read_to_string(fixtures.join("al_fcc.input"))?,
        [true; 3],
        &model,
    )?;
    cases.push(run_case(
        &mut model,
        &fixtures.join("al_fcc.input"),
        "al_fcc_fixed_cell_positions",
        [true; 3],
        settings(2, vec![[true; 3]; al_initial.atomic_numbers.len()]),
    )?);

    let requested_case = std::env::args_os().nth(2);
    if let Some(requested_case) = requested_case {
        let requested_case = requested_case.to_string_lossy();
        cases.retain(|case| case.name == requested_case);
        if cases.is_empty() {
            return Err(format!("unknown reference case {requested_case}").into());
        }
    }

    let report = Report {
        schema: "macer-nep89-relax-fixture-native-reference-v1",
        model: ModelIdentity {
            bytes: model_bytes.len(),
            sha256: model.source_sha256,
        },
        cases,
    };
    let json = serde_json::to_string_pretty(&report)?;
    if let Some(output_path) = std::env::args_os().nth(1) {
        fs::write(output_path, format!("{json}\n"))?;
    } else {
        println!("{json}");
    }
    Ok(())
}
