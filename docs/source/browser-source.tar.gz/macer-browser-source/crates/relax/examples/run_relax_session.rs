use candle_core::Device;
use macer_rust_core::types::Structure;
use macer_rust_model::evaluation::Evaluator;
use macer_rust_relax::{RelaxSession, RelaxSettings, RelaxStatus};
use std::{env, fs, process};

fn main() {
    if let Err(error) = run() {
        eprintln!("run_relax_session: {error}");
        process::exit(2);
    }
}

fn run() -> Result<(), String> {
    let args = env::args().skip(1).collect::<Vec<_>>();
    if args.len() != 4 {
        return Err("usage: run_relax_session <structure.json> <settings.json> <manifest.json> <weights.safetensors>".into());
    }
    let structure: Structure =
        serde_json::from_slice(&fs::read(&args[0]).map_err(|e| e.to_string())?)
            .map_err(|e| e.to_string())?;
    let settings: RelaxSettings =
        serde_json::from_slice(&fs::read(&args[1]).map_err(|e| e.to_string())?)
            .map_err(|e| e.to_string())?;
    let manifest = fs::read(&args[2]).map_err(|e| e.to_string())?;
    let weights = fs::read(&args[3]).map_err(|e| e.to_string())?;
    let mut evaluator = Evaluator::from_bytes(&manifest, &weights, Device::Cpu)?;
    let mut session = RelaxSession::new(structure, settings)?;
    loop {
        let snapshot = session.advance(&mut evaluator)?;
        println!(
            "{}",
            serde_json::to_string(&snapshot).map_err(|e| e.to_string())?
        );
        if snapshot.status != RelaxStatus::Running {
            break;
        }
    }
    Ok(())
}
