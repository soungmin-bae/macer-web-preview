use crate::OptimizerKind;

type Vector = Vec<[f64; 3]>;

fn dot(a: &[[f64; 3]], b: &[[f64; 3]]) -> f64 {
    a.iter()
        .flatten()
        .zip(b.iter().flatten())
        .map(|(a, b)| a * b)
        .sum()
}

fn difference(a: &[[f64; 3]], b: &[[f64; 3]]) -> Vector {
    a.iter()
        .zip(b)
        .map(|(a, b)| std::array::from_fn(|i| a[i] - b[i]))
        .collect()
}

fn axpy(target: &mut [[f64; 3]], scale: f64, source: &[[f64; 3]]) {
    for (target, source) in target.iter_mut().flatten().zip(source.iter().flatten()) {
        *target += scale * source;
    }
}

#[derive(Default)]
pub(crate) struct GradientOptimizer {
    previous: Option<(Vector, Vector)>,
    direction: Vector,
    pairs: std::collections::VecDeque<(Vector, Vector, f64)>,
}

impl GradientOptimizer {
    pub(crate) fn direction(
        &mut self,
        kind: OptimizerKind,
        x: &[[f64; 3]],
        force: &[[f64; 3]],
    ) -> Vector {
        let mut direction = force.to_vec();
        let mut scale = 0.1;
        if let Some((old_x, old_force)) = &self.previous {
            let s = difference(x, old_x);
            let y = difference(old_force, force);
            let curvature = dot(&s, &y);
            let yy = dot(&y, &y);
            if curvature > 1e-10 * (dot(&s, &s) * yy).sqrt() && yy > 0.0 {
                scale = (curvature / yy).clamp(1e-5, 10.0);
                if kind == OptimizerKind::Lbfgs {
                    if self.pairs.len() == 8 {
                        self.pairs.pop_front();
                    }
                    self.pairs.push_back((s, y.clone(), 1.0 / curvature));
                }
            }
            if kind == OptimizerKind::Cg {
                let norm = dot(old_force, old_force);
                if norm > 0.0 {
                    let beta = (-dot(force, &y) / norm).clamp(0.0, 5.0);
                    axpy(&mut direction, beta, &self.direction);
                }
            }
        }
        if kind == OptimizerKind::Lbfgs {
            let mut alpha = Vec::with_capacity(self.pairs.len());
            for (s, y, rho) in self.pairs.iter().rev() {
                let a = rho * dot(s, &direction);
                alpha.push(a);
                axpy(&mut direction, -a, y);
            }
            for value in direction.iter_mut().flatten() {
                *value *= scale;
            }
            for ((s, y, rho), a) in self.pairs.iter().zip(alpha.into_iter().rev()) {
                let b = rho * dot(y, &direction);
                axpy(&mut direction, a - b, s);
            }
        }
        if !direction.iter().flatten().all(|v| v.is_finite())
            || dot(force, &direction) <= 1e-12 * dot(force, force)
        {
            direction = force.to_vec();
            self.pairs.clear();
        }
        self.previous = Some((x.to_vec(), force.to_vec()));
        self.direction = direction.clone();
        if kind == OptimizerKind::Cg {
            for value in direction.iter_mut().flatten() {
                *value *= scale;
            }
        }
        let largest = direction
            .iter()
            .flatten()
            .map(|v| v.abs())
            .fold(0., f64::max);
        if largest > 0.12 {
            for value in direction.iter_mut().flatten() {
                *value *= 0.12 / largest;
            }
        }
        direction
    }
}
