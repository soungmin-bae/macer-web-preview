//! Small-matrix implementation of ASE 3.26's FrechetCellFilter contract.
//!
//! The optimizer coordinates are Cartesian atomic positions in the reference
//! cell followed by `N * log(deformation_gradient)`. This keeps the relaxation
//! independent from Python/SciPy while preserving ASE's cell-force transform.

use macer_rust_core::types::{Evaluation, Structure};

type Mat3 = [[f64; 3]; 3];

const IDENTITY: Mat3 = [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]];

pub struct FrechetCellFilter {
    reference: Structure,
    pressure_ev_per_a3: f64,
    mask: Mat3,
    exp_cell_factor: f64,
    constant_volume: bool,
    hydrostatic_strain: bool,
    fixed_positions: bool,
    atom_movable: Vec<[bool; 3]>,
    fractional_constraints: bool,
}

impl FrechetCellFilter {
    pub fn new(
        reference: &Structure,
        pressure_ev_per_a3: f64,
        fix_axis: &[String],
        constant_volume: bool,
        hydrostatic_strain: bool,
        fixed_positions: bool,
    ) -> Self {
        let mut mask = [[1.0; 3]; 3];
        for axis in fix_axis {
            let row = match axis.to_ascii_lowercase().as_str() {
                "a" => Some(0),
                "b" => Some(1),
                "c" => Some(2),
                _ => None,
            };
            if let Some(row) = row {
                mask[row] = [0.0; 3];
            }
        }
        Self {
            reference: reference.clone(),
            pressure_ev_per_a3,
            mask,
            exp_cell_factor: reference.atomic_numbers.len() as f64,
            constant_volume,
            hydrostatic_strain,
            fixed_positions,
            atom_movable: vec![[true; 3]; reference.atomic_numbers.len()],
            fractional_constraints: false,
        }
    }

    pub fn with_atom_constraints(
        mut self,
        movable: Vec<[bool; 3]>,
        fractional_constraints: bool,
    ) -> Result<Self, String> {
        if !movable.is_empty() && movable.len() != self.reference.atomic_numbers.len() {
            return Err("constraint count must match the atom count".into());
        }
        if !movable.is_empty() {
            self.atom_movable = movable;
        }
        self.fractional_constraints = fractional_constraints;
        Ok(self)
    }

    pub fn initial_coordinates(&self) -> Vec<[f64; 3]> {
        let mut coordinates = self.reference.positions_a.clone();
        coordinates.extend([[0.0; 3]; 3]);
        coordinates
    }

    pub fn apply_coordinates(
        &self,
        coordinates: &[[f64; 3]],
    ) -> Result<(Structure, Vec<[f64; 3]>), String> {
        let atoms = self.reference.atomic_numbers.len();
        if coordinates.len() != atoms + 3 {
            return Err("cell-filter coordinate count must be atom count plus three".into());
        }
        let log_deformation = rows_to_mat3(&coordinates[atoms..])
            .map(|row| row.map(|value| value / self.exp_cell_factor));
        let deformation_gradient = matrix_exp(log_deformation)?;
        let mut deformation = transpose(subtract(deformation_gradient, IDENTITY));
        for i in 0..3 {
            for j in 0..3 {
                deformation[i][j] *= self.mask[i][j];
            }
        }
        let cell_transform = add(IDENTITY, deformation);
        let mut structure = self.reference.clone();
        structure.cell_a = multiply(self.reference.cell_a, cell_transform);
        structure.positions_a = coordinates[..atoms]
            .iter()
            .map(|&position| row_multiply(position, cell_transform))
            .collect();
        structure.validate()?;
        // ASE UnitCellFilter reads its optimizer coordinates back from the
        // projected cell after every set_positions call. Recompute the log
        // deformation here so fixed lattice axes remain exactly constrained.
        let actual_deformation_gradient = transpose(cell_transform);
        let actual_log_deformation = matrix_log(actual_deformation_gradient)?;
        let inverse_cell_transform = inverse(cell_transform)?;
        let mut normalized_coordinates = coordinates.to_vec();
        for (coordinate, position) in normalized_coordinates[..atoms]
            .iter_mut()
            .zip(&structure.positions_a)
        {
            *coordinate = row_multiply(*position, inverse_cell_transform);
        }
        for (row, log_row) in normalized_coordinates[atoms..]
            .iter_mut()
            .zip(actual_log_deformation)
        {
            *row = log_row.map(|value| value * self.exp_cell_factor);
        }
        Ok((structure, normalized_coordinates))
    }

    pub fn coordinates_for_structure(
        &self,
        structure: &Structure,
    ) -> Result<Vec<[f64; 3]>, String> {
        if structure.atomic_numbers != self.reference.atomic_numbers
            || structure.pbc != self.reference.pbc
        {
            return Err(
                "external cell-relax structure changed atom identity or periodicity".into(),
            );
        }
        structure.validate()?;
        let cell_transform = multiply(inverse(self.reference.cell_a)?, structure.cell_a);
        let inverse_transform = inverse(cell_transform)?;
        let log_deformation = matrix_log(transpose(cell_transform))?;
        let mut coordinates = structure
            .positions_a
            .iter()
            .map(|&position| row_multiply(position, inverse_transform))
            .collect::<Vec<_>>();
        coordinates
            .extend(log_deformation.map(|row| row.map(|value| value * self.exp_cell_factor)));
        Ok(coordinates)
    }

    pub fn forces(
        &self,
        structure: &Structure,
        evaluation: &Evaluation,
        coordinates: &[[f64; 3]],
    ) -> Result<Vec<[f64; 3]>, String> {
        let atoms = structure.atomic_numbers.len();
        if coordinates.len() != atoms + 3 || evaluation.forces_ev_per_a.len() != atoms {
            return Err("cell-filter force input dimensions do not match the structure".into());
        }
        let log_deformation = rows_to_mat3(&coordinates[atoms..])
            .map(|row| row.map(|value| value / self.exp_cell_factor));
        let deformation_gradient = matrix_exp(log_deformation)?;
        let volume = structure.signed_volume_a3().abs();
        if !volume.is_finite() || volume < 1.0e-12 {
            return Err("cell filter requires a finite nonzero cell volume".into());
        }

        let mut virial = evaluation.stress_ev_per_a3;
        for i in 0..3 {
            for j in 0..3 {
                virial[i][j] *= -volume;
            }
            virial[i][i] -= volume * self.pressure_ev_per_a3;
        }
        if self.hydrostatic_strain {
            virial = project_hydrostatic(virial);
        }
        for i in 0..3 {
            for j in 0..3 {
                virial[i][j] *= self.mask[i][j];
            }
        }

        // ASE UnitCellFilter uses virial @ inv(deformation_gradient.T) before
        // FrechetCellFilter applies the derivative of exp(log(F)).
        let inverse_transpose = transpose(inverse(deformation_gradient)?);
        let cell_gradient = multiply(virial, inverse_transpose);
        let mut combined = vec![[0.0; 3]; atoms + 3];
        for (atom, (result, force)) in combined[..atoms]
            .iter_mut()
            .zip(&evaluation.forces_ev_per_a)
            .enumerate()
        {
            if !self.fixed_positions {
                let transformed = row_multiply(*force, deformation_gradient);
                let mask = self.atom_movable[atom];
                *result = if self.fractional_constraints {
                    project_fractional_force(transformed, mask, self.reference.cell_a)?
                } else {
                    std::array::from_fn(|axis| if mask[axis] { transformed[axis] } else { 0.0 })
                };
            }
        }
        for mu in 0..3 {
            for nu in 0..3 {
                let mut direction = [[0.0; 3]; 3];
                direction[mu][nu] = 1.0;
                let derivative = matrix_exp_frechet_only(log_deformation, direction)?;
                combined[atoms + mu][nu] =
                    matrix_inner_product(derivative, cell_gradient) / self.exp_cell_factor;
            }
        }
        if self.constant_volume {
            // ASE FrechetCellFilter projects the logarithmic cell force onto
            // the trace-free subspace after applying the Frechet derivative.
            project_diagonal_trace(&mut combined[atoms..]);
        }
        Ok(combined)
    }

    pub fn physical_stress_residual_max(&self, evaluation: &Evaluation) -> (f64, f64) {
        let stress = evaluation.stress_ev_per_a3;
        let residual = (0..3)
            .map(|axis| (stress[axis][axis] + self.pressure_ev_per_a3).abs())
            .chain([stress[1][2].abs(), stress[0][2].abs(), stress[0][1].abs()])
            .fold(0.0, f64::max);
        let pressure_gpa = -((stress[0][0] + stress[1][1] + stress[2][2]) / 3.0) * 160.217_662_08;
        (residual, pressure_gpa)
    }
}

fn project_diagonal_trace(rows: &mut [[f64; 3]]) {
    let trace = rows[0][0] + rows[1][1] + rows[2][2];
    let mean = trace / 3.0;
    for axis in 0..3 {
        rows[axis][axis] -= mean;
    }
}

fn project_hydrostatic(matrix: Mat3) -> Mat3 {
    let mean = (matrix[0][0] + matrix[1][1] + matrix[2][2]) / 3.0;
    [[mean, 0.0, 0.0], [0.0, mean, 0.0], [0.0, 0.0, mean]]
}

fn rows_to_mat3(rows: &[[f64; 3]]) -> Mat3 {
    [rows[0], rows[1], rows[2]]
}

pub(crate) fn matrix_exp(matrix: Mat3) -> Result<Mat3, String> {
    matrix_exp_frechet(matrix, [[0.0; 3]; 3]).map(|(value, _)| value)
}

pub(crate) fn matrix_log(matrix: Mat3) -> Result<Mat3, String> {
    if matrix.iter().flatten().any(|value| !value.is_finite()) {
        return Err("cell deformation contains a non-finite value".into());
    }
    let mut reduced = matrix;
    let mut square_roots = 0u32;
    while matrix_norm(subtract(reduced, IDENTITY)) > 0.25 {
        if square_roots >= 20 {
            return Err("cell deformation logarithm did not converge near identity".into());
        }
        reduced = matrix_sqrt(reduced)?;
        square_roots += 1;
    }

    // log(A) = 2 atanh((A-I)(A+I)^-1), after inverse scaling by square roots.
    let z = multiply(
        subtract(reduced, IDENTITY),
        inverse(add(reduced, IDENTITY))?,
    );
    let z_squared = multiply(z, z);
    let mut term = z;
    let mut sum = z;
    let mut converged = matrix_norm(term) <= 2.0e-17;
    for order in 1..=200 {
        term = multiply(term, z_squared);
        let contribution = matrix_scale(term, 1.0 / (2 * order + 1) as f64);
        sum = add(sum, contribution);
        if matrix_norm(contribution) <= 2.0e-17 {
            converged = true;
            break;
        }
    }
    if !converged {
        return Err("cell deformation logarithm series did not converge".into());
    }
    Ok(matrix_scale(sum, 2.0 * 2.0_f64.powi(square_roots as i32)))
}

fn matrix_sqrt(matrix: Mat3) -> Result<Mat3, String> {
    let mut y = matrix;
    let mut z = IDENTITY;
    for _ in 0..100 {
        let next_y = matrix_scale(add(y, inverse(z)?), 0.5);
        let next_z = matrix_scale(add(z, inverse(y)?), 0.5);
        let difference = matrix_norm(subtract(next_y, y)).max(matrix_norm(subtract(next_z, z)));
        y = next_y;
        z = next_z;
        if difference <= 2.0e-16 {
            if y.iter().flatten().all(|value| value.is_finite()) {
                return Ok(y);
            }
            break;
        }
    }
    Err("cell deformation matrix square root did not converge".into())
}

fn matrix_exp_frechet(matrix: Mat3, direction: Mat3) -> Result<(Mat3, Mat3), String> {
    if matrix.iter().flatten().any(|value| !value.is_finite())
        || direction.iter().flatten().any(|value| !value.is_finite())
    {
        return Err("cell deformation contains a non-finite value".into());
    }
    let norm = matrix_norm(matrix);
    let squarings = if norm <= 0.5 {
        0
    } else {
        (norm / 0.5).log2().ceil().max(0.0) as u32
    };
    if squarings > 60 {
        return Err("cell deformation is too large for a stable matrix exponential".into());
    }
    let scale = 2.0_f64.powi(squarings as i32);
    let scaled = matrix_scale(matrix, 1.0 / scale);
    let scaled_direction = matrix_scale(direction, 1.0 / scale);

    let mut value = IDENTITY;
    let mut term = IDENTITY;
    let mut derivative = [[0.0; 3]; 3];
    let mut derivative_term = [[0.0; 3]; 3];
    let mut converged = false;
    for order in 1..=100 {
        let divisor = order as f64;
        let next_term = matrix_scale(multiply(term, scaled), 1.0 / divisor);
        let next_derivative = matrix_scale(
            add(
                multiply(derivative_term, scaled),
                multiply(term, scaled_direction),
            ),
            1.0 / divisor,
        );
        value = add(value, next_term);
        derivative = add(derivative, next_derivative);
        if matrix_norm(next_term) <= 2.0e-17 && matrix_norm(next_derivative) <= 2.0e-17 {
            converged = true;
            break;
        }
        term = next_term;
        derivative_term = next_derivative;
    }
    if !converged {
        return Err("matrix exponential series did not converge".into());
    }
    for _ in 0..squarings {
        derivative = add(multiply(derivative, value), multiply(value, derivative));
        value = multiply(value, value);
    }
    if value.iter().flatten().any(|entry| !entry.is_finite())
        || derivative.iter().flatten().any(|entry| !entry.is_finite())
    {
        return Err("cell deformation exponential overflowed".into());
    }
    Ok((value, derivative))
}

fn matrix_exp_frechet_only(matrix: Mat3, direction: Mat3) -> Result<Mat3, String> {
    matrix_exp_frechet(matrix, direction).map(|(_, derivative)| derivative)
}

fn matrix_norm(matrix: Mat3) -> f64 {
    matrix
        .iter()
        .map(|row| row.iter().map(|value| value.abs()).sum::<f64>())
        .fold(0.0, f64::max)
}

fn matrix_inner_product(left: Mat3, right: Mat3) -> f64 {
    (0..3)
        .flat_map(|i| (0..3).map(move |j| left[i][j] * right[i][j]))
        .sum()
}

fn add(left: Mat3, right: Mat3) -> Mat3 {
    std::array::from_fn(|i| std::array::from_fn(|j| left[i][j] + right[i][j]))
}

fn subtract(left: Mat3, right: Mat3) -> Mat3 {
    std::array::from_fn(|i| std::array::from_fn(|j| left[i][j] - right[i][j]))
}

fn matrix_scale(matrix: Mat3, scale: f64) -> Mat3 {
    matrix.map(|row| row.map(|value| value * scale))
}

fn multiply(left: Mat3, right: Mat3) -> Mat3 {
    std::array::from_fn(|i| std::array::from_fn(|j| (0..3).map(|k| left[i][k] * right[k][j]).sum()))
}

fn transpose(matrix: Mat3) -> Mat3 {
    std::array::from_fn(|i| std::array::from_fn(|j| matrix[j][i]))
}

fn row_multiply(row: [f64; 3], matrix: Mat3) -> [f64; 3] {
    std::array::from_fn(|j| (0..3).map(|i| row[i] * matrix[i][j]).sum())
}

pub(crate) fn project_fractional_force(
    force: [f64; 3],
    movable: [bool; 3],
    cell: Mat3,
) -> Result<[f64; 3], String> {
    if movable.iter().all(|&is_movable| is_movable) {
        return Ok(force);
    }
    let axes = (0..3).filter(|&axis| movable[axis]).collect::<Vec<_>>();
    if axes.is_empty() {
        return Ok([0.0; 3]);
    }

    // FIRE updates Cartesian optimizer coordinates. A Selective Dynamics mask
    // instead defines a tangent space spanned by the enabled lattice vectors.
    // Project the Cartesian force orthogonally into that span so each update
    // has exactly zero displacement along every fixed fractional coordinate.
    let mut gram = [[0.0; 3]; 3];
    let mut right = [0.0; 3];
    for (i, &axis_i) in axes.iter().enumerate() {
        right[i] = dot(cell[axis_i], force);
        for (j, &axis_j) in axes.iter().enumerate() {
            gram[i][j] = dot(cell[axis_i], cell[axis_j]);
        }
    }
    let coefficients = solve_small(gram, right, axes.len())?;
    let mut projected = [0.0; 3];
    for (i, &axis) in axes.iter().enumerate() {
        for xyz in 0..3 {
            projected[xyz] += coefficients[i] * cell[axis][xyz];
        }
    }
    Ok(projected)
}

fn dot(left: [f64; 3], right: [f64; 3]) -> f64 {
    (0..3).map(|axis| left[axis] * right[axis]).sum()
}

fn solve_small(
    mut matrix: [[f64; 3]; 3],
    mut right: [f64; 3],
    size: usize,
) -> Result<[f64; 3], String> {
    let scale = (0..size)
        .map(|axis| matrix[axis][axis].abs())
        .fold(0.0, f64::max);
    if !scale.is_finite() || scale <= 0.0 {
        return Err("fractional constraint basis is singular".into());
    }
    for column in 0..size {
        let pivot = (column..size)
            .max_by(|&left, &right| {
                matrix[left][column]
                    .abs()
                    .total_cmp(&matrix[right][column].abs())
            })
            .unwrap();
        if !matrix[pivot][column].is_finite() || matrix[pivot][column].abs() <= scale * 1.0e-14 {
            return Err("fractional constraint basis is singular or ill-conditioned".into());
        }
        matrix.swap(column, pivot);
        right.swap(column, pivot);
        let diagonal = matrix[column][column];
        for j in column..size {
            matrix[column][j] /= diagonal;
        }
        right[column] /= diagonal;
        for row in 0..size {
            if row == column {
                continue;
            }
            let factor = matrix[row][column];
            for j in column..size {
                matrix[row][j] -= factor * matrix[column][j];
            }
            right[row] -= factor * right[column];
        }
    }
    if right[..size].iter().any(|value| !value.is_finite()) {
        return Err("fractional force projection produced a non-finite value".into());
    }
    Ok(right)
}

fn inverse(matrix: Mat3) -> Result<Mat3, String> {
    let determinant = matrix[0][0] * (matrix[1][1] * matrix[2][2] - matrix[1][2] * matrix[2][1])
        - matrix[0][1] * (matrix[1][0] * matrix[2][2] - matrix[1][2] * matrix[2][0])
        + matrix[0][2] * (matrix[1][0] * matrix[2][1] - matrix[1][1] * matrix[2][0]);
    if !determinant.is_finite() || determinant.abs() < 1.0e-14 {
        return Err("cell deformation matrix is singular".into());
    }
    Ok([
        [
            (matrix[1][1] * matrix[2][2] - matrix[1][2] * matrix[2][1]) / determinant,
            (matrix[0][2] * matrix[2][1] - matrix[0][1] * matrix[2][2]) / determinant,
            (matrix[0][1] * matrix[1][2] - matrix[0][2] * matrix[1][1]) / determinant,
        ],
        [
            (matrix[1][2] * matrix[2][0] - matrix[1][0] * matrix[2][2]) / determinant,
            (matrix[0][0] * matrix[2][2] - matrix[0][2] * matrix[2][0]) / determinant,
            (matrix[0][2] * matrix[1][0] - matrix[0][0] * matrix[1][2]) / determinant,
        ],
        [
            (matrix[1][0] * matrix[2][1] - matrix[1][1] * matrix[2][0]) / determinant,
            (matrix[0][1] * matrix[2][0] - matrix[0][0] * matrix[2][1]) / determinant,
            (matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0]) / determinant,
        ],
    ])
}

#[cfg(test)]
mod tests {
    use super::{
        inverse, matrix_exp, matrix_exp_frechet_only, matrix_log, project_diagonal_trace,
        project_fractional_force, project_hydrostatic, row_multiply, IDENTITY,
    };

    fn max_diff(a: [[f64; 3]; 3], b: [[f64; 3]; 3]) -> f64 {
        (0..3)
            .flat_map(|i| (0..3).map(move |j| (a[i][j] - b[i][j]).abs()))
            .fold(0.0, f64::max)
    }

    #[test]
    fn exponential_handles_isotropic_strain() {
        let scale = 0.17_f64.exp();
        let result = matrix_exp([[0.17, 0.0, 0.0], [0.0, 0.17, 0.0], [0.0, 0.0, 0.17]]).unwrap();
        assert!(
            max_diff(
                result,
                [[scale, 0.0, 0.0], [0.0, scale, 0.0], [0.0, 0.0, scale]]
            ) < 1e-15
        );
    }

    #[test]
    fn frechet_derivative_matches_centered_finite_difference() {
        let a = [[0.04, 0.03, 0.0], [-0.01, -0.02, 0.02], [0.0, 0.01, 0.03]];
        let direction = [[0.0, 1.0, 0.0], [0.0, 0.0, 0.0], [0.0, 0.0, 0.0]];
        let analytic = matrix_exp_frechet_only(a, direction).unwrap();
        let epsilon = 1.0e-6;
        let plus = matrix_exp(std::array::from_fn(|i| {
            std::array::from_fn(|j| a[i][j] + epsilon * direction[i][j])
        }))
        .unwrap();
        let minus = matrix_exp(std::array::from_fn(|i| {
            std::array::from_fn(|j| a[i][j] - epsilon * direction[i][j])
        }))
        .unwrap();
        let numerical = std::array::from_fn(|i| {
            std::array::from_fn(|j| (plus[i][j] - minus[i][j]) / (2.0 * epsilon))
        });
        assert!(max_diff(analytic, numerical) < 2.0e-10);
    }

    #[test]
    fn zero_strain_exponential_is_identity() {
        assert!(max_diff(matrix_exp([[0.0; 3]; 3]).unwrap(), IDENTITY) < 1.0e-16);
    }

    #[test]
    fn logarithm_inverts_small_nonsymmetric_strain_exponential() {
        let strain = [
            [0.08, 0.025, -0.01],
            [0.005, -0.03, 0.012],
            [0.0, -0.008, 0.04],
        ];
        let round_trip = matrix_log(matrix_exp(strain).unwrap()).unwrap();
        assert!(max_diff(strain, round_trip) < 2.0e-14);
    }

    #[test]
    fn constant_volume_projection_removes_only_the_diagonal_trace() {
        let mut force = [[1.0, 2.0, 3.0], [4.0, 5.0, 6.0], [7.0, 8.0, 9.0]];
        project_diagonal_trace(&mut force);
        assert!((force[0][0] + force[1][1] + force[2][2]).abs() < 1.0e-15);
        assert_eq!(force[0][1], 2.0);
        assert_eq!(force[1][2], 6.0);
        assert_eq!(force[2][0], 7.0);
    }

    #[test]
    fn hydrostatic_projection_keeps_only_mean_diagonal_stress() {
        let result = project_hydrostatic([[3.0, 2.0, -1.0], [4.0, 6.0, 5.0], [7.0, 8.0, 9.0]]);
        assert_eq!(result, [[6.0, 0.0, 0.0], [0.0, 6.0, 0.0], [0.0, 0.0, 6.0]]);
    }

    #[test]
    fn fractional_force_projection_stays_in_enabled_skew_cell_directions() {
        let cell = [[2.0, 0.0, 0.0], [1.0, 1.0, 0.0], [0.2, 0.3, 2.0]];
        let force = [1.0, 0.2, 0.5];
        for movable in [[false, true, false], [true, false, true]] {
            let projected = project_fractional_force(force, movable, cell).unwrap();
            let fractional = row_multiply(projected, inverse(cell).unwrap());
            for axis in 0..3 {
                if !movable[axis] {
                    assert!(fractional[axis].abs() < 1.0e-13, "{fractional:?}");
                }
            }
        }
    }
}
