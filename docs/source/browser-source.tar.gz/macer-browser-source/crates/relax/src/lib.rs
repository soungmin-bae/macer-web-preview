//! Incremental relax state machine shared by native hosts and browser/WASM.
//! The host owns the calculator and calls `advance` once per UI-visible step.

use macer_rust_core::types::{Evaluation, Potential, Structure};
use serde::{Deserialize, Serialize};

pub mod cell_filter;
pub mod symmetry;
use cell_filter::{project_fractional_force, FrechetCellFilter};

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(default)]
pub struct RelaxSettings {
    pub max_steps: usize,
    pub fmax_ev_per_a: f64,
    pub smax_gpa: f64,
    pub pressure_gpa: f64,
    pub optimize_positions: bool,
    pub optimize_cell_shape: bool,
    pub optimize_cell_volume: bool,
    pub fractional_constraints: bool,
    /// When fractional constraints are enabled, `true` allows that lattice-axis
    /// component; otherwise it allows the corresponding Cartesian component.
    pub movable: Vec<[bool; 3]>,
}

impl Default for RelaxSettings {
    fn default() -> Self {
        Self {
            max_steps: 500,
            fmax_ev_per_a: 0.01,
            smax_gpa: 0.1,
            pressure_gpa: 0.0,
            optimize_positions: true,
            optimize_cell_shape: true,
            optimize_cell_volume: true,
            fractional_constraints: false,
            movable: Vec::new(),
        }
    }
}

impl RelaxSettings {
    fn validate(&self, structure: &Structure) -> Result<(), String> {
        let atom_count = structure.atomic_numbers.len();
        if self.max_steps == 0 {
            return Err("maximum relax steps must be greater than zero".into());
        }
        if !self.fmax_ev_per_a.is_finite() || self.fmax_ev_per_a <= 0.0 {
            return Err("force tolerance must be finite and greater than zero".into());
        }
        if !self.smax_gpa.is_finite() || self.smax_gpa <= 0.0 {
            return Err("stress tolerance must be finite and greater than zero".into());
        }
        if !self.pressure_gpa.is_finite() {
            return Err("target pressure must be finite".into());
        }
        if !self.movable.is_empty() && self.movable.len() != atom_count {
            return Err("constraint count must match the atom count".into());
        }
        let has_movable_position = self.optimize_positions
            && (self.movable.is_empty() || self.movable.iter().flatten().any(|&axis| axis));
        if !has_movable_position && !self.optimize_cell_shape && !self.optimize_cell_volume {
            return Err(
                "relax has no movable degrees of freedom; use a single-point evaluation".into(),
            );
        }
        if (self.optimize_cell_shape || self.optimize_cell_volume) && structure.pbc != [true; 3] {
            return Err("cell relaxation requires periodicity on all three axes".into());
        }
        if self.pressure_gpa.abs() > 1.0e-15 && !self.optimize_cell_volume {
            return Err("target pressure requires cell-volume optimization".into());
        }
        Ok(())
    }

    fn projected_forces(
        &self,
        structure: &Structure,
        forces: &[[f64; 3]],
    ) -> Result<Vec<[f64; 3]>, String> {
        forces
            .iter()
            .enumerate()
            .map(|(atom, force)| -> Result<[f64; 3], String> {
                if !self.optimize_positions {
                    return Ok([0.0; 3]);
                }
                let mask = self.movable.get(atom).copied().unwrap_or([true; 3]);
                if self.fractional_constraints && structure.pbc == [true; 3] {
                    project_fractional_force(*force, mask, structure.cell_a)
                } else {
                    Ok(std::array::from_fn(|axis| {
                        if mask[axis] {
                            force[axis]
                        } else {
                            0.0
                        }
                    }))
                }
            })
            .collect()
    }
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub struct RelaxSnapshot {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub symmetry: Option<SymmetryStepReport>,
    pub step: usize,
    pub structure: Structure,
    pub evaluation: Evaluation,
    /// Maximum per-atom norm after projecting onto movable components.
    pub max_force_ev_per_a: f64,
    /// Maximum cell-stress residual over the cell degrees of freedom being
    /// optimized, in GPa. `None` means the cell is fixed and stress is not a
    /// convergence criterion for this run.
    pub max_stress_residual_gpa: Option<f64>,
    pub status: RelaxStatus,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub struct SymmetryStepReport {
    pub position_residual_a: f64,
    pub metric_residual: f64,
    pub maximum_initial_correction_a: f64,
    pub projected_position_degrees_of_freedom: usize,
    pub projected_cell_degrees_of_freedom: usize,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum RelaxStatus {
    Running,
    Converged,
    MaxSteps,
}

#[derive(Clone, Debug)]
pub struct FireOptimizer {
    velocities: Vec<[f64; 3]>,
    initialized: bool,
    dt_fs: f64,
    alpha: f64,
    positive_steps: usize,
}

/// A read-only snapshot of FIRE's internal state for reproducible diagnostics
/// and checkpoint tooling. This is intentionally separate from RelaxSnapshot,
/// whose stable product schema contains only complete physical evaluations.
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub struct FireOptimizerState {
    pub velocities: Vec<[f64; 3]>,
    pub initialized: bool,
    pub dt_fs: f64,
    pub alpha: f64,
    pub positive_steps: usize,
}

impl FireOptimizer {
    pub fn new(atom_count: usize) -> Self {
        Self {
            velocities: vec![[0.0; 3]; atom_count],
            initialized: false,
            dt_fs: 0.1,
            alpha: 0.1,
            positive_steps: 0,
        }
    }

    pub fn state(&self) -> FireOptimizerState {
        FireOptimizerState {
            velocities: self.velocities.clone(),
            initialized: self.initialized,
            dt_fs: self.dt_fs,
            alpha: self.alpha,
            positive_steps: self.positive_steps,
        }
    }

    pub fn step_coordinates(
        &mut self,
        coordinates: &mut [[f64; 3]],
        forces: &[[f64; 3]],
    ) -> Result<(), String> {
        if forces.len() != coordinates.len() || self.velocities.len() != forces.len() {
            return Err("FIRE force count does not match the atom count".into());
        }
        let force_norm = forces.iter().flatten().map(|x| x * x).sum::<f64>().sqrt();
        if !force_norm.is_finite() || force_norm <= 0.0 {
            return Err("FIRE cannot step with a zero or non-finite force norm".into());
        }
        if self.initialized {
            let power = self
                .velocities
                .iter()
                .zip(forces)
                .flat_map(|(v, f)| v.iter().zip(f))
                .map(|(v, f)| v * f)
                .sum::<f64>();
            if power > 0.0 {
                let velocity_norm = self
                    .velocities
                    .iter()
                    .flatten()
                    .map(|x| x * x)
                    .sum::<f64>()
                    .sqrt();
                for (velocity, force) in self.velocities.iter_mut().zip(forces) {
                    for axis in 0..3 {
                        velocity[axis] = (1.0 - self.alpha) * velocity[axis]
                            + self.alpha * force[axis] / force_norm * velocity_norm;
                    }
                }
                if self.positive_steps > 5 {
                    self.dt_fs = (self.dt_fs * 1.1).min(1.0);
                    self.alpha *= 0.99;
                }
                self.positive_steps += 1;
            } else {
                self.velocities.fill([0.0; 3]);
                self.alpha = 0.1;
                self.dt_fs *= 0.5;
                self.positive_steps = 0;
            }
        } else {
            self.initialized = true;
        }
        for (velocity, force) in self.velocities.iter_mut().zip(forces) {
            for axis in 0..3 {
                velocity[axis] += self.dt_fs * force[axis];
            }
        }
        let mut displacement = self
            .velocities
            .iter()
            .map(|velocity| velocity.map(|value| self.dt_fs * value))
            .collect::<Vec<_>>();
        let displacement_norm = displacement
            .iter()
            .flatten()
            .map(|v| v * v)
            .sum::<f64>()
            .sqrt();
        if displacement_norm > 0.1 {
            let scale = 0.1 / displacement_norm;
            for delta in displacement.iter_mut().flatten() {
                *delta *= scale;
            }
        }
        for (position, delta) in coordinates.iter_mut().zip(displacement) {
            for axis in 0..3 {
                position[axis] += delta[axis];
            }
        }
        Ok(())
    }

    pub fn step(&mut self, structure: &mut Structure, forces: &[[f64; 3]]) -> Result<(), String> {
        self.step_coordinates(&mut structure.positions_a, forces)
    }

    fn replace_state(
        &mut self,
        velocities: Vec<[f64; 3]>,
        dt_fs: f64,
        alpha: f64,
        positive_steps: usize,
        initialized: bool,
    ) -> Result<(), String> {
        if velocities.len() != self.velocities.len()
            || velocities.iter().flatten().any(|value| !value.is_finite())
            || !dt_fs.is_finite()
            || dt_fs <= 0.0
            || !alpha.is_finite()
            || !(0.0..=1.0).contains(&alpha)
        {
            return Err("external FIRE state has invalid shape or values".into());
        }
        self.velocities = velocities;
        self.dt_fs = dt_fs;
        self.alpha = alpha;
        self.positive_steps = positive_steps;
        self.initialized = initialized;
        Ok(())
    }
}

/// One completed evaluation per call. The returned structure, energy, forces,
/// and stress always describe the same geometry and can be safely checkpointed.
pub struct RelaxSession {
    structure: Structure,
    settings: RelaxSettings,
    optimizer: FireOptimizer,
    filter: Option<FrechetCellFilter>,
    coordinates: Vec<[f64; 3]>,
    step: usize,
    last_evaluation: Option<Evaluation>,
    evaluation_pending: bool,
    status: RelaxStatus,
    symmetry: Option<symmetry::SymmetryState>,
}

impl RelaxSession {
    pub fn new(structure: Structure, settings: RelaxSettings) -> Result<Self, String> {
        structure.validate()?;
        settings.validate(&structure)?;
        let filter = if settings.optimize_cell_shape || settings.optimize_cell_volume {
            let filter = FrechetCellFilter::new(
                &structure,
                settings.pressure_gpa / 160.217_662_08,
                &[],
                settings.optimize_cell_shape && !settings.optimize_cell_volume,
                !settings.optimize_cell_shape && settings.optimize_cell_volume,
                !settings.optimize_positions,
            )
            .with_atom_constraints(settings.movable.clone(), settings.fractional_constraints)?;
            Some(filter)
        } else {
            None
        };
        let coordinates = filter
            .as_ref()
            .map(FrechetCellFilter::initial_coordinates)
            .unwrap_or_else(|| structure.positions_a.clone());
        Ok(Self {
            optimizer: FireOptimizer::new(coordinates.len()),
            structure,
            settings,
            filter,
            coordinates,
            step: 0,
            last_evaluation: None,
            evaluation_pending: false,
            status: RelaxStatus::Running,
            symmetry: None,
        })
    }

    /// Opt into preserved symmetry before the first evaluation. Legacy sessions
    /// remain byte-for-byte on their old constraint path when this is not called.
    pub fn with_symmetry(
        self,
        operations: symmetry::SymmetryOperations,
        tolerance_a: f64,
    ) -> Result<Self, String> {
        if self.step != 0
            || self.evaluation_pending
            || self.last_evaluation.is_some()
            || self.status != RelaxStatus::Running
        {
            return Err("Symmetry must be frozen before evaluation".into());
        }
        let masks = if self.settings.optimize_positions {
            if self.settings.movable.is_empty() {
                vec![[true; 3]; self.structure.atomic_numbers.len()]
            } else {
                self.settings.movable.clone()
            }
        } else {
            vec![[false; 3]; self.structure.atomic_numbers.len()]
        };
        let state = symmetry::SymmetryState::new(
            &self.structure,
            operations,
            &masks,
            self.settings.fractional_constraints,
            tolerance_a,
        )?;
        if state.projector.degrees_of_freedom() == 0
            && state.projector.cell_degrees_of_freedom(
                self.settings.optimize_cell_shape,
                self.settings.optimize_cell_volume,
            ) == 0
        {
            return Err(
                "No symmetry-allowed degrees of freedom; use a single-point evaluation".into(),
            );
        }
        let mut session = Self::new(state.reference.clone(), self.settings)?;
        session.symmetry = Some(state);
        Ok(session)
    }
    pub fn symmetry_state(&self) -> Option<&symmetry::SymmetryState> {
        self.symmetry.as_ref()
    }

    pub fn structure(&self) -> &Structure {
        &self.structure
    }

    pub fn status(&self) -> RelaxStatus {
        self.status
    }

    /// Return FIRE internals without changing the physical snapshot format.
    pub fn fire_optimizer_state(&self) -> FireOptimizerState {
        self.optimizer.state()
    }

    pub fn advance(&mut self, potential: &mut impl Potential) -> Result<RelaxSnapshot, String> {
        self.prepare_evaluation()?;
        let evaluation = potential.evaluate(&self.structure)?;
        self.accept_evaluation(evaluation)
    }

    /// Prepare the geometry for an asynchronous host calculator (e.g. WebGPU).
    /// Repeated requests before acceptance return the same geometry, so a
    /// failed device evaluation can be retried without a second FIRE update.
    pub fn prepare_evaluation(&mut self) -> Result<&Structure, String> {
        if self.status != RelaxStatus::Running {
            return Err("relax session is already complete".into());
        }
        if self.evaluation_pending {
            return Ok(&self.structure);
        }
        if let Some(evaluation) = self.last_evaluation.as_ref() {
            if let Some(filter) = self.filter.as_ref() {
                let mut forces = filter.forces(&self.structure, evaluation, &self.coordinates)?;
                if let Some(symmetry) = &self.symmetry {
                    symmetry.project_generalized_forces(
                        &mut forces,
                        self.settings.optimize_cell_shape,
                        self.settings.optimize_cell_volume,
                    )?;
                }
                self.optimizer
                    .step_coordinates(&mut self.coordinates, &forces)?;
                if let Some(symmetry) = &self.symmetry {
                    symmetry.project_coordinates(
                        &mut self.coordinates,
                        &mut self.optimizer.velocities,
                        self.settings.optimize_cell_shape,
                        self.settings.optimize_cell_volume,
                    )?;
                }
                let (structure, coordinates) = filter.apply_coordinates(&self.coordinates)?;
                self.structure = structure;
                self.coordinates = coordinates;
            } else {
                let mut projected = self
                    .settings
                    .projected_forces(&self.structure, &evaluation.forces_ev_per_a)?;
                if let Some(symmetry) = &self.symmetry {
                    symmetry.project_generalized_forces(&mut projected, false, false)?;
                }
                self.optimizer
                    .step_coordinates(&mut self.structure.positions_a, &projected)?;
                if let Some(symmetry) = &self.symmetry {
                    symmetry.project_coordinates(
                        &mut self.structure.positions_a,
                        &mut self.optimizer.velocities,
                        false,
                        false,
                    )?;
                }
                self.coordinates = self.structure.positions_a.clone();
            }
            self.step += 1;
        }
        if let Some(symmetry) = &self.symmetry {
            symmetry.check(&self.structure)?;
        }
        self.evaluation_pending = true;
        Ok(&self.structure)
    }

    /// Replace a prepared fixed-cell geometry with the coordinates produced by
    /// an external optimizer such as the browser's device-side FIRE kernel.
    /// The following evaluation is still accepted through this session, so its
    /// snapshot, convergence test, step counter, and CPU final audit stay under
    /// the shared Rust state machine.
    pub fn replace_prepared_positions(&mut self, positions: Vec<[f64; 3]>) -> Result<(), String> {
        if self.symmetry.is_some() {
            return Err("Device-side optimizer replacement bypasses symmetry constraints".into());
        }
        if !self.evaluation_pending || self.status != RelaxStatus::Running {
            return Err("no pending relax geometry is available for coordinate replacement".into());
        }
        if self.filter.is_some() {
            return Err("external coordinate replacement currently requires a fixed cell".into());
        }
        if !self.settings.optimize_positions {
            return Err("external coordinate replacement requires position optimization".into());
        }
        if positions.len() != self.structure.atomic_numbers.len() {
            return Err("replacement coordinate count must match the atom count".into());
        }
        if positions.iter().flatten().any(|value| !value.is_finite()) {
            return Err("replacement coordinates must be finite".into());
        }
        self.structure.positions_a.clone_from(&positions);
        self.coordinates = positions;
        Ok(())
    }

    /// Replace a prepared periodic full-cell geometry and synchronize FIRE's
    /// optimizer memory with the device-resident optimizer. The geometry and
    /// optimizer state are committed together before its matching evaluation.
    pub fn replace_prepared_cell_state(
        &mut self,
        structure: Structure,
        velocities: Vec<[f64; 3]>,
        dt_fs: f64,
        alpha: f64,
        positive_steps: usize,
        initialized: bool,
    ) -> Result<(), String> {
        if self.symmetry.is_some() {
            return Err("Device-side optimizer replacement bypasses symmetry constraints".into());
        }
        if !self.evaluation_pending || self.status != RelaxStatus::Running {
            return Err("no pending relax geometry is available for state replacement".into());
        }
        if self.filter.is_none()
            || !self.settings.optimize_cell_shape
            || !self.settings.optimize_cell_volume
            || !self.settings.optimize_positions
        {
            return Err(
                "external cell FIRE state requires unconstrained full-cell relaxation".into(),
            );
        }
        if !self.settings.movable.is_empty()
            && self
                .settings
                .movable
                .iter()
                .flatten()
                .any(|movable| !movable)
        {
            return Err("external cell FIRE state does not support position constraints".into());
        }
        let filter = self.filter.as_ref().expect("checked cell filter");
        let coordinates = filter.coordinates_for_structure(&structure)?;
        if velocities.len() != coordinates.len() {
            return Err("external FIRE velocity count must match cell-filter coordinates".into());
        }
        self.optimizer
            .replace_state(velocities, dt_fs, alpha, positive_steps, initialized)?;
        self.structure = structure;
        self.coordinates = coordinates;
        Ok(())
    }

    /// Accept a complete evaluation for the last prepared geometry. The host
    /// must retain its run/revision identity across the asynchronous boundary.
    pub fn accept_evaluation(&mut self, evaluation: Evaluation) -> Result<RelaxSnapshot, String> {
        if !self.evaluation_pending || self.status != RelaxStatus::Running {
            return Err("no relax evaluation is pending".into());
        }
        evaluation.validate(self.structure.atomic_numbers.len())?;
        let mut projected = self
            .settings
            .projected_forces(&self.structure, &evaluation.forces_ev_per_a)?;
        if let Some(symmetry) = &self.symmetry {
            symmetry.check(&self.structure)?;
            let masks = if self.settings.optimize_positions {
                if self.settings.movable.is_empty() {
                    vec![[true; 3]; self.structure.atomic_numbers.len()]
                } else {
                    self.settings.movable.clone()
                }
            } else {
                vec![[false; 3]; self.structure.atomic_numbers.len()]
            };
            let current = symmetry::SymmetryProjector::new(
                symmetry.operations.clone(),
                self.structure.cell_a,
                &masks,
                self.settings.fractional_constraints,
            )?;
            projected = current.project_atoms(&evaluation.forces_ev_per_a)?;
        }
        let max_force = projected
            .iter()
            .map(|force| force.iter().map(|v| v * v).sum::<f64>().sqrt())
            .fold(0.0, f64::max);
        let mut max_stress_residual_gpa = self.filter.as_ref().map(|_| {
            projected_stress_residual(
                &evaluation,
                self.settings.optimize_cell_shape,
                self.settings.optimize_cell_volume,
                self.settings.pressure_gpa / 160.217_662_08,
            ) * 160.217_662_08
        });
        if let Some(symmetry) = &self.symmetry {
            if self.filter.is_some() {
                let mut residual = evaluation.stress_ev_per_a3;
                for i in 0..3 {
                    residual[i][i] += self.settings.pressure_gpa / 160.217_662_08;
                }
                let stress = symmetry.projector.project_cell(
                    residual,
                    self.settings.optimize_cell_shape,
                    self.settings.optimize_cell_volume,
                );
                max_stress_residual_gpa = Some(
                    stress.iter().flatten().map(|v| v.abs()).fold(0., f64::max) * 160.217_662_08,
                );
            }
        }
        let converged_force = max_force <= self.settings.fmax_ev_per_a;
        let converged_stress =
            max_stress_residual_gpa.is_none_or(|residual| residual <= self.settings.smax_gpa);
        self.status = if converged_force && converged_stress {
            RelaxStatus::Converged
        } else if self.step >= self.settings.max_steps {
            RelaxStatus::MaxSteps
        } else {
            RelaxStatus::Running
        };
        self.last_evaluation = Some(evaluation.clone());
        self.evaluation_pending = false;
        let symmetry = self
            .symmetry
            .as_ref()
            .map(|state| {
                let (position_residual_a, metric_residual) = state.check(&self.structure)?;
                Ok::<_, String>(SymmetryStepReport {
                    position_residual_a,
                    metric_residual,
                    maximum_initial_correction_a: state.maximum_correction_a,
                    projected_position_degrees_of_freedom: state.projector.degrees_of_freedom(),
                    projected_cell_degrees_of_freedom: state.projector.cell_degrees_of_freedom(
                        self.settings.optimize_cell_shape,
                        self.settings.optimize_cell_volume,
                    ),
                })
            })
            .transpose()?;
        Ok(RelaxSnapshot {
            symmetry,
            step: self.step,
            structure: self.structure.clone(),
            evaluation,
            max_force_ev_per_a: max_force,
            max_stress_residual_gpa,
            status: self.status,
        })
    }

    /// Re-evaluate the last complete geometry with another calculator. This
    /// supports a CPU final audit of a GPU-converged structure without another
    /// optimizer update. A failed audit may continue from the CPU evaluation.
    pub fn recheck_last_evaluation(
        &mut self,
        evaluation: Evaluation,
    ) -> Result<RelaxSnapshot, String> {
        if self.evaluation_pending || self.last_evaluation.is_none() {
            return Err("no complete relax geometry is available for recheck".into());
        }
        evaluation.validate(self.structure.atomic_numbers.len())?;
        self.evaluation_pending = true;
        self.status = RelaxStatus::Running;
        self.accept_evaluation(evaluation)
    }
}

fn projected_stress_residual(
    evaluation: &Evaluation,
    optimize_shape: bool,
    optimize_volume: bool,
    pressure_ev_per_a3: f64,
) -> f64 {
    let mut residual = evaluation.stress_ev_per_a3;
    for axis in 0..3 {
        residual[axis][axis] += pressure_ev_per_a3;
    }
    match (optimize_shape, optimize_volume) {
        (true, true) => residual
            .iter()
            .flatten()
            .map(|x| x.abs())
            .fold(0.0, f64::max),
        (true, false) => {
            let mean = (residual[0][0] + residual[1][1] + residual[2][2]) / 3.0;
            for axis in 0..3 {
                residual[axis][axis] -= mean;
            }
            residual
                .iter()
                .flatten()
                .map(|x| x.abs())
                .fold(0.0, f64::max)
        }
        (false, true) => ((residual[0][0] + residual[1][1] + residual[2][2]) / 3.0).abs(),
        (false, false) => 0.0,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn fire_optimizer_state_is_a_read_only_round_trip_snapshot() {
        let mut optimizer = FireOptimizer::new(2);
        let initial = optimizer.state();
        assert_eq!(initial.velocities, vec![[0.0; 3]; 2]);
        assert!(!initial.initialized);
        assert_eq!(initial.dt_fs, 0.1);
        assert_eq!(initial.alpha, 0.1);
        assert_eq!(initial.positive_steps, 0);

        let velocities = vec![[0.01, -0.02, 0.03], [-0.04, 0.05, -0.06]];
        optimizer
            .replace_state(velocities.clone(), 0.4, 0.08, 7, true)
            .unwrap();
        let resumed = optimizer.state();
        assert_eq!(resumed.velocities, velocities);
        assert!(resumed.initialized);
        assert_eq!(resumed.dt_fs, 0.4);
        assert_eq!(resumed.alpha, 0.08);
        assert_eq!(resumed.positive_steps, 7);
    }

    #[test]
    fn asynchronous_evaluations_preserve_fire_snapshots_and_retry_geometry() {
        let settings = RelaxSettings {
            max_steps: 4,
            optimize_cell_shape: false,
            optimize_cell_volume: false,
            fmax_ev_per_a: 1e-12,
            ..RelaxSettings::default()
        };
        let mut synchronous = RelaxSession::new(structure(), settings.clone()).unwrap();
        let mut asynchronous = RelaxSession::new(structure(), settings).unwrap();
        assert!(asynchronous
            .accept_evaluation(Harmonic.evaluate(&structure()).unwrap())
            .is_err());
        for _ in 0..5 {
            let expected = synchronous.advance(&mut Harmonic).unwrap();
            let prepared = asynchronous.prepare_evaluation().unwrap().clone();
            assert_eq!(asynchronous.prepare_evaluation().unwrap(), &prepared);
            let mut invalid = Harmonic.evaluate(&prepared).unwrap();
            invalid.energy_ev = f64::NAN;
            assert!(asynchronous.accept_evaluation(invalid).is_err());
            assert_eq!(asynchronous.prepare_evaluation().unwrap(), &prepared);
            let actual = asynchronous
                .accept_evaluation(Harmonic.evaluate(&prepared).unwrap())
                .unwrap();
            assert_eq!(actual, expected);
            assert!(asynchronous
                .accept_evaluation(actual.evaluation.clone())
                .is_err());
        }
        assert!(asynchronous.prepare_evaluation().is_err());
    }

    #[test]
    fn cpu_final_audit_can_resume_without_moving_the_audited_geometry() {
        let settings = RelaxSettings {
            optimize_cell_shape: false,
            optimize_cell_volume: false,
            ..RelaxSettings::default()
        };
        let mut session = RelaxSession::new(structure(), settings).unwrap();
        let prepared = session.prepare_evaluation().unwrap().clone();
        let mut approximate = Harmonic.evaluate(&prepared).unwrap();
        approximate.forces_ev_per_a.fill([0.; 3]);
        assert_eq!(
            session.accept_evaluation(approximate).unwrap().status,
            RelaxStatus::Converged
        );
        let audited = session
            .recheck_last_evaluation(Harmonic.evaluate(&prepared).unwrap())
            .unwrap();
        assert_eq!(audited.status, RelaxStatus::Running);
        assert_eq!(audited.step, 0);
        assert_eq!(audited.structure, prepared);
        let refined = session.advance(&mut Harmonic).unwrap();
        assert_eq!(refined.step, 1);
        assert_ne!(refined.structure, prepared);
    }

    #[test]
    fn prepared_external_positions_are_evaluated_and_checkpointed_as_one_snapshot() {
        let settings = RelaxSettings {
            optimize_cell_shape: false,
            optimize_cell_volume: false,
            ..RelaxSettings::default()
        };
        let mut session = RelaxSession::new(structure(), settings).unwrap();
        assert!(session
            .replace_prepared_positions(vec![[1.0, 2.0, 3.0]])
            .is_err());
        session.prepare_evaluation().unwrap();
        let positions = vec![[1.0, 2.0, 3.0]];
        session
            .replace_prepared_positions(positions.clone())
            .unwrap();
        let snapshot = session
            .accept_evaluation(Harmonic.evaluate(session.structure()).unwrap())
            .unwrap();
        assert_eq!(snapshot.step, 0);
        assert_eq!(snapshot.structure.positions_a, positions);
        assert_eq!(
            snapshot.evaluation.forces_ev_per_a,
            vec![[-1.0, -2.0, -3.0]]
        );
        assert!(session.prepare_evaluation().unwrap().positions_a[0][0] < 1.0);
    }

    #[test]
    fn prepared_external_positions_reject_invalid_count_nonfinite_values_and_cell_modes() {
        let fixed_cell = RelaxSettings {
            optimize_cell_shape: false,
            optimize_cell_volume: false,
            ..RelaxSettings::default()
        };
        let mut session = RelaxSession::new(structure(), fixed_cell).unwrap();
        session.prepare_evaluation().unwrap();
        assert!(session.replace_prepared_positions(vec![]).is_err());
        assert!(session
            .replace_prepared_positions(vec![[f64::NAN, 0.0, 0.0]])
            .is_err());

        let mut cell = RelaxSession::new(structure(), RelaxSettings::default()).unwrap();
        cell.prepare_evaluation().unwrap();
        assert!(cell
            .replace_prepared_positions(vec![[1.0, 2.0, 3.0]])
            .is_err());
    }

    #[test]
    fn prepared_external_full_cell_state_round_trips_geometry_and_fire_memory() {
        let mut session = RelaxSession::new(structure(), RelaxSettings::default()).unwrap();
        session.prepare_evaluation().unwrap();
        let mut external = structure();
        external.cell_a = [[5.05, 0.15, 0.0], [0.1, 4.95, 0.2], [0.0, 0.1, 5.1]];
        let transform = external.cell_a.map(|row| row.map(|value| value / 5.0));
        external.positions_a[0] = std::array::from_fn(|axis| {
            (0..3)
                .map(|inner| structure().positions_a[0][inner] * transform[inner][axis])
                .sum()
        });
        let velocities = vec![[0.01, -0.02, 0.03]; 4];
        assert!(session
            .replace_prepared_cell_state(external.clone(), velocities.clone(), 0.2, 0.08, 7, true,)
            .is_ok());
        let snapshot = session
            .accept_evaluation(Harmonic.evaluate(session.structure()).unwrap())
            .unwrap();
        assert_eq!(snapshot.structure, external);
        assert_eq!(snapshot.step, 0);

        session.prepare_evaluation().unwrap();
        assert!(session
            .replace_prepared_cell_state(external.clone(), velocities.clone(), 0.0, 0.08, 7, true,)
            .is_err());
        assert!(session
            .replace_prepared_cell_state(external, vec![[0.0; 3]; 1], 0.2, 0.08, 7, true,)
            .is_err());
    }

    struct Harmonic;
    impl Potential for Harmonic {
        fn evaluate(&mut self, structure: &Structure) -> Result<Evaluation, String> {
            let positions = &structure.positions_a;
            Ok(Evaluation {
                energy_ev: positions.iter().flatten().map(|x| 0.5 * x * x).sum(),
                forces_ev_per_a: positions.iter().map(|p| p.map(|x| -x)).collect(),
                stress_ev_per_a3: [[0.0; 3]; 3],
                energies_ev: None,
                stresses_ev_per_a3: None,
            })
        }
    }

    struct HarmonicWithStress;
    impl Potential for HarmonicWithStress {
        fn evaluate(&mut self, structure: &Structure) -> Result<Evaluation, String> {
            Ok(Evaluation {
                energy_ev: 0.0,
                forces_ev_per_a: vec![[1.0, -2.0, 0.5]; structure.atomic_numbers.len()],
                stress_ev_per_a3: [[0.02, 0.01, 0.0], [0.01, -0.01, 0.0], [0.0, 0.0, 0.015]],
                energies_ev: None,
                stresses_ev_per_a3: None,
            })
        }
    }

    struct UniformStress {
        stress_ev_per_a3: [[f64; 3]; 3],
    }

    impl Potential for UniformStress {
        fn evaluate(&mut self, structure: &Structure) -> Result<Evaluation, String> {
            Ok(Evaluation {
                energy_ev: 0.0,
                forces_ev_per_a: vec![[0.0; 3]; structure.atomic_numbers.len()],
                stress_ev_per_a3: self.stress_ev_per_a3,
                energies_ev: None,
                stresses_ev_per_a3: None,
            })
        }
    }

    fn structure() -> Structure {
        Structure {
            atomic_numbers: vec![14],
            positions_a: vec![[0.5, 0.25, -0.1]],
            cell_a: [[5.0, 0.0, 0.0], [0.0, 5.0, 0.0], [0.0, 0.0, 5.0]],
            pbc: [true; 3],
        }
    }

    fn nep_mixed_skew_structure() -> Structure {
        Structure {
            atomic_numbers: vec![14, 6, 8, 1, 26],
            positions_a: vec![
                [1.04, 1.065, 1.35],
                [3.536, 2.135, 1.53],
                [2.264, 4.914, 2.7],
                [6.187, 6.591, 6.48],
                [7.568, 2.606, 3.78],
            ],
            cell_a: [[8.4, 0.0, 0.0], [1.1, 8.7, 0.0], [0.6, 1.3, 9.0]],
            pbc: [true; 3],
        }
    }

    fn nep_nonperiodic_structure() -> Structure {
        Structure {
            atomic_numbers: vec![14, 6, 8, 1, 26],
            positions_a: vec![
                [0.0, 0.0, 0.0],
                [1.34, 0.2, 0.0],
                [-1.0, 0.8, 0.3],
                [0.3, -1.7, 0.5],
                [12.0, 0.0, 0.0],
            ],
            cell_a: [[0.0; 3]; 3],
            pbc: [false; 3],
        }
    }

    fn nep_si8_structure() -> Structure {
        Structure {
            atomic_numbers: vec![14; 8],
            positions_a: vec![
                [0.0, 0.0, 0.0],
                [0.0, 2.715, 2.715],
                [2.715, 0.0, 2.715],
                [2.715, 2.715, 0.0],
                [1.3575, 1.3575, 1.3575],
                [1.3575, 4.0725, 4.0725],
                [4.0725, 1.3575, 4.0725],
                [4.0725, 4.0725, 1.3575],
            ],
            cell_a: [[5.43, 0.0, 0.0], [0.0, 5.43, 0.0], [0.0, 0.0, 5.43]],
            pbc: [true; 3],
        }
    }

    fn nep_model_from_environment() -> Option<macer_rust_nep::nep89::Nep4ZblModel> {
        let path = std::env::var_os("MACER_NEP89_MODEL")?;
        Some(
            macer_rust_nep::nep89::Nep4ZblModel::from_bytes(&std::fs::read(path).unwrap()).unwrap(),
        )
    }

    #[test]
    fn emits_initial_and_updated_atomic_snapshots() {
        let mut session = RelaxSession::new(structure(), RelaxSettings::default()).unwrap();
        let mut potential = Harmonic;
        let first = session.advance(&mut potential).unwrap();
        let second = session.advance(&mut potential).unwrap();
        assert_eq!(first.step, 0);
        assert_eq!(second.step, 1);
        assert!(second.structure.positions_a[0][0] < first.structure.positions_a[0][0]);
        assert_eq!(
            second.evaluation.energy_ev,
            potential.evaluate(&second.structure).unwrap().energy_ev
        );
        assert_eq!(first.max_stress_residual_gpa, Some(0.0));
    }

    #[test]
    fn nep_evaluator_runs_through_shared_relax_and_honors_per_axis_masks() {
        let Some(mut model) = nep_model_from_environment() else {
            eprintln!("skipping NEP Relax integration: model env is unset");
            return;
        };
        let initial = nep_mixed_skew_structure();
        let settings = RelaxSettings {
            max_steps: 2,
            fmax_ev_per_a: 1.0e-8,
            optimize_cell_shape: false,
            optimize_cell_volume: false,
            movable: vec![
                [true, false, false],
                [false, false, false],
                [false, false, false],
                [false, false, false],
                [false, false, false],
            ],
            ..RelaxSettings::default()
        };
        let mut session = RelaxSession::new(initial.clone(), settings).unwrap();
        let first = session.advance(&mut model).unwrap();
        let second = session.advance(&mut model).unwrap();
        let last = session.advance(&mut model).unwrap();
        assert_eq!(first.step, 0);
        assert_eq!(second.step, 1);
        assert_eq!(last.step, 2);
        assert_eq!(last.status, RelaxStatus::MaxSteps);
        assert_eq!(first.max_stress_residual_gpa, None);
        assert!(first.evaluation.energies_ev.is_some());
        assert!(first.evaluation.stresses_ev_per_a3.is_some());
        assert_ne!(
            second.structure.positions_a[0][0],
            initial.positions_a[0][0]
        );
        assert_eq!(
            second.structure.positions_a[0][1..],
            initial.positions_a[0][1..]
        );
        assert_eq!(second.structure.positions_a[1..], initial.positions_a[1..]);
        assert!(last.evaluation.energy_ev.is_finite());
    }

    #[test]
    fn nep_potential_runs_nonperiodic_xyz_relax_with_zero_cell() {
        let Some(mut model) = nep_model_from_environment() else {
            eprintln!("skipping NEP nonperiodic Relax integration: model env is unset");
            return;
        };
        let initial = nep_nonperiodic_structure();
        let settings = RelaxSettings {
            max_steps: 1,
            fmax_ev_per_a: 1.0e-8,
            optimize_cell_shape: false,
            optimize_cell_volume: false,
            ..RelaxSettings::default()
        };
        let mut session = RelaxSession::new(initial.clone(), settings).unwrap();
        let first = session.advance(&mut model).unwrap();
        let second = session.advance(&mut model).unwrap();
        assert_eq!(first.step, 0);
        assert_eq!(first.max_stress_residual_gpa, None);
        assert_eq!(first.evaluation.stress_ev_per_a3, [[0.0; 3]; 3]);
        assert!(first.evaluation.energies_ev.is_some());
        assert!(first.evaluation.stresses_ev_per_a3.is_none());
        assert_eq!(second.status, RelaxStatus::MaxSteps);
        assert_eq!(second.structure.cell_a, initial.cell_a);
        assert!(second
            .structure
            .positions_a
            .iter()
            .flatten()
            .all(|value| value.is_finite()));
        assert!(second
            .evaluation
            .forces_ev_per_a
            .iter()
            .flatten()
            .all(|value| value.is_finite()));
    }

    #[test]
    fn nep_evaluator_stress_drives_shared_full_cell_filter() {
        let Some(mut model) = nep_model_from_environment() else {
            eprintln!("skipping NEP full-cell Relax integration: model env is unset");
            return;
        };
        let initial = nep_mixed_skew_structure();
        let settings = RelaxSettings {
            max_steps: 1,
            fmax_ev_per_a: 1.0e-8,
            smax_gpa: 1.0e-8,
            ..RelaxSettings::default()
        };
        let mut session = RelaxSession::new(initial.clone(), settings).unwrap();
        let first = session.advance(&mut model).unwrap();
        let second = session.advance(&mut model).unwrap();
        assert_eq!(first.step, 0);
        assert!(first.max_stress_residual_gpa.is_some());
        assert_eq!(second.step, 1);
        assert_eq!(second.status, RelaxStatus::MaxSteps);
        assert_ne!(second.structure.cell_a, initial.cell_a);
        assert!(second
            .structure
            .cell_a
            .iter()
            .flatten()
            .all(|value| value.is_finite()));
        assert!(second
            .evaluation
            .stress_ev_per_a3
            .iter()
            .flatten()
            .all(|value| value.is_finite()));
    }

    #[test]
    fn nep_si8_full_cell_relax_reaches_configured_force_and_stress_tolerances() {
        let Some(mut model) = nep_model_from_environment() else {
            eprintln!("skipping NEP convergence check: model env is unset");
            return;
        };
        let settings = RelaxSettings {
            max_steps: 500,
            fmax_ev_per_a: 0.01,
            smax_gpa: 0.1,
            ..RelaxSettings::default()
        };
        let mut session = RelaxSession::new(nep_si8_structure(), settings).unwrap();
        let mut final_snapshot = None;
        for _ in 0..=500 {
            let snapshot = session.advance(&mut model).unwrap();
            let done = snapshot.status != RelaxStatus::Running;
            final_snapshot = Some(snapshot);
            if done {
                break;
            }
        }
        let final_snapshot = final_snapshot.unwrap();
        println!(
            "NEP Si8 full-cell relax status={:?} steps={} max_force={:.6e} eV/A stress_residual={:.6e} GPa energy={:.12} eV",
            final_snapshot.status,
            final_snapshot.step,
            final_snapshot.max_force_ev_per_a,
            final_snapshot.max_stress_residual_gpa.unwrap_or(f64::NAN),
            final_snapshot.evaluation.energy_ev
        );
        assert_eq!(final_snapshot.status, RelaxStatus::Converged);
        assert!(final_snapshot.max_force_ev_per_a <= 0.01);
        assert!(final_snapshot.max_stress_residual_gpa.unwrap() <= 0.1);
    }

    #[test]
    fn nep_evaluator_shared_filter_preserves_shape_or_volume_in_restricted_cell_modes() {
        let Some(mut model) = nep_model_from_environment() else {
            eprintln!("skipping NEP restricted-cell Relax integration: model env is unset");
            return;
        };
        let initial = nep_mixed_skew_structure();
        let initial_volume = initial.signed_volume_a3().abs();
        for (optimize_shape, optimize_volume, pressure_gpa) in
            [(true, false, 0.0), (false, true, 0.5)]
        {
            let settings = RelaxSettings {
                max_steps: 1,
                fmax_ev_per_a: 1.0e-8,
                smax_gpa: 1.0e-8,
                optimize_positions: false,
                optimize_cell_shape: optimize_shape,
                optimize_cell_volume: optimize_volume,
                pressure_gpa,
                ..RelaxSettings::default()
            };
            let mut session = RelaxSession::new(initial.clone(), settings).unwrap();
            session.advance(&mut model).unwrap();
            let snapshot = session.advance(&mut model).unwrap();
            assert_eq!(snapshot.status, RelaxStatus::MaxSteps);
            if optimize_shape {
                let volume_error =
                    (snapshot.structure.signed_volume_a3().abs() - initial_volume).abs();
                assert!(
                    volume_error <= 1.0e-9,
                    "constant-volume error {volume_error}"
                );
            } else {
                let initial_lengths = initial
                    .cell_a
                    .map(|row| row.iter().map(|x| x * x).sum::<f64>().sqrt());
                let relaxed_lengths = snapshot
                    .structure
                    .cell_a
                    .map(|row| row.iter().map(|x| x * x).sum::<f64>().sqrt());
                let ratios = std::array::from_fn::<_, 3, _>(|axis| {
                    relaxed_lengths[axis] / initial_lengths[axis]
                });
                assert!((ratios[0] - ratios[1]).abs() <= 1.0e-10);
                assert!((ratios[0] - ratios[2]).abs() <= 1.0e-10);
            }
        }
    }

    #[test]
    fn fixed_cell_snapshot_does_not_report_a_stress_convergence_residual() {
        let settings = RelaxSettings {
            optimize_cell_shape: false,
            optimize_cell_volume: false,
            ..RelaxSettings::default()
        };
        let mut session = RelaxSession::new(structure(), settings).unwrap();
        let mut potential = UniformStress {
            stress_ev_per_a3: [[0.02, 0.0, 0.0], [0.0, -0.01, 0.0], [0.0, 0.0, 0.015]],
        };
        let snapshot = session.advance(&mut potential).unwrap();
        assert_eq!(snapshot.max_stress_residual_gpa, None);
    }

    #[test]
    fn stress_residual_uses_only_optimized_cell_degrees_of_freedom() {
        let mut shape_only = RelaxSettings {
            optimize_cell_volume: false,
            ..RelaxSettings::default()
        };
        shape_only.smax_gpa = 0.1;
        let mut session = RelaxSession::new(structure(), shape_only).unwrap();
        let mut hydrostatic = UniformStress {
            stress_ev_per_a3: [[0.02, 0.0, 0.0], [0.0, 0.02, 0.0], [0.0, 0.0, 0.02]],
        };
        let snapshot = session.advance(&mut hydrostatic).unwrap();
        assert!(snapshot.max_stress_residual_gpa.unwrap() < 1.0e-12);
        assert_eq!(snapshot.status, RelaxStatus::Converged);
    }

    #[test]
    fn target_pressure_is_applied_to_volume_convergence_residual() {
        let target_pressure = 0.02 * 160.217_662_08;
        let settings = RelaxSettings {
            optimize_cell_shape: false,
            pressure_gpa: target_pressure,
            smax_gpa: 0.1,
            ..RelaxSettings::default()
        };
        let mut session = RelaxSession::new(structure(), settings).unwrap();
        let mut compressed_state = UniformStress {
            stress_ev_per_a3: [[-0.02, 0.0, 0.0], [0.0, -0.02, 0.0], [0.0, 0.0, -0.02]],
        };
        let snapshot = session.advance(&mut compressed_state).unwrap();
        assert!(snapshot.max_stress_residual_gpa.unwrap() < 1.0e-12);
        assert_eq!(snapshot.status, RelaxStatus::Converged);
    }

    #[test]
    fn full_cell_stress_residual_prevents_false_convergence() {
        let settings = RelaxSettings {
            smax_gpa: 0.1,
            ..RelaxSettings::default()
        };
        let mut session = RelaxSession::new(structure(), settings).unwrap();
        let mut deviatoric = UniformStress {
            stress_ev_per_a3: [[0.02, 0.01, 0.0], [0.01, -0.01, 0.0], [0.0, 0.0, 0.015]],
        };
        let snapshot = session.advance(&mut deviatoric).unwrap();
        assert!(
            (snapshot.max_stress_residual_gpa.unwrap() - 0.02 * 160.217_662_08).abs() < 1.0e-12
        );
        assert_eq!(snapshot.status, RelaxStatus::Running);
    }

    #[test]
    fn fixed_axes_do_not_move_and_do_not_block_convergence() {
        let mut settings = RelaxSettings::default();
        settings.movable = vec![[false, true, false]];
        settings.fmax_ev_per_a = 0.3;
        let original = structure();
        let mut session = RelaxSession::new(original.clone(), settings).unwrap();
        let mut potential = Harmonic;
        let first = session.advance(&mut potential).unwrap();
        assert_eq!(first.max_force_ev_per_a, 0.25);
        assert_eq!(first.status, RelaxStatus::Converged);
        assert_eq!(
            first.structure.positions_a[0][0],
            original.positions_a[0][0]
        );
        assert_eq!(
            first.structure.positions_a[0][2],
            original.positions_a[0][2]
        );
    }

    #[test]
    fn rejects_nonmatching_constraint_count() {
        let mut settings = RelaxSettings::default();
        settings.movable = vec![];
        assert!(RelaxSession::new(structure(), settings).is_ok());
        let mut settings = RelaxSettings::default();
        settings.movable = vec![[true; 3]; 2];
        assert!(RelaxSession::new(structure(), settings).is_err());
    }

    #[test]
    fn rejects_relax_when_every_atom_axis_and_cell_axis_is_fixed() {
        let settings = RelaxSettings {
            optimize_cell_shape: false,
            optimize_cell_volume: false,
            movable: vec![[false; 3]],
            ..RelaxSettings::default()
        };
        let error = match RelaxSession::new(structure(), settings) {
            Ok(_) => panic!("a relax run with no movable degrees of freedom must be rejected"),
            Err(error) => error,
        };
        assert!(error.contains("single-point"));
    }

    #[test]
    fn skew_cell_fractional_constraint_moves_only_along_enabled_lattice_axis() {
        let skew = Structure {
            atomic_numbers: vec![14],
            positions_a: vec![[1.0, 2.0, 3.0]],
            cell_a: [[4.0, 0.0, 0.0], [1.2, 3.0, 0.3], [0.2, 0.4, 5.0]],
            pbc: [true; 3],
        };
        let mut settings = RelaxSettings {
            optimize_cell_shape: false,
            optimize_cell_volume: false,
            fractional_constraints: true,
            movable: vec![[false, true, false]],
            max_steps: 1,
            fmax_ev_per_a: 1.0e-8,
            ..RelaxSettings::default()
        };
        settings.smax_gpa = 0.1;
        let initial = skew.positions_a[0];
        let lattice_axis = skew.cell_a[1];
        let mut session = RelaxSession::new(skew, settings).unwrap();
        let mut potential = Harmonic;
        assert_eq!(session.advance(&mut potential).unwrap().step, 0);
        let final_snapshot = session.advance(&mut potential).unwrap();
        let delta = std::array::from_fn::<_, 3, _>(|axis| {
            final_snapshot.structure.positions_a[0][axis] - initial[axis]
        });
        let cross = [
            delta[1] * lattice_axis[2] - delta[2] * lattice_axis[1],
            delta[2] * lattice_axis[0] - delta[0] * lattice_axis[2],
            delta[0] * lattice_axis[1] - delta[1] * lattice_axis[0],
        ];
        let cross_norm = cross.iter().map(|value| value * value).sum::<f64>().sqrt();
        let delta_norm = delta.iter().map(|value| value * value).sum::<f64>().sqrt();
        assert!(delta_norm > 0.0);
        assert!(cross_norm < 1.0e-12, "delta={delta:?}, cross={cross:?}");
    }

    #[test]
    fn skew_fractional_constraints_survive_cell_relaxation() {
        let input = Structure {
            atomic_numbers: vec![14],
            positions_a: vec![[1.2, 1.7, 2.1]],
            cell_a: [[8.0, 0.0, 0.0], [1.5, 8.0, 0.5], [0.3, 0.4, 8.0]],
            pbc: [true; 3],
        };
        let initial_fractional = multiply_row(input.positions_a[0], inverse3(input.cell_a));
        let settings = RelaxSettings {
            fractional_constraints: true,
            movable: vec![[false, true, false]],
            max_steps: 1,
            fmax_ev_per_a: 1.0e-8,
            smax_gpa: 1.0e-8,
            ..RelaxSettings::default()
        };
        let mut session = RelaxSession::new(input.clone(), settings).unwrap();
        let mut potential = HarmonicWithStress;
        assert_eq!(session.advance(&mut potential).unwrap().step, 0);
        let final_snapshot = session.advance(&mut potential).unwrap();
        assert_ne!(final_snapshot.structure.cell_a, input.cell_a);
        let final_fractional = multiply_row(
            final_snapshot.structure.positions_a[0],
            inverse3(final_snapshot.structure.cell_a),
        );
        assert!((final_fractional[0] - initial_fractional[0]).abs() < 1.0e-12);
        assert!((final_fractional[2] - initial_fractional[2]).abs() < 1.0e-12);
    }

    fn multiply_row(row: [f64; 3], matrix: [[f64; 3]; 3]) -> [f64; 3] {
        std::array::from_fn(|j| (0..3).map(|i| row[i] * matrix[i][j]).sum())
    }

    fn inverse3(m: [[f64; 3]; 3]) -> [[f64; 3]; 3] {
        let d = m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
            - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
            + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
        [
            [
                (m[1][1] * m[2][2] - m[1][2] * m[2][1]) / d,
                (m[0][2] * m[2][1] - m[0][1] * m[2][2]) / d,
                (m[0][1] * m[1][2] - m[0][2] * m[1][1]) / d,
            ],
            [
                (m[1][2] * m[2][0] - m[1][0] * m[2][2]) / d,
                (m[0][0] * m[2][2] - m[0][2] * m[2][0]) / d,
                (m[0][2] * m[1][0] - m[0][0] * m[1][2]) / d,
            ],
            [
                (m[1][0] * m[2][1] - m[1][1] * m[2][0]) / d,
                (m[0][1] * m[2][0] - m[0][0] * m[2][1]) / d,
                (m[0][0] * m[1][1] - m[0][1] * m[1][0]) / d,
            ],
        ]
    }
}
