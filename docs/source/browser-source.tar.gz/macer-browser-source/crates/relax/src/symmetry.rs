//! Orbit-local orthogonal projection onto space-group and directional constraints.
//! Each orbit uses at most three vectors; no global dense 3N projector is built.
use serde::{Deserialize, Serialize};
type V = [f64; 3];
type M = [[f64; 3]; 3];
const ID: M = [[1., 0., 0.], [0., 1., 0.], [0., 0., 1.]];
#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct SymmetryOperations {
    /// Cartesian column-vector rotations, in the original input frame.
    pub rotations: Vec<M>,
    /// Forward atom permutations: operation g maps atom i to permutations[g][i].
    pub permutations: Vec<Vec<usize>>,
}
#[derive(Clone, Debug)]
struct Orbit {
    atoms: Vec<usize>,
    transforms: Vec<M>,
    allowed: Vec<V>,
}
#[derive(Clone, Debug)]
pub struct SymmetryProjector {
    orbits: Vec<Orbit>,
    operations: SymmetryOperations,
    atoms: usize,
}
fn dot(a: V, b: V) -> f64 {
    (0..3).map(|i| a[i] * b[i]).sum()
}
fn mv(a: M, b: V) -> V {
    a.map(|r| dot(r, b))
}
fn tr(a: M) -> M {
    std::array::from_fn(|i| std::array::from_fn(|j| a[j][i]))
}
fn mm(a: M, b: M) -> M {
    let t = tr(b);
    a.map(|r| t.map(|c| dot(r, c)))
}
fn residual(mut x: V, basis: &[V]) -> V {
    for _ in 0..2 {
        for &v in basis {
            let c = dot(x, v);
            for i in 0..3 {
                x[i] -= c * v[i];
            }
        }
    }
    x
}
fn row(basis: &mut Vec<V>, x: V) {
    let y = residual(x, basis);
    let n = dot(y, y).sqrt();
    if n > 1e-10 {
        basis.push(y.map(|v| v / n));
    }
}
fn inverse(a: M) -> Result<M, String> {
    let d = a[0][0] * (a[1][1] * a[2][2] - a[1][2] * a[2][1])
        - a[0][1] * (a[1][0] * a[2][2] - a[1][2] * a[2][0])
        + a[0][2] * (a[1][0] * a[2][1] - a[1][1] * a[2][0]);
    if !d.is_finite() || d.abs() < 1e-12 {
        return Err("Symmetry reference cell is singular".into());
    }
    Ok([
        [
            (a[1][1] * a[2][2] - a[1][2] * a[2][1]) / d,
            (a[0][2] * a[2][1] - a[0][1] * a[2][2]) / d,
            (a[0][1] * a[1][2] - a[0][2] * a[1][1]) / d,
        ],
        [
            (a[1][2] * a[2][0] - a[1][0] * a[2][2]) / d,
            (a[0][0] * a[2][2] - a[0][2] * a[2][0]) / d,
            (a[0][2] * a[1][0] - a[0][0] * a[1][2]) / d,
        ],
        [
            (a[1][0] * a[2][1] - a[1][1] * a[2][0]) / d,
            (a[0][1] * a[2][0] - a[0][0] * a[2][1]) / d,
            (a[0][0] * a[1][1] - a[0][1] * a[1][0]) / d,
        ],
    ])
}
/// Normalize the near-symmetric metric without standardizing cell/order/origin.
/// The group-invariant Cartesian metric H = mean(Q^T Q) unitarizes the
/// representation via sqrt(H). The caller must still verify site residuals.
pub fn normalize_reference(
    reference: &macer_rust_core::types::Structure,
    operations: &SymmetryOperations,
    tolerance: f64,
) -> Result<(macer_rust_core::types::Structure, SymmetryOperations, f64), String> {
    reference.validate()?;
    if !tolerance.is_finite()
        || tolerance <= 0.0
        || operations.rotations.is_empty()
        || operations
            .rotations
            .iter()
            .flatten()
            .flatten()
            .any(|v| !v.is_finite())
    {
        return Err("Invalid symmetry normalization input".into());
    }
    let mut metric = [[0.; 3]; 3];
    for &q in &operations.rotations {
        let gram = mm(tr(q), q);
        for i in 0..3 {
            for j in 0..3 {
                metric[i][j] += gram[i][j] / operations.rotations.len() as f64;
            }
        }
    }
    let logarithm = crate::cell_filter::matrix_log(metric)?;
    let transform = crate::cell_filter::matrix_exp(logarithm.map(|r| r.map(|v| 0.5 * v)))?;
    let inverse_transform = inverse(transform)?;
    let mut corrected = reference.clone();
    corrected.cell_a = mm(reference.cell_a, tr(transform));
    corrected.positions_a = reference
        .positions_a
        .iter()
        .map(|&r| mv(transform, r))
        .collect();
    let displacement = corrected
        .positions_a
        .iter()
        .zip(&reference.positions_a)
        .map(|(a, b)| {
            dot(
                std::array::from_fn(|i| a[i] - b[i]),
                std::array::from_fn(|i| a[i] - b[i]),
            )
            .sqrt()
        })
        .fold(0., f64::max);
    let lattice_change = corrected
        .cell_a
        .iter()
        .zip(&reference.cell_a)
        .map(|(a, b)| {
            dot(
                std::array::from_fn(|i| a[i] - b[i]),
                std::array::from_fn(|i| a[i] - b[i]),
            )
            .sqrt()
        })
        .fold(0., f64::max);
    if displacement.max(lattice_change) > tolerance {
        return Err(format!(
            "Symmetry reference correction {} Angstrom exceeds {}",
            displacement.max(lattice_change),
            tolerance
        ));
    }
    let normalized = SymmetryOperations {
        rotations: operations
            .rotations
            .iter()
            .map(|&q| mm(mm(transform, q), inverse_transform))
            .collect(),
        permutations: operations.permutations.clone(),
    };
    corrected.validate()?;
    Ok((corrected, normalized, displacement.max(lattice_change)))
}
impl SymmetryProjector {
    pub fn new(
        operations: SymmetryOperations,
        cell_rows: M,
        masks: &[[bool; 3]],
        fractional: bool,
    ) -> Result<Self, String> {
        let n = masks.len();
        if n == 0
            || operations.rotations.is_empty()
            || operations.rotations.len() != operations.permutations.len()
        {
            return Err("Invalid symmetry operation count".into());
        }
        for (q, p) in operations.rotations.iter().zip(&operations.permutations) {
            if p.len() != n || q.iter().flatten().any(|v| !v.is_finite()) {
                return Err("Invalid symmetry operation shape".into());
            }
            let mut sorted = p.clone();
            sorted.sort_unstable();
            if sorted != (0..n).collect::<Vec<_>>() {
                return Err("Symmetry atom mapping is not a permutation".into());
            }
            let gram = mm(*q, tr(*q));
            if (0..3).any(|i| (0..3).any(|j| (gram[i][j] - ID[i][j]).abs() > 1e-8)) {
                return Err("Symmetry rotation is not orthogonal".into());
            }
        }
        let mask_normals = if fractional {
            inverse(tr(cell_rows))?
        } else {
            ID
        };
        let mut seen = vec![false; n];
        let mut orbits = Vec::new();
        for rep in 0..n {
            if seen[rep] {
                continue;
            }
            let mut atoms = vec![rep];
            let mut transforms = vec![ID];
            let mut slot = vec![usize::MAX; n];
            slot[rep] = 0;
            let mut k = 0;
            while k < atoms.len() {
                let i = atoms[k];
                for (q, p) in operations.rotations.iter().zip(&operations.permutations) {
                    let j = p[i];
                    if slot[j] == usize::MAX {
                        slot[j] = atoms.len();
                        atoms.push(j);
                        transforms.push(mm(*q, transforms[k]));
                    }
                }
                k += 1;
            }
            let mut forbidden = Vec::new();
            for (k, &i) in atoms.iter().enumerate() {
                seen[i] = true;
                let a = transforms[k];
                for (axis, &allowed) in masks[i].iter().enumerate() {
                    if !allowed {
                        let normal = mask_normals[axis];
                        let norm = dot(normal, normal).sqrt();
                        row(&mut forbidden, mv(tr(a), normal.map(|v| v / norm)));
                    }
                }
                for (q, p) in operations.rotations.iter().zip(&operations.permutations) {
                    let qa = mm(*q, a);
                    let aj = transforms[slot[p[i]]];
                    for j in 0..3 {
                        row(&mut forbidden, std::array::from_fn(|l| qa[j][l] - aj[j][l]));
                    }
                }
            }
            let mut allowed = Vec::new();
            for e in ID {
                let candidate = residual(e, &forbidden);
                row(&mut allowed, candidate);
            }
            orbits.push(Orbit {
                atoms,
                transforms,
                allowed,
            });
        }
        Ok(Self {
            orbits,
            operations,
            atoms: n,
        })
    }
    pub fn degrees_of_freedom(&self) -> usize {
        self.orbits.iter().map(|o| o.allowed.len()).sum()
    }
    pub fn project_atoms(&self, values: &[V]) -> Result<Vec<V>, String> {
        if values.len() != self.atoms || values.iter().flatten().any(|v| !v.is_finite()) {
            return Err("Invalid symmetry vector array".into());
        }
        let mut result = vec![[0.; 3]; self.atoms];
        for o in &self.orbits {
            let mut mean = [0.; 3];
            for (&i, &a) in o.atoms.iter().zip(&o.transforms) {
                let v = mv(tr(a), values[i]);
                for axis in 0..3 {
                    mean[axis] += v[axis] / o.atoms.len() as f64;
                }
            }
            let mut allowed = [0.; 3];
            for &b in &o.allowed {
                let c = dot(mean, b);
                for axis in 0..3 {
                    allowed[axis] += c * b[axis];
                }
            }
            for (&i, &a) in o.atoms.iter().zip(&o.transforms) {
                result[i] = mv(a, allowed);
            }
        }
        Ok(result)
    }
    pub fn cell_degrees_of_freedom(&self, shape: bool, volume: bool) -> usize {
        let mut rank = 0.0;
        for i in 0..3 {
            for j in 0..3 {
                let mut basis = [[0.0; 3]; 3];
                basis[i][j] = 1.0;
                rank += self.project_cell(basis, shape, volume)[i][j];
            }
        }
        rank.round().max(0.0) as usize
    }
    /// Frobenius-orthogonal group projection onto symmetric strain/stress.
    pub fn project_cell(&self, value: M, shape: bool, volume: bool) -> M {
        if !shape && !volume {
            return [[0.; 3]; 3];
        }
        let symmetric =
            std::array::from_fn(|i| std::array::from_fn(|j| 0.5 * (value[i][j] + value[j][i])));
        let mut result = [[0.; 3]; 3];
        for &q in &self.operations.rotations {
            let v = mm(mm(q, symmetric), tr(q));
            for i in 0..3 {
                for j in 0..3 {
                    result[i][j] += v[i][j] / self.operations.rotations.len() as f64;
                }
            }
        }
        let mean = (0..3).map(|i| result[i][i]).sum::<f64>() / 3.;
        if !shape {
            return ID.map(|r| r.map(|x| x * mean));
        }
        if !volume {
            for (i, r) in result.iter_mut().enumerate() {
                r[i] -= mean;
            }
        }
        result
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    fn ops() -> SymmetryOperations {
        SymmetryOperations {
            rotations: vec![ID, [[-1., 0., 0.], [0., -1., 0.], [0., 0., -1.]]],
            permutations: vec![vec![0, 1], vec![1, 0]],
        }
    }
    #[test]
    fn inversion_orbit_and_direction_intersection() {
        let p = SymmetryProjector::new(
            ops(),
            ID,
            &[[true, false, true], [false, true, true]],
            false,
        )
        .unwrap();
        assert_eq!(p.degrees_of_freedom(), 1);
        let f = vec![[1., 2., 3.], [4., 5., 6.]];
        let x = p.project_atoms(&f).unwrap();
        assert_eq!(x, vec![[0., 0., -1.5], [0., 0., 1.5]]);
        assert_eq!(p.project_atoms(&x).unwrap(), x);
    }
    #[test]
    fn skew_fractional_constraints_are_orthogonal() {
        let cell = [[2., 0., 0.], [1., 3., 0.], [0., 0., 4.]];
        let p = SymmetryProjector::new(
            SymmetryOperations {
                rotations: vec![ID],
                permutations: vec![vec![0]],
            },
            cell,
            &[[false, true, false]],
            true,
        )
        .unwrap();
        let x = p.project_atoms(&[[2., 1., 3.]]).unwrap();
        assert!((x[0][0] - 0.5).abs() < 1e-12);
        assert!((x[0][1] - 1.5).abs() < 1e-12);
        assert!(x[0][2].abs() < 1e-12);
    }
    #[test]
    fn global_projection_is_self_adjoint() {
        let p = SymmetryProjector::new(ops(), ID, &[[true; 3]; 2], false).unwrap();
        let a = [[1., 2., 3.], [-2., 4., 9.]];
        let b = [[3., 7., -1.], [8., 2., -4.]];
        let pa = p.project_atoms(&a).unwrap();
        let pb = p.project_atoms(&b).unwrap();
        let left = (0..2).map(|i| dot(a[i], pb[i])).sum::<f64>();
        let right = (0..2).map(|i| dot(pa[i], b[i])).sum::<f64>();
        assert!((left - right).abs() < 1e-12);
    }
    #[test]
    fn cubic_cell_projection_and_trace() {
        let rotations = vec![
            ID,
            [[0., 1., 0.], [0., 0., 1.], [1., 0., 0.]],
            [[0., 0., 1.], [1., 0., 0.], [0., 1., 0.]],
        ];
        let p = SymmetryProjector::new(
            SymmetryOperations {
                permutations: vec![vec![0]; 3],
                rotations,
            },
            ID,
            &[[false; 3]],
            false,
        )
        .unwrap();
        assert_eq!(p.degrees_of_freedom(), 0);
        let a = [[1., 0., 0.], [0., 2., 0.], [0., 0., 6.]];
        assert_eq!(
            p.project_cell(a, true, true),
            [[3., 0., 0.], [0., 3., 0.], [0., 0., 3.]]
        );
        assert_eq!(p.project_cell(a, true, false), [[0.; 3]; 3]);
    }
    #[test]
    fn rejects_bad_permutations() {
        let mut o = ops();
        o.permutations[1] = vec![0, 0];
        assert!(SymmetryProjector::new(o, ID, &[[true; 3]; 2], false).is_err());
    }
}

/// Frozen reference and original atom mappings for a shared RelaxSession.
#[derive(Clone, Debug)]
pub struct SymmetryState {
    pub reference: macer_rust_core::types::Structure,
    pub original: macer_rust_core::types::Structure,
    pub operations: SymmetryOperations,
    pub projector: SymmetryProjector,
    pub maximum_correction_a: f64,
    pub tolerance_a: f64,
    translations_fractional: Vec<V>,
}
impl SymmetryState {
    pub fn new(
        original: &macer_rust_core::types::Structure,
        operations: SymmetryOperations,
        masks: &[[bool; 3]],
        fractional: bool,
        tolerance_a: f64,
    ) -> Result<Self, String> {
        if original.pbc != [true; 3] {
            return Err("Preserved symmetry requires full periodicity".into());
        }
        let (reference, operations, maximum_correction_a) =
            normalize_reference(original, &operations, tolerance_a)?;
        let projector =
            SymmetryProjector::new(operations.clone(), reference.cell_a, masks, fractional)?;
        let inverse_basis = inverse(tr(reference.cell_a))?;
        for (q, permutation) in operations.rotations.iter().zip(&operations.permutations) {
            if permutation
                .iter()
                .enumerate()
                .any(|(i, &j)| reference.atomic_numbers[i] != reference.atomic_numbers[j])
            {
                return Err("Symmetry maps different chemical elements".into());
            }
            let fractional_rotation = mm(mm(inverse_basis, *q), tr(reference.cell_a));
            if fractional_rotation
                .iter()
                .flatten()
                .any(|v| (v - v.round()).abs() > 1e-8)
            {
                return Err("Symmetry rotation does not preserve the periodic lattice".into());
            }
        }
        let translations_fractional = operations
            .rotations
            .iter()
            .zip(&operations.permutations)
            .map(|(&q, p)| {
                let rotated = mv(q, reference.positions_a[0]);
                mv(
                    inverse_basis,
                    std::array::from_fn(|a| reference.positions_a[p[0]][a] - rotated[a]),
                )
            })
            .collect();
        let state = Self {
            original: original.clone(),
            reference,
            operations,
            projector,
            maximum_correction_a,
            tolerance_a,
            translations_fractional,
        };
        state.check(&state.reference)?;
        Ok(state)
    }
    pub fn project_coordinates(
        &self,
        coordinates: &mut [[f64; 3]],
        velocities: &mut [[f64; 3]],
        shape: bool,
        volume: bool,
    ) -> Result<(), String> {
        let n = self.reference.positions_a.len();
        if !(coordinates.len() == n || coordinates.len() == n + 3)
            || velocities.len() != coordinates.len()
        {
            return Err("Invalid symmetry optimizer state".into());
        }
        let delta: Vec<_> = coordinates[..n]
            .iter()
            .zip(&self.reference.positions_a)
            .map(|(a, b)| std::array::from_fn(|i| a[i] - b[i]))
            .collect();
        let positions = self.projector.project_atoms(&delta)?;
        let speeds = self.projector.project_atoms(&velocities[..n])?;
        for i in 0..n {
            coordinates[i] =
                std::array::from_fn(|a| self.reference.positions_a[i][a] + positions[i][a]);
            velocities[i] = speeds[i];
        }
        if coordinates.len() == n + 3 {
            let cell = self.projector.project_cell(
                [coordinates[n], coordinates[n + 1], coordinates[n + 2]],
                shape,
                volume,
            );
            let speed = self.projector.project_cell(
                [velocities[n], velocities[n + 1], velocities[n + 2]],
                shape,
                volume,
            );
            coordinates[n..].copy_from_slice(&cell);
            velocities[n..].copy_from_slice(&speed);
        }
        Ok(())
    }
    pub fn project_generalized_forces(
        &self,
        forces: &mut [[f64; 3]],
        shape: bool,
        volume: bool,
    ) -> Result<(), String> {
        let n = self.reference.positions_a.len();
        if forces.len() != n && forces.len() != n + 3 {
            return Err("Invalid symmetry generalized force count".into());
        }
        let projected = self.projector.project_atoms(&forces[..n])?;
        forces[..n].copy_from_slice(&projected);
        if forces.len() == n + 3 {
            let cell = self.projector.project_cell(
                [forces[n], forces[n + 1], forces[n + 2]],
                shape,
                volume,
            );
            forces[n..].copy_from_slice(&cell);
        }
        Ok(())
    }
    pub fn check(
        &self,
        structure: &macer_rust_core::types::Structure,
    ) -> Result<(f64, f64), String> {
        if structure.atomic_numbers != self.reference.atomic_numbers || structure.pbc != [true; 3] {
            return Err("Symmetry atom identity changed".into());
        }
        let basis = tr(structure.cell_a);
        let inverse_basis = inverse(basis)?;
        let transform = mm(basis, inverse(tr(self.reference.cell_a))?);
        let metric = mm(tr(transform), transform);
        let norm = metric
            .iter()
            .flatten()
            .map(|v| v * v)
            .sum::<f64>()
            .sqrt()
            .max(1.);
        let mut metric_residual: f64 = 0.;
        let mut position_residual: f64 = 0.;
        for ((&q, p), &translation) in self
            .operations
            .rotations
            .iter()
            .zip(&self.operations.permutations)
            .zip(&self.translations_fractional)
        {
            let transformed_metric = mm(mm(tr(q), metric), q);
            for i in 0..3 {
                for j in 0..3 {
                    metric_residual =
                        metric_residual.max((transformed_metric[i][j] - metric[i][j]).abs() / norm);
                }
            }
            let t = mv(basis, translation);
            for (i, &j) in p.iter().enumerate() {
                let rotated = mv(q, structure.positions_a[i]);
                let fractional = mv(
                    inverse_basis,
                    std::array::from_fn(|a| rotated[a] + t[a] - structure.positions_a[j][a]),
                );
                let delta = mv(basis, fractional.map(|v| v - v.round()));
                position_residual = position_residual.max(dot(delta, delta).sqrt());
            }
        }
        if position_residual > self.tolerance_a || metric_residual > 1e-8 {
            return Err(format!(
                "Symmetry invariant failed: position {} Angstrom, metric {}",
                position_residual, metric_residual
            ));
        }
        Ok((position_residual, metric_residual))
    }
}

#[cfg(test)]
mod session_tests {
    use super::*;
    use crate::{RelaxSession, RelaxSettings, RelaxStatus};
    use macer_rust_core::types::{Evaluation, Structure};
    fn structure() -> Structure {
        Structure {
            atomic_numbers: vec![14, 14],
            positions_a: vec![[1., 0., 0.], [-1., 0., 0.]],
            cell_a: [[5., 0., 0.], [0., 5., 0.], [0., 0., 5.]],
            pbc: [true; 3],
        }
    }
    fn operations() -> SymmetryOperations {
        SymmetryOperations {
            rotations: vec![ID, [[-1., 0., 0.], [0., -1., 0.], [0., 0., -1.]]],
            permutations: vec![vec![0, 1], vec![1, 0]],
        }
    }
    fn evaluation() -> Evaluation {
        Evaluation {
            energy_ev: 1.,
            forces_ev_per_a: vec![[1., 2., 3.], [4., 5., 6.]],
            stress_ev_per_a3: [[0.01, 0., 0.], [0., 0.02, 0.], [0., 0., 0.03]],
            energies_ev: None,
            stresses_ev_per_a3: None,
        }
    }
    #[test]
    fn native_steps_preserve_intersection_and_raw_evaluation() {
        let settings = RelaxSettings {
            max_steps: 4,
            optimize_cell_shape: false,
            optimize_cell_volume: false,
            movable: vec![[true, false, true], [false, true, true]],
            ..Default::default()
        };
        let mut session = RelaxSession::new(structure(), settings)
            .unwrap()
            .with_symmetry(operations(), 1e-4)
            .unwrap();
        for _ in 0..5 {
            session.prepare_evaluation().unwrap();
            let snapshot = session.accept_evaluation(evaluation()).unwrap();
            assert_eq!(snapshot.evaluation, evaluation());
            assert!((snapshot.max_force_ev_per_a - 1.5).abs() < 1e-12);
            assert_eq!(snapshot.structure.positions_a[0][0], 1.);
            assert_eq!(snapshot.structure.positions_a[1][0], -1.);
            assert_eq!(snapshot.structure.positions_a[0][1], 0.);
            for axis in 0..3 {
                assert!(
                    (snapshot.structure.positions_a[0][axis]
                        + snapshot.structure.positions_a[1][axis])
                        .abs()
                        < 1e-12
                );
            }
            if snapshot.status != RelaxStatus::Running {
                break;
            }
        }
    }
    #[test]
    fn cell_pressure_path_and_device_optimizer_guard() {
        let settings = RelaxSettings {
            max_steps: 3,
            pressure_gpa: 3.,
            ..Default::default()
        };
        let mut session = RelaxSession::new(structure(), settings)
            .unwrap()
            .with_symmetry(operations(), 1e-4)
            .unwrap();
        for _ in 0..4 {
            session.prepare_evaluation().unwrap();
            assert!(session
                .replace_prepared_positions(vec![[0.; 3]; 2])
                .is_err());
            let snapshot = session.accept_evaluation(evaluation()).unwrap();
            assert!(snapshot.max_stress_residual_gpa.unwrap() > 3.);
            let residual = session
                .symmetry_state()
                .unwrap()
                .check(&snapshot.structure)
                .unwrap();
            assert!(residual.0 < 1e-10);
            assert!(residual.1 < 1e-10);
            if snapshot.status != RelaxStatus::Running {
                break;
            }
        }
    }
    #[test]
    fn zero_freedom_and_invalid_reference_rejected() {
        let settings = RelaxSettings {
            optimize_cell_shape: false,
            optimize_cell_volume: false,
            ..Default::default()
        };
        let o = SymmetryOperations {
            rotations: vec![ID, [[-1., 0., 0.], [0., -1., 0.], [0., 0., -1.]]],
            permutations: vec![vec![0, 1], vec![0, 1]],
        };
        assert!(RelaxSession::new(structure(), settings)
            .unwrap()
            .with_symmetry(o, 1e-4)
            .is_err());
    }
}
