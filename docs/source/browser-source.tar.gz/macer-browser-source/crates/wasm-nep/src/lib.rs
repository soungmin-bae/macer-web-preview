//! Browser adapter for caller-supplied NEP4-ZBL weights.
//! All parsing, evaluation, and relaxation happen in the calling browser worker.

use macer_rust_core::types::{Evaluation, Potential, Structure};
use macer_rust_nep::nep89::Nep4ZblModel;
use macer_rust_nep::nep89_evaluator;
use macer_rust_relax::{symmetry::SymmetryOperations, RelaxSession, RelaxSettings};
use serde::Serialize;
use wasm_bindgen::prelude::*;

#[derive(Serialize)]
struct NepModelMetadata<'a> {
    model_id: &'static str,
    source_sha256: &'a str,
    bytes: usize,
    elements: &'a [String],
    units: NepUnits,
}

#[derive(Serialize)]
struct NepUnits {
    energy: &'static str,
    force: &'static str,
    stress: &'static str,
}

#[derive(Serialize)]
struct EvaluationEvent {
    energy_ev: f64,
    forces_ev_per_a: Vec<[f64; 3]>,
    stress_ev_per_a3: Option<[[f64; 3]; 3]>,
    per_atom_virial_ev: Vec<[f64; 9]>,
}

#[wasm_bindgen]
pub struct BrowserNepEngine {
    model: Nep4ZblModel,
    session: Option<RelaxSession>,
}

#[wasm_bindgen]
impl BrowserNepEngine {
    pub fn evaluate_relax_json(&mut self, structure_json: &str) -> Result<String, JsValue> {
        let structure: Structure = serde_json::from_str(structure_json).map_err(js_error)?;
        serde_json::to_string(&self.model.evaluate(&structure).map_err(js_error)?).map_err(js_error)
    }
    pub fn webgpu_model_json(&self) -> Result<String, JsValue> {
        let c = &self.model.config;
        serde_json::to_string(&serde_json::json!({
            "atomic_numbers":c.atomic_numbers,"cutoff_a":c.cutoff_a,
            "n_max":c.n_max,"basis_size":c.basis_size,"l_max":c.l_max,
            "zbl_transition_a":c.zbl_transition_a,"hidden_neurons":c.hidden_neurons,
            "descriptor_count":c.descriptor_count().map_err(js_error)?,
            "neural_count":c.neural_parameter_count().map_err(js_error)?,
            "sha256":self.model.source_sha256,
        }))
        .map_err(js_error)
    }

    pub fn webgpu_parameters_f32(&self) -> Vec<f32> {
        self.model.parameters.iter().map(|v| *v as f32).collect()
    }

    pub fn webgpu_scales_f32(&self) -> Vec<f32> {
        self.model
            .descriptor_scales
            .iter()
            .map(|v| *v as f32)
            .collect()
    }

    pub fn webgpu_graph_json(&self, structure_json: &str) -> Result<String, JsValue> {
        let structure: Structure = serde_json::from_str(structure_json).map_err(js_error)?;
        structure.validate().map_err(js_error)?;
        let cutoff = self
            .model
            .config
            .cutoff_a
            .iter()
            .copied()
            .fold(self.model.config.zbl_transition_a[1], f64::max);
        let graph =
            macer_rust_nep::nep89_neighbors::NepNeighborGraph::for_structure(&structure, cutoff)
                .map_err(js_error)?;
        let types: Vec<usize> = structure
            .atomic_numbers
            .iter()
            .map(|&z| {
                self.model
                    .config
                    .type_index_for_atomic_number(z)
                    .ok_or_else(|| js_error("unsupported NEP element"))
            })
            .collect::<Result<_, _>>()?;
        serde_json::to_string(&serde_json::json!({
            "types":types,"atomic_numbers":structure.atomic_numbers,
            "centers":graph.neighbors.iter().map(|e|e.center).collect::<Vec<_>>(),
            "neighbors":graph.neighbors.iter().map(|e|e.neighbor).collect::<Vec<_>>(),
            "displacements_a":graph.neighbors.iter().map(|e|e.displacement_a).collect::<Vec<_>>(),
            "center_offsets":graph.center_offsets,
        }))
        .map_err(js_error)
    }

    pub fn prepare_relax_evaluation_json(&mut self) -> Result<String, JsValue> {
        let session = self
            .session
            .as_mut()
            .ok_or_else(|| js_error("relax has not been started"))?;
        serde_json::to_string(&session.prepare_evaluation().map_err(js_error)?).map_err(js_error)
    }

    pub fn replace_prepared_relax_cell_state_json(
        &mut self,
        structure_json: &str,
        velocities_json: &str,
        dt_fs: f64,
        alpha: f64,
        positive_steps: u32,
        initialized: bool,
    ) -> Result<(), JsValue> {
        let structure: Structure = serde_json::from_str(structure_json).map_err(js_error)?;
        let velocities: Vec<[f64; 3]> = serde_json::from_str(velocities_json).map_err(js_error)?;
        let session = self
            .session
            .as_mut()
            .ok_or_else(|| js_error("relax has not been started"))?;
        session
            .replace_prepared_cell_state(
                structure,
                velocities,
                dt_fs,
                alpha,
                positive_steps as usize,
                initialized,
            )
            .map_err(js_error)
    }

    pub fn accept_relax_evaluation_json(
        &mut self,
        evaluation_json: &str,
    ) -> Result<String, JsValue> {
        let evaluation: Evaluation = serde_json::from_str(evaluation_json).map_err(js_error)?;
        let session = self
            .session
            .as_mut()
            .ok_or_else(|| js_error("relax has not been started"))?;
        serde_json::to_string(&session.accept_evaluation(evaluation).map_err(js_error)?)
            .map_err(js_error)
    }

    pub fn recheck_relax_evaluation_json(
        &mut self,
        evaluation_json: &str,
    ) -> Result<String, JsValue> {
        let evaluation: Evaluation = serde_json::from_str(evaluation_json).map_err(js_error)?;
        let session = self
            .session
            .as_mut()
            .ok_or_else(|| js_error("relax has not been started"))?;
        serde_json::to_string(
            &session
                .recheck_last_evaluation(evaluation)
                .map_err(js_error)?,
        )
        .map_err(js_error)
    }

    /// Parse the exact model bytes supplied by the host. This performs no I/O.
    #[wasm_bindgen(constructor)]
    pub fn new(model_bytes: &[u8]) -> Result<BrowserNepEngine, JsValue> {
        let model = Nep4ZblModel::from_bytes(model_bytes).map_err(js_error)?;
        if model.source_sha256 != macer_rust_nep::nep89::NEP89_REFERENCE_SHA256 {
            return Err(JsValue::from_str(
                "NEP89 checkpoint SHA-256 does not match the pinned model identity",
            ));
        }
        Ok(Self {
            model,
            session: None,
        })
    }

    pub fn model_metadata_json(&self) -> Result<String, JsValue> {
        serde_json::to_string(&NepModelMetadata {
            model_id: "nep89-20250409",
            source_sha256: &self.model.source_sha256,
            bytes: macer_rust_nep::nep89::NEP89_REFERENCE_BYTES,
            elements: &self.model.config.element_symbols,
            units: NepUnits {
                energy: "eV",
                force: "eV/angstrom",
                stress: "eV/angstrom^3",
            },
        })
        .map_err(js_error)
    }

    pub fn evaluate_json(&mut self, structure_json: &str) -> Result<String, JsValue> {
        let structure: Structure = serde_json::from_str(structure_json).map_err(js_error)?;
        structure.validate().map_err(js_error)?;
        let output = nep89_evaluator::evaluate(&self.model, &structure).map_err(js_error)?;
        serde_json::to_string(&EvaluationEvent {
            energy_ev: output.total_energy_ev(),
            forces_ev_per_a: output.forces_ev_per_a,
            stress_ev_per_a3: output.stress_ev_per_a3,
            per_atom_virial_ev: output.per_atom_virial_ev,
        })
        .map_err(js_error)
    }

    pub fn start_relax(
        &mut self,
        structure_json: &str,
        settings_json: &str,
    ) -> Result<(), JsValue> {
        let structure: Structure = serde_json::from_str(structure_json).map_err(js_error)?;
        let settings: RelaxSettings = serde_json::from_str(settings_json).map_err(js_error)?;
        self.session = Some(RelaxSession::new(structure, settings).map_err(js_error)?);
        Ok(())
    }

    /// Starts a new relaxation with a frozen, locally analyzed symmetry group.
    /// Kept separate from `start_relax` to preserve old project behavior.
    pub fn start_relax_with_symmetry(
        &mut self,
        structure_json: &str,
        settings_json: &str,
        symmetry_json: &str,
    ) -> Result<(), JsValue> {
        let structure: Structure = serde_json::from_str(structure_json).map_err(js_error)?;
        let settings: RelaxSettings = serde_json::from_str(settings_json).map_err(js_error)?;
        let symmetry: SymmetryOperations = serde_json::from_str(symmetry_json).map_err(js_error)?;
        self.session = Some(
            RelaxSession::new(structure, settings)
                .and_then(|session| session.with_symmetry(symmetry, 1.0e-4))
                .map_err(js_error)?,
        );
        Ok(())
    }

    /// One complete NEP evaluation and one shared Relax update per call.
    pub fn advance_relax(&mut self) -> Result<String, JsValue> {
        let session = self
            .session
            .as_mut()
            .ok_or_else(|| JsValue::from_str("relax has not been started"))?;
        let snapshot = session.advance(&mut self.model).map_err(js_error)?;
        serde_json::to_string(&snapshot).map_err(js_error)
    }

    pub fn relax_status(&self) -> String {
        self.session
            .as_ref()
            .map(|session| format!("{:?}", session.status()).to_lowercase())
            .unwrap_or_else(|| "idle".into())
    }
}

fn js_error(error: impl std::fmt::Display) -> JsValue {
    JsValue::from_str(&error.to_string())
}
