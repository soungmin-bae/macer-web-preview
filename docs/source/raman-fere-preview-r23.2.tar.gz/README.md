# RamanDB FERE preview r23.2 source overlay

This archive contains the fitted Raman coefficient bundle, browser response kernel/worker/runtime/UI, saved Si Gamma phonon example, RamanDB attribution, and Pages integration patches. It is a source overlay for the existing macer-web-preview repository, not a standalone application.

The original integration patch, `patches/r23.1-pages-integration.patch`, applies to base commit `a7c297b2bea8e0d84b2f32cf6d83d849c2834956`. The small r23.2 persistence fix is `patches/r23.2-project-persistence.patch`; apply it on top of the r23.1 deployment base `d0bc17994d1d448d2a9f9a284b3523df72b6ecc9`. The `web/` and `third_party/` trees contain the resulting overlay.

The r23.2 patch fixes FERE response inclusion in project exports, lazy response runtime initialization during project import, and numerical runtime identity checks. It does not change fitted coefficients, phonon force calculations, or the response kernel. The archive includes fitted coefficients but not the RamanDB archive or raw response labels.

The saved Si example is a real previously calculated NEP Gamma phonon result; it does not contain source Raman labels. See `third_party/licenses/ramandb/NOTICE.md` for attribution and license.
